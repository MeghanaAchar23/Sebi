using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
//using System.Net.Configuration;
namespace AutomationCore
{
	public class Utils
	{
		public static string GetValueFromConfig(string key)
		{
			//TODO: retrun configuration value
			return "";
			//return ConfigurationManager.AppSettings[key] ?? "";
		}

		//public static string GetValueFromConfig(Configuration config, string key)
		//{
		//    return config.AppSettings.Settings[key].Value ?? "";
		//}

		//public static bool SetAllowUnsafeHeaderParsing()
		//{
		//    /*Configuration oConfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
		//    NetSectionGroup netSettings = (System.Net.Configuration.NetSectionGroup)oConfig.GetSectionGroup("system.net");
		//    netSettings.Settings.HttpWebRequest.UseUnsafeHeaderParsing = true;
		//    oConfig.Save(ConfigurationSaveMode.Modified);*/

		//    Assembly aNetAssembly = Assembly.GetAssembly(typeof(System.Net.Configuration.SettingsSection));
		//    if (aNetAssembly != null)
		//    {
		//        Type aSettingsType = aNetAssembly.GetType("System.Net.Configuration.SettingsSectionInternal");
		//        if (aSettingsType != null)
		//        {
		//            object anInstance = aSettingsType.InvokeMember("Section", BindingFlags.Static | BindingFlags.GetProperty | BindingFlags.NonPublic, null, null, new object[] { });
		//            if (anInstance != null)
		//            {
		//                FieldInfo aUseUnsafeHeaderParsing = aSettingsType.GetField("useUnsafeHeaderParsing", BindingFlags.NonPublic | BindingFlags.Instance);
		//                if (aUseUnsafeHeaderParsing != null)
		//                {
		//                    aUseUnsafeHeaderParsing.SetValue(anInstance, true);
		//                    return true;
		//                }
		//            }
		//        }
		//    }
		//    return false;

		//}

		public static string GetMD5Hash(string input)
		{
			if (input == null)
				return "";
			System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
			byte[] bs = System.Text.Encoding.UTF8.GetBytes(input);
			bs = x.ComputeHash(bs);
			System.Text.StringBuilder s = new System.Text.StringBuilder();
			foreach (byte b in bs)
			{
				s.Append(b.ToString("x2").ToLower());
			}
			return s.ToString();
		}

		public static string GetSingleValue(JObject ele, string selectToken, bool trim = false)
		{
			try
			{
				var obj = ele.SelectToken(selectToken);
				string sValue = "";
				if (obj != null && obj.HasValues)
				{
					if (obj.Type == JTokenType.Object && ((JProperty)obj.First).Name == "#cdata-section")
						sValue = (string)obj["#cdata-section"] ?? "";
				}
				else
					sValue = obj == null ? "" : obj.Value<string>() ?? "";
				if (trim)
					sValue = sValue.Trim();
				return sValue;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return "";
		}

		public static string GetValue(JObject ele, string key)
		{
			try
			{
				string sValue = "";
				if (ele[key] != null)
				{
					if (ele[key].HasValues)
					{
						if (ele[key] is JValue)
							sValue = (string)ele[key] ?? "";
						else if (((JProperty)ele[key].First).Name == "#cdata-section")
							sValue = (string)ele[key]["#cdata-section"] ?? "";
					}
					else
						sValue = (string)ele[key] ?? "";
				}
				return sValue;
				//return (string)ele[key] ?? "";
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return "";
		}

		public static string GetValueOrDefault(JObject jObject, string key, string defaultValue = null)
		{
			var result = GetValue(jObject, key);

			if (string.IsNullOrEmpty(result) && defaultValue != null)
			{
				return defaultValue;
			}

			return result;
		}

		public static List<string> GetValues(JObject ele, string selectToken, bool trim = false)
		{
			List<string> values = new List<string>();

			try
			{
				//values = ele.SelectToken(selectToken).Cast<string>().Select(s => trim ? s.Trim() : s).ToList();
				var tokens = ele.SelectToken(selectToken);
				if (tokens == null)
					return values;

				if (!tokens.HasValues)
					values.Add(trim ? ((string)tokens).Trim() : (string)tokens);
				else
				{
					if (tokens.Type == JTokenType.Array)
					{
						foreach (var t in tokens)
						{
							if (t is JValue)
								values.Add(trim ? ((string)t).Trim() : (string)t);
							else if (((JProperty)t.First).Name == "#cdata-section")
							{
								var s = (string)t["#cdata-section"] ?? "";
								values.Add(trim ? s.Trim() : s);
							}
						}
					}
					else if (((JProperty)tokens.First).Name == "#cdata-section")
					{
						var s = (string)tokens["#cdata-section"] ?? "";
						values.Add(trim ? s.Trim() : s);
					}
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return values;
		}

		public static string ConvertToFullWidth(string inputString)
		{
			inputString = inputString.Replace(" ", "　");
			return System.Web.HttpUtility.HtmlDecode(inputString.Aggregate("", (current, c) => current + ((c > 32 && c < 127) ? ("&#xff" + ((byte)(c - 32)).ToString("X2") + ";") : c + "")));
		}        

        #nullable enable
        public static string? JoinCharSeparatedStrings(string? first, string? second, char separator = ' ')
        {
            string? trimmedFirst = first?.Trim(separator);
            string? trimmedSecond = second?.Trim(separator);

            if (string.IsNullOrEmpty(trimmedFirst))
                return trimmedSecond;

            if (string.IsNullOrEmpty(trimmedSecond))
                return trimmedFirst;

            return $"{trimmedFirst}{separator}{trimmedSecond}";
        }
    }

	public static class JsonExtension
	{
		public static string ToJson(this object value)
		{
			var settings = new JsonSerializerSettings
			{
				ReferenceLoopHandling = ReferenceLoopHandling.Ignore
			};

			return JsonConvert.SerializeObject(value, Formatting.None, settings);
		}
	}

}
