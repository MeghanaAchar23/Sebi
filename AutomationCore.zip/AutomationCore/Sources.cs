using System;
using System.Collections.Generic;
using System.Linq;

namespace AutomationCore
{
	public class Sources
	{
		public SourceStore Store
		{
			get;
			set;
		}

		/// <summary>
		/// Holds array of Source objects with their IDs
		/// </summary>
		private Dictionary<string, Source> m_oSources = new Dictionary<string, Source>();
		/// <summary>
		/// new Object()
		/// </summary>
		private Object m_oSyncLock = new object();

		/// <summary>
		/// Returns back the source mapped to given m_sID
		/// </summary>
		/// <remarks>Operation has to be performed in lock.</remarks>
		public Source GetSource(string sSourceID)
		{
			Source oSource = null;
			lock (m_oSyncLock)
			{
				m_oSources.TryGetValue(sSourceID, out oSource);
			}
			return oSource;
		}

		/// <summary>
		/// Returns an array of all sources
		/// </summary>
		/// <remarks>Operation has to be performed in lock.</remarks>
		public List<Source> GetAllSources()
		{
			List<Source> t_olAllSources;
			lock (m_oSyncLock)
			{
				t_olAllSources = m_oSources.Values.ToList();
			}
			return t_olAllSources;
		}

		/// <summary>
		/// Add sources into m_oSources
		/// </summary>
		/// <remarks>Operation has to be performed in lock.</remarks>
		/// <returns>True if source is added successfully else false.</returns>
		public bool AddSource(string sSourceID, ref Source oSource)
		{
			bool t_bRet = false;

			//synchronize code so that only one thread can add source at a time.
			lock (m_oSyncLock)
			{
				try
				{
					oSource.ID = sSourceID;
					m_oSources.Add(sSourceID, oSource);
					oSource.Store = this.Store;
                    
                    IEnumerable<string> intersect = oSource.Store.SourceGroupTags.Intersect(oSource.GroupTags);
                    AutomationClient.ReutersLog($"Source added, id: {oSource.ID}, is active: {oSource.IsSourceActive}, group tags [{string.Join(",", oSource.GroupTags)}] in source group(s) [{string.Join(",", intersect)}], path: {oSource.GetResource()}", NLog.LogLevel.Info);
                }
				catch (Exception ex)
				{
					AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				}
			}
			return t_bRet;
		}

		/// <summary>
		/// Returns an array of active source IDs
		/// </summary>
		/// <remarks>Operation to be performed in lock</remarks>
		public List<Source> GetAllActiveSources()
		{
			List<Source> oActiveSources;
			lock (m_oSyncLock)
			{
				oActiveSources = m_oSources.Where(source => source.Value.IsSourceActive).Select(source => source.Value).ToList();
			}
			return oActiveSources;
		}
	}
}
