
namespace AutomationCore
{
	public static class Constants
	{
		public static class EnvironmentVariables
		{
			public const string LUMINATI_CONFIG = "luminati-config";
			public const string SELENIUM_HEADLESS_DISABLED = "SELENIUM_HEADLESS_DISABLED";
		}
	}
}
