using System;
using System.Collections.Generic;
using AutomationCore.Handbrake;

namespace AutomationCore
{
	public static class PublicationMessageTypeExtension
	{
		public static bool IsAlert(this PublicationMessageType oMessageType)
		{
			return (PublicationMessageType.Alert & oMessageType) == PublicationMessageType.Alert;
		}
		public static bool IsStory(this PublicationMessageType oMessageType)
		{
			return (PublicationMessageType.Story & oMessageType) == PublicationMessageType.Story;
		}
		public static bool IsEcon(this PublicationMessageType oMessageType)
		{
			return (PublicationMessageType.ECON & oMessageType) == PublicationMessageType.ECON;
		}
		public static bool IsHandbrake(this PublicationMessageType oMessageType)
		{
			return (PublicationMessageType.Handbrake & oMessageType) == PublicationMessageType.Handbrake;
		}
	}
	[Flags]
	public enum PublicationMessageType
	{
		Default = 0,
		ECON = 1,
		Alert = 2,
		Story = 4,
		Handbrake = 8
	}
	public abstract class PublicationMessage
	{
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sID;
		/// <summary>
		/// default 0 (1=ECON, 2=Alert, 3=Story)
		/// </summary>
		private PublicationMessageType m_oMessageType;

		/// <summary>
		/// destination to published messages
		/// default is null
		/// possible values - ucdp and (or) feedservice
		/// </summary>
		public List<string> Destinations { get; set; }

		/// <summary>
		/// default 110
		/// </summary>
		/// <remarks>
		/// 120 if m_sMessageType is ECON
		/// 110 if m_sMessageType is Alert
		/// 100 if m_sMessageType is Story
		/// </remarks>
		public string QPriority
		{
			get;
			private set;
		}

		public string ID
		{
			get
			{
				return m_sID;
			}
		}

		public Dictionary<string, Handbrake.HandbrakeMessage> HandbrakeMessages
		{
			get;
			set;
		}

		/// <summary>
		/// default null
		/// </summary>
		public string AutomationName
		{
			get;
			set;
		}
		/// <summary>
		/// default null
		/// </summary>
		public PublicationAgent PublicationAgent
		{
			get;
			set;
		}

		/// <summary>
		/// default false
		/// </summary>
		public virtual bool IsSent
		{
			get;
			set;
		}

		/// <summary>
		/// default false
		/// </summary>
		public bool IsActive
		{
			get;
			set;
		}

		public bool IsHandbrake
		{
			get;
			set;
		}

		public bool IsAutomatic
		{
			get;
			set;
		}

        public bool IsLLM
        {
            get;
            set;
        }

        public TimeSpan? EmbargoTime { get; set; }

		public SourceStore Store
		{
			get;
			set;
		}

		public PublicationMessage()
		{
		}

		/// <param name="sMessageType">
		/// possible values - econ/alert/story
		/// if econ then set m_sQPriority to 120
		/// if alert then set m_sQPriority to 110
		/// if story then set m_sQPriority to 100
		/// </param>
		public PublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sQPriority)
		{
			m_oMessageType = oMessageType;
			PublicationAgent = oPublicationAgent;
			AutomationName = sAutomationName;
			m_sID = sID;

			if (!string.IsNullOrWhiteSpace(sQPriority))
				QPriority = sQPriority;
			else
			{
				if (oMessageType.IsAlert())
					QPriority = "110";
				else if (oMessageType.IsStory() || oMessageType.IsHandbrake())
					QPriority = "100";
				else if (oMessageType.IsEcon())
					QPriority = "120";
			}
			if (oMessageType.IsHandbrake())
			{
				IsHandbrake = true;
				IsAutomatic = false;
			}
			else
			{
				IsHandbrake = false;
				IsAutomatic = true;
			}
		}

		public PublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID)
		{
			m_oMessageType = oMessageType;
			PublicationAgent = oPublicationAgent;
			AutomationName = sAutomationName;
			m_sID = sID;

			//TODO: set default QPriority based on oMessageType
			if (oMessageType.IsAlert())
				QPriority = "110";
			else if (oMessageType.IsStory() || oMessageType.IsHandbrake())
				QPriority = "100";
			else if (oMessageType.IsEcon())
				QPriority = "120";

			if (oMessageType.IsHandbrake())
			{
				IsHandbrake = true;
				IsAutomatic = false;
			}
			else
			{
				IsHandbrake = false;
				IsAutomatic = true;
			}
		}

		public bool AddHandbrakeMessage(HandbrakeMessage oHandbrakeMessage)
		{
			try
			{
				if (this.HandbrakeMessages != null)
				{
					if (this.HandbrakeMessages.ContainsKey(oHandbrakeMessage.ID))
						this.HandbrakeMessages.Remove(oHandbrakeMessage.ID);
					this.HandbrakeMessages.Add(oHandbrakeMessage.ID, oHandbrakeMessage);
					if (oHandbrakeMessage.GroupMessages == null)
						oHandbrakeMessage.GroupMessages = new System.Collections.Concurrent.ConcurrentQueue<string>();
					oHandbrakeMessage.GroupMessages.Enqueue(this.ID);
					return true;
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return false;
		}
	}
}
