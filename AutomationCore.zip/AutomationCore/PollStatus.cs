using EAP.Core.Models.SourceContents;

namespace AutomationCore
{
	/// <summary>
	/// Stores the status of the poll to the source.
	/// </summary>
	public class PollStatus
	{
        public virtual void LogAuditPublication() { }
        public virtual void LogAudit() { }
        public virtual void LogAuditError() { }

        /// <summary>
        /// Has a change been detected on this poll ?
        /// </summary>
        public virtual bool ChangeDetected { get; set; } = false;
		
		public SourceContent? SourceContent { get; set; } = null;


        /// <summary>
		/// Gets or sets the Source object for which the poll is being made.
		/// </summary>
		public Source BaseSource
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets an object of PollAttempt class to store the information of the current poll in progress.
		/// </summary>
		public PollAttempt PollAttempt
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets an object of ChunkAttempt to store the information of the current chunk in progress.
		/// </summary>
		public ChunkAttempt ChunkAttempt
		{
			get;
			set;
		}

		/// <summary>
		/// Creates a new ChunkAttempt object with specified ChunkId and assigns to the `ChunkAttempt` proprty.
		/// </summary>
		/// <param name="ChunkID"></param>
		public void SetNewChunkAttempt(string ChunkID)
		{
			ChunkAttempt = PollAttempt.NewChunkAttempt(ChunkID);
		}
	}
}
