using EAP.FileConversion.Service.Client;
using LazyCache;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationCore
{
	/// <summary>
	///  Convert Document(.doc abd .docx to text using Web service.
	/// </summary>
	public class DocumentToText
	{
		private readonly Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory;

		/// <summary>
		/// Retry count to call each web service: Default value is 5.
		/// </summary>
		public int RetryCount { get; set; } = 5;
		/// <summary>
		/// Timed out in seconds to call web service, default value is 30 seconds.
		/// </summary>
		public int TimedOutInSeconds { get; set; } = 30;

		/// <summary>
		/// Creates an instance of DocumentToText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public DocumentToText(int ttlInSeconds = 24 * 3600)
		{
			this.fileConversionServiceClientFactory = FileConversionServiceClientFactory.CreateDefaultFactory(ttlInSeconds, TimedOutInSeconds, RetryCount);
		}

		public DocumentToText(Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory)
		{
			this.fileConversionServiceClientFactory = fileConversionServiceClientFactory ?? throw new ArgumentNullException(nameof(fileConversionServiceClientFactory));
		}

		public bool GetDocumentToText(byte[] documentbuffer, string sDocumentFileExtension, out string sConvertedText, out string sErrorlog)
		{
			if (string.IsNullOrEmpty(sDocumentFileExtension))
			{
				throw new ArgumentNullException(nameof(sDocumentFileExtension));
			}

			sConvertedText = sErrorlog = "";
			try
			{
				sConvertedText = GetDocumentToText(new MemoryStream(documentbuffer))
					.GetAwaiter()
					.GetResult();

				return true;
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sErrorlog) == false)
					sErrorlog += "\r\n";
				sErrorlog += ex.ToString();
			}
			return false;
		}

		public async Task<string> GetDocumentToText(Stream documentFileStream, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("DocumentToText.GetDocumentToText started");

			var client = await fileConversionServiceClientFactory();
			string text = await client.ConvertWordAsync(documentFileStream, cancellationToken);

			AutomationClient.ForceLog("DocumentToText.GetDocumentToText finished");

			return text;
		}
	}
}
