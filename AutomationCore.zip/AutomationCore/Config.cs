using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AutomationCore.Email;
using AutomationCore.Handbrake;
using AutomationCore.Idn;
using AutomationCore.Twitter;
using AutomationCore.UcdpFeed;
using EAP.Automation.HttpClient;
using EAP.Core.Configuration;
using EAP.Core.Elektron;
using EAP.Core.Elektron.Dual;
using EAP.Core.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AutomationCore
{
	public class Config
	{
		private IElektronManager elektronManager;

		public string BaseDirectory
		{
			get;
			private set;
		}

		public string SettingConfigPath
		{
			get;
			private set;
		}

		public JObject SettingConfig
		{
			get;
			private set;
		}

		public string SourceConfigPath
		{
			get;
			private set;
		}

		public JObject SourceConfig
		{
			get;
			private set;
		}

		public string PublicationConfigPath
		{
			get;
			private set;
		}

		public JObject PublicationConfig
		{
			get;
			private set;
		}

		public string AutomationDllName
		{
			get;
			private set;
		}

		private SourceStore Store
		{
			get;
			set;
		}

		public List<PollPatternInfo> PollPatternInfoList = null;

		public Config(string sXmlConfiguration)
		{
			JObject xmlDoc = JObject.Parse(sXmlConfiguration);

			SourceConfig = xmlDoc;
			SettingConfig = xmlDoc;
			PublicationConfig = xmlDoc;

			elektronManager = ElektronManagerFactory.Create();
            elektronManager.StartAsync().Wait();
		}

		/*public AutomationConfiguration ReutersConfig { get; set; }

		public Config(EAP.Core.Configuration.AutomationConfiguration automationConfiguration)
		{        }*/

		public void LoadConfiguration(SourceStore oStore)
		{
			Store = oStore;
			SetStoreParameters();
			LoadSettings();
			LoadPublications();
		}

		public string GetAutomationName()
		{
			JObject jDoc = SourceConfig;
			string sAutomationDll = Utils.GetSingleValue(jDoc, "$.generals.spider_id").Trim();
			return sAutomationDll;
		}

		private void SetStoreParameters()
		{
			JObject jDoc = SourceConfig;

			string sLogUrl = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.log_upload_url");
			sLogUrl = sLogUrl.Trim();

			string sSmsMonitoringFile = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.sms_monitoring_file_path");
			sSmsMonitoringFile = sSmsMonitoringFile.Trim();

			string sRecommendationServiceUrl = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.recommend_setting_service_url");
			sRecommendationServiceUrl = sRecommendationServiceUrl.Trim();

			List<string> sConversionServiceUrl = Utils.GetValues(jDoc, "$.global_execution_parameters.conversion_service_url", true);
            List<string> sSourceGroupTags = Utils.GetValues(jDoc, "$.global_execution_parameters.source_group_tags", true);          


            if (Store != null)
			{
				Store.LogUploadUrl = sLogUrl;
				SourceStore.ConversionServiceUrls = sConversionServiceUrl;
				Store.SmsMonitoringFile = sSmsMonitoringFile;
				Store.RecommendationServiceUrl = sRecommendationServiceUrl;

                Store.SourceGroupTags = sSourceGroupTags;

				Store.AutomationName = GetAutomationName();
				Store.PerformanceLog.AutomationName = Store.AutomationName;

				string sHostingServerName = Utils.GetValue(jDoc, "server_name");
				Store.SetHostingServerName(sHostingServerName);

				string sPostPublicationUrl = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.post_publication_url");

				//SourceStore.PublicationPostUrl = Environment.GetEnvironmentVariable("POST_PUBLICATION_TO_EMSURE_URL") ?? "";

				if (!string.IsNullOrWhiteSpace(sPostPublicationUrl))
					SourceStore.PublicationPostUrl = sPostPublicationUrl.Trim();

				string sEmailMonitoringServiceUrl = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.email_monitoring_service_url");

				if (!string.IsNullOrWhiteSpace(sEmailMonitoringServiceUrl))
					SourceStore.EmailMonitoringServiceUrl = sEmailMonitoringServiceUrl.Trim();
			}
		}

		public void LoadUrlSource(string sourceId, URLSource oSource)
		{
			JObject sourceDocument = SourceConfig;
			var sourceElement = GetSource("url_sources", sourceId);

			oSource.ID = sourceId;
			oSource.Store = Store;
			oSource.IsSourceActive = (Utils.GetValue(sourceElement, "active")).ToLower().Trim() == "yes";
            oSource.GroupTags =Utils.GetValues(sourceElement, "group_tags", true);
            string t_csUrl = Utils.GetValue(sourceElement, "url");
			oSource.Url = t_csUrl.Trim();

			oSource.ChangeDetectionMode = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "change_detection_mode"))
                ? (ChangeDetectionMode)Enum.Parse(typeof(ChangeDetectionMode), Utils.GetValue(sourceElement, "change_detection_mode"), ignoreCase: true)
                : ChangeDetectionMode.Length;

            oSource.ChangeDetectionPath = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "change_detection_path"))
                ? Utils.GetValue(sourceElement, "change_detection_path")
                : String.Empty;

			oSource.InspectPollOnChangeDetectedOnly = Utils.GetValue(sourceElement, "inspect_poll_on_change_detected_only").ToLower().Trim() == "yes";

            oSource.AlternateUrls = sourceElement.ContainsKey("alternate_urls")
            ? JsonConvert.DeserializeObject<List<string>>(sourceElement["alternate_urls"].ToJson())
            : null;
            
            const int defaultConnectionTimeout = 30;
			oSource.ConnectionTimeout = int.TryParse(Utils.GetValue(sourceElement, "timeout_in_sec"), out var timeout) && timeout > 0
					? timeout : defaultConnectionTimeout;

			const int defaultConnectionLeaseTimeoutInMs = 300000;
			oSource.ConnectionLeaseTimeoutInMs = int.TryParse(Utils.GetValue(sourceElement, "connection_lease_timeout_in_ms"), out var ConnectionLeaseTimeoutInMs) && ConnectionLeaseTimeoutInMs > 0
					? ConnectionLeaseTimeoutInMs : defaultConnectionLeaseTimeoutInMs;

			oSource.AlignPollIntervalToWallClock =
				bool.TryParse(Utils.GetValueOrDefault(sourceElement, "align_poll_interval_to_wall_clock", "true"),
					out var alignPollIntervalToWallClock) && alignPollIntervalToWallClock;

			oSource.PollInterspersedMode =
				Enum.TryParse<AutomationConfiguration.PollInterspersedMode>(
					Utils.GetValue(sourceElement, "poll_interspersed_mode"), true, out var mode)
					? mode
					: AutomationConfiguration.PollInterspersedMode.Even;

			oSource.KeepAliveConnection = Utils.GetValue(sourceElement, "enable_keepalive").ToLower().Trim() != "no";

			oSource.CacheControlNoCache = Utils.GetValue(sourceElement, "cache_control_nocache").ToLower().Trim() != "no";
			oSource.CacheControlNoStore = Utils.GetValue(sourceElement, "cache_control_nostore").ToLower().Trim() != "no";
			oSource.ProcessCacheResponseHeaders = Utils.GetValue(sourceElement, "process_cache_response_headers").ToLower().Trim() == "yes";

            bool ReliableAutomationHttpHandlerConfigEnabled = Utils.GetValue(sourceElement, "reliable_automation_http_handler_enabled").ToLower().Trim() == "yes";
            if (ReliableAutomationHttpHandlerConfigEnabled)
            {
                int ReliableAutomationHttpHandlerConfigTimeoutDefault = 60000;
                int Timeout = int.TryParse(Utils.GetValue(sourceElement, "reliable_automation_http_handler_timeout"), out var ReliableAutomationHttpHandlerConfigTimeout) && ReliableAutomationHttpHandlerConfigTimeout > 0
                    ? ReliableAutomationHttpHandlerConfigTimeout : ReliableAutomationHttpHandlerConfigTimeoutDefault;

                oSource.ReliableAutomationHttpHandlerConfig = new ReliableAutomationHttpHandlerConfig() { Enabled = true, MaxWaitTimeInMs = Timeout };
            }

			var sMaxPolls = (string)(sourceElement?["max_poll_at_time"]) ?? "1";
			if (int.TryParse(sMaxPolls, out var iMaxPolls))
				oSource.MaxPollAtTime = iMaxPolls;

			// reduce MaxPollAtTime to 1 when cache response analysis is enabled
			// this should prevent rewriting shared between polls history value
			if (oSource.ProcessCacheResponseHeaders && oSource.MaxPollAtTime > 1)
			{
				AutomationClient.ForceLog($"Cache response analysis enabled forcing maximum concurrent polls to 1, was {oSource.MaxPollAtTime}", NLog.LogLevel.Warn);
				oSource.MaxPollAtTime = 1;
			}

			int iLimitPolls = 0;
			int.TryParse(sourceElement["limit_poll_count"] == null ? "0" : (string)sourceElement["limit_poll_count"] ?? "0", out iLimitPolls);
			if (iLimitPolls > 0)
				oSource.LimitPollCount = iLimitPolls;

			oSource.ChunkProcessing = (Utils.GetValue(sourceElement, "chunk_processing")).ToLower().Trim() == "yes";
			oSource.Cookie = (Utils.GetValue(sourceElement, "enable_cookie")).ToLower().Trim() != "no";
			oSource.UrlRedirectionHandling = (Utils.GetValue(sourceElement, "handle_url_redirection")).ToLower().Trim() != "no";
			oSource.GzipCompression = (Utils.GetValue(sourceElement, "enable_gzip_compression")).ToLower().Trim() != "no";
			oSource.Encoding = sourceElement["encoding"] == null ? Encoding.UTF8 : Encoding.GetEncoding((string)sourceElement["encoding"] ?? "utf-8");
			oSource.AppendUniqueTimestampInUrl = Utils.GetValue(sourceElement, "append_unique_timestamp_in_url");
			oSource.AppendSessionIDInUrl = !string.IsNullOrWhiteSpace(oSource.AppendUniqueTimestampInUrl);
			oSource.AutoLinkExtraction = (Utils.GetValue(sourceElement, "auto_link_extraction")).ToLower().Trim() == "yes";
            oSource.UseHistoryPolling = bool.TryParse(Utils.GetValue(sourceElement, "use_history_polling").ToLower(), out var useHistoryPolling) == false ? true : useHistoryPolling;

            //CRN > 26-Jun-13 : reading full log flag
            oSource.IsContentToBeLoggedInEachPoll = (Utils.GetValue(sourceElement, "enable_full_content_log")).ToLower().Trim() == "yes";
			oSource.PostData = Utils.GetValue(sourceElement, "post_data");

			//CRN > 03-Sep-13 : load byte range
			Int64 iByteStartRange;
			Int64.TryParse(sourceElement["start_byte_range"] == null ? "0" : (string)sourceElement["start_byte_range"] ?? "0", out iByteStartRange);
			if (iByteStartRange > 0)
				oSource.StartByteRange = iByteStartRange;

			Int64 iByteEndRange;
			Int64.TryParse(sourceElement["end_byte_range"] == null ? "0" : (string)sourceElement["end_byte_range"] ?? "0", out iByteEndRange);
			if (iByteEndRange > 0)
				oSource.EndByteRange = iByteEndRange;

			oSource.AlternateEncodingProcessing = (Utils.GetValue(sourceElement, "enable_alternate_encoding")).ToLower().Trim() == "yes";

			oSource.RequestContentType = Utils.GetValue(sourceElement, "content_type");
			oSource.UrlReferer = Utils.GetValue(sourceElement, "url_referrer");
			oSource.PollType = Utils.GetValue(sourceElement, "poll_type");

            string webDriverType = Utils.GetValue(sourceElement, "webdriver_type");
            oSource.WebDriverType = string.IsNullOrEmpty(webDriverType)
                ? WebDriverType.FireFox
                : (WebDriverType)Enum.Parse(typeof(WebDriverType), webDriverType, true);

            string pagePostLoadWaitInMs = Utils.GetValue(sourceElement, "selenium_page_postload_wait_in_ms");
            oSource.SeleniumPagePostLoadWaitInMs = string.IsNullOrEmpty(pagePostLoadWaitInMs)
                ? null
                : int.Parse(pagePostLoadWaitInMs);

            string httpVersion = Utils.GetValue(sourceElement, "http_version");
            oSource.HttpVersion = string.IsNullOrEmpty(httpVersion)
                ? null
                : new Version(int.Parse(httpVersion.Split('.')[0]), int.Parse(httpVersion.Split('.')[1]));
            oSource.WebDriverFileDownload = Utils.GetValue(sourceElement, "web_driver_file_download").ToLower().Trim() == "yes";

            if (oSource.PollType?.ToLower() == "selenium")
			{
				try
				{                    
					oSource.PollManager = new SeleniumPollManager(oSource,
                        oSource.WebDriverType.Value);
				}
				catch (Exception selex) { AutomationClient.ForceLog?.Invoke(selex.ToString()); }
			}

            oSource.CertificateName = Utils.GetValue(sourceElement, "certificate_name");
			oSource.CertificatePassword = Utils.GetValue(sourceElement, "certificate_password");

			const int defaultIntervalMs = 1000;
			oSource.DefaultPollIntervalInMS =
				int.TryParse(Utils.GetValueOrDefault(sourceElement, "default_interval_in_ms"), out var configValue) && configValue > 0
					? configValue : defaultIntervalMs;
			oSource.CurrentPollIntervalInMS = oSource.DefaultPollIntervalInMS;

			string sRandomPollIntervalRange = Utils.GetValue(sourceElement, "poll_interval_range");
			if (!string.IsNullOrWhiteSpace(sRandomPollIntervalRange))
			{
				Match mt = Regex.Match(sRandomPollIntervalRange, @"^(\d+)\s*-\s*(\d+)$");
				if (mt.Success)
				{
					int iStartInterval = 0;
					int.TryParse(mt.Groups[1].Value, out iStartInterval);
					int iEndInterval = 0;
					int.TryParse(mt.Groups[2].Value, out iEndInterval);
					if (iStartInterval != 0 && iEndInterval != 0 && iEndInterval > iStartInterval)
					{
						oSource.RandomIntervalRangeStart = iStartInterval;
						oSource.RandomIntervalRangeEnd = iEndInterval;
						oSource.CurrentPollIntervalInMS = new Random().Next(iStartInterval, iEndInterval);
					}
				}
			}

			//var publicationsElement = sourceElement.Element("publications");
			//if (publicationsElement != null)
			{
				var messages = Utils.GetValues(sourceElement, "$.publication_message_id");
				if (messages != null)
				{
					foreach (var message in messages)
					{
						string sMessageId = message ?? "";
						if (!string.IsNullOrWhiteSpace(sMessageId))
						{
							PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
							if (oPublicationMessage != null)
							{
								oSource.PublicationMessages.AddPublicationMessage(oPublicationMessage);
							}
							else
							{
								//throw new Exception("PublicationMesssage with Id " + sMessageId + " does not exist");
								//Store.AutomationClient.OperatorLog("PublicationMesssage " + sMessageId + " doesn't exist");
								Store.PerformanceLog.LogComment("PublicationMesssage " + sMessageId + " doesn't exist");
							}
						}
					}
				}
			}

			//oSource.PollManager = new URLPollManager(oSource);
			//oSource.PollSchedule = LoadPollSchedule(sourceElement);
			if (PollPatternInfoList != null)
				oSource.PollSchedule = PollPatternInfoList.FirstOrDefault(p => p.ServerName.Equals(Environment.MachineName, StringComparison.OrdinalIgnoreCase) && p.SourceId.Equals(sourceId, StringComparison.OrdinalIgnoreCase));

			if (oSource.IsSourceActive)
			{
				oSource.AuditEvent = new HttpInputEvent { Url = oSource.Url, PollId = oSource.ID };
				oSource.AuditEvent.PollingFrequencyMs.Set(oSource.CurrentPollIntervalInMS);
			}
		}

        public void LoadOmniScanSource(string sourceId, OmniScanSource oSource)
        {            
            var sourceElement = GetSource("omniscan_sources", sourceId);
            JObject jDoc = SourceConfig;

            oSource.ID = sourceId;
            oSource.Store = Store;
            oSource.IsSourceActive = (Utils.GetValue(sourceElement, "active")).ToLower().Trim() == "yes";
            oSource.GroupTags = Utils.GetValues(sourceElement, "group_tags", true);
            oSource.PollType = Utils.GetValue(sourceElement, "poll_type");

            const int defaultIntervalMs = 1000;
            oSource.DefaultPollIntervalInMS =
                int.TryParse(Utils.GetValueOrDefault(sourceElement, "default_interval_in_ms"), out var configValue) && configValue > 0
                    ? configValue : defaultIntervalMs;
            oSource.CurrentPollIntervalInMS = oSource.DefaultPollIntervalInMS;

            oSource.HttpMethod = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "http_method"))
                ? HttpMethod.Parse(Utils.GetValue(sourceElement, "http_method"))
                : HttpMethod.Get;

            oSource.UseSeleniumChrome = bool.TryParse(Utils.GetValue(sourceElement, "use_selenium_chrome"), out bool useSeleniumChrome) == false
               ? false
               : useSeleniumChrome;

            oSource.ProcessCacheHeaders = bool.TryParse(Utils.GetValue(sourceElement, "process_cache_headers"), out bool processCacheHeaders) == false
                ? true
                : processCacheHeaders;

            oSource.AllowRedirection = bool.TryParse(Utils.GetValue(sourceElement, "allow_redirection"), out bool allowRedirection) == false
                ? true
                : allowRedirection;

            const int defaultConnectionTimeout = 30;
            oSource.ConnectionTimeout = int.TryParse(Utils.GetValue(sourceElement, "connection_timeout_in_sec"), out var connectionTimeout) && connectionTimeout > 0
                    ? connectionTimeout : defaultConnectionTimeout;

            const int defaultRequestTimeout = 60;
            oSource.RequestTimeout = int.TryParse(Utils.GetValue(sourceElement, "request_timeout_in_sec"), out var requestTimeout) && requestTimeout > 0
                    ? requestTimeout : defaultRequestTimeout;

            const int defaultOmniScanMaxDegreeOfParallelism = -1;            
            oSource.OmniScanMaxDegreeOfParallelism = int.TryParse(Utils.GetSingleValue(jDoc, "$.global_execution_parameters.omni_scan.max_degree_of_parallelism"), out var omniScanMaxDegreeOfParallelism)
                ? omniScanMaxDegreeOfParallelism : defaultOmniScanMaxDegreeOfParallelism;

            oSource.Url = Utils.GetValue(sourceElement, "url").Trim();

            oSource.Form = sourceElement.ContainsKey("form")
                ? JsonConvert.DeserializeObject<Dictionary<string, string>>(sourceElement["form"].ToJson())
                : null;

            oSource.Body = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "body"))
                ? Utils.GetValue(sourceElement, "body")
                : null; ;

            oSource.ProxyCountries = sourceElement.ContainsKey("proxy_countries")
               ? JsonConvert.DeserializeObject<ProxyCountry[]>(sourceElement["proxy_countries"].ToJson())
               : null;

            oSource.WaitForElement = sourceElement.ContainsKey("wait_for_element")
                ? JsonConvert.DeserializeObject<WaitForElement>(sourceElement["wait_for_element"].ToJson())
                : null;

            oSource.DirectPolls = sourceElement.ContainsKey("direct_poll_regions")
                ? JsonConvert.DeserializeObject<DirectPoll[]>(sourceElement["direct_poll_regions"].ToJson())
                : null;

            oSource.ChangeDetectionMode = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "change_detection_mode"))
                ? (ChangeDetectionMode)Enum.Parse(typeof(ChangeDetectionMode), Utils.GetValue(sourceElement, "change_detection_mode"), ignoreCase: true)
                : ChangeDetectionMode.Content;

            oSource.ChangeDetectionPath = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "change_detection_path"))
                ? Utils.GetValue(sourceElement, "change_detection_path")
                : null;

            oSource.UseHistoryPolling = bool.TryParse(Utils.GetValue(sourceElement, "use_history_polling").ToLower(), out var useHistoryPolling) == false
                ? true
                : useHistoryPolling;

            oSource.RequestHeaders = sourceElement.ContainsKey("headers")
                ? JsonConvert.DeserializeObject<Dictionary<string, string>>(sourceElement["headers"].ToJson())
                : null;

            oSource.AlternateUrls = sourceElement.ContainsKey("alternate_urls")
                ? JsonConvert.DeserializeObject<List<string>>(sourceElement["alternate_urls"].ToJson())
                : null;

            oSource.SwitchUrlOnStatus = sourceElement.ContainsKey("switch_url_on_status")
                ? JsonConvert.DeserializeObject<List<int>>(sourceElement["switch_url_on_status"].ToJson())
                : null;

            oSource.SwitchProxyOnStatus = sourceElement.ContainsKey("switch_proxy_on_status")
                ? JsonConvert.DeserializeObject<List<int>>(sourceElement["switch_proxy_on_status"].ToJson())
                : null;

            oSource.AutomaticDecompression = !string.IsNullOrEmpty(Utils.GetValue(sourceElement, "auto_decompression"))
                ? (AutomaticDecompression)Enum.Parse(typeof(AutomaticDecompression), Utils.GetValue(sourceElement, "auto_decompression"), ignoreCase: true)
                : AutomaticDecompression.On;

            oSource.AutoLinkExtraction = bool.TryParse(Utils.GetValue(sourceElement, "auto_link_extraction"), out bool autoLinkExtraction) == false
                ? true
                : autoLinkExtraction;

            oSource.Encoding = sourceElement["encoding"] == null ? Encoding.UTF8 : Encoding.GetEncoding((string)sourceElement["encoding"] ?? "utf-8");

            var messages = Utils.GetValues(sourceElement, "$.publication_message_id");
            if (messages != null)
            {
                foreach (var message in messages)
                {
                    string sMessageId = message ?? "";
                    if (!string.IsNullOrWhiteSpace(sMessageId))
                    {
                        PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
                        if (oPublicationMessage != null)
                        {
                            oSource.PublicationMessages.AddPublicationMessage(oPublicationMessage);
                        }
                        else
                        {
                            //throw new Exception("PublicationMesssage with Id " + sMessageId + " does not exist");
                            //Store.AutomationClient.OperatorLog("PublicationMesssage " + sMessageId + " doesn't exist");
                            Store.PerformanceLog.LogComment("PublicationMesssage " + sMessageId + " doesn't exist");
                        }
                    }
                }
            }

            oSource.AsURLSource = new OmniScanAsTrimmedUrlSource(oSource);
        }

        public void LoadFolderSource(string sourceId, FolderSource oSource)
		{
			var sourceElement = GetSource("folder_sources", sourceId);

			if (sourceElement == null)
				throw new Exception("Element with Id " + sourceId + " not found");

			oSource.ID = sourceId;
			oSource.Store = Store;
			oSource.IsSourceActive = (Utils.GetValue(sourceElement, "active")).ToLower().Trim() == "yes";
            oSource.GroupTags = Utils.GetValues(sourceElement, "group_tags", true);

            oSource.Path = Utils.GetValue(sourceElement, "path");// sourceElement.Element("path").Value ?? "";

			oSource.Filter = sourceElement["filter"] == null ? "*.*" : (string)sourceElement["filter"] ?? "*.*";

			int iMaxPolls = 10;
			int.TryParse(sourceElement["max_poll_at_time"] == null ? "0" : (string)sourceElement["max_poll_at_time"] ?? "0", out iMaxPolls);
			if (iMaxPolls > 0)
				oSource.MaxPollAtTime = iMaxPolls;

			int iLimitPolls = 0;
			int.TryParse(sourceElement["limit_poll_count"] == null ? "0" : (string)sourceElement["limit_poll_count"] ?? "0", out iLimitPolls);
			if (iLimitPolls > 0)
				oSource.LimitPollCount = iLimitPolls;

			oSource.PollType = Utils.GetValue(sourceElement, "poll_type"); //sourceElement.Element("poll_type") == null ? "" : sourceElement.Element("poll_type").Value ?? "";            
            //var oPollIntervalElement = sourceElement.Element("poll_interval");

            //if (oPollIntervalElement != null)
            {
				int iDefaultInterval = 1000;
				int.TryParse((string)sourceElement["default_interval_in_ms"] ?? "", out iDefaultInterval);
				if (iDefaultInterval > 0)
				{
					oSource.DefaultPollIntervalInMS = iDefaultInterval;
					oSource.CurrentPollIntervalInMS = iDefaultInterval;
				}
			}

			//var publicationsElement = sourceElement.Element("publications");
			//if (publicationsElement != null)
			{
				var messages = Utils.GetValues(sourceElement, "$.publication_message_id");
				if (messages != null)
				{
					foreach (var message in messages)
					{
						string sMessageId = message ?? "";
						if (!string.IsNullOrWhiteSpace(sMessageId))
						{
							PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
							if (oPublicationMessage == null)
								throw new Exception("PublicationMesssage with Id " + sMessageId + " does not exist");
							oSource.PublicationMessages.AddPublicationMessage(oPublicationMessage);
						}
					}
				}
			}

			//JSON based email polling
			//oSource.InitEmailSource();
		}

		public void LoadTwitterSource(string sourceId, TwitterSource oSource)
		{
			var sourceElement = GetSource("twitter_sources", sourceId);

			oSource.ID = sourceId;
			oSource.Store = Store;
			oSource.IsSourceActive = (Utils.GetValue(sourceElement, "active")).ToLower().Trim() == "yes";
            oSource.GroupTags = Utils.GetValues(sourceElement, "group_tags", true);
            oSource.ConsumerKey = Utils.GetValue(sourceElement, "consumer_key");
			oSource.ConsumerSecret = Utils.GetValue(sourceElement, "consumer_secret");
			oSource.AccessToken = Utils.GetValue(sourceElement, "access_token");
			oSource.AccessSecret = Utils.GetValue(sourceElement, "access_secret");
			oSource.Keywords = Utils.GetValues(sourceElement, "$.keyword")?.Where(k => !string.IsNullOrWhiteSpace(k)).ToList();
			oSource.Users = Utils.GetValues(sourceElement, "$.user")?.Where(u => !string.IsNullOrWhiteSpace(u)).ToList();

			var messages = Utils.GetValues(sourceElement, "$.publication_message_id");
			if (messages != null)
			{
				foreach (var message in messages)
				{
					string sMessageId = message ?? "";
					if (!string.IsNullOrWhiteSpace(sMessageId))
					{
						PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
						if (oPublicationMessage == null)
							throw new Exception("PublicationMesssage with Id " + sMessageId + " does not exist");
						oSource.PublicationMessages.AddPublicationMessage(oPublicationMessage);
					}
				}
			}

			oSource.Initialize();
		}

		private static class UcdpConfigField
		{
			public const string ACTIVE = "active";
			public const string TOPIC_NAMES = "topic_names";
			public const string MIME_TYPE = "mime_type";
		}

		public void LoadUcdpSource(string sourceId,
			UcdpBasedSource source,
			string sourceConfigName,
			string sourceLogName)
		{
			var sourceDocument = SourceConfig;

			var sourceElement = (JObject)sourceDocument[sourceConfigName].FirstOrDefault()
				?? throw new Exception($"{sourceConfigName} weren't found in the workflow config");

			source.ID = sourceId;
			source.Store = Store;
			source.IsSourceActive = GetValue(UcdpConfigField.ACTIVE).ToLower().Trim() == "yes";
            source.GroupTags = Utils.GetValues(sourceElement, "group_tags", true);
            source.TopicNames = GetValues(UcdpConfigField.TOPIC_NAMES).ToArray();
			source.MimeType = GetValue(UcdpConfigField.MIME_TYPE);

			var messageIds = Utils.GetValues(sourceElement, "$.publication_message_id");

			messageIds.ForEach(messageId =>
			{
				if (!string.IsNullOrEmpty(messageId))
				{
					var publicationMessage = Store.PublicationMessages.GetPublicationMessage(messageId)
						?? throw new Exception($"Publication message with Id {messageId} does not exist");

					source.PublicationMessages.AddPublicationMessage(publicationMessage);
				}
			});

			source.Initialize();

			List<string> GetValues(string key)
			{
				var value = Utils.GetValues(sourceElement, key);
				if (value?.Any() != true)
				{
					throw new ArgumentException($"{sourceLogName} field {key} is null or empty");
				}

				return value;
			}

			string GetValue(string key)
			{
				var value = Utils.GetValue(sourceElement, key);
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException($"${sourceLogName} field {key} is null or empty");
				}

				return value;
			}
		}

		public void LoadUcdpFeedSource(string sourceId, UcdpSource source) => LoadUcdpSource(sourceId, source, "ucdp_sources", "UcdpFeedSource");

		public void LoadFingerpostSource(string sourceId, FingerpostSource source) => LoadUcdpSource(sourceId, source, "fingerpost_sources", "FingerpostSource");

		public void LoadIdnSource(string sourceId, IdnSource source)
		{
			var sourceElement = GetSource("idn_sources", sourceId);

			source.ID = sourceId;
			source.Store = Store;
			source.IsSourceActive = (Utils.GetValue(sourceElement, "active")).ToLower().Trim() == "yes";
            source.GroupTags = Utils.GetValues(sourceElement, "group_tags", true);
            source.IdnPages = Utils.GetValues(sourceElement, "$.idn_pages")?.ToArray();
			source.Fields = Utils.GetValues(sourceElement, "$.idn_fields")?.Select(s => Convert.ToInt32(s)).ToArray();
			source.IsPage = bool.TryParse(Utils.GetValue(sourceElement, "is_page").ToLower(), out var isPage) && isPage;
			source.Timeout = int.TryParse(Utils.GetValue(sourceElement, "timeout_in_sec"), out var timeout)
				? TimeSpan.FromSeconds(timeout) : TimeSpan.FromSeconds(30);
            source.UseHistoryPolling = bool.TryParse(Utils.GetValue(sourceElement, "use_history_polling").ToLower(), out var useHistoryPolling) == false ? true : useHistoryPolling;
            source.IdnPollType = Enum.TryParse(Utils.GetValue(sourceElement, "idn_poll_type"), true, out IdnSource.IdnPollTypeEnum pollType)
                ? pollType
                : IdnSource.IdnPollTypeEnum.Subscription;

            const int defaultPollCountAtTime = 1;
			source.MaxPollAtTime =
				int.TryParse(Utils.GetValue(sourceElement, "max_poll_at_time"), out var maxPollAtTimeResult)
					? maxPollAtTimeResult
					: defaultPollCountAtTime;

			int iLimitPolls = 0;
			int.TryParse(sourceElement["limit_poll_count"] == null ? "0" : (string)sourceElement["limit_poll_count"] ?? "0", out iLimitPolls);
			if (iLimitPolls > 0)
				source.LimitPollCount = iLimitPolls;

			const int defaultPollingIntervalMs = 30000;
			var pollingInterval =
				int.TryParse(Utils.GetValue(sourceElement, "default_interval_in_ms"), out var intervalResult)
					? intervalResult
					: defaultPollingIntervalMs;
			source.DefaultPollIntervalInMS = pollingInterval;
			source.CurrentPollIntervalInMS = pollingInterval;


			var messageIds = Utils.GetValues(sourceElement, "$.publication_message_id");

			messageIds.ForEach(messageId =>
			{
				if (!string.IsNullOrEmpty(messageId))
				{
					var publicationMessage = Store.PublicationMessages.GetPublicationMessage(messageId)
						?? throw new Exception($"Publication message with Id {messageId} does not exist");

					source.PublicationMessages.AddPublicationMessage(publicationMessage);
				}
			});

			source.Initialize();
		}

		public void LoadSettings()
		{
			if (AutomationClient.UserData == null)
				return;

			var usersettings = AutomationClient.UserData;
			if (usersettings != null)
			{
				foreach (var setting in usersettings)
				{
					try
					{
						if (setting.Key == "ENABLE_FORCE_FILING_YES_NO")
						{
							if (!string.IsNullOrEmpty(setting.Value) && setting.Value.ToUpper() == "YES")
							{
								Environment.SetEnvironmentVariable(EnvVariableNames.FORCE, "true");
								AutomationClient.ForceLog("ENABLE_FORCE_FILING_YES_NO=YES detected setting environment variable FORCE to true", NLog.LogLevel.Warn);
							}
						}
						//AutomationClient.ReutersLogEvents(NLog.LogLevel.Info, "User Data Read", $"{{\"ev-userdata\":{setting.ToJson()}}}");
						Setting oSetting = new Setting();
						oSetting.ID = setting.Key;
						oSetting.Caption = "";
						oSetting.Description = "";
						//oSetting.Value = Setting.GetDecodedValue(setting.Value);
						oSetting.Value = setting.Value;
						Store.Settings.AddSetting(oSetting);
					}
					catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}

			SetUSNSettings();

			SetReutersValues();

			try { AutomationClient.ForceLog($"Settings: {Store.Settings.GetAllSettings().ToJson()}"); } catch { }
		}

		private JObject GetSource(string sourceName, string sourceId)
		{
			return (JObject)SourceConfig[sourceName].FirstOrDefault(u => u["id"] != null && (string)u["id"] == sourceId)
				?? throw new Exception("Element with Id " + sourceId + " is not found");
		}

		private void SetReutersValues()
		{
			try
			{
				var allSettings = Store.Settings.GetAllSettings();
				var reutersSettings = allSettings.Where(s =>
				{
					var id = s.ID.ToUpperInvariant();
					return id.StartsWith("REUTERSPOLL_") || id.StartsWith("REUTERSPRIOR_") || id.StartsWith("REUTERSCURRENCY_");
				}).Select(s => { s.Value = ""; return s; }).ToList();

				var ricsToAskFor = reutersSettings.Select(s =>
				{
					string tempId = s.ID;
					if (tempId.StartsWith("REUTERSCURRENCY_"))
						tempId = tempId + "=";
					return tempId.Replace("REUTERSPOLL_", "").Replace("REUTERSPRIOR_", "").Replace("REUTERSCURRENCY_", "");
				}).Distinct().ToList();

				if (ricsToAskFor.Any())
				{
					var results = elektronManager?.GetHistoricalDataAsync(ricsToAskFor.ToArray(), new int[] { }).GetAwaiter().GetResult();

					foreach (var setting in reutersSettings)
					{
						try
						{
							string tempId = setting.ID;
							if (tempId.StartsWith("REUTERSCURRENCY_"))
								tempId = tempId + "=";
							string ric = tempId.Replace("REUTERSPOLL_", "").Replace("REUTERSPRIOR_", "").Replace("REUTERSCURRENCY_", "");
							var data = results?.Where(r => r.Data.Ric.Equals(ric, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
							if (data != null)
							{
								int index = -1;
								if (setting.ID.StartsWith("REUTERSPOLL_"))
									index = 1056;
								else if (setting.ID.StartsWith("REUTERSPRIOR_"))
									index = 831;
								else if (setting.ID.StartsWith("REUTERSCURRENCY_"))
									index = 22;
								if (index != -1)
									setting.Value = Convert.ToString(data.Data.Values[index]);
							}
						}
						catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
					}
				}
			}
			catch (Exception ex)
			{
				AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error);
			}
		}

		public async Task<string> GetReutersValue(string id)
		{
			try
			{
				if (id.StartsWith("REUTERSCURRENCY_"))
					id = id + "=";

				var ricToAskFor = id.Replace("REUTERSPOLL_", "").Replace("REUTERSPRIOR_", "").Replace("REUTERSCURRENCY_", "");

				var results = await elektronManager?.GetHistoricalDataAsync(new[] { ricToAskFor }, new int[] { });

				var data = results?[0];
				if (data != null)
				{
					int index = -1;
					if (id.StartsWith("REUTERSPOLL_"))
						index = 1056;
					else if (id.StartsWith("REUTERSPRIOR_"))
						index = 831;
					else if (id.StartsWith("REUTERSCURRENCY_"))
						index = 22;
					if (index != -1)
						return Convert.ToString(data.Data.Values[index]);
				}
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
			return "";
		}

		public ElektronResult[] GetReutersValues(string[] rics, int[] fields = null)
		{
			if (rics == null || !rics.Any())
				throw new ArgumentException($"rics null or empty");
			return elektronManager?.GetHistoricalDataAsync(rics, fields).GetAwaiter().GetResult();
		}

		public string GetReutersValue(string ric, int index)
		{
			try
			{
				var results = elektronManager?.GetHistoricalDataAsync(new[] { ric }, new[] { index }).GetAwaiter().GetResult();

				var data = results?[0];
				if (data != null)
					return Convert.ToString(data.Data.Values[index]);
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
			return "";
		}

		private void SetUSNSettings()
		{
			try
			{
				var allSettings = Store.Settings.GetAllSettings();
				var usnSettingsForEmea = allSettings.Where(s => s.ID.ToUpperInvariant().StartsWith("USN_EMEA_")).Select(s => { s.Value = ""; return s; }).ToList();
				var usnSettingsForApac = allSettings.Where(s => s.ID.ToUpperInvariant().StartsWith("USN_APAC_")).Select(s => { s.Value = ""; return s; }).ToList();
				var usnSettingsForAmer = allSettings.Where(s => s.ID.ToUpperInvariant().StartsWith("USN_AMER_") || s.ID.ToUpperInvariant().StartsWith("USN_AMERS_")).Select(s => { s.Value = ""; return s; }).ToList();

				var allUsns = new List<Dictionary<string, string>>();
				
				//AutomationClient.ReutersConfig.Global.Container.TaskARN
				GetUsnsFromEap(AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Emea, usnSettingsForEmea, ref allUsns);
				GetUsnsFromEap(AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Apac, usnSettingsForApac, ref allUsns);
				GetUsnsFromEap(AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Amers, usnSettingsForAmer, ref allUsns);

				if (allUsns.Any())
				{
					var allUsnPairs = allUsns.SelectMany(s => s.ToList()).ToList();
					foreach (var usn in allUsnPairs)
					{
						var setting = Store.Settings.GetSetting(usn.Key);
						setting.Value = usn.Value ?? "";
						if (string.IsNullOrWhiteSpace(setting.Value))
							continue;
						if (setting.ID.ToLowerInvariant().Contains("chinesetraditional"))
							setting.Value = setting.Value.Remove(2, 1).Insert(2, "T");
						else if (setting.ID.ToLowerInvariant().Contains("chinesesimplified"))
							setting.Value = setting.Value.Remove(2, 1).Insert(2, "S");
					}
				}
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		private void GetUsnsFromEap(string prefix, List<Setting> usnSettings, ref List<Dictionary<string, string>> allUsns)
		{
			try
			{
				if (usnSettings != null && usnSettings.Any())
				{
					var keys = usnSettings.Select(s => s.ID).ToList();
					var task = Task.Run(async () => { return await AutomationClient.ReutersConfig.GetUsnsFromKeysAsync(prefix, keys); });
					if (task.Wait(15000))
					{
						var usnDictionary = task.Result;
						if (usnDictionary != null && usnDictionary.Any())
							allUsns.Add(usnDictionary);
					}
				}
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		public void LoadPublications()
		{
			JObject publicationDocument = PublicationConfig;

			#region publication_agent

			var agentElements = publicationDocument["publication_agents"];
			if (agentElements != null)
			{
				foreach (JObject agentElement in agentElements)
				{
					try
					{
						PublicationAgent oAgent;

						string sRegion = Utils.GetValue(agentElement, "region");
						string sLanguage = Utils.GetValue(agentElement, "language");

						string sUsnSettingId = Utils.GetValue(agentElement, "usn_setting_id");

						if (!string.IsNullOrWhiteSpace(sUsnSettingId))
						{
							string[] fields = sUsnSettingId.Split('_');
							if (fields.Length >= 3)
							{
								if (string.IsNullOrWhiteSpace(sRegion))
									sRegion = fields[1].Trim().ToUpper();
								if (string.IsNullOrWhiteSpace(sLanguage))
									sLanguage = fields[2].Trim() == "" ? "DEFAULT" : fields[2].Trim().ToUpper();
							}
						}

						oAgent = new PublicationAgent(sRegion, sLanguage);

						oAgent.Store = Store;
						oAgent.ID = Utils.GetValue(agentElement, "id");
						oAgent.PublisherName = Utils.GetValue(agentElement, "publisher");

						oAgent.Usn = Utils.GetValue(agentElement, "usn");

						if (string.IsNullOrWhiteSpace(oAgent.Usn) && !string.IsNullOrWhiteSpace(sUsnSettingId) && Store.Settings != null)
						{
							oAgent.Usn = Store.Settings.GetSetting(sUsnSettingId) == null ? "" : Store.Settings.GetSetting(sUsnSettingId).Value ?? "";
							if (string.IsNullOrWhiteSpace(oAgent.Usn))
								oAgent.InitUsn(true, false);
						}

						Store.PublicationAgents.AddPublicationAgent(oAgent);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}

				if (Store.PublicationAgents != null)
				{
					foreach (PublicationAgent oAgent in Store.PublicationAgents.GetAllAgents())
					{
						if (string.IsNullOrWhiteSpace(oAgent.Usn))
							oAgent.InitUsn(true);
					}
				}
			}
			#endregion

			#region handbrake_publication_message

			var handbrakeElements = publicationDocument["handbrake_publications"];
			if (handbrakeElements != null)
			{
				foreach (JObject hbElement in handbrakeElements)
				{
					try
					{
						bool bIsActive = (Utils.GetValue(hbElement, "active")).ToLower() == "yes";
                        bool bIsLlm = (Utils.GetValue(hbElement, "llm")).ToLower() == "yes";

                        string sId = Utils.GetValue(hbElement, "id");// hbElement.Element("id") == null ? "" : hbElement.Element("id").Value ?? "";
						string sAutomationName = Utils.GetValue(hbElement, "spider_name");// hbElement.Element("spider_name") == null ? "" : hbElement.Element("spider_name").Value ?? "";

						string sHandbrakeName = "";
						string sHandbrakeUrl = "";
						bool bSkipDuplicateRemoval = false;
						bool bIsUsnReadOnly = true;
						string sEmailAccount = "";
						string sTitle = "";
						bool bIsDisplayUsnInTitle = false;
						bool bIsDelayed = true;
						string sDescription = "";
						bool bEnablePublishAllButton = false;
						string sPublicationOrder = "";

						List<string> saAlternateUrls = new List<string>();

						sHandbrakeName = Utils.GetValue(hbElement, "handbrake_name");
						bSkipDuplicateRemoval = (Utils.GetValue(hbElement, "skip_duplicate_removal")).ToLower() == "yes";
						sHandbrakeUrl = Utils.GetValue(hbElement, "handbrake_post_url");
						bIsDisplayUsnInTitle = (Utils.GetValue(hbElement, "display_usn_in_title")).ToLower() == "yes";
						bIsUsnReadOnly = (Utils.GetValue(hbElement, "usn_readonly")).ToLower() != "no";
						sEmailAccount = Utils.GetValue(hbElement, "aim_email_account");
						sTitle = Utils.GetValue(hbElement, "title");
						sDescription = Utils.GetValue(hbElement, "description");
						bIsDelayed = (Utils.GetValue(hbElement, "is_delayed")).ToLower() == "yes";
						string sDelayDateTime = Utils.GetValue(hbElement, "delay_datetime");
						bEnablePublishAllButton = (Utils.GetValue(hbElement, "enable_publish_all_button")).ToLower() == "yes";
						sPublicationOrder = Utils.GetValue(hbElement, "publication_order");
						bool bIsRetry = (Utils.GetValue(hbElement, "retry_alternate")).ToLower() != "no";

						var oAlternateUrlElements = Utils.GetValues(hbElement, "$.alternate_post_url");
						if (oAlternateUrlElements != null)
						{
							foreach (string sUrl in oAlternateUrlElements)
								if (!string.IsNullOrWhiteSpace(sUrl))
									saAlternateUrls.Add(sUrl.Trim());
						}

						//Prefix AutomationName with Hosting Server name

						string sAgentId = Utils.GetValue(hbElement, "agent_id");// hbElement.Element("agent_id") == null ? "" : hbElement.Element("agent_id").Value ?? "";
						if (string.IsNullOrWhiteSpace(sAgentId))
							throw new Exception("agent_id can not be empty");
						//TODO: validate sAgentId in Store.PublicationAgents
						PublicationAgent oAgent = Store.PublicationAgents.GetPublicationAgent(sAgentId);
						if (oAgent == null)
							throw new Exception("PublicationAgent with Id " + sAgentId + " not found");

						string sProductCodes = Utils.GetValue(hbElement, "p_codes");// hbElement.Element("p_codes") == null ? "" : hbElement.Element("p_codes").Value ?? "";
						string sTopicCodes = Utils.GetValue(hbElement, "t_codes");// hbElement.Element("t_codes") == null ? "" : hbElement.Element("t_codes").Value ?? "";
						string sRicReferences = Utils.GetValue(hbElement, "ric_references");// hbElement.Element("ric_references") == null ? "" : hbElement.Element("ric_references").Value ?? "";
						string sLanguageCode = Utils.GetValue(hbElement, "language_code");// hbElement.Element("language_code") == null ? "" : hbElement.Element("language_code").Value ?? "";
						string sNamedItemCodes = Utils.GetValue(hbElement, "ni_code");// hbElement.Element("ni_code") == null ? "" : hbElement.Element("ni_code").Value ?? "";
						string sQPriority = Utils.GetValue(hbElement, "q_priority");// hbElement.Element("q_priority") == null ? "" : hbElement.Element("q_priority").Value ?? "";
						string sCategoryCode = Utils.GetValue(hbElement, "c_codes");// hbElement.Element("c_codes") == null ? "" : hbElement.Element("c_codes").Value ?? "";
						string sMetaCharset = Utils.GetValue(hbElement, "charset");// hbElement.Element("charset") == null ? "" : hbElement.Element("charset").Value ?? "";
						string sSlug = Utils.GetValue(hbElement, "slug");// hbElement.Element("slug") == null ? "" : hbElement.Element("slug").Value ?? "";
						string sActionCode = Utils.GetValue(hbElement, "action_code");// hbElement.Element("action_code") == null ? "" : hbElement.Element("action_code").Value ?? "";

						HandbrakeMessage oHandbrakeMessage = new HandbrakeMessage(PublicationMessageType.Handbrake, oAgent, sAutomationName, sId, sQPriority, sHandbrakeName, sHandbrakeUrl);
						oHandbrakeMessage.IsActive = bIsActive;

						oHandbrakeMessage.Charset = sMetaCharset;
						oHandbrakeMessage.Description = sDescription;
						oHandbrakeMessage.DisplayUsnInTitle = bIsDisplayUsnInTitle;
						oHandbrakeMessage.EmailAccount = sEmailAccount;
						oHandbrakeMessage.IsUsnReadOnly = bIsUsnReadOnly;
						oHandbrakeMessage.LanguageCode = sLanguageCode;
						oHandbrakeMessage.NICodes = sNamedItemCodes;
						oHandbrakeMessage.PCodes = sProductCodes;
						oHandbrakeMessage.RICCodes = sRicReferences;
						oHandbrakeMessage.CategoryCode = sCategoryCode;
						oHandbrakeMessage.Slug = sSlug;
						oHandbrakeMessage.ActionCode = sActionCode;
						oHandbrakeMessage.SkipDuplicateRemoval = bSkipDuplicateRemoval;
						oHandbrakeMessage.TCodes = sTopicCodes;
						oHandbrakeMessage.Title = sTitle;
						oHandbrakeMessage.IsHandbrake = true;
						oHandbrakeMessage.IsAutomatic = false;
						oHandbrakeMessage.IsDelayed = bIsDelayed;
						oHandbrakeMessage.EnablePublishAllButton = bEnablePublishAllButton;
						oHandbrakeMessage.EmbargoTime = GetEmbargoTime(hbElement);
						oHandbrakeMessage.Store = Store;
                        oHandbrakeMessage.IsLLM = bIsLlm;

						DateTime oDelayDateTime = new DateTime();
						if (!string.IsNullOrWhiteSpace(sDelayDateTime))
							DateTime.TryParseExact(sDelayDateTime.Trim(), "dd:MM:yyyy:HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out oDelayDateTime);
						oHandbrakeMessage.DelayDateTime = oDelayDateTime;

						if (!string.IsNullOrWhiteSpace(sPublicationOrder))
							oHandbrakeMessage.PublicationOrder = sPublicationOrder.Split(new char[] { ',' }).Select(x => x.Trim()).ToList();

						try
						{
							// Notes
							var xAlertNotes = publicationDocument["handbrake_notes"];
							if (xAlertNotes != null && xAlertNotes.Count() > 0)
							{
								foreach (JObject note in xAlertNotes)
								{
									string sNoteName = Utils.GetValue(note, "name");
									string sNoteText = Utils.GetValue(note, "notetext");
									oHandbrakeMessage.AddNote(new Note { Name = sNoteName, NoteText = sNoteText });
								}
							}
						}
						catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

						try
						{
							// Templates
							var xAlertTemplates = publicationDocument["handbrake_templates"];
							if (xAlertTemplates != null && xAlertTemplates.Count() > 0)
							{
								foreach (JObject template in xAlertTemplates)
								{
									string sName = Utils.GetValue(template, "name");
									string sTemplate = Utils.GetValue(template, "template");
									oHandbrakeMessage.AddTemplate(new Template { Name = sName, Text = sTemplate });
								}
							}
						}
						catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

						Store.PublicationMessages.AddPublicationMessage(oHandbrakeMessage);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}
			#endregion

			#region ntm_alert_publication_message

			var ntmAlertElements = publicationDocument["alert_publications"];
			if (ntmAlertElements != null)
			{
				foreach (JObject alertElement in ntmAlertElements)
				{
					try
					{
						bool bIsActive = (Utils.GetValue(alertElement, "active")).ToLower() == "yes";
						bool bIsAuto = (Utils.GetValue(alertElement, "auto")).ToLower() == "yes";
						bool bIsHandbrake = (Utils.GetValue(alertElement, "handbrake")).ToLower() == "yes";
                        bool bIsLlm = (Utils.GetValue(alertElement, "llm")).ToLower() == "yes";

                        string sId = Utils.GetValue(alertElement, "id");

						string sAutomationName = Utils.GetValue(alertElement, "spider_name");

						//Prefix AutomationName with Hosting Server name
						string sAgentId = Utils.GetValue(alertElement, "agent_id");
						if (string.IsNullOrWhiteSpace(sAgentId))
							throw new Exception("agent_id can not be empty");
						//TODO: validate sAgentId in Store.PublicationAgents
						PublicationAgent oAgent = Store.PublicationAgents.GetPublicationAgent(sAgentId);
						if (oAgent == null)
							throw new Exception("PublicationAgent with Id " + sAgentId + " not found");

						string sProductCodes = Utils.GetValue(alertElement, "p_codes");
						string sTopicCodes = Utils.GetValue(alertElement, "t_codes");
						string sRicReferences = Utils.GetValue(alertElement, "ric_references");
						string sAlertTemplate = Utils.GetValue(alertElement, "alert_template");
						string sLanguageCode = Utils.GetValue(alertElement, "language_code");
						string sNamedItemCodes = Utils.GetValue(alertElement, "ni_code");
						string sQPriority = Utils.GetValue(alertElement, "q_priority");
						string sNtmPriority = Utils.GetValue(alertElement, "n_priority");
						string sCategoryCode = Utils.GetValue(alertElement, "c_codes");
						string sActionCode = Utils.GetValue(alertElement, "a_code");
						string sFormatIndicator = Utils.GetValue(alertElement, "format_indicator");
						string sAttribution = Utils.GetValue(alertElement, "attribution");

						string sHandbrakeTitle = "";
						string sNoteName = "";
						bool bIsForceCapitals = true;
						string sMetaCharset = "";
						Dictionary<string, Handbrake.HandbrakeMessage> oHandbrakeMessages = new Dictionary<string, HandbrakeMessage>();
						int iHandbrakeIndex = 0;
						//XElement xHandbrakeConfigs = alertElement.Element("handbrake_configuration");
						//if (xHandbrakeConfigs != null)
						{
							sHandbrakeTitle = Utils.GetValue(alertElement, "handbrake_title"); //alertElement.Element("handbrake_title") == null ? "" : alertElement.Element("handbrake_title").Value ?? "";
							sNoteName = Utils.GetValue(alertElement, "handbrake_note_name"); //alertElement.Element("handbrake_note_name") == null ? "" : alertElement.Element("handbrake_note_name").Value ?? "";
							bIsForceCapitals = (Utils.GetValue(alertElement, "force_capitals")).ToLower() != "no";
							string sHandbrakeIndex = Utils.GetValue(alertElement, "handbrake_index"); //alertElement.Element("handbrake_index") == null ? "" : alertElement.Element("handbrake_index").Value ?? "";

							int.TryParse(sHandbrakeIndex, out iHandbrakeIndex);

							//XElement xHandbrakeMessages = alertElement.Element("handbrake_messages");
							//if (xHandbrakeMessages != null)
							{
								var messages = Utils.GetValues(alertElement, "$.handbrake_message_id");
								if (messages != null)
								{
									foreach (var message in messages)
									{
										string sMessageId = message ?? "";
										if (!string.IsNullOrWhiteSpace(sMessageId))
										{
											PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
											if (oPublicationMessage == null || !(oPublicationMessage is HandbrakeMessage))
												throw new Exception("HandbrakeMesssage with Id " + sMessageId + " does not exist");
											((HandbrakeMessage)oPublicationMessage).GroupMessages.Enqueue(sId);
											oHandbrakeMessages.Add(oPublicationMessage.ID, (HandbrakeMessage)oPublicationMessage);
										}
									}
								}
							}
						}

						AlertPublicationMessage oAlertMessage = new AlertPublicationMessage(PublicationMessageType.Alert, oAgent, sAlertTemplate, sAutomationName, sId, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, sCategoryCode, sQPriority, sHandbrakeTitle, sNoteName, bIsForceCapitals, sMetaCharset, sAttribution);
						oAlertMessage.IsActive = bIsActive;
                        oAlertMessage.IsLLM = bIsLlm;
                        oAlertMessage.HandbrakeIndex = iHandbrakeIndex;
						oAlertMessage.HandbrakeMessages = oHandbrakeMessages;
						oAlertMessage.ActionCode = sActionCode;
						oAlertMessage.FormatIndicator = sFormatIndicator;
						oAlertMessage.Attribution = sAttribution;
						oAlertMessage.EmbargoTime = GetEmbargoTime(alertElement);

						oAlertMessage.Store = Store;

						if (bIsHandbrake)
						{
							oAlertMessage.IsHandbrake = true;
							oAlertMessage.IsAutomatic = false;
						}
						if (bIsAuto)
							oAlertMessage.IsAutomatic = true;


						Store.PublicationMessages.AddPublicationMessage(oAlertMessage);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}
			#endregion

			#region ntm_story_publication_message

			var ntmStoryElements = publicationDocument["story_publications"];
			if (ntmStoryElements != null)
			{
				foreach (JObject storyElement in ntmStoryElements)
				{
					try
					{
						bool bIsActive = (Utils.GetValue(storyElement, "active")).ToLower() == "yes";
                        bool bIsLlm = (Utils.GetValue(storyElement, "llm")).ToLower() == "yes";
                        bool bIsAuto = (Utils.GetValue(storyElement, "auto")).ToLower() == "yes";
						bool bIsHandbrake = (Utils.GetValue(storyElement, "handbrake")).ToLower() == "yes";

						string sId = Utils.GetValue(storyElement, "id");
						string sAutomationName = Utils.GetValue(storyElement, "spider_name");
						string sAgentId = Utils.GetValue(storyElement, "agent_id");
						if (string.IsNullOrWhiteSpace(sAgentId))
							throw new Exception("agent_id can not be empty");
						//TODO: validate sAgentId in Store.PublicationAgents
						PublicationAgent oAgent = Store.PublicationAgents.GetPublicationAgent(sAgentId);
						if (oAgent == null)
							throw new Exception("agent with Id " + sAgentId + " not found");

						string sProductCodes = Utils.GetValue(storyElement, "p_codes");// storyElement.Element("p_codes") == null ? "" : storyElement.Element("p_codes").Value ?? "";
						string sTopicCodes = Utils.GetValue(storyElement, "t_codes");// storyElement.Element("t_codes") == null ? "" : storyElement.Element("t_codes").Value ?? "";
						string sRicReferences = Utils.GetValue(storyElement, "ric_references");//storyElement.Element("ric_references") == null ? "" : storyElement.Element("ric_references").Value ?? "";
						bool bIsTable = (Utils.GetValue(storyElement, "is_table")).ToLower() == "yes";
						string sHeadlineTemplate = Utils.GetValue(storyElement, "headline_template");//storyElement.Element("headline_template") == null ? "" : storyElement.Element("headline_template").Value ?? "";
						string sStoryTextTemplate = Utils.GetValue(storyElement, "story_text_template");//storyElement.Element("story_text_template") == null ? "" : storyElement.Element("story_text_template").Value ?? "";
						string sLanguageCode = Utils.GetValue(storyElement, "language_code");//storyElement.Element("language_code") == null ? "" : storyElement.Element("language_code").Value ?? "";
						string sNamedItemCodes = Utils.GetValue(storyElement, "ni_code");//storyElement.Element("ni_code") == null ? "" : storyElement.Element("ni_code").Value ?? "";
						string sQPriority = Utils.GetValue(storyElement, "q_priority");//storyElement.Element("q_priority") == null ? "" : storyElement.Element("q_priority").Value ?? "";
						string sNtmPriority = Utils.GetValue(storyElement, "n_priority");//storyElement.Element("n_priority") == null ? "3" : storyElement.Element("n_priority").Value ?? "3";
						string sSlug = Utils.GetValue(storyElement, "slug");//storyElement.Element("slug") == null ? "" : storyElement.Element("slug").Value ?? "";
						string sCategoryCode = Utils.GetValue(storyElement, "c_codes");//storyElement.Element("c_codes") == null ? "" : storyElement.Element("c_codes").Value ?? "";
						string sActionCode = Utils.GetValue(storyElement, "a_code");//storyElement.Element("a_code") == null ? "" : storyElement.Element("a_code").Value ?? "";
						string sFormatIndicator = Utils.GetValue(storyElement, "format_indicator");//storyElement.Element("format_indicator") == null ? "" : storyElement.Element("format_indicator").Value ?? "";
						string sAttribution = Utils.GetValue(storyElement, "attribution");//storyElement.Element("attribution") == null ? "" : storyElement.Element("attribution").Value ?? "";

						string sHandbrakeTitle = "";
						string sNoteName = "";
						string sMetaCharset = "";
						bool bIsWrapText = true;

						Dictionary<string, Handbrake.HandbrakeMessage> oHandbrakeMessages = new Dictionary<string, HandbrakeMessage>();
						int iHandbrakeIndex = 0;
						//XElement xHandbrakeConfigs = storyElement.Element("handbrake_configuration");
						//if (xHandbrakeConfigs != null)
						{
							sHandbrakeTitle = Utils.GetValue(storyElement, "handbrake_title");//storyElement.Element("handbrake_title") == null ? "" : storyElement.Element("handbrake_title").Value ?? "";
							sNoteName = Utils.GetValue(storyElement, "handbrake_note_name");//storyElement.Element("handbrake_note_name") == null ? "" : storyElement.Element("handbrake_note_name").Value ?? "";
							sMetaCharset = Utils.GetValue(storyElement, "charset");//storyElement.Element("charset") == null ? "" : storyElement.Element("charset").Value ?? "";
							bIsWrapText = (Utils.GetValue(storyElement, "wrap_text")).ToLower() != "off";
							string sHandbrakeIndex = Utils.GetValue(storyElement, "handbrake_index");//storyElement.Element("handbrake_index") == null ? "" : storyElement.Element("handbrake_index").Value ?? "";

							int.TryParse(sHandbrakeIndex, out iHandbrakeIndex);

							//XElement xHandbrakeMessages = storyElement.Element("handbrake_messages");
							//if (xHandbrakeMessages != null)
							{
								var messages = Utils.GetValues(storyElement, "$.handbrake_message_id");
								if (messages != null)
								{
									foreach (var message in messages)
									{
										string sMessageId = message ?? "";
										if (!string.IsNullOrWhiteSpace(sMessageId))
										{
											PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
											if (oPublicationMessage == null || !(oPublicationMessage is HandbrakeMessage))
												throw new Exception("HandbrakeMesssage with Id " + sMessageId + " does not exist");
											((HandbrakeMessage)oPublicationMessage).GroupMessages.Enqueue(sId);
											oHandbrakeMessages.Add(oPublicationMessage.ID, (HandbrakeMessage)oPublicationMessage);
										}
									}
								}
							}
						}

						StoryPublicationMessage oStoryMessage = new StoryPublicationMessage(PublicationMessageType.Story, oAgent, sHeadlineTemplate, sStoryTextTemplate, sAutomationName, sId, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, bIsTable, sSlug, sCategoryCode, sQPriority, sHandbrakeTitle, sNoteName, sMetaCharset, bIsWrapText, sAttribution);
						oStoryMessage.IsActive = bIsActive;
                        oStoryMessage.IsLLM = bIsLlm;
                        oStoryMessage.HandbrakeIndex = iHandbrakeIndex;
						oStoryMessage.HandbrakeMessages = oHandbrakeMessages;
						oStoryMessage.ActionCode = sActionCode;
						oStoryMessage.FormatIndicator = sFormatIndicator;
						oStoryMessage.Attribution = sAttribution;
						oStoryMessage.EmbargoTime = GetEmbargoTime(storyElement);

						oStoryMessage.Store = Store;

						if (bIsHandbrake)
						{
							oStoryMessage.IsHandbrake = true;
							oStoryMessage.IsAutomatic = false;
						}
						if (bIsAuto)
							oStoryMessage.IsAutomatic = true;

						Store.PublicationMessages.AddPublicationMessage(oStoryMessage);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}
			#endregion

			#region econ_publication_message

			var econElements = publicationDocument["number_publications"];
			if (econElements != null)
			{
				foreach (JObject econElement in econElements)
				{
					try
					{
						bool bIsActive = (Utils.GetValue(econElement, "active")).ToLower().Trim() == "yes";
                        bool bIsLlm = (Utils.GetValue(econElement, "llm")).ToLower().Trim() == "yes";
                        bool bIsAuto = (Utils.GetValue(econElement, "auto")).ToLower() == "yes";
						bool bIsHandbrake = (Utils.GetValue(econElement, "handbrake")).ToLower() == "yes";
						bool bIsFormatted = (Utils.GetValue(econElement, "formatted_econ")).ToLower() == "yes";

						string sId = Utils.GetValue(econElement, "id");
						string sAutomationName = Utils.GetValue(econElement, "spider_name");
						string sAgentId = Utils.GetValue(econElement, "agent_id");
						if (string.IsNullOrWhiteSpace(sAgentId))
							throw new Exception("agent_id can not be empty");
						//TODO: validate sAgentId in Store.PublicationAgents
						PublicationAgent oAgent = Store.PublicationAgents.GetPublicationAgent(sAgentId);
						if (oAgent == null)
							throw new Exception("agent with Id " + sAgentId + " not found");

						string sRicBinaryId = Utils.GetValue(econElement, "ric_binary_id");
						string sEntitleMents = Utils.GetValue(econElement, "entitlements");
						string sQPriority = Utils.GetValue(econElement, "q_priority");

						string sHandbrakeTitle = "";
						string sName = "";
						Dictionary<string, Handbrake.HandbrakeMessage> oHandbrakeMessages = new Dictionary<string, HandbrakeMessage>();

						int iHandbrakeIndex = 0;

						//XElement xHandbrakeConfigs = econElement.Element("handbrake_configuration");
						//if (xHandbrakeConfigs != null)
						{
							sHandbrakeTitle = Utils.GetValue(econElement, "handbrake_title");// econElement.Element("handbrake_title") == null ? "" : econElement.Element("handbrake_title").Value ?? "";
							sName = Utils.GetValue(econElement, "handbrake_tag_name"); //econElement.Element("handbrake_tag_name") == null ? "" : econElement.Element("handbrake_tag_name").Value ?? "";
							string sHandbrakeIndex = Utils.GetValue(econElement, "handbrake_index"); //econElement.Element("handbrake_index") == null ? "" : econElement.Element("handbrake_index").Value ?? "";

							int.TryParse(sHandbrakeIndex, out iHandbrakeIndex);

							//XElement xHandbrakeMessages = econElement.Element("handbrake_messages");
							//if (xHandbrakeMessages != null)
							{
								var messages = Utils.GetValues(econElement, "$.handbrake_message_id");
								if (messages != null)
								{
									foreach (var message in messages)
									{
										string sMessageId = message ?? "";
										if (!string.IsNullOrWhiteSpace(sMessageId))
										{
											PublicationMessage oPublicationMessage = Store.PublicationMessages.GetPublicationMessage(sMessageId);
											if (oPublicationMessage == null || !(oPublicationMessage is HandbrakeMessage))
												throw new Exception("HandbrakeMesssage with Id " + sMessageId + " does not exist");
											((HandbrakeMessage)oPublicationMessage).GroupMessages.Enqueue(sId);
											oHandbrakeMessages.Add(oPublicationMessage.ID, (HandbrakeMessage)oPublicationMessage);
										}
									}
								}
							}
						}

						EconPublicationMessage oEconMessage = new EconPublicationMessage(PublicationMessageType.ECON, oAgent, sAutomationName, sId, sEntitleMents, sRicBinaryId, sQPriority, sHandbrakeTitle, sName);
						oEconMessage.IsActive = bIsActive;
                        oEconMessage.IsLLM = bIsLlm;
						oEconMessage.HandbrakeIndex = iHandbrakeIndex;
						oEconMessage.HandbrakeMessages = oHandbrakeMessages;
						oEconMessage.IsFormatted = bIsFormatted;
						oEconMessage.EmbargoTime = GetEmbargoTime(econElement);
						oEconMessage.Store = Store;

						if (bIsHandbrake)
						{
							oEconMessage.IsHandbrake = true;
							oEconMessage.IsAutomatic = false;
						}
						if (bIsAuto)
							oEconMessage.IsAutomatic = true;

						Store.PublicationMessages.AddPublicationMessage(oEconMessage);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}
			#endregion

			#region email_message

			var forceEmsureEmailToAddressList = new List<string> { "validationfailure.webautomation@allreleases.net", "validationfailure.qa.webautomation@allreleases.net" };

			var emailElements = publicationDocument["email_publications"];
			if (emailElements != null)
			{
				foreach (JObject emailElement in emailElements)
				{
					try
					{
						bool bIsActive = (Utils.GetValue(emailElement, "active")).ToLower() == "yes";
						bool bIsLogEnabled = (Utils.GetValue(emailElement, "enable_log")).ToLower() == "yes";

						string sId = Utils.GetValue(emailElement, "id");

						List<string> ToAddresses = new List<string>();
						List<string> CcAddresses = new List<string>();
						List<string> BccAddresses = new List<string>();

						var toAddresses = Utils.GetValues(emailElement, "$.to");
						if (toAddresses != null && toAddresses.Count() > 0)
						{
							foreach (var toAddress in toAddresses)
							{
								string address = toAddress ?? "";
								address = address.Trim();
								if (!string.IsNullOrEmpty(address))
									ToAddresses.Add(address);
							}
						}

						var ccAddresses = Utils.GetValues(emailElement, "$.cc");
						if (ccAddresses != null && ccAddresses.Count() > 0)
						{
							foreach (var ccAddress in ccAddresses)
							{
								string address = ccAddress ?? "";
								address = address.Trim();
								if (!string.IsNullOrEmpty(address))
									CcAddresses.Add(address);
							}
						}

						var bccAddresses = Utils.GetValues(emailElement, "$.bcc");
						if (bccAddresses != null && bccAddresses.Count() > 0)
						{
							foreach (var bccAddress in bccAddresses)
							{
								string address = bccAddress ?? "";
								address = address.Trim();
								if (!string.IsNullOrEmpty(address))
									BccAddresses.Add(address);
							}
						}

						string sFrom = Utils.GetValue(emailElement, "from");

						string sSubject = "";
						string sTextBody = "";
						string sHtmlBody = "";

						var xSubject = emailElement["subject"];
						if (xSubject != null)
						{
							bool isSubjectBase64 = (Utils.GetValue(emailElement, "subject_encoding")).ToLower() == "base64";

							sSubject = (string)xSubject ?? "";

							if (isSubjectBase64)
								sSubject = Encoding.UTF8.GetString(Convert.FromBase64String(sSubject));
						}

						var xTextBody = emailElement["text_body"];
						if (xTextBody != null)
						{
							bool isTextBase64 = (Utils.GetValue(emailElement, "text_body_encoding")).ToLower() == "base64";

							sTextBody = (string)xTextBody ?? "";

							if (isTextBase64)
								sTextBody = Encoding.UTF8.GetString(Convert.FromBase64String(sTextBody));
						}

						var xHtmlBody = emailElement["html_body"];
						if (xHtmlBody != null)
						{
							bool isHtmlBase64 = (Utils.GetValue(emailElement, "html_body_encoding")).ToLower() == "base64";

							sHtmlBody = (string)xHtmlBody ?? "";

							if (isHtmlBase64)
								sHtmlBody = Encoding.UTF8.GetString(Convert.FromBase64String(sHtmlBody));
						}

						EmailMessage oEmailMessage = new EmailMessage(Store);
						oEmailMessage.ID = sId;
						oEmailMessage.To = ToAddresses;
						oEmailMessage.From = sFrom;
						oEmailMessage.Cc = CcAddresses;
						oEmailMessage.Bcc = BccAddresses;
						oEmailMessage.Subject = sSubject;
						oEmailMessage.TextBody = sTextBody;
						oEmailMessage.HtmlBody = sHtmlBody;
						oEmailMessage.IsActive = bIsActive;
						oEmailMessage.IsLogEnabled = bIsLogEnabled;

						if (forceEmsureEmailToAddressList.Any(t => oEmailMessage.To.Contains(t, StringComparer.OrdinalIgnoreCase)))
							oEmailMessage.EmailServiceOption = "email-emsure-service";

						Store.EmailMessages.AddEmailMessage(oEmailMessage);
					}
					catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
				}
			}
			#endregion

			TimeSpan? GetEmbargoTime(JObject jObject)
			{
				return jObject != null && TimeSpan.TryParse(Utils.GetValue(jObject, "embargo_time"), out var result)
					? result
					: (TimeSpan?)null;
			}
		}

		public HandbrakeMessage GetNewHandbrakeMessage(string sId)
		{
			HandbrakeMessage oHandbrakeMessage = null;

			var publicationDocument = PublicationConfig;

			var hbElement = (JObject)publicationDocument["handbrake_publications"].Where(u => u["id"] != null && (string)u["id"] == sId).Single();

			/*var hbElement = (from source in publicationDocument.XPathSelectElements("//handbrake_publications/handbrake_publication")
								where (source.Element("id") == null ? "" : source.Element("id").Value ?? "") == sId
								select source).SingleOrDefault();*/

			if (hbElement == null)
				throw new Exception("Element with Id " + sId + " not found");

			bool bIsActive = (Utils.GetValue(hbElement, "active")).ToLower() == "yes";
            bool bIsLlm = (Utils.GetValue(hbElement, "llm")).ToLower() == "yes";

            string sAutomationName = Utils.GetValue(hbElement, "spider_name");

			string sHandbrakeName = "";
			string sHandbrakeUrl = "";
			bool bSkipDuplicateRemoval = false;
			bool bIsUsnReadOnly = true;
			string sEmailAccount = "";
			string sTitle = "";
			bool bIsDisplayUsnInTitle = false;
			bool bIsDelayed = true;
			string sDescription = "";
			bool bEnablePublishAllButton = false;
			string sPublicationOrder = "";

			List<string> saAlternateUrls = new List<string>();

			sHandbrakeName = Utils.GetValue(hbElement, "handbrake_name");
			bSkipDuplicateRemoval = (Utils.GetValue(hbElement, "skip_duplicate_removal")).ToLower() == "yes";
			sHandbrakeUrl = Utils.GetValue(hbElement, "handbrake_post_url");
			bIsDisplayUsnInTitle = (Utils.GetValue(hbElement, "display_usn_in_title")).ToLower() == "yes";
			bIsUsnReadOnly = (Utils.GetValue(hbElement, "usn_readonly")).ToLower() != "no";
			sEmailAccount = Utils.GetValue(hbElement, "aim_email_account");
			sTitle = Utils.GetValue(hbElement, "title");
			sDescription = Utils.GetValue(hbElement, "description");
			bIsDelayed = (Utils.GetValue(hbElement, "is_delayed")).ToLower() == "yes";
			string sDelayDateTime = Utils.GetValue(hbElement, "delay_datetime");
			bEnablePublishAllButton = (Utils.GetValue(hbElement, "enable_publish_all_button")).ToLower() == "yes";
			sPublicationOrder = Utils.GetValue(hbElement, "publication_order");
			bool bIsRetry = (Utils.GetValue(hbElement, "retry_alternate")).ToLower() != "no";

			var oAlternateUrlElements = Utils.GetValues(hbElement, "$.alternate_post_url");
			if (oAlternateUrlElements != null)
			{
				foreach (string xUrl in oAlternateUrlElements)
					if (!string.IsNullOrWhiteSpace(xUrl))
						saAlternateUrls.Add(xUrl.Trim());
			}

			//Prefix AutomationName with Hosting Server name

			string sAgentId = Utils.GetValue(hbElement, "agent_id");// hbElement.Element("agent_id") == null ? "" : hbElement.Element("agent_id").Value ?? "";
			if (string.IsNullOrWhiteSpace(sAgentId))
				throw new Exception("agent_id can not be empty");
			//TODO: validate sAgentId in Store.PublicationAgents
			PublicationAgent oAgent = Store.PublicationAgents.GetPublicationAgent(sAgentId);
			if (oAgent == null)
				throw new Exception("PublicationAgent with Id " + sAgentId + " not found");

			string sProductCodes = Utils.GetValue(hbElement, "p_codes");
			string sTopicCodes = Utils.GetValue(hbElement, "t_codes");
			string sRicReferences = Utils.GetValue(hbElement, "ric_references");
			string sLanguageCode = Utils.GetValue(hbElement, "language_code");
			string sNamedItemCodes = Utils.GetValue(hbElement, "ni_code");
			string sQPriority = Utils.GetValue(hbElement, "q_priority");
			string sCategoryCode = Utils.GetValue(hbElement, "c_codes");
			string sMetaCharset = Utils.GetValue(hbElement, "charset");
			string sSlug = Utils.GetValue(hbElement, "slug");

			oHandbrakeMessage = new HandbrakeMessage(PublicationMessageType.Handbrake, oAgent, sAutomationName, sId, sQPriority, sHandbrakeName, sHandbrakeUrl);
			oHandbrakeMessage.IsActive = bIsActive;
            oHandbrakeMessage.IsLLM = bIsLlm;
            oHandbrakeMessage.Charset = sMetaCharset;
			oHandbrakeMessage.Description = sDescription;
			oHandbrakeMessage.DisplayUsnInTitle = bIsDisplayUsnInTitle;
			oHandbrakeMessage.EmailAccount = sEmailAccount;
			oHandbrakeMessage.IsUsnReadOnly = bIsUsnReadOnly;
			oHandbrakeMessage.LanguageCode = sLanguageCode;
			oHandbrakeMessage.NICodes = sNamedItemCodes;
			oHandbrakeMessage.PCodes = sProductCodes;
			oHandbrakeMessage.RICCodes = sRicReferences;
			oHandbrakeMessage.CategoryCode = sCategoryCode;
			oHandbrakeMessage.Slug = sSlug;
			oHandbrakeMessage.SkipDuplicateRemoval = bSkipDuplicateRemoval;
			oHandbrakeMessage.TCodes = sTopicCodes;
			oHandbrakeMessage.Title = sTitle;
			oHandbrakeMessage.IsHandbrake = true;
			oHandbrakeMessage.IsAutomatic = false;
			oHandbrakeMessage.IsDelayed = bIsDelayed;
			oHandbrakeMessage.EnablePublishAllButton = bEnablePublishAllButton;
			oHandbrakeMessage.Store = Store;

			DateTime oDelayDateTime = new DateTime();
			if (!string.IsNullOrWhiteSpace(sDelayDateTime))
				DateTime.TryParseExact(sDelayDateTime.Trim(), "dd:MM:yyyy:HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out oDelayDateTime);
			oHandbrakeMessage.DelayDateTime = oDelayDateTime;

			if (!string.IsNullOrWhiteSpace(sPublicationOrder))
				oHandbrakeMessage.PublicationOrder = sPublicationOrder.Split(new char[] { ',' }).Select(x => x.Trim()).ToList();

			try
			{
				// Notes
				var xAlertNotes = publicationDocument["handbrake_notes"];
				if (xAlertNotes != null && xAlertNotes.Count() > 0)
				{
					foreach (JObject note in xAlertNotes)
					{
						string sNoteName = Utils.GetValue(note, "name");
						string sNoteText = Utils.GetValue(note, "notetext");
						//oHandbrakeMessage.AlertNotes.TryAdd(sNoteName, new Note { Name = sNoteName, NoteText = sNoteText });
						oHandbrakeMessage.AddNote(new Note { Name = sNoteName, NoteText = sNoteText });
					}
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

			//Store.PublicationMessages.AddPublicationMessage(oHandbrakeMessage);
			return oHandbrakeMessage;
		}

		public PollPatternInfo LoadPollSchedule(JObject xele)
		{
			try
			{
				List<string> patterns = Utils.GetValues(xele, "$.poll_pattern");
				if (patterns != null && patterns.Count > 0)
				{
					PollPatternInfo schedule = new PollPatternInfo();
					//string[] patternItems = patterns.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

					foreach (string pattern in patterns)
					{
						string servername = "";
						if (string.IsNullOrWhiteSpace(pattern))
							continue;
						if (pattern.IndexOf("||") > 0)
						{
							string[] splits = pattern.Split(new string[] { "||" }, 2, StringSplitOptions.None);
							servername = splits[0].Trim().ToUpper();
							if (Environment.MachineName.ToUpper() != servername)
								continue;
							string[] parts = splits[1].Split('#');
							foreach (string part in parts)
							{
								string[] fields = part.Split(new char[] { ';' });
								if (fields.Length == 5)
								{
									PollPattern pollPattern = new PollPattern(fields[0].Trim(), fields[1].Trim(), int.Parse(fields[2].Trim()), int.Parse(fields[3].Trim()), int.Parse(fields[4].Trim()));
									schedule.AddPattern(pollPattern);
								}
							}
						}
						else
						{
							servername = pattern.Trim().ToUpper();
							if (Environment.MachineName.ToUpper() != servername)
								continue;
						}
						if (servername != "")
						{

						}
					}
					return schedule;
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}


		public List<PollPatternInfo> LoadPollPatterns(string config)
		{
			//try
			//{
			JObject jDoc = JObject.Parse(config);
			List<PollPatternInfo> oPollPatternInfos = new List<PollPatternInfo>();
			var oElements = jDoc["source"].ToList();
			if (oElements != null)
			{
				foreach (JObject xele in oElements)
				{
					string id = Utils.GetValue(xele, "id");
					List<string> patterns = Utils.GetValues(xele, "$.poll_pattern");
					if (patterns != null && patterns.Count > 0)
					{
						foreach (string pattern in patterns)
						{
							if (string.IsNullOrWhiteSpace(pattern))
								continue;
							PollPatternInfo pollInfo = new PollPatternInfo();
							pollInfo.SourceId = id;

							string servername = "";

							if (pattern.IndexOf("||") > 0)
							{
								string[] splits = pattern.Split(new string[] { "||" }, 2, StringSplitOptions.None);
								servername = splits[0].Trim();

								try
								{
									string[] parts = splits[1].Split('#');
									foreach (string part in parts)
									{
										string[] fields = part.Split(new char[] { ';' });
										if (fields.Length == 5)
										{
											PollPattern pollPattern = new PollPattern(fields[0].Trim(), fields[1].Trim(), int.Parse(fields[2].Trim()), int.Parse(fields[3].Trim()), int.Parse(fields[4].Trim()));
											pollInfo.AddPattern(pollPattern);
										}
									}
								}
								catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
							}
							else
							{
								servername = pattern.Trim();
							}
							if (!string.IsNullOrWhiteSpace(servername))
							{
								pollInfo.ServerName = servername;
								oPollPatternInfos.Add(pollInfo);
							}
						}
					}
				}
			}
			return oPollPatternInfos;
			//}
			//catch (Exception ex){

			//}
			//return null;
		}

		public bool ServerExists()
		{
			if (PollPatternInfoList == null)
				return true;
			return PollPatternInfoList.Any(p => p.ServerName.Equals(Environment.MachineName, StringComparison.OrdinalIgnoreCase));
		}
	}
}
