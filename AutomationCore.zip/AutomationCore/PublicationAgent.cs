using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using EAP.Core.Types;
namespace AutomationCore
{
	public class PublicationAgent
	{
		private string _usnPrefix = "EMN";
		private Dictionary<string, string> _regions;
		private Dictionary<string, string> _languages;
		private string publicationPostUrl = "";
		private HttpClient client = new HttpClient();

		public string ID
		{
			get;
			set;
		}

		public string PublisherName
		{
			get;
			set;
		}

		/// <summary>
		/// Type: GET/SET
		/// </summary>
		public string Usn
		{
			get;
			set;
		}

		public string Region
		{
			get;
			set;
		}

		public string Language
		{
			get;
			set;
		}

		public string UsnPrefix
		{
			get
			{
				return _usnPrefix;
			}
			set
			{
				_usnPrefix = string.IsNullOrWhiteSpace(value) ? "EMN" : value.Trim().ToUpper();
			}
		}

		public string ReutersUsnPrefix
		{
			get
			{
				switch (Region)
				{
					case "EMEA":
						return AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Emea;
					case "AMER":
					case "AMERS":
						return AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Amers;
					case "APAC":
						return AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Apac;
					default:
						return AutomationClient.ReutersConfig.Global.Service.UsnPrefixes.Amers;
				}
			}
		}

		public SourceStore Store { get; set; }

		public PublicationAgent()
		{
			InitializeAgent();
		}

		public PublicationAgent(string region, string language)
			: this("E", region, language)
		{

		}

		public PublicationAgent(string prefix, string region, string language)
			: this()
		{
			string sPrefix = string.IsNullOrWhiteSpace(prefix) ? "E" : prefix.Trim().ToUpper();
			this.Region = string.IsNullOrWhiteSpace(region) ? "AMER" : region.Trim().ToUpper();
			this.Language = string.IsNullOrWhiteSpace(language) ? "DEFAULT" : language.Trim().ToUpper();

			if (_regions[this.Region] != null && _languages[this.Language] != null)
				this.UsnPrefix = sPrefix + _regions[this.Region] + _languages[this.Language];

			publicationPostUrl = GetPublicationPostUrl();
		}

		private void InitializeAgent()
		{
			if (_regions == null)
				_regions = new Dictionary<string, string>();
			if (_languages == null)
				_languages = new Dictionary<string, string>();
			_regions.Add("AMER", "M");
			_regions.Add("AMERS", "M");
			_regions.Add("EMEA", "O");
			_regions.Add("APAC", "N");

			_languages.Add("DEFAULT", "N");
			_languages.Add("CHINESESIMPLIFIED", "S");
			_languages.Add("CHINESETRADITIONAL", "T");
		}
		/// <summary>
		/// Generate USN number if not already set.
		/// </summary>
		/// <returns>False if it can't generate USN</returns>
		public bool InitUsn()
		{
			return InitUsn(false);
		}

		private TimeSpan initUsnTimeout = TimeSpan.FromMilliseconds(30000);

		public bool InitUsn(bool withDelay, bool tryUsnService = true)
		{
			string sUsn = "";
			if (tryUsnService)
			{
				try
				{
					var task = Task.Run<string>(async () =>
					{
						try
						{
							var usns = await AutomationClient.ReutersConfig.GetNextUsnAsync(ReutersUsnPrefix);
							if (usns == null)
								return "";
							var usn = usns[0];
							if (Language.ToLowerInvariant().Contains("chinesetraditional"))
								usn = usn.Remove(2, 1).Insert(2, "T");
							else if (Language.ToLowerInvariant().Contains("chinesesimplified"))
								usn = usn.Remove(2, 1).Insert(2, "S");
							return usn;
						}
						catch (Exception ex)
						{
							AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); return "";
						}
					});

					if (task.Wait(initUsnTimeout))
						sUsn = task.Result;
				}
				catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
			}

			if (!string.IsNullOrWhiteSpace(sUsn))
				Usn = sUsn;
			else
				Usn = UsnPrefix + UsnManager.GetUsnId(withDelay);

			return true;
		}

		private void AddPublicationInput(PublicationItem publication, PollStatus pollStatus)
		{
			// will remove this if statement once we've updated all pollers
			if (pollStatus is UrlPollStatus pstatus)
			{
				pstatus.ChangeDetected = true;
				publication.AddInput(pstatus.SourceContent);
			}
		}

		public void SendUcdpPublication(PublicationItem publication, PollStatus pollStatus, TimeSpan? embargoTimeSpan, List<string> destinations = null)
		{
			if (publication == null)
				return;

			AddPublicationInput(publication, pollStatus);

			var embargoTime = GetEmbargoDateTimeUtc(embargoTimeSpan, AutomationClient.ReutersConfig?.Schedule?.Schedule);

			try
			{
				if (Store.AutomationClient.UcdpManager == null)
				{
					AutomationClient.ForceLog("UcdpManager is null, can't publish!", LogLevel.Error);
					return;
				}

				var publishItem = new EAPPublishType(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
					Dns.GetHostName(),
					publication,
					AutomationClient.ReutersConfig?.SyncToken);

				Store.AutomationClient.UcdpManager.Publish(publishItem, embargoTime, destinations);
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		// Format from workflow.json
		//00:40:00 => schedule start date or regular release date at 00:40:00 
		//1.00:40:00 => schedule start date or regular release date + 1 day at 00:40:00 
		private static DateTime? GetEmbargoDateTimeUtc(TimeSpan? time, Schedule schedule)
		{
			if (time.GetValueOrDefault() <= default(TimeSpan) || string.IsNullOrEmpty(schedule?.Timezone))
			{
				return null;
			}

			var scheduleTimeZone = EAP.Core.Helpers.TypeExtensions.FindTimeZone(schedule.Timezone);

			DateTime startDateLocal;

			if (schedule.StartDate.HasValue
				&& !schedule.IsRunnableUntilCompletion.GetValueOrDefault() && !schedule.IsRegularRelease.GetValueOrDefault())
			{
				startDateLocal = DateTime.SpecifyKind(schedule.StartDate.Value, DateTimeKind.Unspecified);
			}
			else
			{
				// for schedule without end time and for regular releases
				startDateLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, scheduleTimeZone).Date;
			}

			var embargoTimeLocal = startDateLocal.Add(time.GetValueOrDefault());
			var embargoDateTimeUtc = TimeZoneInfo.ConvertTimeToUtc(embargoTimeLocal, scheduleTimeZone);

			return embargoDateTimeUtc <= DateTime.UtcNow ? (DateTime?)null : embargoDateTimeUtc;
		}

		private string GetPublicationPostUrl()
		{
			try
			{
				return SourceStore.PublicationPostUrl;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error); }
			return "";
		}
	}
}
