using System.Threading;
using EAP.Core.Logging.Emsure;

namespace AutomationCore.PollExecutionState
{
	public sealed class PollActivationState : BaseExecutionState, IExecutionState
	{
		public PollActivationState(PollManager pollManager)
			: base(pollManager)
		{
			State = ExecutionState.PollActivationPending;
		}

		public ExecutionState State { get; private set; }

		public void Activate()
		{
			lock (PollManager.SyncRoot)
			{
				PollManager.IsPollingActive = true;
				AutomationClient.ForceLog($"{PollManager.Source.ID} activation started");

				if (PollManager is ISubscriptionManager pollManager)
				{
					PollManager.IsTimerActive = false;
					_ = pollManager.StartAsync();
				}

				if (PollManager.IsTimerActive)
				{
					PollManager.PollTimer ??= new Timer(PollManager.DoPollSafe, PollManager.Source,
						Timeout.Infinite, PollManager.Source.CurrentPollIntervalInMS);

					// reset poll count
					PollManager.LivePollCount = 0;
					PollManager.TotalPollCount = 0;

					// for the first poll we should start immediately and then adjust if needed. This is important for dynamic sources
					// as we should poll immediately to test if the data can be retrieved upon receiving a new url
					var startTimeMs = 0;

					// start the timer
					PollManager.PollTimer.Change(startTimeMs, PollManager.Source.CurrentPollIntervalInMS);
				}

				if (PollManager.IsReutersPollEventsEnabled && !PollManager.IsPollInitialiseSent)
				{
					Polling.Poll.Initialise(PollManager.Source.ID, PollManager.Source.GetResource());
					PollManager.IsPollInitialiseSent = true;
				}

				State = ExecutionState.PollActivationCompleted;				
			}
		}

		public void Deactivate()
		{
			lock (PollManager.SyncRoot)
			{
				if (!PollManager.IsPollingActive)
				{
					AutomationClient.ForceLog(
						$"Unable to deactivate {PollManager.Source.ID} source as it has been already deactivated");
					return;
				}

				PollManager.IsPollingActive = false;
				AutomationClient.ForceLog(
					$"{PollManager.Source.ID} deactivation started. " +
					$"Last executed command - {PollManager.Source.Store.AutomationClient.LastCommandExecuted}");


				if (PollManager is ISubscriptionManager pollManager)
				{
					pollManager.Stop();
				}

				//stop timer
				if (PollManager.PollTimer != null)
				{
					PollManager.PollTimer.Change(Timeout.Infinite, PollManager.Source.CurrentPollIntervalInMS);
					PollManager.PollTimer.Dispose();
					PollManager.PollTimer = null;
				}

				PollManager.IsTimerActive = false;

				if (PollManager.IsReutersPollEventsEnabled)
					Polling.Poll.Terminate(PollManager.Source.ID, PollManager.Source.GetResource());
				
			}
		}
	}
}
