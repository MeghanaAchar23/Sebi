using System.Linq;

namespace AutomationCore.PollExecutionState
{
	public sealed class LoadHistoryState : BaseExecutionState, IExecutionState
	{
		public LoadHistoryState(PollManager pollManager)
			: base(pollManager)
		{
			State = PollManager.Source.Store.AutomationClient.GlobalExecutionState;
		}

		public ExecutionState State { get; private set; }

		public void Activate()
		{
			AutomationClient.ForceLog?.Invoke(
				$"It's unable to activate polling in '{State}' state ");
		}

		public void Deactivate()
		{
			PollManager.Source.IsSourceActive = false;
			AutomationClient.ForceLog?.Invoke(
				$"It's unable to deactivate polling in '{State}' state. " +
				$"{PollManager.Source} was disabled." +
				"If there are not any enabled sources the automation will be stopped");

			State = ExecutionState.LoadHistoryCompleted;

			if (PollManager.Source.Store.Sources.GetAllActiveSources().Any())
			{
				return;
			}

			PollManager.Source.Store.AutomationClient.TryToStop();
		}
	}
}
