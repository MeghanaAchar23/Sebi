namespace AutomationCore.PollExecutionState
{
	public interface IExecutionState
	{
		ExecutionState State { get; }
		void Activate();
		void Deactivate();
	}

	public abstract class BaseExecutionState
	{
		protected readonly PollManager PollManager;

		protected BaseExecutionState(PollManager pollManager)
		{
			PollManager = pollManager;
		}
	}
}
