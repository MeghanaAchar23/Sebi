using EAP.Core.Configuration;
using EAP.Core.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Linq;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace AutomationCore
{
	[Obsolete("Not to be used, use Eap.Core.Elektron")]
	public class ElektronWrapper
	{
		private AutomationConfiguration _automationConfiguration;
		private EapLogger _logger;
		public ElektronWrapper()
		{
			_automationConfiguration = new AutomationConfiguration();
			_logger = EapLogger.GetLogger();
		}
		public JObject SubscribeToChanges(string[] rics)
		{
			_logger.Info("Subscribing current values for:" + string.Join(",", rics));
			try
			{
				var s = string.Format(@"{{""Rics"":[{0}]}}", string.Join(",", rics.Select(p => string.Format(@"""{0}""", p))));
				using (var client = new HttpClient())
				{
					client.DefaultRequestHeaders.Host = "elektronServiceHost";
					client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
					client.Timeout = new TimeSpan(0, 0, 30, 0);
					var req = client.PostAsync(string.Format("{0}/subscribe", _automationConfiguration.Global.Service.Elektron), new StringContent(s, Encoding.ASCII, "application/json"));
					req.Wait();
					req.Result.EnsureSuccessStatusCode();
					var response = req.Result.Content.ReadAsStringAsync();

					response.Wait();
					return (JObject)JsonConvert.DeserializeObject(response.Result);
				}
			}
			catch (Exception ex)
			{
				_logger.Error(ex);

			}
			return null;
		}
		public JArray GetHistoricRic(string[] rics)
		{
			_logger.Info("Requesting current values for:" + string.Join(",", rics));
			try
			{
				var s = string.Format(@"{{""Items"":[{0}]}}", string.Join(",", rics.Select(p => string.Format(@"{{""Ric"": ""{0}"",""Fids"": []}}", p))));
				using (var client = new HttpClient())
				{
					client.DefaultRequestHeaders.Host = "elektronServiceHost";
					client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
					var req = client.PostAsync(string.Format("{0}/history", _automationConfiguration.Global.Service.Elektron), new StringContent(s, Encoding.ASCII, "application/json"));
					req.Wait();
					req.Result.EnsureSuccessStatusCode();
					var response = req.Result.Content.ReadAsStringAsync();

					response.Wait();
					return (JArray)JsonConvert.DeserializeObject(response.Result);
				}
			}
			catch (Exception ex)
			{
				_logger.Error(ex);

			}
			return null;
		}
	}
}
