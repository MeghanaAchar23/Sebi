using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace AutomationCore
{
	/// <summary>
	/// A base class of source classes URLSource and FolderSource. This is an abstract class, must inherit to use.
	/// </summary>
	public abstract class Source
	{
		//constructor
		public Source()
		{
			ID = "";
			PollManager = null;
			Store = null;
			DefaultPollIntervalInMS = 1000;
			CurrentPollIntervalInMS = DefaultPollIntervalInMS;
			MaxPollAtTime = 10;
			PublicationMessages = new PublicationMessages();
			IsContentToBeLoggedInEachPoll = false;
			m_oRandom = new Random();
		}

		/// <summary>
		/// Gets or sets the ID of the source.
		/// </summary>
		/// <value>As specified by <b>&lt;id></b> in xml under <b>&lt;url_source></b> or <b>&lt;folder_source></b></value>
		public string ID
		{
			get;
			set;
		}

        public List<string> GroupTags
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets poll interval (in milliseconds) at which automation is currently running. By default it will be set as `DefaultPollIntervalInMS`.
        /// </summary>
        public int CurrentPollIntervalInMS
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the default poll interval in milliseconds. If not specified in xml the value will be 1000 milliseconds.
		/// </summary>
		/// <value>The number of milliseconds to wait before making a new request to the source. As specified by <b>&lt;default_interval_in_ms></b> in xml. Default value 1000 milliseconds if not specified or failed to parse.</value>
		public int DefaultPollIntervalInMS
		{
			get;
			set;
		}

		/// <summary>
		/// Determines if the source is enabled for polling or not.
		/// </summary>
		/// <remarks>
		/// Returns _true_ if the source is enabled or active.
		/// </remarks>
		/// <value>As specified by <b>&lt;active></b> in xml. Default value _false_ if not specified or failed to parse.</value>
		public bool IsSourceActive
		{
			get;
			set;
		}

		//CRN > 26-Jun-13 : adding property to indicate whether full log is required or not.
		/// <summary>
		/// Determines if the content logging is enabled or not.
		/// </summary>
		/// <remarks>
		/// Returns _true_ if the content logging at each poll is enabled.
		/// </remarks>
		/// <value>As specified by <b>&lt;enable_full_content_log></b> in xml. Default value _false_ if not specified or failed to parse.</value>
		public bool IsContentToBeLoggedInEachPoll
		{
			get;
			set;
		}

		/// <summary>
		/// Determines if the source is currently being polled or not.
		/// </summary>
		/// <remarks>
		/// Returns _true_ if polling is currently active; otherwise _false_.
		/// </remarks>
		public bool IsSourceBeingPolled
		{
			get
			{
				if (PollManager != null)
					return PollManager.IsPollingActive;
				else
					return false;
			}
		}

		/// <summary>
		/// Gets or sets an integer value for maximum polls at a time set in xml. Default value is 1 if not specified in xml.
		/// 
		/// Remarks
		/// =======
		/// Used to limit the number of concurrent polls for the source. Subsequent polls after the set value will be skipped.
		/// </summary>
		/// <value>As specified by <b>&lt;max_poll_at_time></b> in xml. Default value is 1 if not specified or failed to parse.</value>
		public int MaxPollAtTime
		{
			get;
			set;
		} = 1;

		/// <summary>
		/// Gets or sets an interger value to limit the number of polls made for the source. 
		/// 
		/// Remarks
		/// =======
		/// The source will be deactivated/stopped after the number of polls set as value.
		/// </summary>
		/// <value>As specified by <b>&lt;limit_poll_count></b> in xml. Default value 0 if not specified or failed to parse.</value>
		public int LimitPollCount
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies a object of PollManager class to manages the polls of the source
		/// </summary>
		public PollManager PollManager
		{
			get;
			set;
		}

		public ChangeDetectionMode ChangeDetectionMode { get; set; }

		public string ChangeDetectionPath { get; set; }

		public bool InspectPollOnChangeDetectedOnly { get; set; }

		/// <summary>
		/// Specifies the collection of publication messages associated with the current source
		/// </summary>
		public PublicationMessages PublicationMessages
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies the object of SourceStore class to access different properties of the SourceStore from this object itself.
		/// </summary>
		public SourceStore Store
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies the date and time at which the source was activated.
		/// </summary>
		public DateTime StartDateTime
		{
			get;
			set;
		}

		public DateTime LatestPollDateTime
		{
			get;
			set;
		}

		//random interval range parameters
		/// <summary>
		/// Gets or sets the minimum value of the random poll interval range
		/// </summary>
		public int RandomIntervalRangeStart
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the maximum value of the random poll interval range
		/// </summary>
		public int RandomIntervalRangeEnd
		{
			get;
			set;
		}

		/// <summary>
		/// An object of Random class to generate random interval between `RandomIntervalRangeStart` and `RandomIntervalRangeEnd`
		/// </summary>
		protected Random m_oRandom;

		public EAP.Core.Configuration.AutomationConfiguration.PollInterspersedMode PollInterspersedMode
		{
			get;
			set;
		} = EAP.Core.Configuration.AutomationConfiguration.PollInterspersedMode.Even;

		public bool AlignPollIntervalToWallClock { get; set; } = true;

		public string PollType
		{
			get;
			set;
		}

        public bool WebDriverFileDownload { get; set; } = false;

        public PollPatternInfo PollSchedule
		{
			get;
			set;
		}

		public long PollAttemptCount
		{
			get { return PollManager.TotalPollCount; }
		}


		public long ActualPollCount = 0;

		//public functions
		/// <summary>
		/// Activates/Starts the polling of the source
		/// 
		/// Remarks
		/// =======
		/// Executes the ActivatePolling() method of associated PollManager.
		/// </summary>
		public void Activate()
		{
			PollManager.ActivatePolling();
		}

		/// <summary>
		/// Deactivates/Stops the polling of the source
		/// 
		/// Remarks
		/// =======
		/// Executes the DeactivatePolling() method of associated PollManager.
		/// </summary>
		public void Deactivate()
		{
			PollManager.DeactivatePolling();
		}

		/// <summary>
		/// Virtual function to get the URL/Path for this source.
		/// </summary>
		/// <returns>String</returns>
		public virtual string GetResource()
		{
			return "";
		}

        /// <summary>
        /// Loads history of the source. This is a virtual function, can be overridden.
        /// 
        /// Remarks
        /// =======
        /// 1. Calls DoHistoryPoll() of PollManager
        /// 2. If current source is URL Source and `AutoLinkExtraction` is enabled then initializes the HtmlSource object of the source
        /// 3. Calls OnHistoryLoaded() method of the source
        /// 
        /// Returns _true_ if all above steps were executed successfully; otherwise _false_.
        /// </summary>
        /// <returns>Boolean</returns>
        public bool UseHistoryPolling { get; set; } = true;

		public virtual bool LoadHistory()
		{
			//poll URL for history load purpose using PollManager
			PollManager.DoHistoryPoll().GetAwaiter().GetResult();

			if (this is URLSource || this is OmniScanSource)
			{
                bool autoLinkExtraction;
                HtmlSource htmlSource;
                UrlPollStatus oStatus;
                if (this is URLSource)
                {
                    URLSource thisSource = ((URLSource)this);
                    oStatus = thisSource.History;
                    autoLinkExtraction = thisSource.AutoLinkExtraction;
                    htmlSource = thisSource.HtmlSource;
                }
                else
                {
                    OmniScanSource thisSource = ((OmniScanSource)this);
                    oStatus = thisSource.History.CreateUrlPollStatus();
                    autoLinkExtraction = thisSource.AutoLinkExtraction;
                    htmlSource = thisSource.HtmlSource;
                }

                if (autoLinkExtraction)
				{
					if (htmlSource != null)
                        htmlSource.InitializeSource(oStatus);
				}
			}

			bool result = OnHistoryLoaded();

			if (this is URLSource)
			{
				URLSource thisSource = ((URLSource)this);
				UrlPollStatus oStatus = thisSource.History;
				if (oStatus.Content != null)
				{
					if (thisSource.AlternateEncodingProcessing && oStatus.ResponseEncoding != null && oStatus.ResponseEncoding.CodePage != thisSource.Encoding.CodePage)
					{
						oStatus.ContentString = oStatus.ResponseEncoding.GetString(oStatus.Content);
						if (thisSource.AutoLinkExtraction)
						{
							if (thisSource.HtmlSource != null)
								thisSource.HtmlSource.CheckUpdates(oStatus);
						}
						oStatus.PollAttempt.LogComment("Calling OnHistoryLoaded again with encoding: " + oStatus.ResponseEncoding.WebName);
						result = OnHistoryLoaded();
					}
				}
			}

			return result;
		}

		/// <summary>
		/// Excecutes PollManager's ResetPollInterval() method if required.
		/// </summary>
		public void ResetPollInterval()
		{
			//TODO: calculate pattern interval
			long iTimeInterval = 0;

			if (PollSchedule != null)
			{
				//iTimeInterval = PollSchedule.GetCurrentPollInterval();
				PollPattern pattern = PollSchedule.GetCurrentPollPattern();
				if (pattern != null)
				{
					//TODO: check these properties before setting them
					iTimeInterval = pattern.PollInterval;
					this.MaxPollAtTime = pattern.MaxPollsAtTime;
					((URLSource)this).ConnectionTimeout = pattern.Timeout;
				}
			}
			ResetPollInterval(iTimeInterval);
		}

		public void ResetPollInterval(long timeIntervalInMS)
		{
			ResetPollInterval((int)timeIntervalInMS);
		}

		/// <summary>
		/// Gets or sets the value in milliseconds to reset the poll interval of the source.
		/// </summary>
		/// <param name="timeIntervalInMS">Value in milliseconds</param>
		public void ResetPollInterval(int timeIntervalInMS)
		{
			if (timeIntervalInMS == 0)
				timeIntervalInMS = DefaultPollIntervalInMS;

			if (timeIntervalInMS != CurrentPollIntervalInMS)
			{
				CurrentPollIntervalInMS = (int)timeIntervalInMS;
				PollManager.ResetPollInterval();
			}
		}

		/// <summary>
		/// Sets random poll interval of the PollManager of the source
		/// </summary>
		public void SetRandomPollInterval()
		{
			if (RandomIntervalRangeStart != 0 && RandomIntervalRangeEnd != 0 && RandomIntervalRangeEnd > RandomIntervalRangeStart)
			{
				int iRandomInterval = m_oRandom.Next(RandomIntervalRangeStart, RandomIntervalRangeEnd);
				ResetPollInterval(iRandomInterval);
			}
		}

		//abstract functions
		/// <summary>
		/// Will be executed followed by LoadHistory() method. Abstract method, must override in derived source class.
		/// </summary>
		/// <returns>Boolean</returns>
		public abstract bool OnHistoryLoaded();

        /// <summary>
        ///  Called after the configuration is loaded, so that the source can be customized at runtime, for example fixing up a dynamic Url. This is a virtual method, can be overridden. 
        /// </summary>        
        public virtual void OnConfigurationLoaded(SourceStore store, string configId)
        {
            return;
        }
	}

	public enum ChangeDetectionMode
	{
		[EnumMember(Value = "none")]
		None,
		[EnumMember(Value = "length")]
		Length,
		[EnumMember(Value = "content")]
		Content,
		[EnumMember(Value = "xpath")]
		XPath,
		[EnumMember(Value = "jsonpath")]
		JsonPath
	};

}
