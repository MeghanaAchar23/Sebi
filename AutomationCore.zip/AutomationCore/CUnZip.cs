using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ICSharpCode.SharpZipLib.Zip;
using System.IO.Compression;

//nuget pack icsharpcode.sharpziplib.patched

namespace AutomationCore.UnZip
{
	public class CUnZip
	{
		public CUnZip() { }
		//X-Converter-type => Zip
		//X-Zip-File-Pattern => Optional?=Yes -> Default=*.* // *.doc|*.docx|Test.pdf
		//X-Zip-Password =>Optional?=Yes -> Default="" //abcd
		public List<CUnZipFile> UnZipFileList { get; private set; } = new List<CUnZipFile>();
		public static CUnZip GetUnZipObject(byte[] ZipBuffer, out string sError)
		{
			sError = "";
			return GetUnZipObject(ZipBuffer, "*.*", "", out sError);
		}
		public static CUnZip GetUnZipObject(byte[] ZipBuffer, string sFileExtensionPattern, out string sError)
		{
			sError = "";
			return GetUnZipObject(ZipBuffer, sFileExtensionPattern, "", out sError);
		}
		public static CUnZip GetUnZipObject(byte[] ZipBuffer, string sFileNamePattern, string sPassword, out string sError)
		{
			CUnZip t_ucunzipObj = null;
			sError = "";
			try
			{
				string[] saExtensionPattern = sFileNamePattern.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
				string t_csPatternRegex = "";
				for (int t_Ind = 0; t_Ind < saExtensionPattern.Length; t_Ind++)
				{
					string spattern = saExtensionPattern[t_Ind].Trim();
					if (string.Compare(spattern, @"*.*") == 0)
					{
						t_csPatternRegex = "";
						break;
					}
					string tmpPattern = Regex.Escape(spattern);
					t_csPatternRegex += "(?:^" + tmpPattern.Replace(@"\*", @".*?") + "$)";
					if (t_Ind < saExtensionPattern.Length - 1)
						t_csPatternRegex += "|";
				}

				try
				{
					t_ucunzipObj = new CUnZip();

					ZipInputStream zipinputstream = new ZipInputStream(new MemoryStream(ZipBuffer));
					AutomationClient.ForceLog("Created ZipInputStream");
					if (zipinputstream != null)
					{
						if (sPassword != null && sPassword != string.Empty)
							zipinputstream.Password = sPassword;
						ZipEntry zipEntry;

						while ((zipEntry = zipinputstream.GetNextEntry()) != null)
						{
							if (zipEntry.IsFile)
							{
								AutomationClient.ForceLog($"Processing file {zipEntry.Name}");

								//Get extract path here and set file name in below and set path in member variable.
								string t_csTmpName = zipEntry.Name;
								string _FileName = Path.GetFileName(t_csTmpName);
								if (string.IsNullOrWhiteSpace(t_csPatternRegex) == false)
								{
									if (Regex.IsMatch(_FileName, t_csPatternRegex, RegexOptions.CultureInvariant | RegexOptions.IgnoreCase | RegexOptions.Singleline) == false)
										continue;
								}
								//byte[] _databuffer = new byte[zipEntry.Size];
								//zipinputstream.Read(_databuffer, 0, _databuffer.Length);
								byte[] _databuffer = null;
								using (MemoryStream streamWriter = new MemoryStream())
								{
									int size = 16384;
									byte[] data = new byte[16384];
									while (true)
									{
										try
										{
											size = zipinputstream.Read(data, 0, data.Length);
											if (size > 0)
												streamWriter.Write(data, 0, size);
											else
												break;
										}
										catch (Exception ex0) { sError += ex0.Message + "\r\n"; }
									}

									AutomationClient.ForceLog($"Read to memorystream completed");

									streamWriter.Seek(0, SeekOrigin.Begin);
									_databuffer = streamWriter.ToArray();
									try
									{
										streamWriter.Close();
									}
									catch { }
								}
								CUnZipFile ucuzf = new CUnZipFile(_databuffer, _FileName, zipEntry.Name);
								t_ucunzipObj.UnZipFileList.Add(ucuzf);
							}
						}
					}
				}
				catch (Exception exZip)
				{
					sError += exZip.Message + "\r\n";
				}
			}
			catch (Exception ex)
			{
				sError += ex.ToString();
			}

			return t_ucunzipObj;
		}

		public static CUnZip GetUnZipObjectForGZFile(byte[] GZFileBuffer, out string sError)
		{
			CUnZip t_ucunzipObj = null;
			sError = "";
			try
			{
				using (GZipStream stream = new GZipStream(new MemoryStream(GZFileBuffer), CompressionMode.Decompress))
				{

					// const int size = 4096;
					byte[] buffer = new byte[GZFileBuffer.Length];
					using (MemoryStream memory = new MemoryStream())
					{
						int count = 0;
						do
						{
							count = stream.Read(buffer, 0, buffer.Length);
							if (count > 0)
							{
								memory.Write(buffer, 0, count);
							}
						}
						while (count > 0);
						byte[] UnzipfileBuffer = memory.ToArray();

						t_ucunzipObj = new CUnZip();
						CUnZipFile ucuzf = new CUnZipFile(UnzipfileBuffer, "", "");
						t_ucunzipObj.UnZipFileList.Add(ucuzf);
					}
				}
			}
			catch (Exception ex)
			{
				sError += ex.ToString();
			}
			return t_ucunzipObj;
		}
	}

	public class CUnZipFile
	{
		public CUnZipFile(byte[] databuffer, string sFileName, string sFullPath)
		{
			FileDataBuffer = databuffer;
			FileName = sFileName;
			FullPath = sFullPath;
		}

		public string FileName { get; private set; } = "";
		public string FullPath { get; private set; } = "";
		public byte[] FileDataBuffer { get; private set; } = null;
	}
}
