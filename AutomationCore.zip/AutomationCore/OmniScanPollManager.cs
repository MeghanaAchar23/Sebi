using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Amazon.Lambda;
using Amazon.Lambda.Model;
using EAP.Core.Configuration;
using EAP.Core.Types;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using StackExchange.Redis;
using Amazon;
using Google.Protobuf.WellKnownTypes;
using EAP.Automation;
using System.Net.Mime;
using Tweetinvi.Core.Public.Models.Enum;
using Amazon.SimpleEmail.Model;
using Tweetinvi.Core.Events;
using System.Reflection.PortableExecutable;
using Amazon.Runtime.Internal.Transform;
using EAP.Core;
using Microsoft.Extensions.DependencyInjection;

namespace AutomationCore
{
    public record class OmniScanPollManagerOptions(
        string FunctionNamePlaceholder = "eap-{0}-omni-scan",
        string FunctionNamePlaceholderSeleniumChrome = "eap-{0}-omni-scan-selenium-chrome",
        string RedisSessionKeyPrefix = "eap:omniscan:poc",
        int RedisSessionTimeoutInSec = 60,
        int RedisSessionTTLCheckDelayInMs = 5000,
        int RedisStreamCheckDelayInMs = 10,
        int HistoryTimeountInSec = 10);

    public class OmniScanPollManager : PollManager, ISubscriptionManager
    {
        private static JsonSerializerSettings JsonSerializerSettings;

        static OmniScanPollManager()
        {
            JsonSerializerSettings = new JsonSerializerSettings();
            JsonSerializerSettings.NullValueHandling = NullValueHandling.Ignore;
            JsonSerializerSettings.Converters.Add(new StringEnumConverter());
        }

        private static Dictionary<string, string> OmniScanPollStatusFieldMap =
            typeof(OmniScanPollStatus)
            .GetProperties(bindingAttr: BindingFlags.Instance | BindingFlags.Public)
            .Where(p => p.GetCustomAttribute<JsonPropertyAttribute>() != null)
            .Select(p => (TypePropName: p.Name, JsonPropertyName: ((JsonPropertyAttribute)p.GetCustomAttribute(typeof(JsonPropertyAttribute))).PropertyName))
            .ToDictionary(a => a.TypePropName, a => a.JsonPropertyName);

        private Dictionary<string, AmazonLambdaClient> lambdaClients;
        private readonly ConnectionMultiplexer multiplexer;
        private readonly CancellationTokenSource cts;
        private readonly OmniScanSource omniScanSource;
        private readonly OmniScanPollManagerOptions options;
        private readonly SemaphoreSlim mutationSemaphore = new(1, 1);
        private readonly SemaphoreSlim historySemaphore = new(0, 1);

        private string? streamKey = null;
        private string? sessionKey = null;
        private bool started = false;
        private bool stopped = false;
        private bool historyLoaded = false;
        private bool pollStarted = false;

        public OmniScanPollManager(Source source,            
            OmniScanPollManagerOptions? options = null) : base(source)
        {
            this.options = options ?? new OmniScanPollManagerOptions();
            this.omniScanSource = (OmniScanSource)source;
            this.multiplexer = ConnectionMultiplexer.Connect(AutomationClient.ReutersConfig
               .Global
               .Service
               .RedisUrl);
            this.cts = new CancellationTokenSource();
        }

        public override async Task DoHistoryPoll()
        {
            if (historyLoaded)
                return;

            await StartAsyncCore();
            
            // set default for history in case it timesout and is not set
            this.omniScanSource.History = new OmniScanPollStatus()
            {
                BaseSource = omniScanSource,
                PollAttempt = new PollAttempt() { SourceID = omniScanSource.ID, PollID = "0" },
                ChunkAttempt = new ChunkAttempt() { SourceID = omniScanSource.ID, PollID = "0", ChunkID = "0"},
                Url = omniScanSource.Url
            };

            await historySemaphore.WaitAsync(TimeSpan.FromSeconds(
                options.HistoryTimeountInSec));
        }

        public override Task PollFunction(Source source, long pollId)
        {
            throw new NotImplementedException();
        }

        public async Task StartAsync()
        {
            pollStarted = true;
            await StartAsyncCore();
        }

        private async Task StartAsyncCore()
        {
            CheckIfStopped();

            if (started)
                return;

            try
            {
                await mutationSemaphore.WaitAsync();

                if (started)
                    return;

                string containerId = AutomationClient.ReutersConfig.Global.Container.ContainerID;
                sessionKey = $"{options.RedisSessionKeyPrefix}:{containerId}:{omniScanSource.Url}";
                streamKey = $"{sessionKey}:stream";

                InitLabmdaClients();

                await SetUpSessionKeyInRedis(sessionKey);

                _ = Task.Run(async () =>
                {
                    try
                    {
                        Task monitorTask = MonitorSessionTTL(sessionKey);

                        Task streamReadTask = ReadStream(sessionKey, streamKey);

                        try
                        {
                            await Task.WhenAll(monitorTask, streamReadTask);
                        }
                        catch (Exception ex)
                        {
                            AutomationClient.ReutersLog?.Invoke(
                                $"An error occurred in one of the tasks. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                        }
                    }
                    finally
                    {
                        CancelSafe(cts);
                    }
                });

                await LaunchLambdas(sessionKey, streamKey);

                started = true;

                AutomationClient.ReutersLog?.Invoke(
                    $"{nameof(OmniScanPollManager)} is up. SourceID = {omniScanSource.ID}", LogLevel.Info);
            }
            finally
            {
                mutationSemaphore.Release();
            }

            async Task SetUpSessionKeyInRedis(string sessionKey)
            {
                try
                {
                    IDatabase db = multiplexer.GetDatabase();
                    await db.StringSetAsync(sessionKey,
                        sessionKey,
                        TimeSpan.FromSeconds(options.RedisSessionTimeoutInSec));

                    AutomationClient.ReutersLog?.Invoke(
                        $"Session key is set in the Redis. SessionKey = {sessionKey} SourceID = {omniScanSource.ID}", LogLevel.Info);
                }
                catch (Exception ex)
                {
                    AutomationClient.ReutersLog?.Invoke(
                        $"An error occurred while setting session key into the Redis. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                    throw;
                }
            }

            async Task MonitorSessionTTL(string sessionKey)
            {
                try
                {
                    await MonitorSessionTTLCore(sessionKey);
                }
                catch (Exception ex)
                {
                    AutomationClient.ReutersLog?.Invoke(
                        $"An error occurred while monitoring session's TTL. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                }

                async Task MonitorSessionTTLCore(string sessionKey)
                {
                    IDatabase db = multiplexer.GetDatabase();

                    while (!cts.IsCancellationRequested)
                    {
                        TimeSpan? sessionTtl = await db.KeyTimeToLiveAsync(sessionKey);
                        if (sessionTtl is null && await db.StringGetAsync(sessionKey) == RedisValue.Null)
                        {
                            AutomationClient.ReutersLog?.Invoke(
                                $"Redis session is lost. Exiting the recieve loop. SourceID = {omniScanSource.ID}", LogLevel.Error);
                            break;
                        }

                        if (sessionTtl?.TotalMilliseconds <= 0.2 * options.RedisSessionTimeoutInSec * 1_000)
                        {
                            await db.KeyExpireAsync(sessionKey, TimeSpan.FromSeconds(options.RedisSessionTimeoutInSec));

                            AutomationClient.ReutersLog?.Invoke(
                                $"Updating Redis session's ttl. SourceID = {omniScanSource.ID}", LogLevel.Info);
                        }

                        await Task.Delay(options.RedisSessionTTLCheckDelayInMs);
                    }
                }
            }

            async Task ReadStream(string sessionKey,
                string streamKey)
            {
                try
                {
                    await ReadStreamCore(sessionKey, streamKey);
                }
                catch (Exception ex)
                {
                    AutomationClient.ReutersLog?.Invoke(
                        $"An error occurred while setting session key into the Redis. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                }

                async Task ReadStreamCore(string sessionKey,
                    string streamKey)
                {
                    IDatabase db = multiplexer.GetDatabase();

                    string lastReadMessage = "0-0";
                    while (!cts.IsCancellationRequested)
                    {
                        bool historyUpdate = omniScanSource.UseHistoryPolling && !historyLoaded;
                        if (historyUpdate && historyLoaded && !pollStarted)
                        {
                            await Task.Delay(options.RedisStreamCheckDelayInMs);
                            continue;
                        }

                        StreamEntry[] results = await db.StreamReadAsync(streamKey,
                            lastReadMessage);

                        foreach (StreamEntry entry in results)
                        {
                            AutomationClient.ReutersLog?.Invoke(
                                $"Received an entry from the redis stream. Id = {entry.Id} for SourceID = {omniScanSource.ID}", LogLevel.Info);

                            try
                            {
                                OmniScanPollStatus omniScanPollStatus = await ConvertResponseDoc(omniScanSource,
                                    entry,
                                    pollId: GetTimeStampFromRedisId((string)entry.Id));

                                AuditResponse(omniScanPollStatus, omniScanSource);

                                if (omniScanSource.AutoLinkExtraction)
                                {
                                    omniScanPollStatus.LinkUpdates = omniScanSource.HtmlSource.CheckUpdates(
                                        omniScanPollStatus.CreateUrlPollStatus());
                                }

                                switch (historyUpdate)
                                {
                                    case true:
                                        omniScanSource.History = omniScanPollStatus;
                                        historyLoaded = true;
                                        historySemaphore.Release();
                                        break;
                                    case false:
                                        omniScanSource.OnDataReceived(
                                            omniScanPollStatus);
                                        break;
                                }
                            }
                            catch (Exception ex)
                            {
                                AutomationClient.ReutersLog?.Invoke(
                                    $"An error occurred while executing {nameof(OmniScanSource.OnDataReceived)}. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                            }
                        }

                        if (!results.Any())
                        {
                            await Task.Delay(options.RedisStreamCheckDelayInMs);
                            continue;
                        }

                        lastReadMessage = results.Last().Id;
                    }
                }

                long GetTimeStampFromRedisId(string id)
                {
                    string[] parts = id.Split('-');
                    return long.Parse(parts[0]);
                }

                void AuditResponse(OmniScanPollStatus omniScanPollStatus,
                                   OmniScanSource source)
                {
                    AutomationRequestAuditLogBuilder audit = new AutomationRequestAuditLogBuilder();
                    
                    audit.SetRequestHeaders(omniScanPollStatus.RequestHeaders)
                         .SetResponseHeaders(omniScanPollStatus.Headers)
                         .SetUri(new Uri(omniScanSource.Url))
                         .SetStatusCode(omniScanPollStatus.HttpStatusCode)
                         .SetRequestTime(TimeSpan.FromMilliseconds(omniScanPollStatus.TimeInMs))
                         .SetRequestMethod(omniScanSource.HttpMethod.Method)
                         .SetGeoLocation(omniScanPollStatus.GeoLocation);

                    switch (omniScanPollStatus.ContentType?.MediaType)
                    {
                        case null:
                        case "":
                        case MediaTypeNames.Application.Json:
                        case MediaTypeNames.Application.Xml:
                        case MediaTypeNames.Application.Soap:
                        case MediaTypeNames.Text.Html:
                        case MediaTypeNames.Text.Plain:
                        case MediaTypeNames.Text.Xml:
                        case MediaTypeNames.Text.RichText:
                            audit.SetBody(omniScanPollStatus.Content != null ? omniScanSource.Encoding.GetString(omniScanPollStatus.Content) : null);
                            break;
                        default:
                            break;
                    }

                    AutomationClient.ReutersLogEvents(
                        NLog.LogLevel.Info,
                       $"New Content Detected: {omniScanSource.ID} {omniScanSource.HttpMethod.Method} {omniScanSource.Url} ",
                       audit.BuildJson()
                    );
                }
            }

            async Task LaunchLambdas(string sessionKey,
                string streamKey)
            {
                try
                {
                    await LaunchLambdasCore(sessionKey, streamKey);

                    AutomationClient.ReutersLog?.Invoke(
                        $"Lambdas triggered. SourceID = {omniScanSource.ID}", LogLevel.Info);
                }
                catch (Exception ex)
                {
                    AutomationClient.ReutersLog?.Invoke(
                        $"An error occurred while launching omni-scan lambdas. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
                }

                (string host, int port) GetRedisHostAndPort()
                {
                    string[] parts = AutomationClient.ReutersConfig.Global.Service.RedisUrl.Split(':');
                    if(parts.Length == 2)
                        return (parts[0], int.Parse(parts[1]));

                    return (AutomationClient.ReutersConfig.Global.Service.RedisUrl, 6379);
                }

                async Task LaunchLambdasCore(string sessionKey,
                    string streamKey)
                {
                    Caller caller = new(AutomationClient.ReutersConfig.Automation.Automation.Name,
                        AutomationClient.ReutersConfig.Global.Container.TaskARN);
                    
                    (string host, int port) = GetRedisHostAndPort();
                    RedisRequest redisRequest = new(host, port, sessionKey, streamKey);

                    var parallelOptions = new ParallelOptions
                    {
                        CancellationToken = cts.Token,
                        MaxDegreeOfParallelism = omniScanSource.OmniScanMaxDegreeOfParallelism
                    };

                    await LaunchDirectPolls(redisRequest, caller, parallelOptions);

                    await LaunchProxyLambdas(redisRequest, caller, parallelOptions);
                }

                async Task LaunchDirectPolls(RedisRequest redisRequest,
                    Caller caller, ParallelOptions parallelOptions)
                {
                    if (omniScanSource.DirectPolls?.Any() != true)
                        return;

                    await Parallel.ForEachAsync(
                           omniScanSource.DirectPolls
                               .SelectMany(dp => Enumerable.Repeat(dp.Region, dp.Count)),
                           parallelOptions,
                           async (region, ct) =>
                           {
                               if (ct.IsCancellationRequested)
                                   return;

                               await ExecuteFunction(JsonConvert.SerializeObject(
                                    new Request(redisRequest,
                                        FunctionRequest.Create(omniScanSource),
                                        caller),
                                    JsonSerializerSettings),
                                    region);
                           });
                }

                async Task LaunchProxyLambdas(RedisRequest redisRequest,
                     Caller caller, ParallelOptions parallelOptions)
                {
                    if (omniScanSource.ProxyCountries?.Any() != true)
                        return;
                    
                    ProxyType proxy = GetProxy();
                    FixupGlobalCountries();

                    await Parallel.ForEachAsync(
                        omniScanSource.ProxyCountries
                            .SelectMany(c => c.Cities?.Any() == true
                                ? c.Cities.SelectMany(city => Enumerable.Repeat((CountryCode: c.CountryCode, City: city), c.Count))
                                : Enumerable.Repeat((CountryCode: c.CountryCode, City: (string)null), c.Count)),
                        parallelOptions,
                        async (country, ct) =>
                        {
                            if (ct.IsCancellationRequested)
                                return;

                            await ExecuteFunction(JsonConvert.SerializeObject(
                                new Request(redisRequest,
                                    FunctionRequest.Create(omniScanSource, country.CountryCode, country.City, proxy),
                                    caller),
                                JsonSerializerSettings));
                        });
                }

                async Task ExecuteFunction(string payload, string? region = null)
                {
                    string environment = System.Environment.GetEnvironmentVariable("ENVIRONMENT") ?? "dev";

                    InvokeRequest request = new()
                    {
                        FunctionName = string.Format(omniScanSource.UseSeleniumChrome ? options.FunctionNamePlaceholderSeleniumChrome : options.FunctionNamePlaceholder,
                            environment),
                        InvocationType = InvocationType.Event,
                        Payload = payload,

                    };                    

                    string functionRegion = region ?? AutomationClient.ReutersConfig.Global.AwsRegion.SystemName;

                    InvokeResponse response = await lambdaClients[functionRegion].InvokeAsync(request);

                    if (response.FunctionError != null)
                    {
                        AutomationClient.ReutersLog?.Invoke(
                            $"An error occurred while invoking omni-scan lambda. SourceID = {omniScanSource.ID}. Error = {response.FunctionError}", LogLevel.Error);
                    }
                }
            }

            void InitLabmdaClients()
            {
                this.lambdaClients = new Dictionary<string, AmazonLambdaClient>();

                string currentRegion = AutomationClient.ReutersConfig.Global.AwsRegion.SystemName
                    .ToLower();
                this.lambdaClients[currentRegion] =
                    new(AutomationClient.ReutersConfig.AwsCredentialsProvider,
                        AutomationClient.ReutersConfig.Global.AwsRegion);

                foreach (DirectPoll dp in omniScanSource.DirectPolls ?? [])
                {
                    string region = dp.Region
                        .Trim()
                        .ToLower();
                    if (!lambdaClients.ContainsKey(region))
                    {
                        lambdaClients[region] = new(AutomationClient.ReutersConfig.AwsCredentialsProvider,
                            RegionEndpoint.GetBySystemName(region));
                    }
                }
            }
        }

        public void Stop()
        {
            if (!started)
            {
                stopped = true;
                return;
            }

            if (stopped)
                return;

            try
            {
                mutationSemaphore.Wait();

                if (stopped)
                    return;

                StopCore();

                omniScanSource.Store.AutomationClient.TryToStop();
            }
            catch (Exception ex)
            {
                AutomationClient.ReutersLog?.Invoke(
                    $"An error occurred while stopping {nameof(OmniScanPollManager)}. SourceID = {omniScanSource.ID}. Error = {ex.Message}", LogLevel.Error);
            }
            finally
            {
                stopped = true;
                mutationSemaphore.Release();
            }

            void StopCore()
            {
                cts.Cancel();

                omniScanSource.AsURLSource.PollManager.IsPollingActive = false;

                if (sessionKey is null)
                    return;

                IDatabase db = multiplexer.GetDatabase();
                db.KeyDelete(sessionKey);
            }
        }

        private void CheckIfStopped()
        {
            if (stopped)
                throw new Exception("Can't execute as the poller has been stopped");
        }

        private static async Task<OmniScanPollStatus> ConvertResponseDoc(OmniScanSource source,
            StreamEntry entry,
            long pollId)
        {
            byte[]? content = (byte[]?)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.Content)]];

            RedisValue? headersRaw = entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.Headers)]];
            IEnumerable<KeyValuePair<string, string>>? headers = headersRaw != RedisValue.Null
                ? JsonConvert.DeserializeObject<IEnumerable<string[]>>(headersRaw)
                        .Select(h => new KeyValuePair<string, string>(h[0], h[1]))
                : null;

            RedisValue? reqHeadersRaw = entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.RequestHeaders)]];
            IEnumerable<KeyValuePair<string, string>>? reqheaders = reqHeadersRaw != RedisValue.Null
                ? JsonConvert.DeserializeObject<IEnumerable<string[]>>(reqHeadersRaw)
                        .Select(h => new KeyValuePair<string, string>(h[0], h[1]))
                : null;

            string? contenttype = headers?.FirstOrDefault(
                 h => string.Equals(h.Key, HeaderNames.ContentType, StringComparison.OrdinalIgnoreCase))
                 .Value;

            System.Net.Http.Headers.MediaTypeHeaderValue.TryParse(contenttype, out var contentType);

            return new OmniScanPollStatus()
            {
                Content = source.AutomaticDecompression == AutomaticDecompression.On
                    ? await Decompress(headers, content)
                    : content,
                Url = (string)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.Url)]],
                Hash = (string?)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.Hash)]],
                HttpStatusCode = (int)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.HttpStatusCode)]],
                TimeInMs = (int)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.TimeInMs)]],
                Headers = headers,
                RequestHeaders = reqheaders,
                GeoLocation = (string?)entry[OmniScanPollStatusFieldMap[nameof(OmniScanPollStatus.GeoLocation)]],
                ContentType = contentType,
                BaseSource = source,
                PollAttempt = new PollAttempt
                {
                    SourceID = source.ID,
                    PollID = pollId.ToString()
                },
                ChunkAttempt = new ChunkAttempt
                {
                    SourceID = source.ID,
                    PollID = pollId.ToString(),
                    ChunkID = "0"
                }
            };

            async Task<byte[]?> Decompress(IEnumerable<KeyValuePair<string, string>>? headers, byte[]? content)
            {
                if (content == null)
                    return content;

                string? encoding = headers.FirstOrDefault(
                    h => string.Equals(h.Key, HeaderNames.ContentEncoding, StringComparison.OrdinalIgnoreCase))
                    .Value;
                if (string.IsNullOrEmpty(encoding))
                    return content;

                using MemoryStream input = new MemoryStream(content);
                using MemoryStream output = new MemoryStream();
                switch (encoding)
                {
                    case "gzip":
                        {
                            using GZipStream gzipStream = new GZipStream(input, CompressionMode.Decompress, true);
                            await gzipStream.CopyToAsync(output);
                            break;
                        }
                    case "deflate":
                        {
                            ;
                            using DeflateStream dfStream = new DeflateStream(input, CompressionMode.Decompress, true);
                            await dfStream.CopyToAsync(output);
                            break;
                        }
                    case "br":
                        {
                            using BrotliStream brStream = new BrotliStream(input, CompressionMode.Decompress, true);
                            await brStream.CopyToAsync(output);
                            break;
                        }
                    default:
                        throw new Exception($"Unsupported encoding {encoding}");
                }

                return output.ToArray();
            }
        }

        class ProxyCountryIgnoreCaseComparer : IEqualityComparer<ProxyCountry>
        {
            public bool Equals(ProxyCountry x, ProxyCountry y)
            {
                return x.CountryCode.Equals(y.CountryCode, StringComparison.CurrentCultureIgnoreCase);
            }

            public int GetHashCode(ProxyCountry obj)
            {
                return obj.CountryCode.ToLower().GetHashCode();
            }
        }

        private void FixupGlobalCountries()
        {            
            ProxyCountry? global = omniScanSource.ProxyCountries.Where(x => x.CountryCode.Equals("global", StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            if (global != null)
            {
                ProxyType? proxy = AutomationClient.ReutersConfig?.Proxy;
                if (proxy != null)
                {
                    List<ProxyCountry> countries = new List<ProxyCountry>();
                    foreach (var country in proxy.AvailableCountries)
                    {
                        countries.Add(new ProxyCountry(country.Code, null, global.Count));
                    }
                   
                    countries = omniScanSource.ProxyCountries.Union(countries, new ProxyCountryIgnoreCaseComparer()).ToList();
                    countries.Remove(countries.Where(x => x.CountryCode.Equals("global", StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault());
                    omniScanSource.ProxyCountries = countries.ToArray();
                }
            }
        }

        private static ProxyType GetProxy()
        {
            string? proxyJson = System.Environment.GetEnvironmentVariable(EnvVariableNames.PROXY);
            if (string.IsNullOrEmpty(proxyJson))
                throw new Exception($"{nameof(OmniScanPollManager)} requires {EnvVariableNames.PROXY} env var to be set");

            ProxyType? proxy = JsonConvert.DeserializeObject<ProxyType>(proxyJson);
            if (proxy == null)
                throw new Exception("Failed to parse PROXY env var into ProxyType");

            if (!proxy.Enabled)
                throw new Exception($"{nameof(OmniScanPollManager)} found {EnvVariableNames.PROXY} env var but it is disabled");

            return proxy;
        }

        private static void CancelSafe(CancellationTokenSource cts)
        {
            try { cts.Cancel(); } catch { }
        }

        class LowercaseNamingStrategy : NamingStrategy
        {
            protected override string ResolvePropertyName(string name)
            {
                return name.ToLowerInvariant();
            }

            public override string GetPropertyName(string name, bool hasSpecifiedName)
            {
                return hasSpecifiedName ? name : name.ToLowerInvariant();
            }
        }

        [JsonObject(NamingStrategyType = typeof(LowercaseNamingStrategy))]
        record class ProxySettings(
            string Proxy,
            int Port,
            string UserName,
            string Password,
            GeoTargetting GeoTargetting);

        [JsonObject(NamingStrategyType = typeof(LowercaseNamingStrategy))]
        record class GeoTargetting(string Country,
            string City);

        record class Caller(string Name, string TaskArn);

        record class Request
        {
            public Request(RedisRequest redis,
                FunctionRequest functionRequest,
                Caller caller)
            {
                Redis = redis;
                FunctionRequest = functionRequest;
                Caller = caller;
            }

            public RedisRequest Redis { get; init; }

            [JsonProperty("Request")]
            public FunctionRequest FunctionRequest { get; init; }

            public Caller Caller { get; init; }
        };

        record class RedisRequest(string Host,
            int Port,
            string SessionKey,
            string StreamKey);

        record class FunctionRequest(string Url,
            string RequestType,
            Dictionary<string, string> Headers,
            Dictionary<string, string> Form,
            List<string> AlternateUrls,
            List<int> SwitchUrlOnStatus,
            List<int> SwitchProxyOnStatus,
            string Body,
            int ConnectionTimeout,
            int RequestTimeout,
            bool AllowRedirection,
            ProxySettings? Proxy,
            float FrequencyInSeconds,
            ChangeDetectionMode ChangeDetectionMode,
            string ChangeDetectionPath,
            bool PrePollHeadCheck,
            bool UseSelenium,
            bool ProcessCacheHeaders,
            WaitForElement? WaitForElement
            )
        {
            public static FunctionRequest Create(OmniScanSource source,
                string countryCode,
                string? city,
                ProxyType proxy)
            {
                ArgumentNullException.ThrowIfNull(proxy, nameof(proxy));
                ArgumentNullException.ThrowIfNull(countryCode, nameof(countryCode));

                return CreateCore(source, countryCode, city, proxy);
            }

            public static FunctionRequest Create(OmniScanSource source)
            {
                return CreateCore(source, null, null, null);
            }

            private static FunctionRequest CreateCore(OmniScanSource source,
                string? countryCode,
                string? city,
                ProxyType? proxy)
            {
                ArgumentException.ThrowIfNullOrEmpty(source.Url, nameof(source.Url));
                
                Dictionary<string, string> defaultHeaders = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase)
                {
                    { HeaderNames.Accept.ToLower(), "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7" },                    
                    { HeaderNames.AcceptLanguage.ToLower(), "en-GB,en-US;q=0.9,en;q=0.8" },                    
                    { "priority", "u=0, i" },
                    { "sec-ch-ua", "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"" },
                    { "sec-ch-ua-arch", "arm" },
                    { "sec-ch-ua-bitness", "64" },
                    { "sec-ch-ua-form-factors", "Desktop" },
                    { "sec-ch-ua-full-version", "135.0.7049.115" },
                    { "sec-ch-ua-full-version-list", "\"Google Chrome\";v=\"135.0.7049.115\", \"Not-A.Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"135.0.7049.115\"" },
                    { "sec-ch-ua-mobile", "?0" },
                    { "sec-ch-ua-model", "\"MacBookPro16,1\"" },
                    { "sec-ch-ua-platform", "\"macOS\"" },
                    { "sec-ch-ua-platform-version", "\"14.7.5\"" },
                    { "sec-ch-ua-wow64", "?0" },
                    { "sec-fetch-dest", "document" },
                    { "sec-fetch-mode", "navigate" },
                    { "sec-fetch-site", "same-origin" },
                    { "upgrade-insecure-requests", "1" },
                    { "x-browser-channel", "stable" },
                    { "x-browser-copyright", "Copyright 2025 Google LLC. All rights reserved." },
                    { "x-browser-validation", "13HBm07VQc7qHh1u8F6WtUTUItA=" },
                    { "x-browser-year", "2025" }
                };
                
                // merge default headers
                Dictionary<string, string> headers = null;
                if (source.RequestHeaders != null)
                {
                    headers = new Dictionary<string, string>(source.RequestHeaders, StringComparer.InvariantCultureIgnoreCase);
                    foreach(var header in defaultHeaders)
                    {
                        headers.TryAdd(header.Key, header.Value);
                    }
                }
                else
                {
                    headers = defaultHeaders;
                }

                // set user agent, from request, from config or from resolver
                string userAgent = null;
                headers.TryGetValue(HeaderNames.UserAgent.ToLower(), out userAgent);

                userAgent = AutomationClient.ReutersConfig.UserAgentResolver?.Resolve(
                      configUserAgents: userAgent != null ? new string[] { userAgent } : source.ConfigUserAgents,
                      configFullDbResolve: source.ConfigFullDbResolve,
                      configStrategy: source.ConfigResolveStrategyEnum);

                headers[HeaderNames.UserAgent.ToLower()] = userAgent;

                if (source.AutomaticDecompression == AutomaticDecompression.On)
                {
                    headers.TryAdd(HeaderNames.AcceptEncoding.ToLower(), "gzip, deflate, br");
                }

                return new FunctionRequest(source.Url,
                    source.HttpMethod.Method,
                    headers,
                    source.Form,
                    source.AlternateUrls,
                    source.SwitchUrlOnStatus,
                    source.SwitchProxyOnStatus,
                    source.Body,
                    source.ConnectionTimeout,
                    source.RequestTimeout,
                    source.AllowRedirection,
                    proxy != null
                        ? new ProxySettings(proxy.Address,
                            proxy.Port,
                            proxy.Credentials?.Username,
                            proxy.Credentials?.Password,
                            new GeoTargetting(countryCode, city))
                        : null,
                    source.DefaultPollIntervalInMS / 1_000f,
                    source.ChangeDetectionMode,
                    source.ChangeDetectionPath,
                    !source.UseHistoryPolling,// if UseHistoryPolling is true, then PrePollHeadCheck should be false
                    source.UseSeleniumChrome,
                    source.ProcessCacheHeaders,
                    source.WaitForElement
                    ); 
            }
        }
    }
}
