using System;
using System.Threading;
using System.Threading.Tasks;
using EAP.Core.Elektron;
using EAP.Core.Elektron.Contracts;
using EAP.Core.Elektron.Dual;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Tweetinvi.Core.Extensions;

namespace AutomationCore.Idn
{
	public class IdnPollManager : PollManager
	{
		protected readonly Lazy<IElektronManager> ElektronManager;
		protected IdnSource IdnSource => (IdnSource)Source;

		public IdnPollManager(Source oSource) : base(oSource)
		{
			ElektronManager = new Lazy<IElektronManager>(() =>
            {
                IElektronManager manager = ElektronManagerFactory.Create(
                    (int)IdnSource.Timeout.TotalSeconds);
                manager.StartAsync().Wait();
                return manager;
            });
		}

		public override async Task PollFunction(Source source, long pollId)
		{
			var idnSource = (IdnSource)source;

			var pollStatus = new IdnPollStatus
			{
				PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() }
			};

			pollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());

			pollStatus.Source = idnSource;

			//log start time
			pollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
				pollStatus.Result = await ElektronManager.Value
					.GetHistoricalDataAsync(idnSource.IdnPages, idnSource.Fields);

                pollStatus.PollAttempt.LogComment($"PollFunction. Historical data received. {IdnSource}");

				pollStatus.ChunkAttempt = pollStatus.PollAttempt.NewChunkAttempt("1");
				pollStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
				idnSource.OnDataReceived(pollStatus);
				pollStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;
			}
			catch (Exception ex)
			{
				pollStatus.PollAttempt.LogError(
					$"PollFunction. History request request fails: {idnSource}. Exception: {ex}");
			}

			//log end time
			pollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(source.ID, pollId.ToString(), 0,
					pollStatus.PollAttempt.ToJson());
			}
		}

		public override async Task DoHistoryPoll()
		{
			var idnSource = (IdnSource)Source;

			if (IsReutersPollEventsEnabled && !IsPollInitialiseSent)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Initialise(idnSource.ID, idnSource.GetResource());
				IsPollInitialiseSent = true;
			}

			var status = new IdnPollStatus
			{
				PollAttempt = new PollAttempt() { SourceID = idnSource.ID, PollID = "0" }
			};

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Start(idnSource.ID, status.PollAttempt.PollID.ToString());
			}


			status.PollAttempt.PollStartTime = DateTime.UtcNow;

			status.Source = idnSource;

			status.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
				status.Result = await ElektronManager.Value
					.GetHistoricalDataAsync(idnSource.IdnPages, idnSource.Fields);

				status.PollAttempt.LogComment(
					$"OnHistoryLoad. Historical data received {IdnSource}");
			}
			catch (Exception ex)
			{
				status.PollAttempt.LogError($"OnHistoryLoad. History request fails: {idnSource}. Exception: {ex}");
			}

			status.PollAttempt.RequestEndTime = DateTime.UtcNow;

			idnSource.History = status;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(idnSource.ID, status.PollAttempt.PollID);
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(idnSource.ID, status.PollAttempt.PollID, 0,
					status.PollAttempt.ToJson());
			}
		}		
	}

	public class IdnSubscriptionManager : IdnPollManager, ISubscriptionManager
	{
		private readonly CancellationTokenSource _cancellationTokenSource;
		private readonly TimeSpan _subscriptionTimeout = TimeSpan.FromSeconds(180);

		public IdnSubscriptionManager(Source oSource) : base(oSource)
		{
			_cancellationTokenSource = new CancellationTokenSource();
		}

		public Task StartAsync()
		{
			try
			{
				if (IdnSource.IdnPages.IsNullOrEmpty())
				{
					AutomationClient.ForceLog?.Invoke("IdnPollManager couldn't start subscribing. Rics list is empty",
						LogLevel.Warn);
				}

				AutomationClient.ReutersLog?.Invoke("IdnPollManager started subscribing on " +
					$"{string.Join(", ", IdnSource.IdnPages ?? Array.Empty<string>())}",
					LogLevel.Info);

				long _ = 0;
				OnPollStart(ref _);

				if (IdnSource.IdnPages != null)
				{
					Task.Run(async () =>
					{
						using CancellationTokenSource cts = new(_subscriptionTimeout);
						await ElektronManager.Value.SubscribeAsync(IdnSource.IdnPages,
							IdnSource.IsPage,
							OnData,
                            OnData,
                            OnError,
							cts.Token);
					});
				}
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog?.Invoke(
					ex.Message + ex.InnerException?.Message, LogLevel.Error);
			}

			return Task.CompletedTask;
		}

		public void Stop()
		{
			AutomationClient.ForceLog?.Invoke($"IdnPollManager {IdnSource.ID} before stopping", LogLevel.Info);

			try
			{
				ElektronManager.Value.UnsubcribeAsync(IdnSource.IdnPages)
					.Wait();
				OnPollEnd();
				_cancellationTokenSource.Cancel();
			}
			catch (Exception e)
			{
				AutomationClient.ForceLog?.Invoke(
					$"IdnPollManager {IdnSource.ID} couldn't make unsubscription for" +
					$"{string.Join(", ", IdnSource.IdnPages)}. Error - {e}",
					LogLevel.Error);
				return;
			}

			AutomationClient.ForceLog?.Invoke(
				$"IdnPollManager {IdnSource.ID} unsubscribed",
				LogLevel.Info);

			Source.Store.AutomationClient.TryToStop();
		}

		private Task OnData(ElektronResult result)
		{
			var pollStatus = new IdnPollStatus
			{
				Result = result != null
				? new[] { result }
				: Array.Empty<ElektronResult>(),
				Source = IdnSource,
				PollAttempt = new PollAttempt
				{
					SourceID = IdnSource.ID
				},
				ChunkAttempt = new ChunkAttempt
				{
					SourceID = IdnSource.ID
				}
			};

			try
			{
				IdnSource.OnDataReceived(pollStatus);
			}
			catch (Exception e)
			{
				pollStatus.PollAttempt.LogError(e.Message + e.InnerException?.Message);
			}

			return Task.CompletedTask;
		}

		private static Task OnError(TerminatedSubscriptionInfo info)
		{
			AutomationClient.ReutersLog?.Invoke(
				$"An error occurred while processing the response. {info.ErrorMessage}", LogLevel.Error);

			return Task.CompletedTask;
		}

		public override Task PollFunction(Source source, long pollId)
		{
			return Task.CompletedTask;
		}
	}

	public class IdnPollStatus : PollStatus
	{
		public IdnSource Source
		{
			get => (IdnSource)BaseSource;
			set => BaseSource = value;
		}

		public ElektronResult[] Result { get; set; }
	}
}
