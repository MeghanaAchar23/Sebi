using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EAP.Core.Elektron.Dual;
using EAP.Core.Elektron;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace AutomationCore.Idn
{
    internal static class ElektronManagerFactory
    {
        public static IElektronManager Create(
            int historyRequestTimeoutSeconds = 180)
        {
            var tokenProvider = AutomationClient.ReutersConfig.TokenProvider;

            ServiceCollection services = new();
            services.AddLogging(b =>
            {
                b.ClearProviders();
                b.AddNLog();
            });
            IServiceProvider sp = services.BuildServiceProvider();

            switch (new ConfigBasedElektronManagerResolver(AutomationClient.ReutersConfig.Global).Resolve())
            {
                case EAP.Core.Configuration.ElektronServiceType.New:

                    return new ElektronManagerShim(
                         new ElektronManager(
                            AutomationClient.ReutersConfig.Global,
                            tokenProvider,
                            sp.GetRequiredService<ILoggerFactory>(),
                            new ClientReliabilityOptions()
                            {
                                AutoReconnectEnabled = true,
                                RetryConnectionForever = true,
                                ConnectionRetryMaxRetryDelayInSec = 10,
                                RetryOpForever = true,
                                OpRetryMaxRetryDelayInSec = 10
                            },
                            AutomationClient.ReutersConfig.Global.Service.Elektron));

                case EAP.Core.Configuration.ElektronServiceType.Dual:

                    return new DualElektronManagerWithTotalFallback(
                        CreateLegacyElektronManager(),
                        new ElektronManager(
                            AutomationClient.ReutersConfig.Global,
                            tokenProvider,
                            sp.GetRequiredService<ILoggerFactory>(),
                            new ClientReliabilityOptions()
                            {
                                AutoReconnectEnabled = true,
                                RetryConnectionForever = false,
                                ConnectionRetryMaxRetryDelayInSec = 10,
                                MaxConnectionRetryAttempts = 3,
                                RetryOpForever = false,
                                OpRetryMaxRetryDelayInSec = 10,
                                MaxOpRetryAttempts = 2
                            },
                            AutomationClient.ReutersConfig.Global.Service.Elektron),
                        sp.GetRequiredService<ILoggerFactory>().CreateLogger<DualElektronManagerWithTotalFallback>());

                default:

                    return new LegacyElektronManagerShim(
                        CreateLegacyElektronManager());
            }

            EAP.Core.Elektron.Legacy.ElektronManager CreateLegacyElektronManager() =>
                new EAP.Core.Elektron.Legacy.ElektronManager(
                    tokenProvider,
                    AutomationClient.ReutersConfig.Global.Service.ElektronLegacy,
                    executorType: EAP.Core.Elektron.Legacy.SubscriptionRequestExecutorType.Sequential,
                    historyRequstTimeoutSeconds: historyRequestTimeoutSeconds);
        }
    }
}
