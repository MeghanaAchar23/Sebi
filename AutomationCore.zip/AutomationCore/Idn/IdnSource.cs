using System;

namespace AutomationCore.Idn
{
	public abstract class IdnSource : Source
	{
		public TimeSpan Timeout { get; set; }
		public string[] IdnPages { get; set; }
		public int[] Fields { get; set; }
		public bool IsPage { get; set; }		
		public IdnPollStatus History { get; set; }
        public enum IdnPollTypeEnum
        {
            History,
            Subscription
        }
        public IdnPollTypeEnum IdnPollType { get; set; } = IdnPollTypeEnum.Subscription;

        public void Initialize()
		{
			PollManager = IdnPollType == IdnPollTypeEnum.History
                ? new IdnPollManager(this)
				: new IdnSubscriptionManager(this);
		}

		public override string GetResource()
		{
			return $"{IdnPages?.ToJson()}\r\n{Fields?.ToJson()}";
		}

		public override string ToString()
		{
			return
				$"Rics: {string.Join(" , ", IdnPages ?? Array.Empty<string>())} . " +
				$"Fids: {string.Join(" , ", Fields ?? Array.Empty<int>())}";
		}

		public abstract void OnDataReceived(IdnPollStatus pollStatus);
	}
}
