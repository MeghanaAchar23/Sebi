using EAP.FileConversion.Service.Client;
using LazyCache;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationCore
{
	public enum PDFVerionTypeEnum
	{
		WinnovativePDFTOText_2012 = 0,
		WinnovativePDFTOText_2016 = 1
	}

	public enum PDFConversionLayoutEnum
	{
		OriginalLayout = 0,
		ReadingLayout = 1,
		TableModeLayout = 2,
		FixedLineSpacingLayout = 3,
		PdfInternalOrderLayout = 4
	}

	/// <summary>
	///  Convert PDF to text using Web service.
	/// </summary>
	public class PDFToText
	{
		private readonly Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory;

		/// <summary>
		/// Retry count to call each web service: Default value is 5.
		/// </summary>
		public int RetryCount { get; set; } = 5;
		/// <summary>
		/// Timed out in seconds to call web service, default value is 30 seconds.
		/// </summary>
		public int TimedOutInSeconds { get; set; } = 30;

		/// <summary>
		/// PDF version Type: Based on input Winnovative pdf to text dll will use, By default value is WinnovativePDFTOText_2012.
		/// </summary>
		public PDFVerionTypeEnum PDFVersionType { get; set; } = PDFVerionTypeEnum.WinnovativePDFTOText_2012;
		/// <summary>
		/// PDF conversion Layout: will use only in case of WinnovativePDFTOText_2016, Bydefault value is OriginalLayout.
		/// </summary>
		public PDFConversionLayoutEnum PDFConversionLayout { get; set; } = PDFConversionLayoutEnum.OriginalLayout;

		/// <summary>
		/// If value is true then Page breaks line will include between page data, Bydefault value is true.
		/// </summary>
		public bool IsMarkPageBreaksRequire { get; set; } = true;
		/// <summary>
		/// It will provide from given page number, Bydefalut value ins int.MinValue.
		/// </summary>
		public int StartPageNumber { get; set; } = int.MinValue;
		/// <summary>
		///  It will provide output upto endpage number(including end page number), Bydefalut value ins int.MinValue.
		/// </summary>
		public int EndPageNumber { get; set; } = int.MinValue;

		#region Constructors

		/// <summary>
		/// Creates an instance of PDFToText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public PDFToText(int ttlInSeconds = 24 * 3600)
		{
			this.fileConversionServiceClientFactory = FileConversionServiceClientFactory.CreateDefaultFactory(ttlInSeconds, TimedOutInSeconds, RetryCount);
		}

		/// <summary>
		/// Creates an instance of PDFToText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="pdfVersionType">PDF Version Type</param>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public PDFToText(PDFVerionTypeEnum pdfVersionType,
			int ttlInSeconds = 24 * 3600) : this(ttlInSeconds)
		{
			PDFVersionType = pdfVersionType;
		}

		/// <summary>
		///  Creates an instance of PDFToText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="pdfVersionType">PDF Version Type</param>
		/// <param name="pdfConversionLayout">PDF Layout</param>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public PDFToText(PDFVerionTypeEnum pdfVersionType,
			PDFConversionLayoutEnum pdfConversionLayout,
			int ttlInSeconds = 24 * 3600) : this(ttlInSeconds)
		{
			PDFVersionType = pdfVersionType;
			PDFConversionLayout = pdfConversionLayout;
		}

		public PDFToText(Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory)
		{
			this.fileConversionServiceClientFactory = fileConversionServiceClientFactory ?? throw new ArgumentNullException(nameof(fileConversionServiceClientFactory));
		}
		#endregion

		/// <summary>
		/// Convert PDF buffer in to text.
		/// </summary>
		/// <param name="pdfbuffer">PDF buffer</param>
		/// <param name="sOutputText">Output text</param>
		/// <param name="sError">set error in case of unsuccessful</param>
		/// <returns>if converted successfully then return true otherwise return false</returns>
		public bool GetPDFTotext(byte[] pdfbuffer, ref string sOutputText, ref string sError)
		{
			sError = sOutputText = "";
			try
			{
				sOutputText = GetPDFTotextAsync(new MemoryStream(pdfbuffer))
					.GetAwaiter()
					.GetResult();

				return true;
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.ToString();
			}
			return false;
		}

		public async Task<string> GetPDFTotextAsync(Stream pdfFileStream, CancellationToken cancellationToken = default)
		{
            var isValidPDF = await PDFValidator.IsPDFAsync(pdfFileStream);
            if (!isValidPDF)
            {
                throw new ArgumentException("Given file is not valid PDF");
            }
			var client = await fileConversionServiceClientFactory();

			AutomationClient.ForceLog("PDFToText.GetPDFTotextAsync started");

			string text = string.Empty;

			switch (PDFVersionType)
			{
				case PDFVerionTypeEnum.WinnovativePDFTOText_2012:
					text = await client.ConvertPdfViaWinnovative2012Async(pdfFileStream,
						new Winnovative2012PdfToTextOptions()
						{
							MarkPageBreaks = IsMarkPageBreaksRequire,
							StartPageNumber = StartPageNumber != int.MinValue ? StartPageNumber : null,
							EndPageNumber = EndPageNumber != int.MinValue ? EndPageNumber : null
						},
						cancellationToken);
					break;

				case PDFVerionTypeEnum.WinnovativePDFTOText_2016:
					text = await client.ConvertPdfViaWinnovative2016Async(pdfFileStream,
						new Winnovative2016PdfToTextOptions()
						{
							MarkPageBreaks = IsMarkPageBreaksRequire,
							StartPageNumber = StartPageNumber != int.MinValue ? StartPageNumber : null,
							EndPageNumber = EndPageNumber != int.MinValue ? EndPageNumber : null,
							Layout = (Winnovative2016TextLayout)(int)PDFConversionLayout
						},
						cancellationToken);
					break;
			}

			AutomationClient.ForceLog("PDFToText.GetPDFTotextAsync finished");

			return text;
		}
	}
}
