using System;
using System.Net;
using System.Text;
using EAP.Core.Logging;
using EAP.Core.Helpers;
using EAP.Automation.HttpClient;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using Refit;

namespace AutomationCore
{
	/// <summary>
	/// Provides base class to URL sources in xml. This is an abstract class, must inherit to use.
	/// </summary>
	/// <remarks>
	/// Every web source as specified by &lt;url_source> in xml must have the associated class inherited from URLSource. URLSource class provides the properties and methods related to web requests.
	/// URLPollManager provides the timer for polling the source.
	/// </remarks>
	public abstract class URLSource : Source
	{
		private string _url = null;
		private string m_sXRequestor = "Thomson Reuters; TR-EAP@ThomsonReuters.com";
		protected CookieContainer m_oCookieContainer;
		protected readonly object m_oSyncLock = new object();

		public ProcessCacheResponse ProcessCacheResponse { get; set; }

		public HttpInputEvent AuditEvent { get; set; }

		public HttpOptions Options
		{
			get
			{
				HttpOptions options = HttpOptions.None;
				if (UrlRedirectionHandling)
					options |= HttpOptions.AllowRedirect;
				if (KeepAliveConnection)
					options |= HttpOptions.KeepAlive;
				if (ChunkProcessing)
					options |= HttpOptions.ChunkProcessing;
				if (AppendSessionIDInUrl)
					options |= HttpOptions.AppendSessionId;
				if (GzipCompression)
					options |= HttpOptions.EnableCompression;
				if (Cookie)
					options |= HttpOptions.AllowCookie;

				return options;
			}
		}

		/// <summary>
		/// Creates a new instance of URLSource class with optional PollManager.
		/// </summary>
		public URLSource(PollManager pollManager = null)
			: base()
		{
			KeepAliveConnection = true;
			History = new UrlPollStatus();
			ConnectionTimeout = 30;
			ConnectionLeaseTimeoutInMs = 300000;
			PollManager = pollManager ?? new URLPollManager(this);
			Encoding = Encoding.UTF8;
			AppendUniqueTimestampInUrl = "";
			PostData = "";
			StartByteRange = 0;
			EndByteRange = 0;
			AlternateEncodingProcessing = true;
			HtmlSource = new HtmlSource();
			RequestHeaders = new WebHeaderCollection();
			Expect100Continue = false;
			ProcessCacheResponseHeaders = false;

			/*
			try
			{
				//TODO: Get X-REQUESTOR from config
				string t_sXRequestor = "";// System.Configuration.ConfigurationManager.AppSettings["X-REQUESTOR"] ?? "";
				if (!string.IsNullOrWhiteSpace(t_sXRequestor))
					m_sXRequestor = t_sXRequestor;
			}
			catch { }*/
		}

		/// <summary>
		/// Specifies if the source URL will have the cache buster parameter appended at the end of the URL. Default value is _false_.
		/// </summary>
		/// <remarks>
		/// If the value specified is _true_ then at each poll to the source library will append a timestamp value at the end of the PollUrl. Sometimes it is require to have this parameter as a cache buster so the website could return the latest data.
		/// Default value is _false_ that means it will not append any value in the PollUrl.
		/// </remarks>
		public bool AppendSessionIDInUrl
		{
			get;
			set;
		}

		/// <summary>
		/// Determines if the request content hast to be processed chunk-wise. This property is no longer used as now all the requests are process chunk-wise.
		/// </summary>
		public bool ChunkProcessing
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies if the cookie has to be enabled at every request. Default value is _false_.
		/// </summary>
		/// <remarks>
		/// If the value is _true_ it will store the cookies from the website response in the CookieContainer and will pass to consecutive requests made to the source so the further requests will be made with the cookies stored in the CookieContainer.
		/// Defult value is _false_ that means cookies are not allowed.
		/// </remarks>
		public bool Cookie
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies if requests will be made with _Connection: Keep-alive_ header. Default value is _true_.
		/// </summary>
		public bool KeepAliveConnection
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies if requests has to allow automatic redirections from the website. Default value is _false_.
		/// </summary>
		/// <remarks>
		/// If the value is _true_ then automatic redirections will be allowed.
		/// </remarks>
		public bool UrlRedirectionHandling
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies if the requests should send the header _Accept-Encoding: gzip_ to receive gzip encoded response.
		/// </summary>
		public bool GzipCompression
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets a value in seconds for request timeout.
		/// </summary>
		public int ConnectionTimeout
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets a value of the URL of the source.
		/// </summary>
		public string Url
		{
			get
			{
				return _url;
			}
			set
			{
				_url = value;
			}
		}

        public List<string>? AlternateUrls
        {
            get;
            set;
        }

        public string UrlHash
		{
			get
			{
				string postData = string.IsNullOrWhiteSpace(PostData) ? "" : PostData;
				string urlHash = Utils.GetMD5Hash(Url + postData);
				return urlHash;
			}
		}

		/// <summary>
		/// Gets or sets an expected encoding in which the response content might be recieved.
		/// </summary>
		public Encoding Encoding
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the PostBack parameters to be sent at every request.
		/// </summary>
		public string PostData
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the UrlPollStatus of history poll.
		/// </summary>
		/// <remarks>
		/// History will provide the content of the reuwest made during LoadHistory method. If AutoLinkExtraction is enabled then it will store all the links found at every request to the source.
		/// </remarks>
		public UrlPollStatus History
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the parameter to send as cache buster at each request.
		/// </summary>
		/// <remarks>
		/// Value to be set depends on the URL of the source. If URL already contains the querystring then the value shoud be something like "?name", otherwise "&name". "name" can be any word.
		/// On every request to the URL a timestamp value will be appended to the parameter specified separated by '=' (i.e., "?name=2015050414071234567") and appended to the URL before requesting.
		/// This works as a cache buster for some websites so that each request made to the webiste will be considered as a new request.
		/// </remarks>
		public string AppendUniqueTimestampInUrl
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the value of the start byte range for the begining of the requested data.
		/// </summary>
		public Int64 StartByteRange
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the value of the end byte range for the ending of the requested data.
		/// </summary>
		public Int64 EndByteRange
		{
			get;
			set;
		}

		public string ResponseType
		{
			get;
			set;
		}

		/// <summary>
		/// If overriden in derived class it will do some processing on the history content and returns status accordingly. By default this will return true if not overrided in the derived class.
		/// </summary>
		public override bool OnHistoryLoaded()
		{
			return true;
		}

		/// <summary>
		/// Returns the URL of the source.
		/// </summary>
		/// <returns></returns>
		public override string GetResource()
		{
			return Url;
		}

		/// <summary>
		/// Gets or sets a collection to store the cookies received from the server.
		/// </summary>
		public virtual CookieContainer CookieContainer
		{
			get
			{
				lock (m_oSyncLock)
				{
					if (m_oCookieContainer == null)
					{
						m_oCookieContainer = new CookieContainer();
					}
				}
				return m_oCookieContainer;
			}
			set
			{
				lock (m_oSyncLock)
				{
					if (m_oCookieContainer == value)
						return;
					m_oCookieContainer = value;
				}
			}
		}

		/// <summary>
		/// Gets or sets a boolean value indicating if the alternate encoding processing is enabeld or not.
		/// </summary>
		public bool AlternateEncodingProcessing
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the value of Content-Type header received in the response from the server.
		/// </summary>
		public string RequestContentType
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the URL specified as a previously requested URL to the server.
		/// </summary>
		public string UrlReferer
		{
			get;
			set;
		}

		/// <summary>
		/// HtmlSource object to manage the link extraction and history.
		/// </summary>
		public HtmlSource HtmlSource
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets a value indicating if automatic link extraction is enabled or not.
		/// </summary>
		public bool AutoLinkExtraction
		{
			get;
			set;
		}

		/// <summary>
		/// A collection of the header name/value pair to be sent in the header in the request.
		/// </summary>
		public WebHeaderCollection RequestHeaders
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets whether to send Expect: 100-Continue header in the request.
		/// </summary>
		public bool Expect100Continue
		{
			get;
			set;
		}

		public bool ProcessCacheResponseHeaders { get; set; }

		public bool CacheControlNoCache
		{
			get;
			set;
		}

		public bool CacheControlNoStore
		{
			get;
			set;
		}

		public int SpiderLinuxHostCount
		{
			get;
			set;
		}

		public string XRequestorHeader
		{
			get
			{
				return m_sXRequestor;
			}
			set
			{
				m_sXRequestor = value;
			}
		}

		public string CertificateName
		{
			get; set;
		}

		public string CertificatePassword
		{
			get; set;
		}

		public int ConnectionLeaseTimeoutInMs
		{
			get; set;
		}

		public ResolveStrategyEnum ConfigResolveStrategyEnum
		{
			get; set;
		}

		public bool ConfigFullDbResolve
		{
			get; set;
		}

		public string[] ConfigUserAgents
		{
			get; set;
		}

        public WebDriverType? WebDriverType { get; set; }

        public int? SeleniumPagePostLoadWaitInMs { get; set; }

        public Version? HttpVersion { get; set; }

        public ReliableAutomationHttpHandlerConfig? ReliableAutomationHttpHandlerConfig
		{
			get; set;
		}

		/// <summary>
		/// Derived class can override if wants to process content in chunk. This is an abstract method.
		/// </summary>
		//public virtual void OnChunkReceived(ref byte[] abChunk, ref byte[] abFullContent) { }

		/// <summary>
		/// Derived class must need to override to process data received in a URL poll. This is an abstract method.
		/// </summary>
		public abstract void OnDataReceived(UrlPollStatus oUrlPollStatus);

		/// <summary>
		/// Derived class can override if wants to do post processing once the request is complete. This is virtual method.
		/// </summary>
		/// <param name="oUrlPollStatus"></param>
		public virtual void OnRequestCompleted(UrlPollStatus oUrlPollStatus)
		{
			return;
		}

        private string PreviousHash = string.Empty;
        private long PreviousContentSize = -1;


        public virtual void OnChangeDetectionCheck(UrlPollStatus oUrlPollStatus)
        {
            string hash = string.Empty;
			double percentageOfContentSizeChange = 0.0;

			byte[] content = oUrlPollStatus.Content;
            string contentString = oUrlPollStatus.ContentString;

			// SDK provided change detection logic
			oUrlPollStatus.ChangeDetected = ChangeDetectionHandler.DetectChange(ChangeDetectionMode, ChangeDetectionPath, content, contentString, ref PreviousHash, ref PreviousContentSize, out percentageOfContentSizeChange);

			// legacy automations will need to always have the callback invoked as they detect content change in their user code
			// in the future they can make use of the change detection logic provided here in the SDK and choose to only invoke
			// their user code when a change has actually been detected
			if ((oUrlPollStatus.ChangeDetected && InspectPollOnChangeDetectedOnly == true) || InspectPollOnChangeDetectedOnly == false)
			{
				// invoke the data received callback, which may call to publish and use the referenced metadata
				OnDataReceived(oUrlPollStatus);

				// now check again if the content has changed in case content change detection logic is done inside on data received function
				if (oUrlPollStatus.ChangeDetected)
				{
					// SourceContent is now set in the ChangeDetected property setter
					Task.Run(() => ChangeDetectionHandler.StoreSourceContent(oUrlPollStatus.Content, oUrlPollStatus.SourceContent));
				}

				AuditOnChangeDetected(oUrlPollStatus, content, percentageOfContentSizeChange);
            }

            return;
        }

        private void AuditOnChangeDetected(UrlPollStatus oUrlPollStatus, byte[] content, double percentageOfContentSizeChange)
        {
            if (oUrlPollStatus.ChangeDetected)
            {
                switch (ChangeDetectionMode)
                {
                    case ChangeDetectionMode.Length:
                        {
                            AutomationClient.ReutersLogEvents(NLog.LogLevel.Info,
								$"Poll change detection, " +
                                $"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"New Content Detected: {this.ID} {this.Url} " +
                                $"Content size differs by {Math.Round(percentageOfContentSizeChange, 1)}% " +
                                $"Current content size: {content.Length} " +
                                $"Previous content size: {this.PreviousContentSize}",
                                oUrlPollStatus.Audit.BuildJson());
                            break;
                        }
                    default:
                        {
                            AutomationClient.ReutersLogEvents(NLog.LogLevel.Info,
								$"Poll change detection, " +
                                $"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"New Content Detected: {this.ID} {this.Url} ",
                                oUrlPollStatus.Audit.BuildJson());
                            break;
                        }
                }
            }
            else
            {
                switch (ChangeDetectionMode)
                {
                    case ChangeDetectionMode.Length:
                        {
                            AutomationClient.ReutersLog($"Poll change detection, " +
								$"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"No difference with the previous content: {this.ID} {this.Url} " +
                                $"Content size differs by {Math.Round(percentageOfContentSizeChange, 1)}% " +
                                $"Current content size: {content.Length} " +
                                $"Previous content size: {this.PreviousContentSize}", NLog.LogLevel.Info);
                                
                            AutomationClient.ReutersLogEvents(NLog.LogLevel.Trace,
								$"Poll change detection, " +
                                $"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"No difference with the previous content: {this.ID} {this.Url} " +
                                $"Content size differs by {Math.Round(percentageOfContentSizeChange, 1)}% " +
                                $"Current content size: {content.Length} " +
                                $"Previous content size: {this.PreviousContentSize}",
                                oUrlPollStatus.Audit.BuildJson());
                            break;
                        }
                    default:
                        {
                            AutomationClient.ReutersLog($"Poll change detection, " +
								$"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"No difference with the previous content: {this.ID} {this.Url}", NLog.LogLevel.Info);
                                
                            AutomationClient.ReutersLogEvents(NLog.LogLevel.Trace,
								$"Poll change detection, " +
                                $"PollID: {oUrlPollStatus.PollAttempt.PollID} " +
                                $"No difference with the previous content: {this.ID} {this.Url} ",
                                oUrlPollStatus.Audit.BuildJson());
                            break;
                        }
                }
            }
        }

    }

	public interface ISourceContentApi
	{
		[Multipart]
		[Post("/api/sourcecontent/create")]
		Task<HttpResponseMessage> CreateSourceContent(
			[AliasAs("sourceContentMetadata")] string metadata,
			[AliasAs("sourceContentPayload")] StreamPart content);
	}
}
