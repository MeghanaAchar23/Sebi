using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using EAP.FileConversion.Client;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace AutomationCore
{
	internal class CConversionServiceCall
	{
		private int m_iRemoveOlderEntryInMinute = 1440; // 1440 => 24 hours

		public int RetryCount { get; set; } = 5;
		public int TimedOutInSeconds { get; set; } = 30;

		private static ConcurrentDictionary<string, string> m_condicConvertedValue = new ConcurrentDictionary<string, string>();
		private static ConcurrentDictionary<string, DateTime> m_condicConvertedDateTime = new ConcurrentDictionary<string, DateTime>();

		private readonly File2TextConverter _fileConversionServiceClient;

		public CConversionServiceCall()
		{
			_fileConversionServiceClient = new File2TextConverter(new FileConversionServiceOptions
			{
				Url = AutomationClient.ReutersConfig?.Global?.Service?.FileConversion,
				RetryCount = RetryCount,
				Timeout = Timeout.InfiniteTimeSpan
			}, LoggerFactory.Create(x => x.AddNLog()).CreateLogger<File2TextConverter>());
		}

		public bool GetConvertedData(byte[] sourceBuffer, List<PostParameter> options, ref string conversionResult, ref string error)
		{
			try
			{
				if (IsAllReadyConverted(sourceBuffer, options, out var hash) &&
					!string.IsNullOrWhiteSpace(hash) && m_condicConvertedValue.TryGetValue(hash, out conversionResult))
				{
					AutomationClient.ForceLog("File conversion result was got from a cache");
					return true;
				}

				var result = SendConversionRequest(sourceBuffer, options);

				if (result.Success)
				{
					conversionResult = result.Content;

					if (!string.IsNullOrWhiteSpace(hash) && !string.IsNullOrWhiteSpace(conversionResult))
					{
						m_condicConvertedValue.TryAdd(hash, conversionResult);
						m_condicConvertedDateTime.TryAdd(hash, GetCurrentUTCTime());
					}
					return true;
				}

				error = result.Error;
				return false;
			}
			catch (Exception ex)
			{
				error = ex.ToString();
			}
			return false;
		}

		private ConversionResult SendConversionRequest(byte[] sourceBuffer, IEnumerable<PostParameter> options)
		{
			AutomationClient.ForceLog?.Invoke("Starting file conversion request");
			var stopWatch = Stopwatch.StartNew();

			var conversionOptions = options.ToDictionary(
				x => x.ParameterName,
				x => x.ParameterValue);
			var cancellationToken = new CancellationTokenSource(TimeSpan.FromSeconds(TimedOutInSeconds)).Token;

			var result = _fileConversionServiceClient.ConvertAsync(sourceBuffer, conversionOptions, cancellationToken)
				.GetAwaiter().GetResult();

			stopWatch.Stop();
			AutomationClient.ForceLog?.Invoke($"File conversion request took {stopWatch.ElapsedMilliseconds} ms");

			return result;
		}

		bool IsAllReadyConverted(byte[] Sourcebuffer, List<PostParameter> lstPostParamerter, out string _MD5Hash)
		{
			_MD5Hash = "";
			try
			{
				_MD5Hash = GetMD5Hash(Sourcebuffer);
				string t_csPostParamert = "";
				foreach (PostParameter t_postParamert in lstPostParamerter)
					t_csPostParamert += t_postParamert.ParameterName + ":" + t_postParamert.ParameterValue + "\r\n";
				_MD5Hash += "_" + GetMD5Hash(new UTF8Encoding().GetBytes(t_csPostParamert));
				RemoveOlderEntry();

				return m_condicConvertedValue.ContainsKey(_MD5Hash);
			}
			catch { }
			return false;
		}

		void RemoveOlderEntry()
		{
			try
			{
				DateTime t_dtRemoveTime = GetCurrentUTCTime().AddMinutes((m_iRemoveOlderEntryInMinute * -1));
				List<string> t_lstRemoveMD5Hash = new List<string>();
				foreach (KeyValuePair<string, DateTime> t_Entry in m_condicConvertedDateTime)
				{
					if (t_Entry.Value < t_dtRemoveTime)
						t_lstRemoveMD5Hash.Add(t_Entry.Key);
				}
				DateTime t_dtTmp;
				string t_csTmp;
				foreach (string t_csRemoveEntryMD5Hash in t_lstRemoveMD5Hash)
				{
					m_condicConvertedDateTime.TryRemove(t_csRemoveEntryMD5Hash, out t_dtTmp);
					m_condicConvertedValue.TryRemove(t_csRemoveEntryMD5Hash, out t_csTmp);
				}
			}
			catch { }
		}

		DateTime GetCurrentUTCTime()
		{
			return DateTime.UtcNow;
		}

		string GetMD5Hash(byte[] Sourcebuffer)
		{
			StringBuilder sbHash = new StringBuilder();
			MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
			byte[] md5buffer = md5provider.ComputeHash(Sourcebuffer);

			for (int t_i = 0; t_i < md5buffer.Length; t_i++)
				sbHash.Append(md5buffer[t_i].ToString("x2"));
			return sbHash.ToString();
		}
	}

	class PostParameter
	{
		public PostParameter(string t_csParameterName, string t_csParameterValue)
		{
			ParameterName = t_csParameterName;
			ParameterValue = t_csParameterValue;
		}
		public string ParameterName = "";
		public string ParameterValue = "";
	}
}
