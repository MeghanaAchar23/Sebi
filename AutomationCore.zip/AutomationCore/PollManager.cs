using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using AutomationCore.PollExecutionState;

namespace AutomationCore
{
	public interface ISubscriptionManager
	{
		Task StartAsync();
		void Stop();
	}

	public abstract class PollManager
	{
		internal Timer PollTimer;

		internal readonly object SyncRoot = new object();

		public Source Source { get; }

		public int LivePollCount { get; internal set; }

		public bool IsPollingActive { get; internal set; }

		public long TotalPollCount { get; internal set; }

		public bool IsPollInitialiseSent { get; set; }

		public bool IsReutersPollEventsEnabled { get; set; }

		public bool IsTimerActive { get; set; }

		internal long PreviousContentSize { get; set; } = -1;


		protected PollManager(Source source)
		{
			Source = source;
			PollTimer = new Timer(DoPollSafe, Source, Timeout.Infinite, Source.CurrentPollIntervalInMS);
			IsReutersPollEventsEnabled = AutomationClient.LogOptions.Contains(LogOptions.PollEventsToAmazon);
		}

		private IExecutionState GetExecutionState()
		{
			switch (Source.Store.AutomationClient.GlobalExecutionState)
			{
				case ExecutionState.LoadHistoryPending:
				case ExecutionState.LoadHistoryCompleted: return new LoadHistoryState(this);
				case ExecutionState.PollActivationPending:
				case ExecutionState.PollActivationCompleted: return new PollActivationState(this);
				default:
					throw new ArgumentOutOfRangeException();
			}
		}

		public void ActivatePolling(bool enableTimer = true)
		{
			IsTimerActive = enableTimer;
			var executionState = GetExecutionState();
			executionState.Activate();
		}

		public void DeactivatePolling()
		{
			var executionState = GetExecutionState();
			executionState.Deactivate();
		}

		internal static bool IsNewContentDetected(long currentContentSize, long previousContentSize,
			out double percentageOfContentSizeChange)
		{
			percentageOfContentSizeChange = 0;

			if (previousContentSize == -1) return true;
			if (currentContentSize <= 0) return false;

			const int allowedSizeDifferenceInPercent = 20;

			percentageOfContentSizeChange =
				Math.Abs(currentContentSize - previousContentSize) / (double)previousContentSize * 100;

			return percentageOfContentSizeChange - allowedSizeDifferenceInPercent >= 0;
		}


		/// <summary>
		/// Called before starting an actual poll.
		/// Remarks
		/// =======
		/// This method will be called at each poll to the source. It will increment the iPollID and LivePollCount values by 1.
		/// If iPollId is same as the Source.LimitPollCount, it will deactivate the source.
		/// </summary>
		/// <param name="iPollID"></param>
		/// <returns>Returns _true_ if LivePollCount is less than or equal to Source.MaxPollAtTime.</returns>
		public bool OnPollStart(ref Int64 iPollID)
		{
			bool t_bRet = false;

			lock (SyncRoot)
			{
				// first time in so reset the interval if wall clock alignment option is set
				if (TotalPollCount == 0 && Source.AlignPollIntervalToWallClock == true && IsTimerActive)
				{
					var startTimeMs = 0;

					// get polling interspersed mode between automation instances, even, random or none
					startTimeMs = AutomationClient.ReutersConfig.GetNextPollStartTimeMilliseconds(Source.ID, Source.CurrentPollIntervalInMS, Source.PollInterspersedMode);

					// start the timer
					PollTimer.Change(startTimeMs, Source.CurrentPollIntervalInMS);
				}

				//increment live poll count for source
				LivePollCount++;

				//increment poll id number
				TotalPollCount++;
				iPollID = TotalPollCount;

				if (!IsPollingActive)
					return false;

				if (Source.LimitPollCount != 0 && TotalPollCount == Source.LimitPollCount)
				{
					AutomationClient.ForceLog?.Invoke($"Limit poll count for {Source.ID}  was reached");
					DeactivatePolling();
				}

				if (LivePollCount <= Source.MaxPollAtTime)
				{
					t_bRet = true;

					//if (IsSequentialPolling)
					//    StopTimer();
				}
			}

			return t_bRet;
		}

		/// <summary>
		/// Called after a poll completes.
		///
		/// Remarks
		/// =======
		/// This method is called after each poll completes. It will decrement the value of LivePollCount property by 1.
		/// </summary>
		public void OnPollEnd()
		{
			lock (SyncRoot)
			{
				//m_dtLastPollTime = DateTime.UtcNow;
				LivePollCount--;

				//if (IsSequentialPolling && m_bIsPollingActive)
				//    StartTimer();
			}
		}

		internal async void DoPollSafe(object oSource)
		{
			try
			{
				await DoPoll(oSource);
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}
		}

		/// <summary>
		/// Timer callback function which will be called at every timer event.
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// This method will first call the OnPollStart() method and determine if the new poll has to be initiated or not. If yes, then it will execute the PollFunction() method.
		/// After calling PollFunction(), if all the Source objects are deactivated it will execute the PerformExit() method of Store object.
		/// Calls the OnPollEnd() method to finish current poll.
		/// </remarks>
		/// <param name="oSource">Target `Source` object</param>
		public async Task DoPoll(object oSource)
		{
			var source = (Source)oSource;

			long t_iPollID = 0;
			var t_bRet = OnPollStart(ref t_iPollID);

			//enclose below two IF conditions in TRY...CATCH so that any exception occured will be handled and live poll count will be decremented in any case.
			try
			{
				if (t_bRet)
				{
					try
					{
                        if (source.PollManager.IsTimerActive)
                            source.SetRandomPollInterval();
					}
					catch (Exception ex)
					{
						AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
					}

					source.LatestPollDateTime = DateTime.UtcNow;

					await PollFunction(source, t_iPollID);
				}
				else
				{
					//report an error
					//CRN 13Aug13 : commented writing operator log
					if (Source.Store.AutomationClient.IsLoadedFromController)
						Source.Store.AutomationClient.OperatorLog(source.ID + ": Maximum Concurrent Poll limit is reached, this poll will be skipped.", NLog.LogLevel.Warn);
				}
			}
			catch (Exception ex)
			{
				//TODO: Add error in XML log.
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}

			OnPollEnd();

			Debug.WriteLine($"{Source.ID}{Environment.NewLine}" +
							$" - IsSourceBeingPolled {source.IsSourceBeingPolled}{Environment.NewLine}" +
							$" - LivePollCount {source.PollManager.LivePollCount}{Environment.NewLine}" +
							$" - Thread id {Thread.CurrentThread.ManagedThreadId}{Environment.NewLine}");

			if (!source.IsSourceBeingPolled)
			{
				source.Store.AutomationClient.TryToStop();
			}
		}

		/// <summary>
		/// Reset timer interval
		/// </summary>
		public void ResetPollInterval()
		{
			lock (SyncRoot)
			{
				// by default start timer immediately
				var startTimeMs = 0;

				// align the polling interval to the wall clock
				if (Source.AlignPollIntervalToWallClock == true)
				{
					// get polling interspersed mode between automation instances, even, random or none
					startTimeMs = AutomationClient.ReutersConfig.GetNextPollStartTimeMilliseconds(Source.ID, Source.CurrentPollIntervalInMS, Source.PollInterspersedMode);
				}

				// start the timer
				PollTimer?.Change(startTimeMs, Source.CurrentPollIntervalInMS);
			}
		}

		//abstract function
		/// <summary>
		/// Makes request to the source `oSource`. This is an abstract function.
		/// </summary>
		/// <param name="source"></param>
		/// <param name="pollId"></param>
		public abstract Task PollFunction(Source source, Int64 pollId);

		/// <summary>
		/// Makes request to the source for initializing history parameters. This is an abstract function.
		/// </summary>
		public abstract Task DoHistoryPoll();
	}
}
