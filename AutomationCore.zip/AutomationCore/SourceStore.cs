using AutomationCore.Email;
using AutomationCore.Handbrake;
using AutomationCore.Idn;
using AutomationCore.Twitter;
using AutomationCore.UcdpFeed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Tweetinvi.Core.Extensions;

namespace AutomationCore
{
	/// <summary>
	/// Collects/provides most of the required components of an automation through a single instance. This is an abstract class, must inherit to use it.
	/// </summary>
	/// <remarks>
	/// Example
	/// =======
	/// The following code shows how to create a MySourceStore class which inherits the SourceStore class.
	/// </remarks>
	/// <example>
	/// <code>
	///     public class MySourceStore : SourceStore
	///     {
	///         public MySourceStore(string sAutomationDllFullPath, Config oConfig)
	///             : base(sAutomationDllFullPath, oConfig)
	///         {
	///        
	///         }
	///    
	///         public override void OnHistoryLoaded()
	///         {
	///             //history of all sources are loaded, you can perform any required action.
	///         }
	///
	///         public override void OnPollingStopped()
	///         {
	///             //Polling of all sources is stopped, you can perform any required action.
	///         }
	///     }
	/// </code>
	/// </example>    
	public abstract class SourceStore
	{
		private Object m_oSyncLock = new Object();
		private Timer m_oResetPollIntervalTimer;
		private int m_iTimerInterval = 250;
		private string m_sAutomationDllFullPath;
		private bool m_IsExitPerformed;
		private EmailMessage m_oCompletionNotificationEmail = null;

		/// <summary>
		/// Gets or sets the full path to the Automation Dll in use
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// Derives the full path to the dll name as speicfied in the element <b>&lt;library_name></b> in xml.
		/// </remarks>
		public string AutomationDllFullPath
		{
			get
			{
				return m_sAutomationDllFullPath ?? string.Empty;
			}
			set
			{
				m_sAutomationDllFullPath = value;
			}
		}

		/// <summary>
		/// Gets or sets the name of the automation or Spider Id
		/// 
		/// Remarks
		/// =======
		/// AutomationName is used to send the logs for specific automation. Also, it is sent as a Automation Name in alerts/stories published in automation to store in quantum publication database.
		/// </summary>
		/// <value>Value is the name without the extention speicifed in the element <b>&lt;spider_library_name></b> in xml.</value>
		public string AutomationName
		{
			get;
			set;
		}

		public string AutomationFullName
		{
			get;
			set;
		}

        public List<string> SourceGroupTags
        {
            get;
            set;
        }

        /// <summary>
        /// Specifies a collection of all [PublicationAgent](@ref PublicationAgent) objects defined in xml.
        /// Relates with the element(s) <b>&lt;publication_agent></b> under section &lt;publication_agents> in xml.
        /// </summary>
        public PublicationAgents PublicationAgents
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies a collection of all [PublicationMessage](@ref PublicationMessage) objects including alerts, stories, econs, handbrakes etc. defined in xml.
		/// Relates with the element(s) <b>&lt;number_publication></b>, <b>&lt;alert_publication></b>, <b>&lt;story_publication></b> and <b>&lt;handbrake_publication></b> in xml.
		/// </summary>
		public PublicationMessages PublicationMessages
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies a collection of all [EmailMessage](@ref EmailMessage) objects defined in xml.
		/// Relates with the element(s) <b>&lt;email_publication></b> in xml.
		/// </summary>
		public EmailMessages EmailMessages
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies a collection of all Source objects defined in xml including [URLSource](@ref URLSource) and/or [FolderSource](@ref FolderSource).
		/// Relates with the element(s) <b>&lt;url_source></b> and <b>&lt;folder_source></b> in xml.
		/// </summary>
		public Sources Sources
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies a collection of all Setting parameters defined in xml.
		/// Relates with the element(s) <b>&lt;setting></b> in xml.
		/// </summary>
		public Settings Settings
		{
			get;
			set;
		}

		/// <summary>
		/// Gets log information including sources being monitored, poll information, publication informations with timings.
		/// </summary>
		public AutomationLog PerformanceLog
		{
			get;
			private set;
		}

		/// <summary>
		/// Get or sets the URL to post the log to.
		/// </summary>
		/// <value>Sets the value from the element <b>&lt;log_upload_url></b> in xml.</value>
		public string LogUploadUrl
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies an EmailClient object to send emails.
		/// </summary>
		public EmailClient EmailClient
		{
			get;
			set;
		}


		/// <summary>
		/// Determines whether the source has stopped polling.
		/// </summary>
		/// <remarks>Checks IsSourceActive and IsSourceBeingPolled properties of all sources and returns true only if all are false.
		/// Retruns _true_ if all the sources are stopped/deactivated; otherwise _false_.
		/// </remarks>
		public bool IsPollingStopped
		{
			get
			{
				return Sources.GetAllActiveSources().All(oSource => !oSource.IsSourceBeingPolled);
			}
		}

		/// <summary>
		/// Specifies the instance of the Config class to parse the xml configuration.
		/// </summary>
		public Config Config
		{
			get;
			set;
		}

		/// <summary>
		/// Specifies the instance of AutomationClient class.
		/// </summary>
		public AutomationClient AutomationClient
		{
			get;
			set;
		}

		/// <summary>
		/// Gets the number of live polls in progress of all the sources specified in `Sources`.
		/// </summary>
		public int LivePollCount
		{
			get
			{
				var count = 0;

				if (Sources != null)
				{
					foreach (var source in Sources.GetAllSources())
					{
						count += source?.PollManager?.LivePollCount ?? 0;
					}
				}

				return count;
			}
		}

		/// <summary>
		/// Gets or sets the full file path to update the date and time for SMS Monitoring.
		/// </summary>
		/// <value>Sets the value from the element <b>&lt;sms_monitoring_file_path></b> in xml.</value>
		public string SmsMonitoringFile
		{
			get;
			set;
		}

		public string RecommendationServiceUrl { get; set; }


		public bool IsSpiderLinuxEnabled
		{
			get;
			set;
		}

		public string SpiderLinuxMode
		{
			get;
			set;
		}

		public static List<string> ConversionServiceUrls { get; set; }

		public static string PublicationPostUrl { get; set; }

		public static string EmailMonitoringServiceUrl { get; set; }

		/// <summary>
		/// Initializes the new object and loads automation specific configurations and initializes required componenets
		/// </summary>
		/// <param name="sAutomationDllFullPath">Full path to automation dll file</param>
		/// <param name="oConfig">Object of [Config](@ref Config) class</param>
		public SourceStore(string sAutomationDllFullPath, Config oConfig)
		{
			Config = oConfig;
			Initialize(sAutomationDllFullPath);
			m_IsExitPerformed = false;
		}

		private void Initialize(string sAutomationDllFullPath)
		{
			m_sAutomationDllFullPath = sAutomationDllFullPath;

			Settings = new AutomationCore.Settings() { Store = this };
			PublicationAgents = new AutomationCore.PublicationAgents() { Store = this };
			PublicationMessages = new AutomationCore.PublicationMessages() { Store = this };
			EmailMessages = new AutomationCore.Email.EmailMessages() { Store = this };
			Sources = new AutomationCore.Sources() { Store = this };

			m_oResetPollIntervalTimer = new Timer(new TimerCallback(ResetPollInterval), null, Timeout.Infinite, m_iTimerInterval);
			PerformanceLog = new AutomationLog();
			PerformanceLog.AutomationStartDateTime = DateTime.UtcNow;
			AutomationName = "";
			LogUploadUrl = "";
			Config.LoadConfiguration(this);
		}

        private bool InSourceGroup(Source source)
        {            
            if (source.IsSourceActive && (SourceGroupTags.IsEmpty() || SourceGroupTags.Intersect(source.GroupTags).Any()))
            {
                return true;
            }
            return false;
        }

		/// <summary>
		/// Updates a [URLSource](@ref URLSource) object by reading the xml in the `oSource` object.
		/// </summary>
		///<remarks>
		/// Remarks
		/// =======
		/// Tries to find the element <b>&lt;url_source></b> with the id `sSourceId` in the xml. Parses the element and gets all the parameters specified in xml and sets to the corresponding properties in `oSource`.
		/// </remarks>
		/// <param name="sSourceId">The ID of the URL source from spider xml</param>
		/// <param name="oSource">The `URLSource` to update with the matching xml URL source</param>
		/// <returns>Boolean</returns>
		/// <value>Returns _true_ if URL source with `sSourceId` is found in xml and loaded correctly; otherwise _false_.</value>
		/// <example>
		/// Example
		/// =======
		/// The code below will load a url source with id "timeanddate" from the xml and add to the `Sources` of the `Store`.
		/// <code>
		/// //All automation DLL MUST need to have class Main and derive it from AutomationClient
		/// public class Main : AutomationClient
		/// {
		///    //All automation DLL MUST need to have this function.
		///    public override SourceStore LoadSourceStore(Config config)
		///    {
		///        //Store is the object of MySourceStore class which is inherited from SourceStore class.
		///        MySourceStore Store = new MySourceStore(this.GetType().Assembly.Location, config);
		///
		///        //Create an object of your URL Source handler class, url1 here is the object of the Url1Source class inherited from URLSource class.
		///        Source url1 = new Url1Source();
		///        Url1Source url1Temp = (Url1Source)url1;
		///
		///        //Load URL source with ID "timeanddate" into this UrlSource object.
		///        Store.LoadURLSource("timeanddate", url1Temp);
		///        
		///        //Add the source object to Sources collection in Store
		///        Store.Sources.AddSource("timeanddate", ref url1);
		///        
		///        DefaultCommandExecutionSequence = "loadhistory,startpolling";
		///
		///        return Store;
		///    }
		/// }
		/// </code>
		/// </example>
		public bool LoadURLSource(string sSourceId, URLSource oSource)
		{
			try
			{                
				Config.LoadUrlSource(sSourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sSourceId);                
				return true;
			}
			catch (Exception ex) { AutomationClient.ForceLog?.Invoke(ex.ToString()); }
			return false;
		}

        public bool LoadURLSource(string sSourceId, string sDestSourceId, URLSource oSource)
        {
            try
            {
                Config.LoadUrlSource(sSourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.ID = sDestSourceId;
                oSource.OnConfigurationLoaded(this, sSourceId); // user sourceId here as it is the configId in the xml, client can use sDestSourceId to refer to the source
                return true;
            }
            catch (Exception ex) { AutomationClient.ForceLog?.Invoke(ex.ToString()); }
            return false;
        }

        public bool LoadOmniScanSource(string sSourceId, OmniScanSource oSource)
        {
            try
            {
                Config.LoadOmniScanSource(sSourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sSourceId);
                return true;
            }
            catch (Exception ex) {
                AutomationClient.ForceLog?.Invoke(ex.ToString());
            }
            return false;
        }

        /// <summary>
        /// Updates a [FolderSource](@ref FolderSource) object by reading the xml in the `oSource` object.
        /// </summary>
        /// <remarks>
        /// Remarks
        /// =======
        /// Tries to find the element <b>&lt;folder_source></b> with the id `sSourceId` in the xml. Parses the element and gets all the parameters specified in xml and sets to the corresponding properties in `oSource`.
        /// </remarks>
        /// <param name="sSourceId">The ID of the Folder source from spider xml</param>
        /// <param name="oSource">The `FolderSource` to update with the matching xml folder source</param>
        /// <value>Returns _true_ if folder source with `sSourceId` is found in xml and loaded correctly; otherwise _false_.</value>
        /// <example>
        /// Example
        /// =======
        /// The code below will load a folder source with id "timeanddate" from the xml and add to the `Sources` of the `Store`.
        /// <code>
        /// //all automation DLL MUST need to have class Main and derive it from AutomationClient
        /// public class Main : AutomationClient
        /// {
        ///    //all automation DLL MUST need to have this function.
        ///    public override SourceStore LoadSourceStore(Config config)
        ///    {
        ///        //Store is the object of MySourceStore class which is inherited from SourceStore class.
        ///        MySourceStore Store = new MySourceStore(this.GetType().Assembly.Location, config);
        ///
        ///        //Create an object of your Folder Source handler class, folderSource1 here is the object of the FolderSource1 class inherited from FolderSource class.
        ///        Source folderSource1= new FolderSource1();
        ///        FolderSource1 folderSourceTemp = (FolderSource1)folderSource1;
        ///
        ///        //Load Folder source with ID "timeanddate" into this FolderSource object.
        ///        Store.LoadFolderSource("timeanddate", folderSourceTemp);
        ///        
        ///        //Add the source object to Sources collection in Store
        ///        Store.Sources.AddSource("timeanddate", ref folderSource1);
        ///        
        ///        DefaultCommandExecutionSequence = "loadhistory,startpolling";
        ///
        ///        return Store;
        ///    }
        /// }
        /// </code>
        /// </example>
        public bool LoadFolderSource(string sSourceId, FolderSource oSource)
		{
			try
			{
				Config.LoadFolderSource(sSourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sSourceId);
                return true;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return false;
		}

		public bool LoadTwitterSource(string sSourceId, TwitterSource oSource)
		{
			try
			{
				Config.LoadTwitterSource(sSourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sSourceId);
                return true;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return false;
		}

		public bool LoadUcdpFeedSource(string sourceId, UcdpSource oSource)
		{
			try
			{
				Config.LoadUcdpFeedSource(sourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sourceId);
                return true;
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				return false;
			}
		}

		public bool LoadIdnSource(string sourceId, IdnSource oSource)
		{
			try
			{
				Config.LoadIdnSource(sourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sourceId);
                return true;
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				return false;
			}
		}

		public bool LoadFingerpostSource(string sourceId, FingerpostSource oSource)
		{
			try
			{
				Config.LoadFingerpostSource(sourceId, oSource);
                oSource.IsSourceActive = InSourceGroup(oSource);
                oSource.OnConfigurationLoaded(this, sourceId);
                return true;
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				return false;
			}
		}

		/// <summary>
		/// Generates new instance of HandbrakeMessage class from the element <b>&lt;handbrake_message></b> with the ID `sId` in the xml.
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// Throws exception if the handbrake message with the ID `sId` is not found in xml.
		/// </remarks>
		/// <param name="sId">The ID of the HandbrakeMessage from xml</param>
		/// <returns>HandbrakeMessage</returns>
		/// <example>
		/// Example
		/// =======
		/// The following code example gets the new handbrake message with id "hb0001" from xml.
		/// <code>
		/// HandbrakeMessage hbMessage = Store.GetNewHandbrakeMessage("hb0001");
		/// </code>
		/// </example>
		public HandbrakeMessage GetNewHandbrakeMessage(string sId)
		{
			return Config.GetNewHandbrakeMessage(sId);
		}

		/// <summary>
		/// Generates new instance of HandbrakeMessage class from the element <b>&lt;fhandbrake_message></b> with the id `sId` in the xml and adds the publication message ids specified in `sPublicationMessageIds` in `GroupMessages`.
		/// 
		/// Remarks
		/// =======
		/// Throws exception if Handbrake Message with id `sId` not found.
		/// 
		/// Generates new HandbrakeMessage from xml with `sId`, adds the HandbrakeMessage object to all PublicationMessages specified
		/// in `sPublicationMessageIds`, adds all PublicationMessage IDs in `sPublicationMessageIds` to GroupMessages queue of the HandbrakeMessage object.
		/// This will remove the existing HandbrakeMessage with the same Id as `sId` from the PublicationMessage.
		/// </summary>
		/// <param name="sId">The ID of the HandbrakeMessage from xml</param>
		/// <param name="sPublicationMessageIds">Array of PublicationMessage IDs to add into the handbrake GroupMessages</param>
		/// <returns>HandbrakeMessage</returns>
		public HandbrakeMessage SetUpNewHandbrakeMessage(string sId, string[] sPublicationMessageIds)
		{
			HandbrakeMessage oHbMessage = Config.GetNewHandbrakeMessage(sId);
			if (oHbMessage != null && sPublicationMessageIds != null)
			{
				foreach (string messageId in sPublicationMessageIds)
				{
					PublicationMessage msg = PublicationMessages.GetPublicationMessage(messageId);
					if (msg != null)
					{
						msg.HandbrakeMessages.Clear();
						msg.AddHandbrakeMessage(oHbMessage);
					}
				}
			}
			return oHbMessage;
		}

		private void ResetPollInterval(object oTarget)
		{
			lock (m_oSyncLock)
			{
				if (Sources != null)
				{
					foreach (Source oSource in Sources.GetAllActiveSources())
					{
						if (oSource.IsSourceBeingPolled)
							oSource.ResetPollInterval();
					}
				}
			}
		}

		/// <summary>
		/// [Not in use] Deactivates timer for poll patterns
		/// </summary>
		public void ActivatePollPatternManager()
		{
			m_oResetPollIntervalTimer.Change(0, m_iTimerInterval);
		}

		/// <summary>
		/// Deactivates timer for poll patterns
		/// </summary>
		public void DeactivatePollPatternManager()
		{
			if (m_oResetPollIntervalTimer != null)
			{
				m_oResetPollIntervalTimer.Change(Timeout.Infinite, m_iTimerInterval);
				m_oResetPollIntervalTimer.Dispose();
				m_oResetPollIntervalTimer = null;
			}
		}

		/// <summary>
		/// Virtual function which will be called after `LoadHistory()` function of all the sources are completed
		/// </summary>
		public virtual void OnHistoryLoaded() { }

		/// <summary>
		/// Virtual function which will be called after all the sources in `SourceStore` are stopped
		/// </summary>
		public virtual void OnPollingStopped() { }

		/// <summary>
		/// Starts polling of all the active sources
		/// 
		/// Remarks
		/// ======= 
		/// Calls Activate() method of all the source objects added in `Sources` which have IsActive property set as yes in xml
		/// </summary>
		public void StartPolling()
		{
			List<Source> oActiveSources = Sources.GetAllActiveSources();

			foreach (Source oSource in oActiveSources)
			{
				oSource.Activate();
				oSource.StartDateTime = DateTime.UtcNow;
			}

			//TODO: Fix reset issue
			//ActivatePollPatternManager();

			if (!oActiveSources.Any(s => s.IsSourceBeingPolled))
				AutomationClient.ForceLog("WARNING! Not any source activated", LogLevel.Warn);
		}

		/// <summary>
		/// Stops polling of all the sources
		/// 
		/// Remarks
		/// =======
		/// Calls Deactivate() method of all the source objects added in `Sources`.
		/// </summary>
		public void StopPolling()
		{
			DeactivatePollPatternManager();

			var oSources = Sources.GetAllSources();

			try
			{
				foreach (Source oSource in oSources)
				{
					if (oSource != null && oSource.IsSourceBeingPolled)
						oSource.Deactivate();
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

			try { AutomationClient.EapEmailPollClient.Stop(); } catch { }
			//var urlSources = oSources.Where(s => s is URLSource);
		}

		/// <summary>
		/// Performs various operations before automation stops.
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// 1. Calls OnPollingStopped() method
		/// 2. Sends Completion notification email
		/// 3. Uploads log to Log service
		/// 
		/// Called only once in the automation life cycle. Writes error to OperatorLog if fails at any point.
		/// </remarks>
		public void PerformExit()
		{
			if (!m_IsExitPerformed)
			{
				m_IsExitPerformed = true;
				try
				{
					OnPollingStopped();
				}
				catch (Exception ex)
				{
					AutomationClient.OperatorLog("Failed to perform exit operation. Error -> " + ex.ToString(), NLog.LogLevel.Error);
				}

				try
				{
					if (PerformanceLog.RecommendedNextRunSettingValues != null)
					{
						foreach (var setting in PerformanceLog.RecommendedNextRunSettingValues)
						{
							RecommendNextRunSettingValueToReuters(setting);
						}
					}
				}
				catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

				PerformanceLog.AutomationStopDateTime = DateTime.UtcNow;

				// remove this as it's just a dump of the already logged logs
                 try { if (AutomationClient.LogOptions.Contains(LogOptions.PerformanceLogToAmazon)) AutomationClient.ForceLog(PerformanceLog.ToJson()); } catch { }
			}
		}

		public void RecommendNextRunSettingValueToReuters(RecommendedNextRunSettingValue setting)
		{
			try
			{
				AutomationClient.ReutersLog(string.Format("Updating user data: Key: {0}, Value: {1}", setting.SettingID, setting.SettingValue), NLog.LogLevel.Trace);
				var librarySetting = Settings.GetSetting(setting.SettingID);
				var usersetting = new EAP.Core.Types.KeyValue { Key = setting.SettingID, Value = setting.SettingValue, Caption = librarySetting.Caption, Description = librarySetting.Description };
				AutomationClient.ReutersConfig.SetCustomUserDataKVAsync(usersetting)
					.GetAwaiter()
					.GetResult();
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		/// <summary>
		/// Gets or Creates EmailMessage for completion notification
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// Gets or creates new EmailMessage object with ID `completion_notification` from xml.
		/// Sets default to and/or from email address as SpiderAutoNotification@AllReleases.net if not specified in xml.
		/// </remarks>
		public void SetCompletionNotificationEmail()
		{
			if (EmailMessages != null)
				m_oCompletionNotificationEmail = EmailMessages.GetEmailMessage("completion_notification");

			if (m_oCompletionNotificationEmail == null)
			{
				m_oCompletionNotificationEmail = new EmailMessage(this);
				m_oCompletionNotificationEmail.ID = "completion_notification";
				m_oCompletionNotificationEmail.IsActive = true;
			}

			if (string.IsNullOrWhiteSpace(m_oCompletionNotificationEmail.Subject))
			{
				string sAutomationName = AutomationName;
				if (!string.IsNullOrWhiteSpace(PerformanceLog.HostingServerName))
					sAutomationName = sAutomationName.Replace(PerformanceLog.HostingServerName, "");
				m_oCompletionNotificationEmail.Subject = "Automation update - " + sAutomationName;
			}

			if (m_oCompletionNotificationEmail.To == null)
				m_oCompletionNotificationEmail.To = new List<string>();
			if (m_oCompletionNotificationEmail.To.Count == 0)
				m_oCompletionNotificationEmail.To.Add("SpiderAutoNotification@AllReleases.net");

			if (string.IsNullOrWhiteSpace(m_oCompletionNotificationEmail.From))
				m_oCompletionNotificationEmail.From = "SpiderAutoNotification@AllReleases.net";
		}

		/// <summary>
		/// Sends completion notification email if at least one PublicationMessage was sent
		/// </summary>
		public void SendCompletionNotificationEmail()
		{
			if (m_oCompletionNotificationEmail == null)
				SetCompletionNotificationEmail();
		}

		/// <summary>
		/// Writes log in xml format to datetime wise file in folder speicified in `FolderPath`
		/// </summary>
		/// <param name="FolderPath">Directory where log will be saved</param>
		public void WriteLogToXMLFile(string FolderPath)
		{

		}

		/// <summary>
		/// Prefix hosting server name to all PublicationMessages' `AutomationName` property
		/// 
		/// Remarks
		/// =======
		/// Hosting server name is the user-friendly name of the dadicated server/host from where automation is running
		/// </summary>
		/// <param name="sHostingServerName">Hosting server name</param>
		public void SetHostingServerName(string sHostingServerName)
		{
			//insert hosting server name into automation name
			sHostingServerName = sHostingServerName.Replace(";", " ");
			PublicationMessages.UpdateAutomationName(sHostingServerName);

			//set hosting server name in XML log
			PerformanceLog.HostingServerName = sHostingServerName;
		}

		/// <summary>
		/// Writes/updates system datetime in "yyyyMMddHHmmssfff" format in file specified in `SmsMonitoringFile`
		/// 
		/// Remarks
		/// =======
		/// This method will update the `SmsMonitoringFile` file only if loaded from standalone automation controller
		/// </summary>
		public void UpdateSMSMonitoringTime()
		{

		}

		public bool RecommendNextRunSettingValue(string SettingId, string Value)
		{
			try
			{
				return PerformanceLog.AddOrUpdateRecommendedNextRunSettingValue(SettingId, Value);
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return false;
		}

        public T MapUcdpSourceHandler<T>(string SourceId) where T : UcdpSource, new()
        {
            Source source = new T();
            LoadUcdpFeedSource(SourceId, (T)source);
            Sources.AddSource(SourceId, ref source);
            return (T)source;
        }

        public T MapIdnSourceHandler<T>(string SourceId) where T : IdnSource, new()
        {
            Source source = new T();
            LoadIdnSource(SourceId, (T)source);
            Sources.AddSource(SourceId, ref source);
            return (T)source;
        }

        public T MapFolderSourceHandler<T>(string SourceId) where T : FolderSource, new()
        {
            Source source = new T();
            LoadFolderSource(SourceId, (T)source);
            Sources.AddSource(SourceId, ref source);
            return (T)source;
        }

        public T MapTwitterSourceHandler<T>(string SourceId) where T : TwitterSource, new()
        {
            Source source = new T();
            LoadTwitterSource(SourceId, (T)source);
            Sources.AddSource(SourceId, ref source);
            return (T)source;
        }

        public T MapOmniScanSourceHandler<T>(string SourceId) where T : OmniScanSource, new()
        {
            Source source = new T();
            source.Store = this;
            LoadOmniScanSource(SourceId, (T)source);
            Sources.AddSource(SourceId, ref source);
            return (T)source;
        }

        public T MapUrlSourceHandler<T>(string SourceId) where T : URLSource, new()
        {
            return MapUrlSourceHandler<T>(SourceId, SourceId);
        }

        public T MapUrlSourceHandler<T>(string SourceId, string DestSourceId) where T : URLSource, new()
        {
            Source source = new T();
            LoadURLSource(SourceId, DestSourceId, (T)source);    
            Sources.AddSource(DestSourceId, ref source);
            return (T)source;
        }

        public void MapSourceHandlers(Dictionary<string, Type> SourceHandlers)
        {
            foreach (var item in SourceHandlers)
            {
                Source source = (Source)Activator.CreateInstance(item.Value);
                if(item.Value == typeof(URLSource))
                {
                    LoadURLSource(item.Key, (URLSource)source);
                }
                if (item.Value == typeof(OmniScanSource))
                {
                    LoadOmniScanSource(item.Key, (OmniScanSource)source);
                }
                if (item.Value == typeof(UcdpSource))
                {
                    LoadUcdpFeedSource(item.Key, (UcdpSource)source);
                }
                if (item.Value == typeof(IdnSource))
                {
                    LoadIdnSource(item.Key, (IdnSource)source);
                }
                if (item.Value == typeof(TwitterSource))
                {
                    LoadTwitterSource(item.Key, (TwitterSource)source);
                }
                if (item.Value == typeof(FolderSource))
                {
                    LoadFolderSource(item.Key, (FolderSource)source);
                }
                Sources.AddSource(item.Key, ref source);
            }
        }
    }
}
