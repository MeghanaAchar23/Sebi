using System.Collections.Generic;
using System.IO;
using System.Threading;
using EAP.FileConversion.SDK.PDF.Textract;
using EAP.FileConversion.SDK.Textract.Models;

namespace AutomationCore
{
    public class TextractPdfToText
    {
        private IPagedPdfAsyncFileConvertor pagedPdfAsyncFileConvertor;

        private TextractPdfToText()
        {
            
        }

        public static TextractPdfToText CreateSqsPagedPdfAsyncFileConvertor()
        {
            return new TextractPdfToText()
            {
                pagedPdfAsyncFileConvertor = new PagedPdfAsyncFileConvertor(TextractFileConvertorFactory.CreateSqsPagedTextractAsyncFileConvertor())
            };
        }

        public IAsyncEnumerable<PageResponseModel> GetPdfToTextObjectAsync(byte[] pdfBytesBuffer, List<string> queries = null, CancellationToken cancellationToken = default)
          => pagedPdfAsyncFileConvertor.ConvertAsync(new PdfToTextOptions(new TextractOptions(queries)), new MemoryStream(pdfBytesBuffer), cancellationToken);

        public IAsyncEnumerable<PageResponseModel> GetPdfToTextObjectAsync(Stream pdfContentStream, List<string> queries = null, CancellationToken cancellationToken = default)
           => pagedPdfAsyncFileConvertor.ConvertAsync(new PdfToTextOptions(new TextractOptions(queries)), pdfContentStream, cancellationToken);

        public IAsyncEnumerable<PageResponseModel> GetPdfToTextObjectAsync(string pdfFilePath, List<string> queries = null, CancellationToken cancellationToken = default)
           => pagedPdfAsyncFileConvertor.ConvertAsync(new PdfToTextOptions(new TextractOptions(queries)), pdfFilePath, cancellationToken);

    }
}
