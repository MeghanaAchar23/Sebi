using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
namespace AutomationCore
{
	public class CWebClientEx : WebClient
	{
		private int timeout;
		private bool _allowAutoRedirect = true;
		private int _maximumAutomaticRedirections = 10;
		public int Timeout
		{
			get { return timeout; }
			set { timeout = value; }
		}

		public bool AllowAutoRedirect
		{
			get { return _allowAutoRedirect; }
			set { _allowAutoRedirect = value; }
		}

		public int MaximumAutomaticRedirections
		{
			get { return _maximumAutomaticRedirections; }
			set { _maximumAutomaticRedirections = value; }
		}

		public CWebClientEx()
		{
			timeout = 100000;
		}

		protected override WebRequest GetWebRequest(Uri address)
		{
			WebRequest request = base.GetWebRequest(address);

			if (request.GetType() == typeof(HttpWebRequest))
			{
				HttpWebRequest req = ((HttpWebRequest)request);
				req.Timeout = timeout;
				req.AllowAutoRedirect = _allowAutoRedirect;
				req.MaximumAutomaticRedirections = _maximumAutomaticRedirections;
			}

			return request;
		}
	}
}
