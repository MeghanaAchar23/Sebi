using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore
{
	public class Link
	{
		public string Url
		{
			get;
			set;
		}

		public string Title
		{
			get;
			set;
		}
	}
}
