using System;
using System.Threading.Tasks;
using EAP.Core.Configuration;

namespace AutomationCore
{
	//URLPollManager class
	/// <summary>
	/// Manages polls for URLSource. Provides functions for making requests to URL.
	/// </summary>
	public class URLPollManager : PollManager
	{
		private DateTime lastState = DateTime.UtcNow.AddSeconds(-30);
		private readonly Lazy<HttpClientUtils> _httpUtils;

		//constructor
		/// <summary>
		/// Creates new instance of URLPollManager.
		/// </summary>
		/// <param name="oSource"></param>
		public URLPollManager(Source oSource)
			: base(oSource)
		{
			if (Source is URLSource urlSource)
			{
				_httpUtils = new Lazy<HttpClientUtils>(() => new HttpClientUtils(urlSource));
			}
		}

		//public functions
		/// <summary>
		/// Method executed at each poll. Actual request to the URL source will be made from this method.
		/// </summary>
		/// <param name="source">URLSource type casted to Source</param>
		/// <param name="pollId">Number representing the poll count</param>
		public override async Task PollFunction(Source source, Int64 pollId)
		{
			URLSource urlSource = (URLSource)source;

			//URL polling will go here.
			UrlPollStatus oPollStatus = new UrlPollStatus
			{
				PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() }
			};

			oPollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());

			oPollStatus.Source = urlSource;

			//log start time
			oPollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			oPollStatus = await _httpUtils.Value.DoWebRequest(urlSource, oPollStatus);

			try
			{
				urlSource.OnRequestCompleted(oPollStatus);

				if (oPollStatus.Result)
					urlSource.History = oPollStatus;
			}
			catch (Exception ex)
			{
				oPollStatus.PollAttempt.LogError(ex.ToString());
			}

			//log end time
			oPollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(source.ID, pollId.ToString(), oPollStatus.ResponseCode, oPollStatus.PollAttempt.ToJson());
			}

			if (lastState < DateTime.UtcNow.AddSeconds(-30))
			{
				AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
				lastState = DateTime.UtcNow;
			}
		}

		/// <summary>
		/// Makes a request to the source and stores the status in History.
		/// </summary>
		public override async Task DoHistoryPoll()
		{
			URLSource urlSource = (URLSource)Source;

			if (IsReutersPollEventsEnabled && !IsPollInitialiseSent)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Initialise(urlSource.ID, urlSource.GetResource());
				IsPollInitialiseSent = true;
			}

			UrlPollStatus oStatus = new UrlPollStatus
			{
				PollAttempt = new PollAttempt() { SourceID = urlSource.ID, PollID = "0" }
			};

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(urlSource.ID, oStatus.PollAttempt.PollID.ToString());

			oStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			oStatus.Source = urlSource;

			oStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			oStatus = await _httpUtils.Value.DoWebRequest(urlSource,
				oStatus,
				isCallbackEnabled: false,
				isHistoryPoll: true);

			oStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			oStatus.PollAttempt.ResponseCode = oStatus.ResponseCode.ToString();

			oStatus.ChunkAttempt = new ChunkAttempt { SourceID = urlSource.ID, PollID = oStatus.PollAttempt.PollID, ChunkID = "0" };

			urlSource.History = oStatus;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(urlSource.ID, oStatus.PollAttempt.PollID.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(urlSource.ID, oStatus.PollAttempt.PollID.ToString(), oStatus.ResponseCode, oStatus.PollAttempt.ToJson());
			}
		}
	}
}
