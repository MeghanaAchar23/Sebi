using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore
{
	public class Settings
	{
		private Dictionary<string, Setting> m_oSettings = new Dictionary<string, Setting>();
		private object m_oSyncLock = new object();

		public SourceStore Store
		{
			get;
			set;
		}

		public void AddSetting(Setting oSetting)
		{
			lock (m_oSyncLock)
			{
				m_oSettings.Add(oSetting.ID, oSetting);
			}
		}

		public List<Setting> GetAllSettings()
		{
			lock (m_oSyncLock)
			{
				return m_oSettings.Values.ToList<Setting>();
			}
		}

		public Setting GetSetting(string sID)
		{
			Setting oSetting = null;
			lock (m_oSyncLock)
			{
				m_oSettings.TryGetValue(sID, out oSetting);
			}
			return oSetting;
		}
	}
}
