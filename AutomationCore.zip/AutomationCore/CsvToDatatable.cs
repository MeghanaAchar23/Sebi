using System;
using System.IO;
using EAP.FileConversion.SDK.CSV;
using CsvHelper.Configuration;
using System.Data;

namespace AutomationCore
{
	/// <summary>
	///  Convert Csv to Datatable using file convertors.
	/// </summary>
	public class CsvToDatatable
    {
		private readonly ICsvToDatatableConvertor csvToDatatableConvertor;

		public CsvToDatatable()
		{
			this.csvToDatatableConvertor = new CsvToDatatableConvertor();
		}

        public DataTable Convert(byte[] csvBytesBuffer, CsvConfiguration csvConfiguration)
          => csvToDatatableConvertor.Convert(csvConfiguration, new MemoryStream(csvBytesBuffer));

        public DataTable Convert(Stream csvContentStream, CsvConfiguration csvConfiguration)
           => csvToDatatableConvertor.Convert(csvConfiguration, csvContentStream);

        public DataTable Convert(string csvFilePath, CsvConfiguration csvConfiguration)
           => csvToDatatableConvertor.Convert(csvConfiguration, csvFilePath);
    }
}
