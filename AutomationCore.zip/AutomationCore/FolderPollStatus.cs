using System.Collections.Generic;

namespace AutomationCore
{
	public class FolderPollStatus : PollStatus
	{
		public FolderSource Source
		{
			get
			{
				return (FolderSource)BaseSource;
			}
			set
			{
				BaseSource = value;
			}
		}

		public string CreatedOrModifiedFile
		{
			get;
			set;
		}

		public string BucketName
		{
			get;
			set;
		}

		public string ObjectKey
		{
			get;
			set;
		}

		public string EmailSource
		{
			get;
			set;
		}

		public List<string> EmailDestinations
		{
			get;
			set;
		}
	}
}
