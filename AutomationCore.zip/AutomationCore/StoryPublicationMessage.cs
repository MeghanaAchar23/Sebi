using System;
using System.Linq;
using AutomationCore.Handbrake;
using EAP.Core.Types;

namespace AutomationCore
{
	public class StoryPublicationMessage : PublicationMessage
	{
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sProductCodes;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sTopicCodes;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sRicReferences;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sLanguageCode;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sNamedItemCodes;

		private string m_sSlug;

		private string m_sCategoryCode;


		public string ProductCodes
		{
			get { return m_sProductCodes; }
			set { m_sProductCodes = value; }
		}

		public string TopicCodes
		{
			get { return m_sTopicCodes; }
			set { m_sTopicCodes = value; }
		}

		public string RicReferences
		{
			get { return m_sRicReferences; }
			set { m_sRicReferences = value; }
		}

		public string NamedItemCodes
		{
			get { return m_sNamedItemCodes; }
			set { m_sNamedItemCodes = value; }
		}

		public string CategoryCode
		{
			get { return m_sCategoryCode; }
			set { m_sCategoryCode = value; }
		}

		public string LanguageCode
		{
			get { return m_sLanguageCode; }
			set { m_sLanguageCode = value; }
		}

		public string Slug
		{
			get { return m_sSlug; }
			set { m_sSlug = value; }
		}

		public bool IsTable
		{
			get { return m_bIsTable; }
			set { m_bIsTable = value; }
		}

		/// <summary>
		/// default 0
		/// </summary>
		/// <remarks>
		/// 1 if m_sMessageType is Alert
		/// 3 if m_sMessageType is Story
		/// </remarks>
		private string m_sNtmPriority;
		private string m_sHeadlineTemplate;
		private string m_sStoryTextTemplate;

		private bool m_bIsTable;

		private string m_sHandbrakeTitle;
		private string m_sNoteName;
		private string m_sCharset;
		private bool m_bIsWrapText;
		/// <summary>
		/// default false
		/// </summary>
		private bool IsHandbrakeSent
		{
			get;
			set;
		}

		/// <summary>
		/// default false
		/// </summary>
		private bool IsAlertSent
		{
			get;
			set;
		}

		public override bool IsSent
		{
			get
			{
				if (IsAutomatic && IsHandbrake)
					return IsAlertSent && IsHandbrakeSent;
				else if (IsAutomatic)
					return IsAlertSent;
				else if (IsHandbrake)
					return IsHandbrakeSent;
				else return base.IsSent;
			}
			set
			{
				//Reuse Message
				IsAlertSent = value;
				IsHandbrakeSent = value;
				base.IsSent = value;
			}
		}

		public int HandbrakeIndex { get; set; }

		public string ActionCode { get; set; }

		public string FormatIndicator { get; set; }

		public string Attribution { get; set; }

		/// <summary>
		/// call parent constructor
		/// </summary>
		/// <param name="sMessageType">
		/// possible values - econ/alert/story
		/// if econ then set m_sQPriority to 120
		/// if alert then set m_sQPriority to 110
		/// if story then set m_sQPriority to 100
		/// </param>
		public StoryPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sHeadlineTemplate, string sStoryTextTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, bool bIsTable, string sSlug, string sCategoryCode, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sHeadlineTemplate, sStoryTextTemplate, sAutomationName, sID, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, bIsTable, sSlug, sCategoryCode, sAttribution);
		}

		public StoryPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sHeadlineTemplate, string sStoryTextTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, bool bIsTable, string sSlug, string sCategoryCode, string sQPriority, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sHeadlineTemplate, sStoryTextTemplate, sAutomationName, sID, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, bIsTable, sSlug, sCategoryCode, sAttribution);
		}

		public StoryPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sHeadlineTemplate, string sStoryTextTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, bool bIsTable, string sSlug, string sCategoryCode, string sHandbrakeTitle, string sNoteName, string sCharset = "", bool bIsWrapText = true, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sHeadlineTemplate, sStoryTextTemplate, sAutomationName, sID, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, bIsTable, sSlug, sCategoryCode, sHandbrakeTitle, sNoteName, sCharset, bIsWrapText, sAttribution);
		}

		public StoryPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sHeadlineTemplate, string sStoryTextTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, bool bIsTable, string sSlug, string sCategoryCode, string sQPriority, string sHandbrakeTitle, string sNoteName, string sCharset = "", bool bIsWrapText = true, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sHeadlineTemplate, sStoryTextTemplate, sAutomationName, sID, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, bIsTable, sSlug, sCategoryCode, sHandbrakeTitle, sNoteName, sCharset, bIsWrapText, sAttribution);
		}

		private void Initialize(string sHeadlineTemplate, string sStoryTextTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, bool bIsTable, string sSlug, string sCategoryCode, string sHandbrakeTitle = "", string sNoteName = "", string sCharset = "", bool bIsWrapText = true, string sAttribution = "")
		{
			m_sHeadlineTemplate = sHeadlineTemplate;
			m_sStoryTextTemplate = sStoryTextTemplate;
			m_sLanguageCode = sLanguageCode;
			m_sNamedItemCodes = sNamedItemCodes;
			if (!string.IsNullOrWhiteSpace(sNtmPriority))
				m_sNtmPriority = sNtmPriority;
			else
				m_sNtmPriority = "3";
			m_sProductCodes = sProductCodes;
			m_sRicReferences = sRicReferences;
			m_sTopicCodes = sTopicCodes;
			m_bIsTable = bIsTable;
			m_sSlug = sSlug;
			m_sCategoryCode = sCategoryCode;
			m_sHandbrakeTitle = sHandbrakeTitle;
			m_sNoteName = sNoteName;
			m_sCharset = sCharset;
			m_bIsWrapText = bIsWrapText;
			this.Attribution = sAttribution;
		}

		/// <summary>
		/// Type: GET, return m_sMessageTemplate
		/// </summary>
		public string HeadlineTemplate
		{
			get
			{
				return m_sHeadlineTemplate;
			}
		}

		public string StoryTextTemplate
		{
			get
			{
				return m_sStoryTextTemplate;
			}
		}

		/// <param name="sHeadlineTemplate">AlertText</param>
		/// <param name="sAdditionalProductCodes">append at the end of m_sProductCodes if not blank</param>
		/// <param name="sAdditionalTopicCodes">append at the end of m_sTopicCodes if not blank</param>
		/// <param name="sAdditionalRicReferences">append at the end of m_sRicReferences if not blank</param>
		/// <param name="sAdditionalNamedItemCodes">append at the end of m_sNamedItemCodes if not blank</param>
		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, bool isDisabled, PollStatus PollStatus)
		{
			if (IsSent || !IsActive)
			{
				IsSent = true;
				string sMessage = "HEADLINE: " + sHeadlineTemplate + " STORY: " + sStoryTextTemplate;
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DateTime.UtcNow, PollStatus.BaseSource.ID, sMessage);

				return true;
			}

			string t_sProductCodes = m_sProductCodes;
			string t_sTopicCodes = m_sTopicCodes;
			string t_sRicReferences = m_sRicReferences;
			string t_sNamedItemCodes = m_sNamedItemCodes;

            t_sProductCodes = Utils.JoinCharSeparatedStrings(t_sProductCodes, sAdditionalProductCodes);
            t_sTopicCodes = Utils.JoinCharSeparatedStrings(t_sTopicCodes, sAdditionalTopicCodes);
            t_sRicReferences = Utils.JoinCharSeparatedStrings(t_sRicReferences, sAdditionalRicReferences);
            t_sNamedItemCodes = Utils.JoinCharSeparatedStrings(t_sNamedItemCodes, sAdditionalNamedItemCodes);
            
			if (IsAutomatic)
				IsAlertSent = SendMessage(sHeadlineTemplate, sStoryTextTemplate, t_sProductCodes, t_sTopicCodes, t_sRicReferences, t_sNamedItemCodes, sActionCode, PollStatus);

			if (IsHandbrake)
				IsHandbrakeSent = SendHandbrake(sHeadlineTemplate, sStoryTextTemplate, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, sActionCode, isDisabled, PollStatus);

			return IsSent;
		}

		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, PollStatus PollStatus)
		{
			return Send(sHeadlineTemplate, sStoryTextTemplate, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, false, PollStatus);
		}

		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, PollStatus PollStatus)
		{
			return Send(sHeadlineTemplate, sStoryTextTemplate, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, sActionCode, false, PollStatus);
		}

		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, bool isDisabled, PollStatus PollStatus)
		{
			string t_sActionCode = "";
			if (!string.IsNullOrWhiteSpace(ActionCode))
				t_sActionCode = ActionCode.Trim().ToUpper();
			return Send(sHeadlineTemplate, sStoryTextTemplate, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, t_sActionCode, isDisabled, PollStatus);
		}
		/// <param name="sHeadlineTemplate">Alert text</param>
		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, PollStatus PollStatus)
		{
			return Send(sHeadlineTemplate, sStoryTextTemplate, "", "", "", "", false, PollStatus);
		}

		/// <param name="sAlertText">Alert text</param>
		public bool Send(string sHeadlineTemplate, string sStoryTextTemplate, bool isDisabled, PollStatus PollStatus)
		{
			return Send(sHeadlineTemplate, sStoryTextTemplate, "", "", "", "", isDisabled, PollStatus);
		}

		private bool SendMessage(string sHeadlineTemplate, string sStoryTextTemplate, string t_sProductCodes, string t_sTopicCodes, string t_sRicReferences, string t_sNamedItemCodes, string t_sActionCode, PollStatus PollStatus)
		{
			DateTime DevSendTime = DateTime.UtcNow;

			if (IsAlertSent || !IsActive)
			{
				IsSent = true;
				string sMessage = "HEADLINE: " + sHeadlineTemplate + " STORY: " + sStoryTextTemplate;
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, sMessage);

				return true;
			}

			if (string.IsNullOrWhiteSpace(sHeadlineTemplate))
				return false;

			IsAlertSent = SendToUcdp(sHeadlineTemplate, sStoryTextTemplate, t_sProductCodes, t_sTopicCodes, t_sRicReferences, t_sNamedItemCodes, t_sActionCode, PollStatus);

			//write log
			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, "HEADLINE: " + sHeadlineTemplate + " STORY: " + sStoryTextTemplate);
			return IsAlertSent;
		}

		private bool SendHandbrake(string sHeadlineTemplate, string sStoryTextTemplate, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, bool isDisabled, PollStatus PollStatus)
		{
			//Log that Developer has sent alert
			DateTime DevSentTime = DateTime.UtcNow;

			string sMessage = "HEADLINE: " + sHeadlineTemplate + " STORY: " + sStoryTextTemplate;

			if (IsHandbrakeSent || !IsActive)
			{
				IsSent = true;
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, sMessage);

				return true;
			}

			if (HandbrakeMessages != null && HandbrakeMessages.Count > 0)
			{
				foreach (HandbrakeMessage message in HandbrakeMessages.Values)
				{
					Story newStory = new Story();
					newStory.Id = ID;
					newStory.Title = m_sHandbrakeTitle;
					newStory.Headline = sHeadlineTemplate;
					newStory.Text = sStoryTextTemplate;
					newStory.NoteName = m_sNoteName;
					newStory.IsTable = m_bIsTable;
					newStory.IsWraptext = m_bIsWrapText;
					newStory.Index = HandbrakeIndex == 0 ? "" : HandbrakeIndex.ToString();
					newStory.ActionCode = sActionCode;
					newStory.Disabled = isDisabled;

					if (string.IsNullOrWhiteSpace(message.LanguageCode))
						message.LanguageCode = m_sLanguageCode;

					string t_sProductCodes = message.PCodes;
					string t_sTopicCodes = message.TCodes;
					string t_sRicReferences = message.RICCodes;
					string t_sNamedItemCodes = message.NICodes;

                    t_sProductCodes = Utils.JoinCharSeparatedStrings(t_sProductCodes, sAdditionalProductCodes);
                    t_sTopicCodes = Utils.JoinCharSeparatedStrings(t_sTopicCodes, sAdditionalTopicCodes);
                    t_sRicReferences = Utils.JoinCharSeparatedStrings(t_sRicReferences, sAdditionalRicReferences);
                    t_sNamedItemCodes = Utils.JoinCharSeparatedStrings(t_sNamedItemCodes, sAdditionalNamedItemCodes);

					message.PCodes = t_sProductCodes.Trim();
					message.TCodes = t_sTopicCodes.Trim();
					message.RICCodes = t_sRicReferences.Trim();
					message.NICodes = t_sNamedItemCodes.Trim();

					message.Send(newStory, PollStatus);
				}

				if (HandbrakeMessages.Values.All(message => message.Stories.Values.Any(story => story.Id == ID)))
					IsHandbrakeSent = true;
			}

			//log send attempt
			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, sMessage);
			return IsHandbrakeSent;
		}

		private bool SendToUcdp(string sHeadlineTemplate, string sStoryTextTemplate, string t_sProductCodes, string t_sTopicCodes, string t_sRicReferences, string t_sNamedItemCodes, string t_sActionCode, PollStatus PollStatus)
		{
			PublicationItem publication = new PublicationItem();

			string USN = PublicationAgent.Usn;
			var trJson = new TRJson
			{
				MessageID = ID,
				Headline = sHeadlineTemplate,
				Body = sStoryTextTemplate,
				Priority = 3,
				PNAC = !string.IsNullOrWhiteSpace(USN) ? ("n" + USN) : null,
				Slugline = m_sSlug,
				FormatIndicator = m_bIsTable ? "T" : "",
				Action = t_sActionCode,
				CreationTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
				PublishedTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Llm = IsLLM
			};

			if (!string.IsNullOrWhiteSpace(m_sLanguageCode))
			{
				trJson.Language = m_sLanguageCode;
				trJson.HeadlineLanguage = m_sLanguageCode;
			}

			if (!string.IsNullOrWhiteSpace(Attribution))
				trJson.Attribution = Attribution;
			if (!string.IsNullOrWhiteSpace(t_sProductCodes))
				trJson.ProductCodes = t_sProductCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();

			MetaDataType metadata = new MetaDataType();
			if (!string.IsNullOrWhiteSpace(t_sRicReferences))
				metadata.Add(MetaDataType.eMetaDataType.ORGANIZATION, "ric", t_sRicReferences.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(t_sTopicCodes))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "n2000", t_sTopicCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(t_sNamedItemCodes))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "nameditem", t_sNamedItemCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(m_sCategoryCode))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "iptc", m_sCategoryCode.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());

			trJson.MetaData = metadata;

			publication.AddOutput(trJson);

			SendToUcdp(publication, PollStatus);
			
            // log the request\response audit
			PollStatus.LogAuditPublication();

            return true;
		}


		private void SendToUcdp(PublicationItem publication, PollStatus pollStatus)
		{
			PublicationAgent.SendUcdpPublication(publication, pollStatus, EmbargoTime, Destinations);
		}
	}
}
