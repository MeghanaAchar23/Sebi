using System;
using System.Threading.Tasks;
using EAP.Core.Configuration;
using Polly;
using Polly.Retry;
using Tweetinvi;
using Tweetinvi.Exceptions;
using Tweetinvi.Models;
using Tweetinvi.Streaming;

namespace AutomationCore.Twitter
{
	public delegate void TweetReceived(ITweet tweet);

	public class TwitterClient
	{
		private object _syncObject = new object();

		private int retryCount = 0;
		private int retry420Count = 0;

		public string ConsumerKey { get; set; }
		public string ConsumerSecret { get; set; }
		public string AccessToken { get; set; }
		public string AccessSecret { get; set; }
		public ITwitterCredentials ClientCredentials { get; set; }
		public TweetReceived OnTweetReceived;
		public bool IsRunning { get; set; }
		public IFilteredStream TwitterStream;
		public TwitterSource Source { get; set; }

		private RetryPolicy GetRetryPolicy = Policy.Handle<TwitterException>().WaitAndRetry(5, retryAttempt => TimeSpan.FromSeconds(5));
		private RetryPolicy ExpRetryPolicy = Policy.Handle<TwitterException>().WaitAndRetry(5, retryAttempt => TimeSpan.FromSeconds(5 * (Math.Pow(2, retryAttempt))));
		private SourceStore Store { get; set; }

		public TwitterClient(TwitterSource twittersource)
		{
			try
			{
				Source = twittersource;
				Store = Source.Store;

				ExceptionHandler.SwallowWebExceptions = false;
				ConsumerKey = twittersource.ConsumerKey;
				ConsumerSecret = twittersource.ConsumerSecret;
				AccessToken = twittersource.AccessToken;
				AccessSecret = twittersource.AccessSecret;

				ClientCredentials = new TwitterCredentials(ConsumerKey, ConsumerSecret, AccessToken, AccessSecret);
				//Auth.SetUserCredentials(ConsumerKey, ConsumerSecret, AccessToken, AccessSecret);
				InititalizeStream();
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), LogLevel.Error); }
		}

		public Task Start()
		{
			AutomationClient.ReutersLog($"{Source.ID}: Starting TwitterClient");
			return Task.Factory.StartNew(async () => await Run(), default,
				TaskCreationOptions.LongRunning, TaskScheduler.Default);
		}

		public void Restart(TimeSpan delay)
		{
			if (!Source.IsSourceBeingPolled)
				return;

			AutomationClient.ReutersLog($"{Source.ID}: Restarting TwitterClient");
			_ = Task.Factory.StartNew(async () =>
			{
				await Task.Delay(delay).ConfigureAwait(false);
				await Run();
			}, default, TaskCreationOptions.LongRunning, TaskScheduler.Default);
		}

		public void Stop()
		{
			try { AutomationClient.ReutersLog($"{Source.ID}: Stopping TwitterClient"); TwitterStream?.StopStream(); } catch { }
		}

		private void InititalizeStream()
		{
			try
			{
				AutomationClient.ReutersLog($"{Source.ID}: Creating filtered stream");

				TwitterStream = Stream.CreateFilteredStream();
				TwitterStream.Credentials = ClientCredentials;
				TwitterStream.StallWarnings = true;

				AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));

				//Add Track
				if (Source.Keywords != null)
				{
					foreach (var keyword in Source.Keywords)
					{
						if (!string.IsNullOrWhiteSpace(keyword))
							TwitterStream.AddTrack(keyword);
					}
				}

				//Add Follow
				try
				{
					var users = GetRetryPolicy.Execute(() => Auth.ExecuteOperationWithCredentials(ClientCredentials, () => User.GetUsersFromScreenNames(Source.Users)));
					if (users != null)
					{
						foreach (var user in users)
						{
							TwitterStream.AddFollow(user);
						}
					}
				}
				catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), LogLevel.Error); }

				TwitterStream.KeepAliveReceived += (s, e) => { retryCount = 0; retry420Count = 0; AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass)); };
				TwitterStream.LimitReached += (s, e) => { AutomationClient.ForceLog($"{Source.ID}: Twitter sending limit reached. {e.NumberOfTweetsNotReceived} tweets were not received.", LogLevel.Warn); };
				TwitterStream.MatchingTweetReceived += (s, e) =>
				{
					AutomationClient.ForceLog($"{Source.ID}: Tweet received, {e.Tweet.Text}", LogLevel.Trace);

					Task.Run(() =>
					{
						OnTweetReceived?.Invoke(e.Tweet);
					}).ContinueWith(t => { AutomationClient.ForceLog(t.Exception?.ToString(), LogLevel.Error); }, TaskContinuationOptions.OnlyOnFaulted);

					AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
				};

				TwitterStream.WarningFallingBehindDetected += Stream_WarningFallingBehindDetected;
				TwitterStream.DisconnectMessageReceived += Stream_DisconnectMessageReceived;
				TwitterStream.StreamStarted += Stream_StreamStarted;
				TwitterStream.StreamStopped += Stream_StreamStopped;
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), LogLevel.Error); }
		}

		private async Task Run()
		{
			try
			{
				if (TwitterStream == null)
				{
					AutomationClient.ForceLog($"{Source.ID}: TwitterStream is null", LogLevel.Warn);
					return;
				}

				await TwitterStream.StartStreamMatchingAllConditionsAsync().ConfigureAwait(false);
			}
			catch (Exception ex)
			{
				AutomationClient.ForceLog("Exception in Twitter stream: " + ex.ToString(), LogLevel.Error);
			}
		}

		private void Stream_StreamStopped(object sender, Tweetinvi.Events.StreamExceptionEventArgs e)
		{
			lock (_syncObject)
				IsRunning = false;

			if (e.DisconnectMessage == null && e.Exception == null)
			{
				AutomationClient.ForceLog($"{Source.ID}: Twitter stream stopped.", LogLevel.Warn);
				return;
			}

			if (e.DisconnectMessage != null)
				AutomationClient.ForceLog($"{Source.ID}: Stream was Stopped. Description: {e.DisconnectMessage}", LogLevel.Error);
			if (e.Exception != null)
				AutomationClient.ForceLog($"{Source.ID}: Stream was Stopped. Exception: {e.Exception.ToString()}", LogLevel.Error);

			if (e.DisconnectMessage != null || (e.Exception != null && e.Exception is TwitterException && ((TwitterException)e.Exception).StatusCode != 420))
			{
				if (retryCount < 7)
					retryCount++;

				TimeSpan retryInterval = TimeSpan.FromSeconds(Math.Pow(2, retryCount));

				if (retryInterval.TotalSeconds > 120)
					retryInterval = TimeSpan.FromSeconds(120);

				Restart(retryInterval);
			}
			else if (e.Exception != null && e.Exception is TwitterException && ((TwitterException)e.Exception).StatusCode == 420)
			{
				if (retry420Count < 4)
					retry420Count++;

				TimeSpan retryInterval = TimeSpan.FromMinutes(Math.Pow(2, retry420Count));

				if (retryInterval.TotalMinutes > 15)
					retryInterval = TimeSpan.FromMinutes(15);

				Restart(retryInterval);
			}
			else if (e.Exception != null)
			{
				Restart(TimeSpan.FromSeconds(5));
			}
		}

		private void Stream_StreamStarted(object sender, EventArgs e)
		{
			//AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
			lock (_syncObject)
				IsRunning = true;
		}

		private void Stream_DisconnectMessageReceived(object sender, Tweetinvi.Events.DisconnectedEventArgs e)
		{
			AutomationClient.ForceLog($"{Source.ID}: Stream was disconnected by twitter. Description: {e.DisconnectMessage}", LogLevel.Error);
		}

		private void Stream_WarningFallingBehindDetected(object sender, Tweetinvi.Events.WarningFallingBehindEventArgs e)
		{
			AutomationClient.ForceLog($"{Source.ID}: Stream falling behind warning detected", LogLevel.Warn);
		}

		/*
		public bool LoadHistory()
		{
			AutomationClient.ForceLog("Starting LoadHistory");

			try
			{
				var homeTimelineParameters = new HomeTimelineParameters { ExcludeReplies = true, MaximumNumberOfTweetsToRetrieve = 20 };
				var tweets = getTweetsPolicy.Execute(() => Timeline.GetHomeTimeline(homeTimelineParameters));


			}
			catch { }

			return false;
		}*/
	}
}
