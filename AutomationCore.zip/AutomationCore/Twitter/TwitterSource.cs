using System.Collections.Generic;
using System.Text;
using EAP.Core.Configuration;
using Tweetinvi.Models;

namespace AutomationCore.Twitter
{
	public abstract class TwitterSource : Source
	{
		public TwitterSource()
			: base()
		{
			PollManager = new TwitterPollManager(this);
		}

		public List<string> Keywords { get; set; }
		public List<string> Users { get; set; }

		public string ConsumerKey { get; set; }
		public string ConsumerSecret { get; set; }
		public string AccessToken { get; set; }
		public string AccessSecret { get; set; }

		public void Initialize()
		{
			((TwitterPollManager)PollManager).Initialize();
		}

		public override bool LoadHistory()
		{
			return OnHistoryLoaded();
		}

		public override bool OnHistoryLoaded()
		{
			return true;
		}

		public override string GetResource()
		{
			return $"{Users?.ToJson()}\r\n{Keywords?.ToJson()}";
		}

		public abstract void OnNewTweetReceived(TwitterPollStatus oTwitterPollStatus);
	}
}
