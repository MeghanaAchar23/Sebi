using Tweetinvi.Models;

namespace AutomationCore.Twitter
{
	public class TwitterPollStatus : PollStatus
	{
		public TwitterSource Source
		{
			get
			{
				return (TwitterSource)BaseSource;
			}
			set
			{
				BaseSource = value;
			}
		}

		public ITweet Tweet
		{
			get;
			set;
		}
	}
}
