using System;
using System.Threading.Tasks;
using Tweetinvi.Models;

namespace AutomationCore.Twitter
{
	public class TwitterPollManager : PollManager, ISubscriptionManager
	{
		public TwitterClient Client { get; set; }

		//constructor
		public TwitterPollManager(Source oSource)
			: base(oSource)
		{

		}

		public void Initialize()
		{
			Client = new TwitterClient((TwitterSource)Source);
			Client.OnTweetReceived += ProcessTweet;
		}

		public void Stop()
		{
			Client?.Stop();
			Source.Store.AutomationClient.TryToStop();
		}

		public Task StartAsync()
		{
			return Client?.Start();
		}

		protected void ProcessTweet(ITweet tweet)
		{
			Int64 t_iPollID = 0;
			bool t_bRet = OnPollStart(ref t_iPollID);

			try
			{
				Source.LatestPollDateTime = DateTime.UtcNow;

				PollFunction(Source, t_iPollID, tweet);
			}
			catch (Exception ex)
			{
				//TODO: Add error in XML log.
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}

			OnPollEnd();
		}

		protected void PollFunction(Source source, Int64 pollId, ITweet tweet)
		{
			AutomationClient.ReutersLog($"{source.ID}, {pollId}, {tweet.Text}");

			TwitterSource twitterSource = (TwitterSource)source;

			TwitterPollStatus oPollStatus = new TwitterPollStatus();

			//UrlPollEvent oEvent = new UrlPollEvent();
			oPollStatus.PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() };
            oPollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());

			oPollStatus.Source = twitterSource;

			//log start time
			oPollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
				oPollStatus.Tweet = tweet;
				oPollStatus.ChunkAttempt = oPollStatus.PollAttempt.NewChunkAttempt("1");
				oPollStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
				oPollStatus.ChunkAttempt.LogComment($"Tweet: {oPollStatus.Tweet.IdStr}, {oPollStatus.Tweet.Text}");

				twitterSource.OnNewTweetReceived(oPollStatus);
			}
			catch (Exception ex)
			{
				oPollStatus.ChunkAttempt.LogError(ex.ToString());
			}

			oPollStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;

			//log end time
			oPollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(source.ID, pollId.ToString(), 0, oPollStatus.PollAttempt.ToJson());
			}
		}

		public override Task PollFunction(Source source, Int64 pollId)
		{
			return Task.CompletedTask;
		}

		public override Task DoHistoryPoll()
		{
			return Task.CompletedTask;
		}
	}
}
