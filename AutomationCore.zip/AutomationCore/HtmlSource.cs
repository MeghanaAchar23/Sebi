using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Diagnostics;

namespace AutomationCore
{
	[Flags]
	public enum HtmlSourceSettings
	{
		Default = 0x3E,
		OnlyLinks = 0x1A,
		OnlyTitles = 0x24,
		ExtractLink = 0x02,
		ExtractTitle = 0x04,
		ConvertToAbsoluteUri = 0x08,
		RemoveNewLinesFromUrl = 0x10,
		CleanTitle = 0x20,
		RemoveScripts = 0x40,
		None = 0x01
	}

	[Flags]
	public enum ComparisonOptions
	{
		CompareOnlyLink = 0x01,
		CompareOnlyTitle = 0x02,
		CompareBothLinkAndTitle = 0x04,
		CompareOnlyLinkIgnoreCase = 0x08,
		CompareOnlyTitleIgnoreCase = 0x10,
		CompareBothLinkAndTitleIgnoreCase = 0x20
	}

	public partial class HtmlSource
	{
		private HtmlSourceSettings _extractionSettings;

		public string Url
		{
			get;
			set;
		}

		public List<Link> Links
		{
			get;
			set;
		}

		public HtmlSourceSettings ExtractionSetting
		{
			get
			{
				return _extractionSettings;
			}
			set
			{
				_extractionSettings = value;
				if ((_extractionSettings & HtmlSourceSettings.ExtractLink) != HtmlSourceSettings.ExtractLink)
					ComparisonOptions = ComparisonOptions.CompareOnlyTitleIgnoreCase;
				else if ((_extractionSettings & HtmlSourceSettings.ExtractTitle) != HtmlSourceSettings.ExtractTitle)
					ComparisonOptions = ComparisonOptions.CompareOnlyLinkIgnoreCase;
				else
					ComparisonOptions = ComparisonOptions.CompareBothLinkAndTitleIgnoreCase;
			}
		}

		public ComparisonOptions ComparisonOptions
		{
			get;
			set;
		}

		private object m_SyncLocker = new object();

		public int MaximumLinksInList
		{
			get;
			set;
		}

		public HtmlSource()
		{
			ExtractionSetting = HtmlSourceSettings.Default;
			MaximumLinksInList = int.MaxValue;
		}

		public HtmlSource(string sUrl)
			: this()
		{
			Url = sUrl;
		}

		public void InitializeSource(UrlPollStatus oPollStatus)
		{
			try
			{
				Stopwatch st = new Stopwatch();
				st.Start();
				Encoding encoding = oPollStatus.Source.Encoding;
				/*if (oPollStatus.ResponseEncoding != null)
					encoding = oPollStatus.ResponseEncoding;*/
				string sUrl = oPollStatus.Source.Url;
				if (oPollStatus.ResponseUri != null)
					sUrl = oPollStatus.ResponseUri.AbsoluteUri;
				lock (m_SyncLocker)
				{
					Links = GetLinksFromContent(sUrl, oPollStatus.Content, encoding);
					Links = Links.Distinct(new LinkComparer(ComparisonOptions)).ToList();
					oPollStatus.LinkUpdates = Links;
				}
				st.Stop();
				oPollStatus.PollAttempt.LogComment("Time to extract links: " + st.ElapsedMilliseconds + " ms");
			}
			catch (Exception ex)
			{
				oPollStatus.PollAttempt.LogError(ex.ToString());
			}
		}

		public void InitializeSource(string baseUrl, string content)
		{
			try
			{
				lock (m_SyncLocker)
				{
					Links = GetLinksFromContent(baseUrl, content);
					Links = Links.Distinct(new LinkComparer(ComparisonOptions)).ToList();
				}
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}
		}

		public List<Link> CheckUpdates(UrlPollStatus oPollStatus)
		{
			try
			{
				Stopwatch st = new Stopwatch();
				st.Start();

				Encoding encoding = oPollStatus.Source.Encoding;

				if (oPollStatus.ResponseEncoding != null)
					encoding = oPollStatus.ResponseEncoding;

				string sUrl = oPollStatus.Source.Url;

				if (oPollStatus.ResponseUri != null)
					sUrl = oPollStatus.ResponseUri.AbsoluteUri;

				List<Link> oUpdateLinks = GetLinksFromContent(sUrl, oPollStatus.Content, encoding);
				oUpdateLinks = oUpdateLinks.Distinct(new LinkComparer(ComparisonOptions)).ToList();
				st.Stop();

				if (oPollStatus.ChunkAttempt != null)
					oPollStatus.ChunkAttempt.LogComment("Time to extract links: " + st.ElapsedMilliseconds + " ms");
				else
					oPollStatus.PollAttempt.LogComment("Time to extract links: " + st.ElapsedMilliseconds + " ms");
				lock (m_SyncLocker)
				{
					st.Restart();
					if (Links != null)
					{
						List<Link> oNewLinks = oUpdateLinks.Except(Links, new LinkComparer(ComparisonOptions)).ToList();
						st.Stop();
						if (oPollStatus.ChunkAttempt != null)
							oPollStatus.ChunkAttempt.LogComment("Time to compare links: " + st.ElapsedMilliseconds + " ms");
						else
							oPollStatus.PollAttempt.LogComment("Time to compare links: " + st.ElapsedMilliseconds + " ms");
						AddLinks(oNewLinks);
						return oNewLinks;
					}
					else
					{						
						AddLinks(oUpdateLinks);
						return oUpdateLinks;
					}
				}
			}
			catch (Exception ex)
			{
				if (oPollStatus.ChunkAttempt != null)
					oPollStatus.ChunkAttempt.LogError(ex.ToString());
				else
					oPollStatus.PollAttempt.LogError(ex.ToString());

				oPollStatus.LogAuditError();
			}
			return new List<Link>();
		}

		public List<Link> CheckUpdates(string baseUrl, string content)
		{
			try
			{
				List<Link> oUpdateLinks = GetLinksFromContent(baseUrl, content);
				oUpdateLinks = oUpdateLinks.Distinct(new LinkComparer(ComparisonOptions)).ToList();
				lock (m_SyncLocker)
				{
					if (Links != null)
					{
						List<Link> oNewLinks = oUpdateLinks.Except(Links, new LinkComparer(ComparisonOptions)).ToList();
						AddLinks(oNewLinks);
						return oNewLinks;
					}
					else
					{
                        AddLinks(oUpdateLinks);
                        return oUpdateLinks;
                    }
				}
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}
			return new List<Link>();
		}

		private void AddLinks(List<Link> newLinks)
		{
			lock (m_SyncLocker)
			{
				if (Links == null)
					Links = new List<Link>();

				if (Links.Count > MaximumLinksInList)
					Links.RemoveRange(0, newLinks.Count);
				Links.AddRange(newLinks);
			}
		}

		public List<Link> GetLinksFromContent(string content)
		{
			return GetLinksFromContent(Url, content);
		}

		public List<Link> GetLinksFromContent(byte[] byContent)
		{
			if (byContent != null)
			{
				string htmlContent = Encoding.UTF8.GetString(byContent);
				return GetLinksFromContent(Url, htmlContent);
			}
			return new List<Link>();
		}

		public List<Link> GetLinksFromContent(byte[] byContent, Encoding encoding)
		{
			if (encoding != null)
			{
				string htmlContent = encoding.GetString(byContent);
				return GetLinksFromContent(Url, htmlContent);
			}
			return new List<Link>();
		}

		public List<Link> GetLinksFromContent(string baseUrl, byte[] byContent)
		{
			if (byContent != null)
			{
				string htmlContent = Encoding.UTF8.GetString(byContent);
				return GetLinksFromContent(baseUrl, htmlContent);
			}
			return new List<Link>();
		}

		public List<Link> GetLinksFromContent(string baseUrl, byte[] byContent, Encoding encoding)
		{
			if (encoding != null && byContent != null)
			{
				string htmlContent = encoding.GetString(byContent);
				return GetLinksFromContent(baseUrl, htmlContent);
			}
			return new List<Link>();
		}

		public List<Link> GetLinksFromContent(string baseUrl, string htmlContent)//, HtmlSourceSettings settings = HtmlSourceSettings.ConvertToAbsoluteUri | HtmlSourceSettings.ExtractTitle | HtmlSourceSettings.RemoveNewLinesFromUrl)
		{
			htmlContent = Regex.Replace(htmlContent, @"<!--.*?-->", "", RegexOptions.Singleline);
			htmlContent = Regex.Replace(htmlContent, @"<link.*?(/?>|</link>)", "", RegexOptions.Singleline);

			if ((ExtractionSetting & HtmlSourceSettings.RemoveScripts) == HtmlSourceSettings.RemoveScripts)
				htmlContent = Regex.Replace(htmlContent, @"<script.*?</script>", "", RegexOptions.Singleline);

			List<Link> oList = new List<Link>();

			string sBaseUrl = "";

			if ((ExtractionSetting & HtmlSourceSettings.ConvertToAbsoluteUri) == HtmlSourceSettings.ConvertToAbsoluteUri)
			{
				sBaseUrl = GetBaseUri(htmlContent);
				if (!string.IsNullOrWhiteSpace(sBaseUrl) && (sBaseUrl.StartsWith("http:") || sBaseUrl.StartsWith("https:")))
					baseUrl = sBaseUrl;
			}

			string sPattern = @"<a\s+[^>]*href\s*=\s*(""[^""]*""|'[^']*'|[^>\s]+).*?>(.*?)(?=</a>|<a)";
			Regex ObjRegex = new Regex(sPattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);

			string[] ignoreUrlStartingWith = new string[] { "mailto:", "res:" };

			MatchCollection mLinksColl = ObjRegex.Matches(htmlContent);
			if (mLinksColl.Count != 0)
			{
				foreach (Match m in mLinksColl)
				{
					string t_csUrl = "";
					string t_csTitle = "";

					if ((ExtractionSetting & HtmlSourceSettings.ExtractTitle) == HtmlSourceSettings.ExtractTitle)
					{
						t_csTitle = m.Groups[2].Value.Trim();
						t_csTitle = Regex.Replace(t_csTitle, "&nbsp;", " ", RegexOptions.IgnoreCase | RegexOptions.Singleline);
						if ((ExtractionSetting & HtmlSourceSettings.CleanTitle) == HtmlSourceSettings.CleanTitle)
							t_csTitle = CleanTitle(t_csTitle);
					}

					if ((ExtractionSetting & HtmlSourceSettings.ExtractLink) == HtmlSourceSettings.ExtractLink)
					{
						t_csUrl = m.Groups[1].Value.Trim();
						if ((t_csUrl.StartsWith("\"") && t_csUrl.EndsWith("\"")) || (t_csUrl.StartsWith("'") && t_csUrl.EndsWith("'")))
						{
							t_csUrl = t_csUrl.Remove(0, 1);
							t_csUrl = t_csUrl.Remove(t_csUrl.Length - 1, 1);
						}

						t_csUrl = CleanUrl(t_csUrl);

						if (ignoreUrlStartingWith.Any(s => t_csUrl.ToLowerInvariant().StartsWith(s)))
							continue;

						if (!string.IsNullOrWhiteSpace(baseUrl) && (ExtractionSetting & HtmlSourceSettings.ConvertToAbsoluteUri) == HtmlSourceSettings.ConvertToAbsoluteUri)
						{
							try
							{
								Uri ObjUri = new Uri(new Uri(baseUrl), t_csUrl);
								t_csUrl = ObjUri.AbsoluteUri;
							}
							catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
						}
					}

					oList.Add(new Link { Url = t_csUrl, Title = t_csTitle });
				}
			}
			return oList;
		}

		public string GetBaseUri(string sLinkData)
		{
			string sPattern = @"<base\s+[^>]*href\s*=\s*(""[^""]*""|'[^']*'|[^>\s]+)";
			Regex ObjReg = new Regex(sPattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
			Match mt = ObjReg.Match(sLinkData);
			if (mt.Success)
			{
				string t_csUrl = mt.Groups[1].Value.Trim();
				if ((t_csUrl.StartsWith("\"") && t_csUrl.EndsWith("\"")) || (t_csUrl.StartsWith("'") && t_csUrl.EndsWith("'")))
				{
					t_csUrl = t_csUrl.Remove(0, 1);
					t_csUrl = t_csUrl.Remove(t_csUrl.Length - 1, 1);
				}
				return CleanUrl(t_csUrl);
			}
			return "";
		}

		public string CleanUrl(string t_csUrl)
		{
			string EncodingCharacter = @"&#xd;|&#xa;|&#x9;";
			if ((ExtractionSetting & HtmlSourceSettings.RemoveNewLinesFromUrl) == HtmlSourceSettings.RemoveNewLinesFromUrl)
				EncodingCharacter += "|[\r\n\t]";

			t_csUrl = Regex.Replace(t_csUrl, EncodingCharacter, "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
			t_csUrl = HttpUtility.HtmlDecode(t_csUrl);
            t_csUrl = DecodeAndTrimUrlPath(t_csUrl);
            t_csUrl = t_csUrl.Trim();
			if (t_csUrl.ToLower() == "http://#" || t_csUrl.ToLower() == "https://#")
				t_csUrl = "#";
			if (Regex.IsMatch(t_csUrl, @"^https?://\W*$", RegexOptions.IgnoreCase | RegexOptions.Multiline))
				t_csUrl = "";

			return t_csUrl;
		}

		public string CleanTitle(string t_csTitle)
		{
			t_csTitle = HttpUtility.HtmlDecode(t_csTitle);
			t_csTitle = ConvertToText(ref t_csTitle);
			return t_csTitle;
		}

        public string DecodeAndTrimUrlPath(string url)
        {
            if (string.IsNullOrEmpty(url))
                return url;

            try
            {
                return DecodeAndTrimUrlPathImpl(url);
            }
            catch(Exception ex)
            {
                AutomationClient.ReutersLog($"Failed to decode and trim {url}. Error = {ex.Message}",
                       NLog.LogLevel.Debug);

                return url;
            }

            string DecodeAndTrimUrlPathImpl(string url)
            {
                int schemaPos = url.IndexOf("://");
                schemaPos = schemaPos > -1
                    ? schemaPos + "://".Length
                    : 0;

                int queryStringPos = url.IndexOf("?");
                int fragmentPos = url.IndexOf("#");
                int absolutePathLastIndex = queryStringPos > -1
                    ? queryStringPos
                    : fragmentPos > -1
                        ? fragmentPos
                        : url.Length;

                int firstSlashIndxAfterSchema = url.IndexOf('/',
                    schemaPos);
                int absolutePathFirstIndex = firstSlashIndxAfterSchema > -1
                    ? firstSlashIndxAfterSchema
                    : absolutePathLastIndex;

                if (absolutePathFirstIndex - schemaPos <= 0)
                    return url;

                string host = url.Substring(schemaPos,
                    absolutePathFirstIndex - schemaPos);

                return url.Substring(0, schemaPos)
                    + HttpUtility.UrlDecode(host).Trim()
                    + url.Substring(absolutePathFirstIndex);
            }
        }

		public class LinkComparer : IEqualityComparer<Link>
		{
			public LinkComparer()
			{
			}

			public LinkComparer(ComparisonOptions options)
			{
				this.CompareOptions = options;
			}

			public ComparisonOptions CompareOptions
			{
				get;
				set;
			}

			public bool Equals(Link a, Link b)
			{
				if (a == null)
					return b == null;
				bool blg = false;
				if ((CompareOptions & ComparisonOptions.CompareOnlyLink) == ComparisonOptions.CompareOnlyLink)
					blg = a.Url == b.Url;
				else if ((CompareOptions & ComparisonOptions.CompareOnlyLinkIgnoreCase) == ComparisonOptions.CompareOnlyLinkIgnoreCase)
					blg = (string.Compare(a.Url, b.Url, true) == 0);
				else if ((CompareOptions & ComparisonOptions.CompareOnlyTitle) == ComparisonOptions.CompareOnlyTitle)
					blg = a.Title == b.Title;
				else if ((CompareOptions & ComparisonOptions.CompareOnlyTitleIgnoreCase) == ComparisonOptions.CompareOnlyTitleIgnoreCase)
					blg = (string.Compare(a.Title, b.Title, true) == 0);
				else if ((CompareOptions & ComparisonOptions.CompareBothLinkAndTitle) == ComparisonOptions.CompareBothLinkAndTitle)
					blg = a.Url == b.Url && a.Title == b.Title;
				else
					blg = (string.Compare(a.Url, b.Url, true) == 0 && string.Compare(a.Title, b.Title, true) == 0);
				return blg;
			}

			public int GetHashCode(Link a)
			{
				if ((CompareOptions & ComparisonOptions.CompareOnlyLink) == ComparisonOptions.CompareOnlyLink)
					return a.Url.GetHashCode();
				else if ((CompareOptions & ComparisonOptions.CompareOnlyLinkIgnoreCase) == ComparisonOptions.CompareOnlyLinkIgnoreCase)
					return a.Url.ToLower().GetHashCode();
				else if ((CompareOptions & ComparisonOptions.CompareOnlyTitle) == ComparisonOptions.CompareOnlyTitle)
					return a.Title.GetHashCode();
				else if ((CompareOptions & ComparisonOptions.CompareOnlyTitleIgnoreCase) == ComparisonOptions.CompareOnlyTitleIgnoreCase)
					return a.Title.ToLower().GetHashCode();
				else if ((CompareOptions & ComparisonOptions.CompareBothLinkAndTitle) == ComparisonOptions.CompareBothLinkAndTitle)
					return (a.Url + a.Title).GetHashCode();
				else
					return (a.Url + a.Title).ToLower().GetHashCode();
			}
		}

		private Regex tagComment = new Regex("<!--(.|\\s)*?-->", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
		private Regex tagScript = new Regex("<(script|style).*?>.*?</(script|style)[\\s]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
		private Regex tagS = new Regex("\\s+");
		private Regex tagW = new Regex("<[\\w!/](.|\n)*?>", RegexOptions.IgnoreCase | RegexOptions.Compiled);
		private Regex tagS2 = new Regex("^\\s+", RegexOptions.Multiline | RegexOptions.Compiled);

		public string ConvertToText(ref string t_sHtml)
		{
			string sFormat = "";
			string sText = t_sHtml;
			sText = System.Web.HttpUtility.HtmlDecode(sText);

			sFormat = "";
			sText = tagComment.Replace(sText, sFormat);

			sFormat = "";
			sText = tagScript.Replace(sText, sFormat);

			sFormat = " ";
			sText = tagS.Replace(sText, sFormat);

			sFormat = "";
			sText = tagW.Replace(sText, sFormat);

			sFormat = "";
			sText = tagS2.Replace(sText, sFormat);

			return sText.Trim();
		}
	}
}
