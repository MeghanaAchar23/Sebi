using System;
using System.Linq;
using AutomationCore.Handbrake;
using EAP.Core.Types;

namespace AutomationCore
{
	public class AlertPublicationMessage : PublicationMessage
	{
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sProductCodes;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sTopicCodes;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sRicReferences;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sLanguageCode;
		/// <summary>
		/// default blank
		/// </summary>
		private string m_sNamedItemCodes;

		private string m_sCategoryCode;

		public string ProductCodes
		{
			get { return m_sProductCodes; }
			set { m_sProductCodes = value; }
		}

		public string TopicCodes
		{
			get { return m_sTopicCodes; }
			set { m_sTopicCodes = value; }
		}

		public string RicReferences
		{
			get { return m_sRicReferences; }
			set { m_sRicReferences = value; }
		}

		public string NamedItemCodes
		{
			get { return m_sNamedItemCodes; }
			set { m_sNamedItemCodes = value; }
		}

		public string CategoryCode
		{
			get { return m_sCategoryCode; }
			set { m_sCategoryCode = value; }
		}

		public string LanguageCode
		{
			get { return m_sLanguageCode; }
			set { m_sLanguageCode = value; }
		}

		/// <summary>
		/// default 0
		/// </summary>
		/// <remarks>
		/// 1 if m_sMessageType is Alert
		/// 3 if m_sMessageType is Story
		/// </remarks>
		private string m_sNtmPriority;
		private string m_sAlertTemplate;

		private string m_sHandbrakeTitle;
		private string m_sNoteName;
		private bool m_bForceCapitals;

		/// <summary>
		/// default false
		/// </summary>
		private bool IsHandbrakeSent
		{
			get;
			set;
		}

		/// <summary>
		/// default false
		/// </summary>
		private bool IsAlertSent
		{
			get;
			set;
		}

		public override bool IsSent
		{
			get
			{
				if (IsAutomatic && IsHandbrake)
					return IsAlertSent && IsHandbrakeSent;
				else if (IsAutomatic)
					return IsAlertSent;
				else if (IsHandbrake)
					return IsHandbrakeSent;
				else return base.IsSent;
			}
			set
			{
				//Reuse Message
				IsAlertSent = value;
				IsHandbrakeSent = value;
				base.IsSent = value;
			}
		}

		public int HandbrakeIndex { get; set; }

		public string ActionCode { get; set; }

		public string FormatIndicator { get; set; }

		public string Attribution { get; set; }

		/// <summary>
		/// call parent constructor
		/// </summary>
		/// <param name="sMessageType">
		/// possible values - econ/alert/story
		/// if econ then set m_sQPriority to 120
		/// if alert then set m_sQPriority to 110
		/// if story then set m_sQPriority to 100
		/// </param>
		public AlertPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAlertTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, string sCategoryCode, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sAlertTemplate, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, sCategoryCode, sAttribution);
		}

		public AlertPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAlertTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, string sCategoryCode, string sQPriority, string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sAlertTemplate, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, sCategoryCode, sAttribution);
		}

		public AlertPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAlertTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, string sCategoryCode, string sHandbrakeTitle, string sNoteName, bool bForceCapitals = true, string sCharset = "", string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sAlertTemplate, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, sCategoryCode, sHandbrakeTitle, sNoteName, bForceCapitals, sCharset, sAttribution);
		}

		public AlertPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAlertTemplate, string sAutomationName, string sID, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, string sCategoryCode, string sQPriority, string sHandbrakeTitle, string sNoteName, bool bForceCapitals = true, string sCharset = "", string sAttribution = "")
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sAlertTemplate, sLanguageCode, sNamedItemCodes, sNtmPriority, sProductCodes, sRicReferences, sTopicCodes, sCategoryCode, sHandbrakeTitle, sNoteName, bForceCapitals, sCharset, sAttribution);
		}

		private void Initialize(string sAlertTemplate, string sLanguageCode, string sNamedItemCodes, string sNtmPriority, string sProductCodes, string sRicReferences, string sTopicCodes, string sCategoryCode, string sHandbrakeTitle = "", string sNoteName = "", bool bForceCapitals = true, string sCharset = "", string sAttribution = "")
		{
			m_sAlertTemplate = sAlertTemplate;
			m_sLanguageCode = sLanguageCode;
			m_sNamedItemCodes = sNamedItemCodes;
			if (!string.IsNullOrWhiteSpace(sNtmPriority))
				m_sNtmPriority = sNtmPriority;
			else
				m_sNtmPriority = "1";
			m_sProductCodes = sProductCodes;
			m_sRicReferences = sRicReferences;
			m_sTopicCodes = sTopicCodes;
			m_sCategoryCode = sCategoryCode;
			m_sHandbrakeTitle = sHandbrakeTitle;
			m_sNoteName = sNoteName;
			m_bForceCapitals = bForceCapitals;
			this.Attribution = sAttribution;
		}

		/// <summary>
		/// Type: GET, return m_sMessageTemplate
		/// </summary>
		public string AlertTemplate
		{
			get
			{
				return m_sAlertTemplate;
			}
		}

		/// <param name="sHeadlineTemplate">AlertText</param>
		/// <param name="sAdditionalProductCodes">append at the end of m_sProductCodes if not blank</param>
		/// <param name="sAdditionalTopicCodes">append at the end of m_sTopicCodes if not blank</param>
		/// <param name="sAdditionalRicReferences">append at the end of m_sRicReferences if not blank</param>
		/// <param name="sAdditionalNamedItemCodes">append at the end of m_sNamedItemCodes if not blank</param>
		public bool Send(string sAlertText, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, bool isDisabled, PollStatus PollStatus)
		{
			if (IsSent || !IsActive)
			{
				//log that developer has sent alert
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DateTime.UtcNow, PollStatus.BaseSource.ID, sAlertText);
				IsSent = true;
				return true;
			}

			string t_sProductCodes = m_sProductCodes;
			string t_sTopicCodes = m_sTopicCodes;
			string t_sRicReferences = m_sRicReferences;
			string t_sNamedItemCodes = m_sNamedItemCodes;
            			
            t_sProductCodes = Utils.JoinCharSeparatedStrings(t_sProductCodes, sAdditionalProductCodes);
            t_sTopicCodes = Utils.JoinCharSeparatedStrings(t_sTopicCodes, sAdditionalTopicCodes);
            t_sRicReferences = Utils.JoinCharSeparatedStrings(t_sRicReferences, sAdditionalRicReferences);
            t_sNamedItemCodes = Utils.JoinCharSeparatedStrings(t_sNamedItemCodes, sAdditionalNamedItemCodes);
            
			if (IsAutomatic)
				IsAlertSent = SendMessage(sAlertText, t_sProductCodes, t_sTopicCodes, t_sRicReferences, t_sNamedItemCodes, sActionCode, PollStatus);

			if (IsHandbrake)
				IsHandbrakeSent = SendHandbrake(sAlertText, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, sActionCode, isDisabled, PollStatus);

			return IsSent;
		}

		public bool Send(string sAlertText, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, PollStatus PollStatus)
		{
			return Send(sAlertText, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, false, PollStatus);
		}

		public bool Send(string sAlertText, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, PollStatus PollStatus)
		{
			return Send(sAlertText, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, sActionCode, false, PollStatus);
		}

		public bool Send(string sAlertText, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, bool isDisabled, PollStatus PollStatus)
		{
			string t_sActionCode = "";
			if (!string.IsNullOrWhiteSpace(ActionCode))
				t_sActionCode = ActionCode.Trim().ToUpper();
			return Send(sAlertText, sAdditionalProductCodes, sAdditionalTopicCodes, sAdditionalRicReferences, sAdditionalNamedItemCodes, t_sActionCode, isDisabled, PollStatus);
		}

		/// <param name="sAlertText">Alert text</param>
		public bool Send(string sAlertText, PollStatus PollStatus)
		{
			return Send(sAlertText, "", "", "", "", false, PollStatus);
		}

		/// <param name="sAlertText">Alert text</param>
		public bool Send(string sAlertText, bool isDisabled, PollStatus PollStatus)
		{
			return Send(sAlertText, "", "", "", "", isDisabled, PollStatus);
		}

		private bool SendMessage(string sAlertText, string t_sProductCodes, string t_sTopicCodes, string t_sRicReferences, string t_sNamedItemCodes, string t_sActionCode, PollStatus PollStatus)
		{
			//Log that Developer has sent alert
			DateTime DevSentTime = DateTime.UtcNow;

			if (string.IsNullOrWhiteSpace(sAlertText))
				return false;

			if (IsAlertSent || !IsActive)
			{
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, sAlertText);
				IsSent = true;
				return true;
			}

			IsAlertSent = SendToUcdp(sAlertText, t_sProductCodes, t_sTopicCodes, t_sRicReferences, t_sNamedItemCodes, t_sActionCode, PollStatus);

			//log send attempt
			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, sAlertText);
			return IsAlertSent;
		}

		private bool SendHandbrake(string sAlertText, string sAdditionalProductCodes, string sAdditionalTopicCodes, string sAdditionalRicReferences, string sAdditionalNamedItemCodes, string sActionCode, bool isDisabled, PollStatus PollStatus)
		{
			//Log that Developer has sent alert
			DateTime DevSentTime = DateTime.UtcNow;

			if (IsHandbrakeSent || !IsActive)
			{
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, "(Handbrake) " + sAlertText);
				IsSent = true;
				return true;
			}

			if (HandbrakeMessages != null && HandbrakeMessages.Count > 0)
			{
				foreach (HandbrakeMessage message in HandbrakeMessages.Values)
				{
					Alert newAlert = new Alert();
					newAlert.Id = ID;
					newAlert.Title = m_sHandbrakeTitle;
					newAlert.Text = sAlertText;
					newAlert.NoteName = m_sNoteName;
					newAlert.ForceCapitals = m_bForceCapitals;
					newAlert.Index = HandbrakeIndex == 0 ? "" : HandbrakeIndex.ToString();
					newAlert.ActionCode = sActionCode;
					newAlert.Disabled = isDisabled;

					if (string.IsNullOrWhiteSpace(message.LanguageCode))
						message.LanguageCode = m_sLanguageCode;

					string t_sProductCodes = message.PCodes;
					string t_sTopicCodes = message.TCodes;
					string t_sRicReferences = message.RICCodes;
					string t_sNamedItemCodes = message.NICodes;

                    t_sProductCodes = Utils.JoinCharSeparatedStrings(t_sProductCodes, sAdditionalProductCodes);
                    t_sTopicCodes = Utils.JoinCharSeparatedStrings(t_sTopicCodes, sAdditionalTopicCodes);
                    t_sRicReferences = Utils.JoinCharSeparatedStrings(t_sRicReferences, sAdditionalRicReferences);
                    t_sNamedItemCodes = Utils.JoinCharSeparatedStrings(t_sNamedItemCodes, sAdditionalNamedItemCodes);
                                        
					message.PCodes = t_sProductCodes.Trim();
					message.TCodes = t_sTopicCodes.Trim();
					message.RICCodes = t_sRicReferences.Trim();
					message.NICodes = t_sNamedItemCodes.Trim();

					message.Send(newAlert, PollStatus);
				}

				if (HandbrakeMessages.Values.All(message => message.Alerts.Values.Any(alert => alert.Id == ID)))
					IsHandbrakeSent = true;
			}

			//log send attempt
			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSentTime, PollStatus.BaseSource.ID, "(Handbrake) " + sAlertText);
			return IsHandbrakeSent;
		}

		private bool SendToUcdp(string sAlertText, string t_sProductCodes, string t_sTopicCodes, string t_sRicReferences, string t_sNamedItemCodes, string t_sActionCode, PollStatus PollStatus)
		{
			PublicationItem publication = new PublicationItem();

			string USN = PublicationAgent.Usn;

			var trJson = new TRJson
			{
				MessageID = ID,
				Body = sAlertText,
				Priority = 1,
				PNAC = !string.IsNullOrWhiteSpace(USN) ? ("n" + USN) : null,
				CreationTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
				PublishedTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Llm = IsLLM
            };

			if (!string.IsNullOrWhiteSpace(m_sLanguageCode))
				trJson.Language = m_sLanguageCode;
			if (!string.IsNullOrWhiteSpace(Attribution))
				trJson.Attribution = Attribution;
			if (!string.IsNullOrWhiteSpace(t_sProductCodes))
				trJson.ProductCodes = t_sProductCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();

			MetaDataType metadata = new MetaDataType();
			if (!string.IsNullOrWhiteSpace(t_sRicReferences))
				metadata.Add(MetaDataType.eMetaDataType.ORGANIZATION, "ric", t_sRicReferences.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(t_sTopicCodes))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "n2000", t_sTopicCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(t_sNamedItemCodes))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "nameditem", t_sNamedItemCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
			if (!string.IsNullOrWhiteSpace(m_sCategoryCode))
				metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "iptc", m_sCategoryCode.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());

			trJson.MetaData = metadata;

			publication.AddOutput(trJson);

			SendToUcdp(publication, PollStatus);

            // log the request\response audit
            PollStatus.LogAuditPublication();

            return true;
		}

		private void SendToUcdp(PublicationItem publication, PollStatus pollStatus)
		{
			PublicationAgent.SendUcdpPublication(publication, pollStatus, EmbargoTime, Destinations);
		}
	}
}
