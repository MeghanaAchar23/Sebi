using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore
{
	public class Setting
	{
		public Setting()
		{
			ID = "";
			Caption = "";
			Value = "";
			Description = "";
		}
		public string ID
		{
			get;
			set;
		}
		public string Caption
		{
			get;
			set;
		}

		private string _Value = "";
		public string Value
		{
			get
			{
				return _Value;
			}
			set
			{
				_Value = value ?? "";
			}
		}

		public string Description
		{
			get;
			set;
		}

		public static string GetDecodedValue(string value)
		{
			if (string.IsNullOrWhiteSpace(value))
				return value;

			if (value.Trim().StartsWith("<![CDATA["))
			{
				value = System.Text.RegularExpressions.Regex.Replace(value.Trim(), @"^\<!\[CDATA\[|]]>$", "");
			}
			else
				value = System.Web.HttpUtility.HtmlDecode(value);

			return value;
		}
	}
}
