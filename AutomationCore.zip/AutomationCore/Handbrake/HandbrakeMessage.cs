using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Concurrent;
using System.Threading;
using EAP.Core.Types;

namespace AutomationCore.Handbrake
{
	public class HandbrakeMessage : PublicationMessage
	{
		public string HandbrakeName
		{
			get;
			set;
		}

		public bool SkipDuplicateRemoval
		{
			get;
			set;
		}

		public bool IsUsnReadOnly
		{
			get;
			set;
		}

		public string EmailAccount
		{
			get;
			set;
		}

		public string Title
		{
			get;
			set;
		}

		public bool DisplayUsnInTitle
		{
			get;
			set;
		}

		public string Description
		{
			get;
			set;
		}

		public string HandbrakeId
		{
			get;
			set;
		}

		public string NICodes
		{
			get;
			set;
		}
		public string PCodes
		{
			get;
			set;
		}
		public string TCodes
		{
			get;
			set;
		}
		public string RICCodes
		{
			get;
			set;
		}
		public string Charset
		{
			get;
			set;
		}
		public string LanguageCode
		{
			get;
			set;
		}
		public string Slug
		{
			get;
			set;
		}
		public string CategoryCode
		{
			get;
			set;
		}
		public bool NICodesEditable
		{
			get;
			set;
		}
		public bool PCodesEditable
		{
			get;
			set;
		}
		public bool RICCodesEditable
		{
			get;
			set;
		}
		public bool TCodesEditable
		{
			get;
			set;
		}

		public bool AllowEmptyNICodes
		{
			get;
			set;
		}

		public bool AllowEmptyRICCodes
		{
			get;
			set;
		}

		public string USN
		{
			get
			{
				return PublicationAgent.Usn;
			}
			set
			{
				PublicationAgent.Usn = value;
			}
		}

		public string AlternateLogDirectory
		{
			get;
			set;
		}

		public bool IsDelayed
		{
			get;
			set;
		}

		public DateTime DelayDateTime
		{
			get;
			set;
		}

		public bool EnablePublishAllButton
		{
			get;
			set;
		}

		public string ActionCode { get; set; }

		public ConcurrentQueue<string> GroupMessages = null;
		public ConcurrentDictionary<string, Alert> Alerts = null;
		public ConcurrentDictionary<string, Story> Stories = null;
		public ConcurrentDictionary<string, Econ> Econs = null;
		public ConcurrentDictionary<string, Template> Templates = null;
		public ConcurrentDictionary<string, Note> AlertNotes = null;

		public List<string> PublicationOrder
		{
			get;
			set;
		}

		private bool IsReady
		{
			get
			{
				List<string> activeGroup = GroupMessages.Where(id => Store.PublicationMessages.GetPublicationMessage(id).IsActive).ToList();
				if (activeGroup.All(id => Alerts.ContainsKey(id) || Stories.ContainsKey(id) || Econs.ContainsKey(id)))
					return true;
				return false;
			}
		}

		public HandbrakeMessage()
			: base()
		{

		}

		public HandbrakeMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sHandbrakeName, string sHandbrakePostUrl)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sHandbrakeName);
		}

		public HandbrakeMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sQPriority, string sHandbrakeName, string sHandbrakePostUrl)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sHandbrakeName);
		}

		public void Initialize(string sHandbrakeName)
		{
			this.HandbrakeName = sHandbrakeName;
			this.AlternateLogDirectory = "";
			this.CategoryCode = "";
			this.Charset = "";
			this.Description = "";
			this.DisplayUsnInTitle = false;
			this.EmailAccount = "";
			this.LanguageCode = "";
			this.NICodes = "";
			this.PCodes = "";
			this.RICCodes = "";
			this.Slug = "";
			this.TCodes = "";
			this.Title = "";
			//this.USN = "";
			this.IsDelayed = false;
			this.DelayDateTime = DateTime.MinValue;
			this.IsUsnReadOnly = true;
			this.PCodesEditable = true;
			this.NICodesEditable = true;
			this.TCodesEditable = true;
			this.RICCodesEditable = true;
			GroupMessages = new ConcurrentQueue<string>();
			Alerts = new ConcurrentDictionary<string, Alert>();
			Stories = new ConcurrentDictionary<string, Story>();
			Econs = new ConcurrentDictionary<string, Econ>();
			AlertNotes = new ConcurrentDictionary<string, Note>();
			Templates = new ConcurrentDictionary<string, Template>();
		}

		public bool Send(Alert alert, PollStatus pollStatus)
		{
			if (GroupMessages.Contains(alert.Id))
				Add(alert);
			return SendHandbrake(pollStatus);
		}

		public void Add(Alert alert)
		{
			if (alert == null)
				return;
			if (DisplayUsnInTitle)
				alert.Title += " (" + USN + ")";
			if (Alerts == null)
				Alerts = new ConcurrentDictionary<string, Alert>();
			Alerts.GetOrAdd(alert.Id, alert);
		}

		public bool Send(Story story, PollStatus pollStatus)
		{
			if (GroupMessages.Contains(story.Id))
				Add(story);
			return SendHandbrake(pollStatus);
		}

		public void Add(Story story)
		{
			if (story == null)
				return;
			if (DisplayUsnInTitle)
				story.Title += " (" + USN + ")";
			if (Stories == null)
				Stories = new ConcurrentDictionary<string, Story>();
			Stories.GetOrAdd(story.Id, story);
		}

		public bool Send(Econ econ, PollStatus pollStatus)
		{
			if (GroupMessages.Contains(econ.Id))
				Add(econ);
			return SendHandbrake(pollStatus);
		}

		public void Add(Econ econ)
		{
			if (econ == null)
				return;

			if (Econs == null)
				Econs = new ConcurrentDictionary<string, Econ>();
			Econs.GetOrAdd(econ.Id, econ);
		}

		private ConcurrentBag<string> idsSentToUcdp = new ConcurrentBag<string>();
		public bool SendHandbrake(bool forceSend, PollStatus pollStatus = null)
		{
			if (IsSent || !IsActive)
			{
				IsSent = true;
				return true;
			}


			SendCollectedMessagesToUcdp(pollStatus);

			if (!forceSend && !IsReady)
				return true;

			IsSent = true;
			return IsSent;
		}

		public bool SendHandbrake(PollStatus pollStatus = null)
		{
			return SendHandbrake(false, pollStatus);
		}

		private void SendCollectedMessagesToUcdp(PollStatus pollStatus)
		{
			try
			{
				if (Econs != null)
					Econs.Values.Cast<Econ>().All(m => { SendToUcdp(m, pollStatus); return true; });
				if (Alerts != null)
					Alerts.Values.Cast<Alert>().All(m => { SendToUcdp(m, pollStatus); return true; });
				if (Stories != null)
					Stories.Values.Cast<Story>().All(m => { SendToUcdp(m, pollStatus); return true; });
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		private void SendToUcdp(Econ econ, PollStatus pollStatus)
		{
			if (econ == null || idsSentToUcdp.Contains(econ.Id))
				return;
			var publication = GetPublicationItem(econ);
			if (publication != null)
			{
				SendToUcdp(publication, pollStatus);
				idsSentToUcdp.Add(econ.Id);
			}
		}

		private PublicationItem SendToUcdp(Alert alert, PollStatus pollStatus)
		{
			if (alert == null || idsSentToUcdp.Contains(alert.Id))
				return null;
			var publication = GetPublicationItem(alert);
			if (publication != null)
			{
				SendToUcdp(publication, pollStatus);
				idsSentToUcdp.Add(alert.Id);
			}

			return publication;
		}

		private void SendToUcdp(Story story, PollStatus pollStatus)
		{
			if (story == null || idsSentToUcdp.Contains(story.Id))
				return;
			var publication = GetPublicationItem(story);
			if (publication != null)
			{
				SendToUcdp(publication, pollStatus);
				idsSentToUcdp.Add(story.Id);
			}
		}

		private PublicationItem GetPublicationItem(Econ econ)
		{
			try
			{
				PublicationItem publication = new PublicationItem();

				var trJson = new TRJsonEcon() { Llm = IsLLM };
				trJson.Handbrake = true;

				var instrument = new Instrument() { RIC = econ.Id };

				string NowDate = DateTime.Now.ToString("yyyy-MM-dd");
				string NowTime = DateTime.Now.ToString("HH:mm:ss.fffffff");

				if (!string.IsNullOrWhiteSpace(econ.ActualValue))
				{
					string value = econ.ActualValue.Trim();
					if (value.StartsWith("+"))
						value = value.Substring(1);
					instrument.ECON_ACT = value;
					instrument.CORR_ACT = " ";

					// set date and time for actual value
					instrument.ECI_ACT_DT = NowDate;
					instrument.SRC_ES_NS = NowTime;
				}

				if (!string.IsNullOrWhiteSpace(econ.RevisedValue))
				{
					string value = econ.RevisedValue.Trim();
					if (value.StartsWith("+"))
						value = value.Substring(1);
					instrument.PRIOR_REV = value;
					instrument.CORR_REV = " ";
					// no date tim for revised value
				}

				trJson.AddInstrument(instrument);

				trJson.TimeStamp = DateTime.UtcNow.ToString("yyyy'-'MM'-'ddTHH:mm:ss.fff");

				publication.AddOutput(trJson);

				return publication;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}

		private PublicationItem GetPublicationItem(Alert alert)
		{
			try
			{
				PublicationItem publication = new PublicationItem();

				string USN = PublicationAgent.Usn;

				var trJson = new TRJson
				{
					MessageID = alert.Id,
					Handbrake = true,
					Body = alert.Text,
					Priority = 1,
					PNAC = !string.IsNullOrWhiteSpace(USN) ? ("n" + USN) : null,
					CreationTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
					PublishedTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
					Llm = IsLLM
				};

				if (!string.IsNullOrWhiteSpace(LanguageCode))
				{
					trJson.Language = LanguageCode;
					trJson.HeadlineLanguage = LanguageCode;
				}

				if (!string.IsNullOrWhiteSpace(PCodes))
					trJson.ProductCodes = PCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();

				MetaDataType metadata = new MetaDataType();
				if (!string.IsNullOrWhiteSpace(RICCodes))
					metadata.Add(MetaDataType.eMetaDataType.ORGANIZATION, "ric", RICCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(TCodes))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "n2000", TCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(NICodes))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "nameditem", NICodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(CategoryCode))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "iptc", CategoryCode.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());

				trJson.MetaData = metadata;

				publication.AddOutput(trJson);

				return publication;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}

		private PublicationItem GetPublicationItem(Story story)
		{
			try
			{
				PublicationItem publication = new PublicationItem();

				string USN = PublicationAgent.Usn;

				var trJson = new TRJson
				{
					MessageID = story.Id,
					Handbrake = true,
					Headline = story.Headline,
					Body = story.Text,
					Priority = 3,
					PNAC = !string.IsNullOrWhiteSpace(USN) ? ("n" + USN) : null,
					Slugline = Slug,
					FormatIndicator = story.IsTable ? "T" : "",
					Action = story.ActionCode,
					CreationTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
					PublishedTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
					Llm = IsLLM
				};

				if (!string.IsNullOrWhiteSpace(LanguageCode))
				{
					trJson.Language = LanguageCode;
					trJson.HeadlineLanguage = LanguageCode;
				}

				if (!string.IsNullOrWhiteSpace(PCodes))
					trJson.ProductCodes = PCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();

				MetaDataType metadata = new MetaDataType();
				if (!string.IsNullOrWhiteSpace(RICCodes))
					metadata.Add(MetaDataType.eMetaDataType.ORGANIZATION, "ric", RICCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(TCodes))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "n2000", TCodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(NICodes))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "nameditem", NICodes.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());
				if (!string.IsNullOrWhiteSpace(CategoryCode))
					metadata.Add(MetaDataType.eMetaDataType.SUBJECT, "iptc", CategoryCode.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray());

				trJson.MetaData = metadata;

				publication.AddOutput(trJson);

				return publication;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}

		private void SendToUcdp(PublicationItem publication, PollStatus pollStatus)
		{
			PublicationAgent.SendUcdpPublication(publication, pollStatus, EmbargoTime, Destinations);
		}

		public void AddNote(Note oNote)
		{
			if (oNote.SourceUrlAt == DateTime.MinValue)
				oNote.SourceUrlAt = DateTime.UtcNow;
			AlertNotes.GetOrAdd(oNote.Name, oNote);
		}

		public void AddTemplate(Template oTemplate)
		{
			Templates.GetOrAdd(oTemplate.Name, oTemplate);
		}

		public void UpdateNote(Note oNote)
		{
			if (oNote.SourceUrlAt == DateTime.MinValue)
				oNote.SourceUrlAt = DateTime.UtcNow;
			AlertNotes.AddOrUpdate(oNote.Name, oNote, (key, note) => oNote);
		}

		public bool RemoveMessageFromGroup(string messageId)
		{
			bool blg = false;
			ConcurrentQueue<string> tempQueue = Interlocked.Exchange(ref GroupMessages, new ConcurrentQueue<string>());
			try
			{
				List<string> list = tempQueue.ToList<string>();
				int cnt = list.RemoveAll((item) => item == messageId);
				if (cnt > 0)
				{
					tempQueue = new ConcurrentQueue<string>(list);
					blg = true;
				}
			}
			finally
			{
				Interlocked.Exchange(ref GroupMessages, tempQueue);
			}
			return blg;
		}
	}
}
