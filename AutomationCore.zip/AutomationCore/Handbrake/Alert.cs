using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore.Handbrake
{
	public class Alert
	{
		public string Id = "";
		public string Title = "";
		public string Text = "";
		public string Encoding = "";
		public string KobraLangCode = "";
		public string NoteName = "";
		public string Template = "";
		public bool ForceCapitals = true;
		public string Index = "";
		public string ActionCode = "";
		public bool Disabled = false;
	}

	public class Template
	{
		public string Name = "";
		public string Text = "";
	}

	public class Econ
	{
		public string Id = "";
		public string Title = "";
		public string Name = "";
		public string QPriority = "";
		public string SendingSystemId = "";
		public string BinaryId = "";
		public string ActualValue = null;
		public string RevisedValue = null;
		public string EnTitlements = "";
		public string Index = "";
		public bool IsFormatted = false;
		public bool Disabled = false;
	}

	public class Story
	{
		public string Id = "";
		public string Title = "";
		public string Headline = "";
		public string Text = "";
		public string NoteName = "";
		public bool IsTable = false;
		public string Template = "";
		public bool IsWraptext = true;
		public string Index = "";
		public string ActionCode = "";
		public bool Disabled = false;
	}
}
