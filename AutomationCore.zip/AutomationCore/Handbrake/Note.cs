using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore.Handbrake
{
	public class Note
	{
		public string Name = "";
		public string NoteText = "";
		public string SourceUrl = "";
		public DateTime SourceUrlAt = DateTime.MinValue;
	}
}
