using System;
using System.Linq;
using AutomationCore.Handbrake;
using EAP.Core.Types;

namespace AutomationCore
{
	public class EconPublicationMessage : PublicationMessage
	{
		private string m_sRicBinaryID;
		private string m_sEntitlements;
		private string m_sHandbrakeTitle;
		private string m_sName;

		/// <summary>
		/// default false
		/// </summary>
		private bool IsHandbrakeSent
		{
			get;
			set;
		}

		/// <summary>
		/// default false
		/// </summary>
		private bool IsAlertSent
		{
			get;
			set;
		}

		public override bool IsSent
		{
			get
			{
				if (IsAutomatic && IsHandbrake)
					return IsAlertSent && IsHandbrakeSent;
				else if (IsAutomatic)
					return IsAlertSent;
				else if (IsHandbrake)
					return IsHandbrakeSent;
				else return base.IsSent;
			}
			set
			{
				//Reuse Message
				IsAlertSent = value;
				IsHandbrakeSent = value;
				base.IsSent = value;
			}
		}

		public int HandbrakeIndex { get; set; }

		public bool IsFormatted
		{
			get;
			set;
		}

		public EconPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sEntitlements, string sRicBinaryID, string sQPriority)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sEntitlements, sRicBinaryID);
		}

		public EconPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sEntitlements, string sRicBinaryID)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sEntitlements, sRicBinaryID);
		}

		public EconPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sEntitlements, string sRicBinaryID, string sQPriority, string sHandbrakeTitle, string sECONName)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID, sQPriority)
		{
			Initialize(sEntitlements, sRicBinaryID, sHandbrakeTitle, sECONName);
		}

		public EconPublicationMessage(PublicationMessageType oMessageType, PublicationAgent oPublicationAgent, string sAutomationName, string sID, string sEntitlements, string sRicBinaryID, string sHandbrakeTitle, string sECONName)
			: base(oMessageType, oPublicationAgent, sAutomationName, sID)
		{
			Initialize(sEntitlements, sRicBinaryID, sHandbrakeTitle, sECONName);
		}

		private void Initialize(string sEntitlements, string sRicBinaryID, string sHandbrakeTitle = "", string sECONName = "")
		{

			m_sEntitlements = sEntitlements;
			m_sRicBinaryID = sRicBinaryID;

			m_sHandbrakeTitle = sHandbrakeTitle;
			m_sName = sECONName;
			IsFormatted = false;
		}

		public bool Send(string sActualValue, string sRevisedValue, bool isDisabled, PollStatus PollStatus)
		{
			if (IsSent || !IsActive)
			{
				string sMessage = "Actual value: " + sActualValue + ", Revised value: " + sRevisedValue;
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DateTime.UtcNow, PollStatus.BaseSource.ID, sMessage);
				IsSent = true;
				return true;
			}
			if (IsAutomatic)
				IsAlertSent = SendMessage(sActualValue, sRevisedValue, PollStatus);

			if (IsHandbrake)
				IsHandbrakeSent = SendHandbrake(sActualValue, sRevisedValue, isDisabled, PollStatus);

			return IsSent;
		}

		public bool Send(string sActualValue, string sRevisedValue, PollStatus PollStatus)
		{
			return Send(sActualValue, sRevisedValue, false, PollStatus);
		}

		private bool SendMessage(string sActualValue, string sRevisedValue, PollStatus PollStatus)
		{
			DateTime DevSendTime = DateTime.UtcNow;

			if (string.IsNullOrWhiteSpace(sActualValue) && string.IsNullOrEmpty(sRevisedValue))
				return false;

			if (IsAlertSent || !IsActive)
			{
				string sMessage = "Actual value: " + sActualValue + ", Revised value: " + sRevisedValue;
				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, sMessage);
				IsSent = true;
				return true;
			}

			PublicationItem publication = new PublicationItem();

            var trJson = new TRJsonEcon()
            {
                Llm = IsLLM
            };
			var instrument = new Instrument() { RIC = ID };

			string NowDate = DateTime.Now.ToString("yyyy-MM-dd");
			string NowTime = DateTime.Now.ToString("HH:mm:ss.fffffff");

			if (!string.IsNullOrWhiteSpace(sActualValue))
			{
				string value = sActualValue.Trim();
				if (value.StartsWith("+"))
					value = value.Substring(1);
				instrument.ECON_ACT = value;
				instrument.CORR_ACT = " "; // " " or CORR

				// set date and time for actual value
				instrument.ECI_ACT_DT = NowDate;
				instrument.SRC_ES_NS = NowTime;
			}

			if (!string.IsNullOrWhiteSpace(sRevisedValue))
			{
				string value = sRevisedValue.Trim();
				if (value.StartsWith("+"))
					value = value.Substring(1);
				instrument.PRIOR_REV = value;
				instrument.CORR_REV = " ";
				// no date tim for revised value
			}

			trJson.AddInstrument(instrument);

            trJson.TimeStamp = DateTime.UtcNow.ToString("yyyy'-'MM'-'ddTHH:mm:ss.fff");

			publication.AddOutput(trJson);

			SendToUcdp(publication, PollStatus);

			IsAlertSent = true;

			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, "Actual value: " + sActualValue + ", Revised value: " + sRevisedValue);
			return IsAlertSent;
		}

		private bool SendHandbrake(string sActualValue, string sRevisedValue, bool isDisabled, PollStatus PollStatus)
		{
			DateTime DevSendTime = DateTime.UtcNow;

			string sMessage = "Actual value: " + sActualValue + ", Revised value: " + sRevisedValue;

			if (IsHandbrakeSent || !IsActive)
			{

				PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, sMessage);
				IsSent = true;
				return true;
			}

			if (HandbrakeMessages != null && HandbrakeMessages.Count > 0)
			{
				foreach (HandbrakeMessage message in HandbrakeMessages.Values)
				{
					Econ newEcon = new Econ();
					newEcon.ActualValue = sActualValue;
					newEcon.RevisedValue = sRevisedValue;
					newEcon.BinaryId = m_sRicBinaryID;
					newEcon.EnTitlements = m_sEntitlements;
					newEcon.Id = ID;
					newEcon.Name = m_sName;
					newEcon.Title = m_sHandbrakeTitle;
					newEcon.QPriority = QPriority;
					newEcon.Index = HandbrakeIndex == 0 ? "" : HandbrakeIndex.ToString();
					newEcon.IsFormatted = IsFormatted;
					newEcon.Disabled = isDisabled;

					message.Send(newEcon, PollStatus);
				}

				if (HandbrakeMessages.Values.All(message => message.Econs.Values.Any(econ => econ.Id == ID)))
					IsHandbrakeSent = true;
			}

			PollStatus.BaseSource.Store.PerformanceLog.LogPublicationGeneratedAtttempt(ID, PollStatus.PollAttempt.PollID, PollStatus.ChunkAttempt.ChunkID, DevSendTime, PollStatus.BaseSource.ID, sMessage);

			return IsHandbrakeSent;
		}

		private void SendToUcdp(PublicationItem publication, PollStatus pollStatus)
		{
			PublicationAgent.SendUcdpPublication(publication, pollStatus, EmbargoTime, Destinations);
		}
	}
}
