using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using EAP.Core.Logging;
using EAP.Core.Configuration;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AutomationCore
{
	//ElektronPollManager class
	/// <summary>
	/// Manages polls for URLSource. Provides functions for making requests to URL.
	/// </summary>
	public class ElektronPollManager : PollManager
	{
		DateTime lastState = DateTime.UtcNow.AddSeconds(-30);

		string outputTemplate = @"<?xml version=""1.0"" encoding=""utf-8""?>
<ArrayOfRecommendedValue xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns=""http://tempuri.org/"">
	<RecommendedValue>
	<Title>{settingid}</Title>
	<Value>{settingvalue}</Value>
	</RecommendedValue>
</ArrayOfRecommendedValue>";

		//constructor
		/// <summary>
		/// Creates new instance of URLPollManager.
		/// </summary>
		/// <param name="oSource"></param>
		public ElektronPollManager(Source oSource)
			: base(oSource)
		{
		}

		//public functions
		/// <summary>
		/// Method executed at each poll. Actual request to the URL source will be made from this method.
		/// </summary>
		/// <param name="source">URLSource type casted to Source</param>
		/// <param name="pollId">Number representing the poll count</param>
		public override async Task PollFunction(Source source, Int64 pollId)
		{
			URLSource urlSource = (URLSource)source;

			//URL polling will go here.
			UrlPollStatus oPollStatus = new UrlPollStatus();

			oPollStatus.PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() };
            oPollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());

			oPollStatus.Source = urlSource;

			//log start time
			oPollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
				var namevalues = System.Web.HttpUtility.ParseQueryString(urlSource.PostData);
				var settingId = namevalues["SettingID"] ?? "";

				if (string.IsNullOrWhiteSpace(settingId))
					throw new Exception("PostData does not contain SettingID parameter");

				string value = await Source.Store.Config.GetReutersValue(settingId);

				oPollStatus.ResponseHeaders = new WebHeaderCollection();
				oPollStatus.ResponseCode = 200;
				oPollStatus.PollAttempt.ResponseCode = "200";
				oPollStatus.ResponseUri = new Uri(urlSource.Url);
				oPollStatus.IsRequestCompleted = true;

				string result = outputTemplate.Replace("{settingid}", settingId).Replace("{settingvalue}", value);

				oPollStatus.Content = Encoding.UTF8.GetBytes(result);
				oPollStatus.ContentString = result;
				oPollStatus.LatestChunkSize = oPollStatus.Content.Length;
				oPollStatus.ChunkAttempt = oPollStatus.PollAttempt.NewChunkAttempt("1");

				oPollStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
				oPollStatus.ChunkAttempt.ChunkSize = oPollStatus.LatestChunkSize;
				oPollStatus.Result = true;

				urlSource.OnDataReceived(oPollStatus);

				oPollStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;
			}
			catch (Exception ex)
			{
				oPollStatus.ResponseCode = -1;
				oPollStatus.PollAttempt.LogError(ex.ToString());
			}

			try
			{
				urlSource.OnRequestCompleted(oPollStatus);
			}
			catch (Exception ex)
			{
				oPollStatus.PollAttempt.LogError(ex.ToString());
			}

			//log end time
			oPollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(source.ID, pollId.ToString(), oPollStatus.ResponseCode, oPollStatus.PollAttempt.ToJson());
			}

			if (lastState < DateTime.UtcNow.AddSeconds(-30))
			{
				AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
				lastState = DateTime.UtcNow;
			}
		}

		/// <summary>
		/// Makes a request to the source and stores the status in History.
		/// </summary>
		public override async Task DoHistoryPoll()
		{
			//poll the source URL and
			URLSource urlSource = (URLSource)Source;

			if (IsReutersPollEventsEnabled && !IsPollInitialiseSent)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Initialise(Source.ID, Source.GetResource());
				IsPollInitialiseSent = true;
			}

			UrlPollStatus oStatus = new UrlPollStatus();

			oStatus.PollAttempt = new PollAttempt() { SourceID = Source.ID, PollID = "0"};

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(urlSource.ID, oStatus.PollAttempt.PollID.ToString());

			oStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			oStatus.Source = urlSource;

			oStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
				var namevalues = System.Web.HttpUtility.ParseQueryString(urlSource.PostData);
				var settingId = namevalues["SettingID"] ?? "";

				if (string.IsNullOrWhiteSpace(settingId))
					throw new Exception("PostData does not contain SettingID parameter");

				string value = await Source.Store.Config.GetReutersValue(settingId);

				oStatus.ResponseHeaders = new WebHeaderCollection();
				oStatus.ResponseCode = 200;
				oStatus.PollAttempt.ResponseCode = "200";
				oStatus.ResponseUri = new Uri(urlSource.Url);
				oStatus.IsRequestCompleted = true;

				string result = outputTemplate.Replace("{settingid}", settingId).Replace("{settingvalue}", value);

				oStatus.Content = Encoding.UTF8.GetBytes(result);
				oStatus.ContentString = result;
				oStatus.LatestChunkSize = oStatus.Content.Length;
				oStatus.ChunkAttempt = oStatus.PollAttempt.NewChunkAttempt("1");

				oStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
				oStatus.ChunkAttempt.ChunkSize = oStatus.LatestChunkSize;
				oStatus.Result = true;
			}
			catch (Exception ex)
			{
				oStatus.ResponseCode = -1;
				oStatus.PollAttempt.LogError(ex.ToString());
			}

			oStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			//setup variables accordingly.
			urlSource.History = oStatus;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(urlSource.ID, oStatus.PollAttempt.PollID.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(urlSource.ID, oStatus.PollAttempt.PollID.ToString(), oStatus.ResponseCode, oStatus.PollAttempt.ToJson());
			}
		}
	}
}
