using System;
using System.Threading;
using System.Threading.Tasks;
using Azure;
using Azure.AI.OpenAI;
using EAP.Core.LLM.Models;
using EAP.Core.LLM.OpenAILLM;

namespace AutomationCore
{
    public class OpenAiLlmFactory
    {
        private IOpenAILLMService openAILLMService;
        private OpenAiLlmFactory()
        {

        }
        public static OpenAiLlmFactory CreateOpenAILLMService()
        {
            string openAIBaseUrl = AutomationClient.ReutersConfig.Global?.Service?.LlmConfiguration?.OpenAI?.BaseUrl;
            string openAIKey = AutomationClient.ReutersConfig.Global?.Service?.LlmConfiguration?.OpenAI?.ApiKey;

            OpenAIClient openAIClient = new OpenAIClient(
             new Uri(openAIBaseUrl),
              new AzureKeyCredential(openAIKey)
             );

            return new OpenAiLlmFactory()
            {
                openAILLMService = new OpenAILLMService(openAIClient, AutomationClient.ReutersConfig.Global?.Service?.LlmAutomationConfiguration?.OpenAiOptions)
            };
        }
    
        public Task<LlmResponse> GetOpenAIAPIResponse(LlmRequest lLMInputDataModel, CancellationToken cancellationToken = default)
          => openAILLMService.GetOpenAIResponse(lLMInputDataModel, cancellationToken);
    }
}
