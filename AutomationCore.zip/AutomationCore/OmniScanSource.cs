using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using System;
using EAP.Core.Helpers;
using System.Net.Http.Headers;

namespace AutomationCore
{    
    public abstract class OmniScanSource : Source
	{
		public OmniScanSource(PollManager pollManager = null)
			: base()
		{
            History = new() { BaseSource = this };
            PollManager = pollManager ?? new OmniScanPollManager(this);
            HtmlSource = new();
            Encoding = Encoding.UTF8;
        }

        public HttpMethod HttpMethod { get; set; } = HttpMethod.Get;

        public bool UseSeleniumChrome { get; set; } = false;

        public bool AllowRedirection{ get; set; } = true;

        public bool ProcessCacheHeaders { get; set; } = true;

        public int ConnectionTimeout { get; set; } = 30;

        public int RequestTimeout { get; set; } = 60;

        public int OmniScanMaxDegreeOfParallelism { get; set; }

        public string Url
		{
            get;
            set;
		}

        public List<string>? AlternateUrls
        {
            get;
            set;
        }

        public List<int>? SwitchUrlOnStatus
        {
            get;
            set;
        }

        public List<int>? SwitchProxyOnStatus
        {
            get;
            set;
        }
        public Dictionary<string, string>? Form
		{
			get;
			set;
		}

        public string? Body
        {
            get;
            set;
        }

        public WaitForElement? WaitForElement { get; set; }

        public ProxyCountry[] ProxyCountries { get; set; }

        public DirectPoll[] DirectPolls { get; set; }

        public AutomaticDecompression AutomaticDecompression { get; set; } = AutomaticDecompression.On;

        public OmniScanPollStatus History
		{
			get;
			set;
		}
        
        public override bool OnHistoryLoaded() => true;

		public override string GetResource()
		{
			return Url;
		}

        public Dictionary<string, string>? RequestHeaders { get; set; } = null;

        /// <summary>
        /// For UrlSource compatibility
        /// </summary>
        public HtmlSource HtmlSource
        {
            get;
            set;
        }

        /// <summary>
        /// For UrlSource compatibility
        /// </summary>
        public bool AutoLinkExtraction { get; set; } = false;

        /// <summary>
        /// For UrlSource compatibility
        /// </summary>
        public Encoding Encoding { get; set; }

        internal URLSource AsURLSource { get; set; }

        public ResolveStrategyEnum ConfigResolveStrategyEnum
        {
            get; set;
        }

        public bool ConfigFullDbResolve
        {
            get; set;
        }

        public string[] ConfigUserAgents
        {
            get; set;
        }

        public abstract void OnDataReceived(OmniScanPollStatus oUrlPollStatus);
    }

    /// <summary>
    /// A trimmed version of OmniScanSource to be used as URLSource in the links extraction routine.
    /// </summary>
    internal class OmniScanAsTrimmedUrlSource : URLSource
    {
        public OmniScanAsTrimmedUrlSource(OmniScanSource inner) : base(inner.PollManager)
        {
            this.HtmlSource = inner.HtmlSource;            
            this.Store = inner.Store;
            this.ID = inner.ID;
            this.HtmlSource = inner.HtmlSource;
            this.Encoding = inner.Encoding;
            this.Url = inner.Url;            
        }

        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            throw new NotImplementedException();
        }
    }

    public record class WaitForElement([JsonProperty("by")] string By,
        [JsonProperty("value")] string Value);

    public record class ProxyCountry([JsonProperty("country_code")]string CountryCode,
        [JsonProperty("cities")]string[]? Cities,
        [JsonProperty("count")]int Count);

    public record class DirectPoll([JsonProperty("region")] string Region,
        [JsonProperty("count")] int Count);

    public enum AutomaticDecompression
    {
        On,
        Off
    }

    public class OmniScanPollStatus : PollStatus
    {
        [JsonProperty("url")]
        public string Url { get; set; }

        [JsonProperty("hash")]
        public string? Hash { get; set; }

        [JsonProperty("status")]
        public int HttpStatusCode { get; set; }

        [JsonProperty("timeinms")]
        public int TimeInMs { get; set; }

        [JsonProperty("headers")]
        public IEnumerable<KeyValuePair<string, string>>? Headers { get; set; }

        [JsonProperty("requestheaders")]
        public IEnumerable<KeyValuePair<string, string>>? RequestHeaders { get; set; }

        [JsonProperty("geolocation")]
        public string? GeoLocation { get; set; }

        [JsonProperty("content")]
        public byte[]? Content { get; set; }

        public MediaTypeHeaderValue? ContentType { get; set; }

        /// <summary>
        /// For UrlSource compatibility
        /// </summary>
        public List<Link> LinkUpdates { get; set; }

        public UrlPollStatus CreateUrlPollStatus()
        {
            OmniScanSource omniScanSource = (OmniScanSource)this.BaseSource;

            System.Net.WebHeaderCollection headers = null;
            if (Headers != null)
            {
                headers = new();
                foreach (KeyValuePair<string, string> kv in Headers)
                    headers.Add(kv.Key, kv.Value);
            }

            return new UrlPollStatus
            {                
                BaseSource = omniScanSource?.AsURLSource,
                PollAttempt = this.PollAttempt,
                Content = this.Content,
                ContentString = this.Content != null ? omniScanSource?.Encoding.GetString(this.Content) : null,
                LatestChunkSize = this.Content != null ? this.Content.LongLength : 0,
                ResponseCode = this.HttpStatusCode,
                HttpMethod = omniScanSource?.HttpMethod.ToString(),
                IsRequestCompleted = true,
                LinkUpdates = this.LinkUpdates,
                ResponseHeaders = headers,
                ResponseUri = new System.Uri(this.Url),
                Result = this.Content?.Length > 0,
                ChunkAttempt = this.ChunkAttempt
            };
        }
    }

    public class OmniscanSourceToURLSource<T> : OmniScanSource where T : URLSource, new()
    {
        private Lazy<T> _innerSource;

        public OmniscanSourceToURLSource()
        {
            _innerSource = new Lazy<T>(() =>
            {
                T source = new T();
                source.ID = this.ID;
                source.PollManager = this.PollManager;
                source.HtmlSource = this.HtmlSource;
                source.Store = this.Store;
                source.Url = this.Url;
                source.UseHistoryPolling = this.UseHistoryPolling;
                source.PublicationMessages = this.PublicationMessages;
                source.AlternateUrls = this.AlternateUrls = this.AlternateUrls != null ? this.AlternateUrls : new List<string>();
                return source;
            });
        }

        public override void OnConfigurationLoaded(SourceStore store, string configId)
        {
            T source = _innerSource.Value;
            source.OnConfigurationLoaded(store, configId);
            this.Url = this.AsURLSource.Url = source.Url;
        }

        public override void OnDataReceived(OmniScanPollStatus oOmniScanPollStatus)
        {
            T source = _innerSource.Value;
            UrlPollStatus urlPollStatus = oOmniScanPollStatus.CreateUrlPollStatus();
            source.OnDataReceived(urlPollStatus);
            source.OnRequestCompleted(urlPollStatus);
        }

        public override bool OnHistoryLoaded()
        {
            T source = _innerSource.Value;
            source.History = History.CreateUrlPollStatus();            
            return source.OnHistoryLoaded();
        }
    }
}
