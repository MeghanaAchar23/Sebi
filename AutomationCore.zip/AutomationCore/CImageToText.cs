using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Amazon.Rekognition;
using EAP.FileConversion.SDK.Image.AmazonRekognition;
using EAP.FileConversion.SDK.Models;
using LazyCache;

namespace AutomationCore
{
	/// <summary>
	/// Summary description for ImageToText
	/// </summary>
	public class CImageToText
	{
		private readonly IAsyncFileConvertor<ImageToTextOptions, string> fileConvertor;

		/// <summary>
		/// Creates an instance of CImageText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public CImageToText(int ttlInSeconds = 24 * 3600)
		{
			this.fileConvertor = new AsyncCachingFileConvertorDecorator<ImageToTextOptions, string>(
					new AsyncImageToTextFileConvertor(new AmazonRekognitionClient(AutomationClient.ReutersConfig.Global.EC2.Region)),
					new CachingService(),
					ttlInSeconds);
		}

		public CImageToText(IAsyncFileConvertor<ImageToTextOptions, string> fileConvertor)
		{
			this.fileConvertor = fileConvertor ?? throw new ArgumentNullException(nameof(fileConvertor));
		}

		public Task<string> GetImageToTextObjectAsync(Stream imageContent, CancellationToken cancellationToken = default)
			=> fileConvertor.ConvertAsync(new ImageToTextOptions(), imageContent, cancellationToken);

		public Task<string> GetImageToTextObjectAsync(string imageFilePath, CancellationToken cancellationToken = default)
			=> fileConvertor.ConvertAsync(new ImageToTextOptions(), imageFilePath, cancellationToken);
	}
}
