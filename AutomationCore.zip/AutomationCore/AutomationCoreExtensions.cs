using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationCore
{
	public static class AutomationCoreExtensions
	{
		public static async Task<byte[]> ReadBytesAsync(this Stream stream, int bufferLength,
			CancellationToken cancellationToken = default)
		{
			if (bufferLength < 0)
			{
				throw new ArgumentOutOfRangeException("bufferLength");
			}

			if (bufferLength == 0)
			{
				return Array.Empty<byte>();
			}

			byte[] buffer = new byte[bufferLength];

			var numBytesRead = 0;

			do
			{
				var bytesRead = await stream
					.ReadAsync(buffer, numBytesRead, bufferLength, cancellationToken)
					.ConfigureAwait(false);

				if (bytesRead == 0)
				{
					break;
				}

				numBytesRead += bytesRead;
				bufferLength -= bytesRead;
			} while (bufferLength > 0);

			if (numBytesRead != buffer.Length)
			{
				//End of stream
				byte[] copy = new byte[numBytesRead];
				Buffer.BlockCopy(buffer, 0, copy, 0, numBytesRead);
				buffer = copy;
			}

			return buffer;
		}
	}
}
