using System;
using System.Collections.Generic;
using System.Linq;

namespace AutomationCore
{
	public class PublicationMessages
	{
		/// <summary>
		/// Holds PublicationMessage array.
		/// </summary>
		private Dictionary<string, PublicationMessage> m_oPublicationMessages = new Dictionary<string, PublicationMessage>();
		private object m_oSyncLock = new object();

		public SourceStore Store
		{
			get;
			set;
		}

		/// <summary>
		/// operation to be performed in lock
		/// </summary>
		public void AddPublicationMessage(PublicationMessage oPublicationMessage)
		{
			lock (m_oSyncLock)
			{
				try
				{
					m_oPublicationMessages.Add(oPublicationMessage.ID, oPublicationMessage);
				}
				catch (Exception ex)
				{
					AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				}
			}
		}

		/// <summary>
		/// Returns all Agent IDs, operation to be performed in lock
		/// </summary>
		public List<PublicationMessage> GetAllPublicationMessages()
		{
			List<PublicationMessage> t_olAllMessages;
			lock (m_oSyncLock)
			{
				t_olAllMessages = m_oPublicationMessages.Values.ToList();
			}
			return t_olAllMessages;
		}

		/// <summary>
		/// operation to be performed in lock.
		/// </summary>
		public PublicationMessage GetPublicationMessage(string sID)
		{
			PublicationMessage oMessage = null;
			lock (m_oSyncLock)
			{
				m_oPublicationMessages.TryGetValue(sID, out oMessage);
			}
			return oMessage;
		}

		public void UpdateAutomationName(string sHostingServerName)
		{
			lock (m_oSyncLock)
			{
				foreach (KeyValuePair<string, PublicationMessage> Pair in m_oPublicationMessages)
				{
					PublicationMessage Message = Pair.Value;
					Message.AutomationName = sHostingServerName + "--" + Message.AutomationName;
				}
			}
		}
	}
}
