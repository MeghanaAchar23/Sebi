using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace AutomationCore
{
	public class PollPattern
	{
		public string FromTime { get; set; }
		public string ToTime { get; set; }

		public PollPattern()
		{
		}

		public PollPattern(string fromTime, string toTime, int interval)
		{
			FromTime = fromTime;
			ToTime = toTime;
			StartTicks = GetTicks(fromTime);
			EndTicks = GetTicks(toTime);
			PollInterval = interval;
			Timeout = 30;
			MaxPollsAtTime = 5;
		}

		public PollPattern(string fromTime, string toTime, int interval, int maxPollsAtTime, int timeout)
		{
			FromTime = fromTime;
			ToTime = toTime;
			StartTicks = GetTicks(fromTime);
			EndTicks = GetTicks(toTime);
			PollInterval = interval;
			Timeout = timeout;
			MaxPollsAtTime = maxPollsAtTime;
		}

		public long StartTicks
		{
			get;
			set;
		}

		public long EndTicks { get; set; }

		public long GetTicks(string datetime)
		{
			DateTime dt = DateTime.MinValue;
			DateTime.TryParseExact(datetime + " +05:30", "dd'-'MM'-'yyyy HH:mm:ss zzz", CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AdjustToUniversal, out dt);
			if (DateTime.MinValue != dt.Date)
			{
				return dt.Ticks;
			}
			return 0;
		}

		public static TimeSpan GetTimeSpan(string time)
		{
			string[] parts = time.Split(':');
			switch (parts.Length)
			{
				case 2:
					{
						return new TimeSpan(Convert.ToInt16(parts[0]), Convert.ToInt16(parts[1]), 0);
					}
				case 3:
					{
						return new TimeSpan(Convert.ToInt16(parts[0]), Convert.ToInt16(parts[1]), Convert.ToInt16(parts[2]));
					}
				default:
					{
						return TimeSpan.Zero;
					}
			}
		}


		/// <summary>
		/// Poll interval in milliseconds
		/// </summary>
		public Int64 PollInterval
		{
			get;
			set;
		}

		public int Timeout { get; set; }
		public int MaxPollsAtTime { get; set; }
	}
}
