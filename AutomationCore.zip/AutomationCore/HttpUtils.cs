using System;
namespace AutomationCore
{
	public static class HttpOptionsExtension
	{
		public static bool IsKeepAlive(this HttpOptions options)
		{
			return (HttpOptions.KeepAlive & options) == HttpOptions.KeepAlive;
		}
		public static bool IsChunkProcessing(this HttpOptions options)
		{
			return (HttpOptions.ChunkProcessing & options) == HttpOptions.ChunkProcessing;
		}
		public static bool IsAllowRedirect(this HttpOptions options)
		{
			return (HttpOptions.AllowRedirect & options) == HttpOptions.AllowRedirect;
		}
		public static bool IsAppendSessionId(this HttpOptions options)
		{
			return (HttpOptions.AppendSessionId & options) == HttpOptions.AppendSessionId;
		}
		public static bool IsEnableCompression(this HttpOptions options)
		{
			return (HttpOptions.EnableCompression & options) == HttpOptions.EnableCompression;
		}
		public static bool IsCookie(this HttpOptions options)
		{
			return (HttpOptions.AllowCookie & options) == HttpOptions.AllowCookie;
		}
	}

	[Flags]
	public enum HttpOptions
	{
		None = 0x0,
		KeepAlive = 0x01,
		ChunkProcessing = 0x02,
		AllowRedirect = 0x04,
		AppendSessionId = 0x08,
		EnableCompression = 0x10,
		AllowCookie = 0x20
	}

}
