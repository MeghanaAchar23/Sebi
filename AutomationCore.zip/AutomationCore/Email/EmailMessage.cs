using System.Collections.Generic;
using System.Threading.Tasks;

namespace AutomationCore.Email
{
	public class EmailMessage
	{
		public string ID
		{
			get;
			set;
		}

		public List<string> To
		{
			get;
			set;
		}

		public string From
		{
			get;
			set;
		}

		public List<string> Cc
		{
			get;
			set;
		}

		public List<string> Bcc
		{
			get;
			set;
		}

		public string Subject
		{
			get;
			set;
		}

		public string TextBody
		{
			get;
			set;
		}

		public string HtmlBody
		{
			get;
			set;
		}

		public List<EmailAttachment> Attachments
		{
			get;
			set;
		}

		public bool IsSent
		{
			get;
			set;
		}

		public bool IsActive
		{
			get;
			set;
		}

		private EmailClient EmailClient
		{
			get;
			set;
		}

		public SourceStore Store
		{
			get;
			set;
		}

		public bool IsLogEnabled
		{
			get;
			set;
		}

		public string EmailServiceOption { get; set; } = "";

		public EmailMessage(SourceStore store)
		{
			ID = "";
			To = new List<string>();
			From = "";
			Cc = new List<string>();
			Bcc = new List<string>();
			Subject = "";
			Attachments = new List<EmailAttachment>();
			IsSent = false;
			Store = store;
		}

		public bool Send()
		{
			if (!IsActive)
			{
				IsSent = true;
				return true;
			}

			if (EmailClient == null)
			{
				EmailClient = Store.EmailClient;
			}

			if (EmailClient != null)
			{
				EmailClient.SendAsync(this).
				ContinueWith(t => AutomationClient.ReutersLog(t.Exception.ToString(), NLog.LogLevel.Error),
				TaskContinuationOptions.OnlyOnFaulted);

				return true;
			}

			return false;
		}

		public bool Send(string subject, string textBody, string htmlBody)
		{
			return Send(subject, textBody, htmlBody, this.Attachments);
		}

		public bool Send(string subject, string textBody, string htmlBody, EmailAttachment Attachment)
		{
			return Send(subject, textBody, htmlBody, [Attachment]);
		}

		public bool Send(string subject, string textBody, string htmlBody, List<EmailAttachment> oAttachments)
		{
			EmailMessage newMessage = (EmailMessage)this.MemberwiseClone();
			newMessage.IsSent = false;
			newMessage.Subject = subject;
			newMessage.TextBody = textBody;
			newMessage.HtmlBody = htmlBody;
			newMessage.Attachments = oAttachments;
			return newMessage.Send();
		}
	}
}
