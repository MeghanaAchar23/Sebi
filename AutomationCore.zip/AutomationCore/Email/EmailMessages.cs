using System;
using System.Collections.Generic;
using System.Linq;
namespace AutomationCore.Email
{
	public class EmailMessages
	{
		/// <summary>
		/// Holds PublicationMessage array.
		/// </summary>
		private System.Collections.Generic.Dictionary<string, EmailMessage> m_oEmailMessages = new Dictionary<string, EmailMessage>();
		private object m_oSyncLock = new object();

		public SourceStore Store
		{
			get;
			set;
		}

		/// <summary>
		/// operation to be performed in lock
		/// </summary>
		public void AddEmailMessage(EmailMessage oEmailMessage)
		{
			lock (m_oSyncLock)
			{
				try
				{
					m_oEmailMessages.Add(oEmailMessage.ID, oEmailMessage);
				}
				catch (Exception ex)
				{
					AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				}
			}
		}

		/// <summary>
		/// Returns all email messages, operation to be performed in lock
		/// </summary>
		public List<EmailMessage> GetAllEmailMessages()
		{
			List<EmailMessage> t_olAllMessages;
			lock (m_oSyncLock)
			{
				t_olAllMessages = m_oEmailMessages.Values.ToList();
			}
			return t_olAllMessages;
		}

		/// <summary>
		/// operation to be performed in lock.
		/// </summary>
		public EmailMessage GetEmailMessage(string sID)
		{
			EmailMessage oMessage = null;
			lock (m_oSyncLock)
			{
				m_oEmailMessages.TryGetValue(sID, out oMessage);
			}
			return oMessage;
		}
	}
}
