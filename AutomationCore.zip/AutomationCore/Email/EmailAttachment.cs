using System;
using System.IO;
namespace AutomationCore.Email
{
	public class EmailAttachment
	{
		public string FileName
		{
			get;
			set;
		}

		public byte[] Content
		{
			get;
			set;
		}

		public EmailAttachment(string filepath)
		{
			if (File.Exists(filepath))
			{
				FileName = Path.GetFileName(filepath);
				Content = File.ReadAllBytes(filepath);
			}
		}

		public EmailAttachment(string fileName, byte[] content)
		{
			FileName = fileName;
			Content = content;
		}

		public EmailAttachment(string fileName, Stream stream)
		{
			try
			{
				FileName = fileName;
				using (MemoryStream ms = stream as MemoryStream)
				{
					byte[] byContent = ms.ToArray();
					Content = byContent;
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
		}
	}
}
