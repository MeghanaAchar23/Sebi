using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using MimeKit;
using EAP.Core.SimpleEmailService;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

namespace AutomationCore.Email
{
	public class EmailClient
	{
		public SimpleEmailService EmailService { get; set; }

		public EmailClient()
		{
			EmailService = new SimpleEmailService();
		}
		public async Task SendAsync(EmailMessage email)
		{
			await Task.Factory.StartNew(() => Send(email), TaskCreationOptions.LongRunning);
		}

		private Dictionary<String, DateTime> _emailduplicates = new Dictionary<String, DateTime>();

		public static string HashToString(byte[] bytes)
		{
			StringBuilder str = new StringBuilder();

			for (int i = 0; i < bytes.Length; i++)
				str.AppendFormat("{0:X2}", bytes[i]);

			return str.ToString();
		}

		private string GetEmailHashCode(EmailMessage email)
		{
			using var sha256 = SHA256.Create();

			byte[] subject = Encoding.UTF8.GetBytes(email.Subject);
			byte[] body = Encoding.UTF8.GetBytes(email.TextBody);
			byte[] from = Encoding.UTF8.GetBytes(email.From);
			byte[] to = Encoding.UTF8.GetBytes(string.Join(",", email.To.ToArray()));

			sha256.TransformBlock(subject, 0, subject.Length, subject, 0);
			sha256.TransformBlock(body, 0, body.Length, body, 0);
			sha256.TransformBlock(from, 0, from.Length, from, 0);
			foreach (EmailAttachment attachment in email.Attachments)
			{
				if (attachment.Content != null && attachment.Content.Length > 0)
					sha256.TransformBlock(attachment.Content, 0, attachment.Content.Length, attachment.Content, 0);
			}
			sha256.TransformFinalBlock(to, 0, to.Length);

			return HashToString(sha256.Hash);
		}

		private int _EmailExpiryInSeconds = 3600;
		private bool IsExpired(DateTime value)
		{
			if (DateTime.Now.Subtract(value).TotalSeconds > _EmailExpiryInSeconds)
			{
				return true;
			}
			return false;
		}

		private object _lock = new object();
		private bool IsEmailDuplicate(EmailMessage email)
		{
			// protect _emailduplicates container
			lock (_lock)
			{
				DateTime value;
				string hash = GetEmailHashCode(email);

				// does this has exist ?
				if (_emailduplicates.TryGetValue(hash, out value))
				{
					// if expired then not a duplicate
					if (IsExpired(value))
					{
						// store new data time for this hash
						_emailduplicates[hash] = DateTime.Now;
						return false;
					}
					// message not expired so must be duplicate
					else
						return true;
				}
				else
				{
					// message not in list so add
					_emailduplicates.TryAdd(hash, DateTime.Now);
				}

				// remove any expired items when list is greater than max size
				RemoveExpiredItems();
			}
			return false;
		}

		private int _maxduplicatestostore = 1000;
		private void RemoveExpiredItems()
		{
			lock (_lock)
			{
				if (_emailduplicates.Count > _maxduplicatestostore)
				{
					List<string> itemstoremove = new List<string>();
					foreach (var item in _emailduplicates)
					{
						if (IsExpired(item.Value))
							itemstoremove.Add(item.Key);
					}
					foreach (var item in itemstoremove)
					{
						_emailduplicates.Remove(item);
					}
				}
			}
		}

		public void Send(EmailMessage email)
		{
			try
			{
				// dont sent duplicated emails
				if (IsEmailDuplicate(email) == false)
				{
					// JIRA: EAP-1520 EmSure notifications send as email - stop sending to EmSure web server                    

					// only send emails if in production environment
					// only send emails is not validation email
					// all other cases just log email
					if (!email.EmailServiceOption.Equals("email-emsure-service", StringComparison.OrdinalIgnoreCase) &&
						AutomationClient.ReutersConfig.Global.Service.Environment == EAP.Core.Configuration.EnumEnvironment.prd)
					{
						SendViaEap(email);
					}
					else
					{
						LogEmail(email);
					}
				}
				{
					AutomationClient.ReutersLog($"Dropping duplicate email {email.Subject}");
				}
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error);
			}
		}

		public void LogEmail(EmailMessage email)
		{
			if (email == null)
				throw new Exception("email can not be null");

			if (string.IsNullOrWhiteSpace(email.From))
				throw new Exception("from address can not be empty value");

			JArray jAttachments = new JArray();
			foreach (EmailAttachment attachment in email.Attachments)
			{
				JObject jAttachment =
					new JObject(
						new JProperty("filename", attachment.FileName ?? ""),
						new JProperty("encoding", "base64"),
						new JProperty("content", "not logged") // dont log attachments as they can be very large and cause significant performance and resource issues
																//new JProperty("content", attachment.Content != null ? Convert.ToBase64String(attachment.Content) : "")                    
					);
				jAttachments.Add(jAttachment);
			}

			JObject jEmail =
				new JObject(
					new JProperty("ev-email-emsure-service",
						new JObject(
							new JProperty("to", new JArray(email.To)),
							new JProperty("cc", new JArray(email.Cc)),
							new JProperty("bcc", new JArray(email.Bcc)),
							new JProperty("from", email.From),
							new JProperty("subject", email.Subject),
							new JProperty("textbody", email.TextBody),
							new JProperty("htmlbody", email.HtmlBody),
							new JProperty("attachments", jAttachments)
						)
					)
				);

			var message = $"Logging Email {email.Subject} to {string.Join(",", email.To.ToArray())}";
			AutomationClient.ReutersLogEvents(NLog.LogLevel.Info, message, jEmail.ToString(Newtonsoft.Json.Formatting.None));
		}

		public void SendViaEap(EmailMessage email)
		{
			var message = new MimeMessage();
			message.From.Add(new MailboxAddress(SimpleEmailService.SOURCE_ADDRESS));
			message.To.AddRange(email.To.Select(t => new MailboxAddress(t)));
			if (email.Cc.Any())
				message.Cc.AddRange(email.Cc.Select(t => new MailboxAddress(t)));
			if (email.Bcc.Any())
				message.Bcc.AddRange(email.Bcc.Select(t => new MailboxAddress(t)));

			message.Subject = email.Subject;
			var builder = new BodyBuilder();
			if (!string.IsNullOrWhiteSpace(email.TextBody))
				builder.TextBody = email.TextBody;
			if (!string.IsNullOrWhiteSpace(email.HtmlBody))
				builder.HtmlBody = email.HtmlBody;
			foreach (var attachment in email.Attachments)
			{
				builder.Attachments.Add(attachment.FileName, attachment.Content);
			}

			message.Body = builder.ToMessageBody();

			using (MemoryStream ms = new MemoryStream())
			{
				message.WriteTo(ms, false);
				ms.Seek(0, SeekOrigin.Begin);
				EmailService.SendRawEmail(AutomationClient.ReutersConfig.Global.EC2.Region, email.To, ms);
			}
		}
	}
}
