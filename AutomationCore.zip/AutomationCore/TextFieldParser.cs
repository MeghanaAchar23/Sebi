using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Konves.Csv;
using System.Linq;

namespace AutomationCore
{
	public class TextFieldParser : IDisposable
	{

		private CsvStreamReader m_Reader;
		public TextFieldParser(Stream stream)
		{
			m_Reader = new CsvStreamReader(stream);
		}

		public TextFieldParser(string path)
		{
			m_Reader = new CsvStreamReader(path);
		}

		public TextFieldParser(Stream stream, Encoding defaultEncoding)
		{
			m_Reader = new CsvStreamReader(stream, defaultEncoding);
		}

		public TextFieldParser(string path, Encoding defaultEncoding)
		{
			m_Reader = new CsvStreamReader(path, defaultEncoding);
		}

		public TextFieldParser(Stream stream, Encoding defaultEncoding, bool detectEncoding)
		{
			m_Reader = new CsvStreamReader(stream, defaultEncoding, detectEncoding);
		}

		public TextFieldParser(string path, Encoding defaultEncoding, bool detectEncoding)
		{
			m_Reader = new CsvStreamReader(path, defaultEncoding, detectEncoding);
		}

		public void Close()
		{
			if (m_Reader != null)
				m_Reader.Close();


			m_Reader = null;
		}

		~TextFieldParser()
		{
			this.Dispose(false);
		}

		public string[] ReadFields()
		{
			return m_Reader.ReadRecord();
		}

		public void SetDelimiters(char delimiter)
		{
			this.Delimiter = delimiter;
		}

		public char Delimiter
		{
			get
			{
				return m_Delimiter;
			}
			set
			{
				m_Delimiter = value;
				m_Reader.Delimiter = m_Delimiter;
			}
		}

		public bool EndOfData
		{
			get
			{
				return (m_Reader.EndOfStream);
			}
		}

		private bool disposedValue = false;
		private char m_Delimiter;

		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				this.Close();
			}

			this.disposedValue = true;
		}

		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}
	}
}
