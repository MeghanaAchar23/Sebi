using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using EAP.Core.Models.SourceContents;
using EAP.Extensions.Authorization.AwsCognito;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HtmlAgilityPack;
using Refit;
using Microsoft.AspNetCore.StaticFiles;
using System.Linq;
using System.Collections.Generic;

namespace AutomationCore
{
    public class ChangeDetectionHandler
    {
        private static readonly HttpClient _httpClient;
        private static readonly ISourceContentApi _sourceContentApi;
        private static readonly Dictionary<string, string> _preferredMimeTypeToFileExtensionsMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        { "application/liquidmotion", "jck" },
        { "application/msaccess", "accdb" },
        { "application/msword", "doc" },
        { "application/octet-stream", "bin" },
        { "application/onenote", "one" },
        { "application/pkcs7-signature", "p7s" },
        { "application/postscript", "ps" },
        { "application/vnd.ms-excel", "xls" },
        { "application/vnd.ms-powerpoint", "ppt" },
        { "application/vnd.ms-works", "wps" },
        { "application/vnd.visio", "vsd" },
        { "application/x-director", "dcr" },
        { "application/x-font-ttf", "ttf" },
        { "application/x-internet-signup", "ins" },
        { "application/x-msmediaview", "mvb" },
        { "application/x-perfmon", "pmc" },
        { "application/x-pkcs12", "p12" },
        { "application/x-pkcs7-certificates", "p7b" },
        { "application/x-texinfo", "texi" },
        { "application/x-troff", "t" },
        { "application/x-x509-ca-cert", "crt" },
        { "application/xhtml+xml", "xhtml" },
        { "audio/aiff", "aiff" },
        { "audio/basic", "au" },
        { "audio/mid", "mid" },
        { "audio/ogg", "oga" },
        { "audio/vnd.dlna.adts", "adts" },
        { "audio/x-pn-realaudio", "ra" },
        { "audio/x-smd", "smd" },
        { "image/bmp", "bmp" },
        { "image/jpeg", "jpg" },
        { "image/png", "png" },
        { "image/svg+xml", "svg" },
        { "image/tiff", "tiff" },
        { "message/rfc822", "eml" },
        { "text/calendar", "ical" },
        { "text/html", "html" },
        { "text/markdown", "md" },
        { "text/plain", "txt" },
        { "text/xml", "xml" },
        { "video/3gpp", "3gp" },
        { "video/3gpp2", "3g2" },
        { "video/mp4", "mp4" },
        { "video/mpeg", "mpg" },
        { "video/ogg", "ogg" },
        { "video/quicktime", "mov" },
        { "video/vnd.dlna.mpeg-tts", "ts" },
        { "video/x-la-asf", "lsf" },
        { "video/x-ms-asf", "asf" },
        { "x-world/x-vrml", "wrl" }
    };
        private static readonly Dictionary<string, List<string>> _mimeTypeToFileExtensionsMap =
        new FileExtensionContentTypeProvider().Mappings
        .GroupBy(x => x.Value)
        .ToDictionary(
            g => g.Key,
            g => g.Select(x => x.Key.TrimStart('.')).ToList());

        static ChangeDetectionHandler()
        {
            var baseUrl = AutomationClient.ReutersConfig.Global.Service.WebInternal;
            _httpClient = new HttpClient { BaseAddress = new System.Uri(baseUrl) };
            _sourceContentApi = RestService.For<ISourceContentApi>(_httpClient);
        }

        public static bool DetectChange(ChangeDetectionMode changeDetectionMode, string changeDetectionPath, byte[] content, string contentString, ref string previousHash, ref long previousContentSize, out double percentageOfContentSizeChange)
        {
            percentageOfContentSizeChange = 0;
            string hash = string.Empty;
            bool changeDetected = false;

            switch (changeDetectionMode)
            {
                case ChangeDetectionMode.None:
                    break;

                case ChangeDetectionMode.XPath:
                    hash = HashXpathResult(contentString, changeDetectionPath);
                    changeDetected = hash != previousHash;
                    AutomationClient.ReutersLog($"Poll change detection, using mode: {changeDetectionMode}, path: {changeDetectionPath}, hash: {hash}", NLog.LogLevel.Info);
                    previousHash = hash;
                    break;

                case ChangeDetectionMode.Content:
                    hash = HashContents(content);
                    changeDetected = hash != previousHash;
                    AutomationClient.ReutersLog($"Poll change detection, using mode: {changeDetectionMode}, hash: {hash}", NLog.LogLevel.Info);
                    previousHash = hash;
                    break;

                case ChangeDetectionMode.JsonPath:
                    hash = HashJsonPathResult(contentString, changeDetectionPath);
                    changeDetected = hash != previousHash;
                    AutomationClient.ReutersLog($"Poll change detection, using mode: {changeDetectionMode}, path: {changeDetectionPath}, hash: {hash}", NLog.LogLevel.Info);
                    previousHash = hash;
                    break;

                case ChangeDetectionMode.Length:
                    changeDetected = HasContentLengthChanged(content.Length, previousContentSize, out percentageOfContentSizeChange);
                    AutomationClient.ReutersLog($"Poll change detection, using mode: {changeDetectionMode}, content size: {content.Length}", NLog.LogLevel.Info);
                    previousContentSize = content.Length;
                    break;
            }

            return changeDetected;
        }

        private static string HashContents(byte[] content)
        {
            try
            {
                if (content == null)
                    return null;

                using var hash = System.Security.Cryptography.SHA256.Create();
                return Convert.ToHexString(hash.ComputeHash(content)).ToLower();
            }
            catch (Exception)
            {
            }

            return string.Empty;
        }

        private static string HashXpathResult(string html, string xpath)
        {
            try
            {
                var doc = new HtmlDocument();
                doc.LoadHtml(html);
                var nodes = doc.DocumentNode.SelectNodes(xpath);
                if (nodes == null)
                {
                    return HashContents(Encoding.UTF8.GetBytes(html));
                }

                using var hash = System.Security.Cryptography.SHA256.Create();

                foreach (var node in nodes)
                {
                    byte[] innerHtml = Encoding.UTF8.GetBytes(node.InnerHtml);
                    hash.TransformBlock(innerHtml, 0, innerHtml.Length, innerHtml, 0);
                }

                hash.TransformFinalBlock(new byte[] { }, 0, 0);

                return Convert.ToHexString(hash.Hash).ToLower();
            }
            catch (Exception)
            {
                return HashContents(Encoding.UTF8.GetBytes(html));
            }
        }

        private static string HashJsonPathResult(string json, string jsonpath)
        {
            try
            {
                var doc = JObject.Parse(json);
                var nodes = doc.SelectTokens(jsonpath);

                using var hash = System.Security.Cryptography.SHA256.Create();

                foreach (var node in nodes)
                {
                    byte[] innerJson = Encoding.UTF8.GetBytes(node.ToJson());
                    hash.TransformBlock(innerJson, 0, innerJson.Length, innerJson, 0);
                }

                hash.TransformFinalBlock(new byte[] { }, 0, 0);

                return Convert.ToHexString(hash.Hash).ToLower();
            }
            catch (Exception)
            {
                return HashContents(Encoding.UTF8.GetBytes(json));
            }
        }

        private static bool HasContentLengthChanged(long currentContentSize, long previousContentSize,
             out double percentageOfContentSizeChange)
        {
            percentageOfContentSizeChange = 0;

            if (previousContentSize == -1) return true;
            if (currentContentSize <= 0) return false;

            const int allowedSizeDifferenceInPercent = 20;

            percentageOfContentSizeChange =
                Math.Abs(currentContentSize - previousContentSize) / (double)previousContentSize * 100;

            return percentageOfContentSizeChange - allowedSizeDifferenceInPercent >= 0;
        }

        public static SourceContent GenerateSourceContent(int length, string mimeType, ProviderSpecificMetadata metadata)
        {
            string provider = "automation";
            string automationName = AutomationClient.ReutersConfig.Automation.Automation.Name;
            string environment = AutomationClient.ReutersConfig.Global.Service.Environment.ToString();
            string region = AutomationClient.ReutersConfig.Global.AwsRegion.SystemName;
            var now = DateTime.UtcNow;
            var fileExtension = GetExtensionFromMimeType(mimeType);

            return new SourceContent()
            {
                DateTime = now,
                CreatedBy = "eap",
                Provider = provider,
                Topic = automationName,
                Length = length,
                MimeType = mimeType,
                S3Uri = $"s3://eap-{environment}-{region}-source-content/{provider}/{automationName}/{now:yyyy-MM-dd}/{Guid.NewGuid()}.{fileExtension}",
                ProviderSpecificMetadata = metadata
            };
        }

        public static string GetExtensionFromMimeType(string mimeType)
        {

            string baseMimeType = mimeType;
            if (MediaTypeHeaderValue.TryParse(mimeType, out var parsedMimeType))
            {
                baseMimeType = parsedMimeType.MediaType ?? baseMimeType;
            }

            if (_mimeTypeToFileExtensionsMap.TryGetValue(baseMimeType, out var extensions) && extensions.Count == 1)
            {
                return extensions[0];
            }

            if (_preferredMimeTypeToFileExtensionsMap.TryGetValue(baseMimeType, out var extension))
            {
                return extension;
            }

            return "file";
        }

        public static async Task StoreSourceContent(byte[] content, SourceContent sourceContent)
        {
            var cognitoUser = AutomationClient.ReutersConfig.CognitoUser;
            var cognitoUserAuthOptions = new CognitoUserAuthOptions
            {
                ClientId = cognitoUser.ClientId,
                Password = cognitoUser.Password,
                Region = cognitoUser.Region,
                UserName = cognitoUser.Username,
                UserPoolId = cognitoUser.UserPoolId
            };
            var tokenProducer = TokenProducerBuilder.BuildTokenProducer(cognitoUserAuthOptions);
            var token = await tokenProducer.GetAsync();

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(token.Scheme, token.Value);

            using (var contentStream = new MemoryStream(content))
            {
                var metadata = JsonConvert.SerializeObject(sourceContent);
                var sourcecontentStream = new StreamPart(contentStream, "content.payload", "application/octet-stream");
                using (var response = await _sourceContentApi.CreateSourceContent(metadata, sourcecontentStream))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        var errorContent = await response.Content.ReadAsStringAsync();
                        AutomationClient.ReutersLogEvents(NLog.LogLevel.Error,
                            $"Failed to store source content: {sourceContent.S3Uri}, {sourceContent.Provider}, {sourceContent.Topic}, status code: {response.StatusCode}", errorContent);
                    }
                }
            }
        }
    }
}
