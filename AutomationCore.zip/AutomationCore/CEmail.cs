using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using MimeKit;

namespace AutomationCore
{
	/// <summary>
	/// CEmail class which includes all the Methods and Properties regarding Email Processing (MimeKit.dll)
	/// </summary>
	public class CEmail
	{
		public CEmail() { }

		public CEmail(byte[] EmailBuffer)
		{
			try
			{
				this.CommonFunction(EmailBuffer, false, "");
			}
			catch (Exception ex)
			{ this.sErrorLog = ex.ToString(); }
		}

		public CEmail(byte[] EmailBuffer, bool IsEmailRequireWithoutAttachments)
		{
			try
			{
				this.CommonFunction(EmailBuffer, IsEmailRequireWithoutAttachments, "");
			}
			catch (Exception ex)
			{ this.sErrorLog = ex.ToString(); }
		}

		public CEmail(byte[] EmailBuffer, string IncludeAttachmentsForGivenExtension)
		{
			try
			{
				this.CommonFunction(EmailBuffer, false, IncludeAttachmentsForGivenExtension);
			}
			catch (Exception ex)
			{ this.sErrorLog = ex.ToString(); }
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, false, "", new CConversionServiceCall().TimedOutInSeconds, new CConversionServiceCall().RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, bool IsEmailRequireWithoutAttachments, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, IsEmailRequireWithoutAttachments, "", new CConversionServiceCall().TimedOutInSeconds, new CConversionServiceCall().RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, string IncludeAttachmentsForGivenExtension, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, false, IncludeAttachmentsForGivenExtension, new CConversionServiceCall().TimedOutInSeconds, new CConversionServiceCall().RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, int _TimedOutInSeconds, int _RetryCount, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, false, "", _TimedOutInSeconds, _RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, bool IsEmailRequireWithoutAttachments, int _TimedOutInSeconds, int _RetryCount, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, IsEmailRequireWithoutAttachments, "", _TimedOutInSeconds, _RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		public static CEmail GetEmailObject(byte[] EmailBuffer, string IncludeAttachmentsForGivenExtension, int _TimedOutInSeconds, int _RetryCount, ref string sError)
		{
			try
			{
				sError = "";
				return GetEmailObject(EmailBuffer, false, IncludeAttachmentsForGivenExtension, _TimedOutInSeconds, _RetryCount, ref sError);
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.Message;
			}
			return null;
		}

		static CEmail GetEmailObject(byte[] EmailBuffer, bool IsEmailRequireWithoutAttachments, string sIncludeAttachmentsForGivenExtension, int _TimedOutInSeconds, int _RetryCount, ref string sError)
		{
			try
			{
				sError = "";
				CEmail tmpObj = new CEmail();
				tmpObj.CommonFunction(EmailBuffer, IsEmailRequireWithoutAttachments, sIncludeAttachmentsForGivenExtension);
				return tmpObj;

				////////Dotnet4.5//////
				//string sOutputJson = "";
				//List<PostParameter> t_lstPostParamert = new List<PostParameter>();
				//t_lstPostParamert.Add(new PostParameter(@"X-Converter-Type", "Email"));
				//if (IsEmailRequireWithoutAttachments && string.IsNullOrWhiteSpace(sIncludeAttachmentsForGivenExtension))
				//    t_lstPostParamert.Add(new PostParameter(@"X-Email-Remove-Attachments", "YES"));
				//if (string.IsNullOrWhiteSpace(sIncludeAttachmentsForGivenExtension) == false)
				//    t_lstPostParamert.Add(new PostParameter(@"X-Email-Include-Attachments-for-given-extension", sIncludeAttachmentsForGivenExtension));
				//CConversionServiceCall ObjConversionServiceCall = new CConversionServiceCall();
				//ObjConversionServiceCall.RetryCount = _RetryCount;
				//ObjConversionServiceCall.TimedOutInSeconds = _TimedOutInSeconds;
				//if (ObjConversionServiceCall.GetConvertedData(EmailBuffer, t_lstPostParamert, ref sOutputJson, ref sError))
				//    return JsonConvert.DeserializeObject<CEmail>(sOutputJson);
				//////Dotnet4.5//////

				/////DotnetCore//////
				//string t_csSourceEmailJson = Encoding.UTF8.GetString(EmailBuffer);
				//CEmail t_ucEmail = JsonConvert.DeserializeObject<CEmail>(t_csSourceEmailJson);
				//List<CAttachment> tmpLstAttachment = new List<CAttachment>();
				//if (string.IsNullOrWhiteSpace(sIncludeAttachmentsForGivenExtension) && IsEmailRequireWithoutAttachments)
				//{
				//    if (t_ucEmail != null)
				//        t_ucEmail.AttachmentList = tmpLstAttachment;
				//}
				//else if (string.IsNullOrWhiteSpace(sIncludeAttachmentsForGivenExtension) == false)
				//{
				//    if (t_ucEmail.AttachmentList != null)
				//    {
				//        for (int t_i = 0; t_i < t_ucEmail.AttachmentList.Count; t_i++)
				//        {
				//            CAttachment tmpAttachment = t_ucEmail.AttachmentList[t_i];
				//            CheckExtensionInAttachment(sIncludeAttachmentsForGivenExtension, t_ucEmail.AttachmentList[t_i].FileName, ref tmpLstAttachment, ref tmpAttachment);
				//        }
				//    }
				//    t_ucEmail.AttachmentList = tmpLstAttachment;
				//}
				//return t_ucEmail;
				////DotnetCore//////
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sError) == false)
					sError += "\r\n";
				sError += ex.ToString();
			}
			return null;
		}

		private void CommonFunction(byte[] EmailBuffer, bool IsAttachmentRemove, string sFileExtension)
		{
			this.sErrorLog = "";

			using (MemoryStream stream = new MemoryStream(EmailBuffer))
			{
				var message = MimeMessage.Load(stream);
				#region set Property
				if (message != null)
				{
					try
					{
						//Header
						if (message.Headers != null)
						{
							foreach (var header in message.Headers)
							{
								if (EmailHeader.ContainsKey(header.Field) == false)
									EmailHeader.Add(header.Field, new List<string>(new string[] { header.Value }));
								else
									EmailHeader[header.Field].Add(header.Value);
							}
						}
						if (message.Body != null && message.Body.ContentType != null)
						{
							string t_csParameterName = "";
							string t_csValue = "";
							int t_iColonInd = message.Body.ContentType.ToString().IndexOf(':');
							if (t_iColonInd != -1)
							{
								t_csParameterName = message.Body.ContentType.ToString().Substring(0, t_iColonInd);
								t_csValue = message.Body.ContentType.ToString().Substring(t_iColonInd + 1).Trim();

								if (EmailHeader.ContainsKey(t_csParameterName) == false)
									EmailHeader.Add(t_csParameterName, new List<string>(new string[] { t_csValue }));
								else
									EmailHeader[t_csParameterName].Add(t_csValue);
							}
						}
					}
					catch (Exception ex) { this.sErrorLog += "\r\nEmailHeader Exception:" + ex.Message; }

					try
					{
						this.EmailCharacterSet = message.Body.ContentType.Charset;
					}
					catch (Exception ex) { this.sErrorLog += "\r\nEmailCharacterSet Exception:" + ex.Message; }

					try
					{
						//To
						if (message.To != null && message.To.Count > 0)
						{
							string t_csTo = "";
							for (int i = 0; i < message.To.Count; i++)
							{
								t_csTo += message.To[i].ToString();
								if ((i + 1) < message.To.Count)
									t_csTo += ",";
							}
							this.ToAddresses = t_csTo;
						}
						else
							this.ToAddresses = "";
					}
					catch (Exception ex) { this.sErrorLog += "\r\nToAddresses Exception:" + ex.Message; }

					try
					{
						//From 
						if (message.From != null && message.From.Count > 0)
						{
							string t_csFrom = "";
							for (int i = 0; i < message.From.Count; i++)
							{
								t_csFrom += message.From[0].ToString();
								if ((i + 1) < message.From.Count)
									t_csFrom += ",";
							}
							this.FromAddresses = t_csFrom;
						}
						else
							this.FromAddresses = "";
					}
					catch (Exception ex) { this.sErrorLog += "\r\n FromAddresses Exception:" + ex.Message; }

					try
					{
						//Cc
						if (message.Cc != null && message.Cc.Count > 0)
						{
							string t_csCc = "";
							for (int i = 0; i < message.Cc.Count; i++)
							{
								t_csCc += message.Cc[i].ToString();
								if ((i + 1) < message.Cc.Count)
									t_csCc += ",";
							}
							this.CcAddresses = t_csCc;
						}
						else
							this.CcAddresses = "";
					}
					catch (Exception ex) { this.sErrorLog += "\r\n CcAddresses Exception:" + ex.Message; }

					//Append both To And Cc Adresses
					try
					{
						string strTemp = "";
						if (!string.IsNullOrEmpty(this.CcAddresses) || !string.IsNullOrEmpty(this.ToAddresses))
						{
							if (!string.IsNullOrEmpty(this.ToAddresses))
								strTemp = this.ToAddresses;
							if (!string.IsNullOrEmpty(this.CcAddresses))
							{
								if (strTemp != "")
									strTemp = strTemp + "," + this.CcAddresses;
								else
									strTemp = this.CcAddresses;
							}
							this.ToCcAddresses = strTemp;
						}
						else
						{
							this.ToCcAddresses = "";
						}
					}
					catch (Exception ex) { this.sErrorLog += "\r\n ToCcAddresses Exception:" + ex.Message; }

					try
					{
						//Subject
						if (message.Subject != null)
							this.Subject = message.Subject;
					}
					catch (Exception ex) { this.sErrorLog += "\r\n Subject Exception:" + ex.Message; }

					try
					{
						//EmailDate
						if (message.Date != null)
						{
							this.EmailDate = message.Date.DateTime;
						}
					}
					catch (Exception ex) { this.sErrorLog += "\r\n EmailDate Exception:" + ex.Message; }

					try
					{
						//TextBody
						if (message.TextBody != null)
						{
							StringBuilder sbTmp = new StringBuilder(message.TextBody);
							this.TextBody = sbTmp.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n").ToString();
						}
					}
					catch (Exception ex) { this.sErrorLog += "\r\n TextBody Exception:" + ex.Message; }

					try
					{
						//HtmlBody
						if (!string.IsNullOrWhiteSpace(message.HtmlBody))
						{
							StringBuilder sbTmp = new StringBuilder(message.HtmlBody);
							this.HtmlBody = sbTmp.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n").ToString();
						}
						else
						{
							StringBuilder sbTmp = new StringBuilder(message.TextBody);
							this.HtmlBody = sbTmp.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n").ToString();
						}
					}
					catch (Exception ex) { this.sErrorLog += "\r\n TextBody Exception:" + ex.Message; }

				}
				#endregion

				try
				{
					if (IsAttachmentRemove == false)
						this.AttachmentList = GetAttachmentsCommonFunction(message, sFileExtension);
				}
				catch (Exception ex) { this.sErrorLog += "\r\n GetAttachment Exception:" + ex.Message; }

				//try
				//{
				//    message.Dispose();
				//}
				//catch { }
			}
		}

		private List<CAttachment> GetAttachmentsCommonFunction(MimeMessage message, string strFileExtension)
		{
			List<CAttachment> objCAttachment = new List<CAttachment>();

			try
			{
				if (message != null)
				{
					foreach (var attachment in message.Attachments)
					{
						try
						{
							byte[] DataBuffer = null;
							string sContentType = "";
							string sHeader = "";
							string stempFileName = "";
							using (var stream1 = new MemoryStream()) //File.Create("fileName"))
							{
								if (attachment is MessagePart)
								{
									var part = (MessagePart)attachment;
									part.Message.WriteTo(stream1);
									stream1.Position = 0;
									DataBuffer = stream1.ReadFully();
									sContentType = part.ContentType.MimeType;
									stempFileName = part.ContentDisposition.FileName;
									foreach (var hederstr in part.Headers)
										sHeader += hederstr.Field + ": " + hederstr.Value + "\r\n";
								}
								else
								{
									var part = (MimePart)attachment;
									IMimeContent cont = part.Content;
									part.Content.DecodeTo(stream1);
									stream1.Position = 0;
									DataBuffer = stream1.ReadFully();
									sContentType = part.ContentType.MimeType;
									if (string.IsNullOrWhiteSpace(part.FileName))
										stempFileName = part.ContentDisposition.FileName;
									else
										stempFileName = part.FileName;
									foreach (var hederstr in part.Headers)
										sHeader += hederstr.Field + ": " + hederstr.Value + "\r\n";
								}
							}

							CAttachment objTemp = new CAttachment(stempFileName, sHeader, sContentType, DataBuffer);

							if (!string.IsNullOrWhiteSpace(strFileExtension))
							{
								CheckExtensionInAttachment(strFileExtension, stempFileName, ref objCAttachment, ref objTemp);
							}
							else
							{
								objCAttachment.Add(objTemp);
							}

						}
						catch { }
					}

					//foreach (LumiSoft.Net.MIME.MIME_Entity entity in t_MailMsg.AllEntities)
					//{

					//    if (entity.ContentDisposition == null || entity.ContentType == null)
					//        continue;
					//    try
					//    {
					//        string t_csDisposition = entity.ContentDisposition.DispositionType.ToString();
					//        string t_csContentType = entity.ContentType.TypeWithSubtype.ToString();

					//        if (t_csDisposition.ToLower().StartsWith("inline") && t_csContentType.ToLower().StartsWith("text/plain"))
					//        {
					//            if (string.IsNullOrEmpty(entity.ContentDisposition.Param_FileName))
					//                continue;

					//            MIME_h_ContentDisposition mcd = new MIME_h_ContentDisposition(MIME_DispositionTypes.Attachment.ToString());

					//            if (entity.ContentType.Param_Name != null)
					//                mcd.Param_FileName = entity.ContentType.Param_Name.ToString();

					//            string stempFileName = mcd.Param_FileName;
					//            string sHeader = entity.Header.ToString();
					//            string sContentType = entity.ContentType.ToString();
					//            byte[] DataBuffer = ((MIME_b_SinglepartBase)entity.Body).Data;

					//            CAttachment objTemp = new CAttachment(stempFileName, sHeader, sContentType, DataBuffer);

					//            if (!string.IsNullOrWhiteSpace(strFileExtension))
					//            {
					//                CheckExtensionInAttachment(strFileExtension, stempFileName, ref objCAttachment, ref objTemp);
					//            }
					//            else
					//            {
					//                objCAttachment.Add(objTemp);
					//            }
					//        }
					//    }
					//    catch { }
					//}

					if (!string.IsNullOrEmpty(message.TextBody))
					{
						try
						{
							UUCodec objUuCodec = new UUCodec();
							using (MemoryStream mdecode = new MemoryStream(Encoding.ASCII.GetBytes(message.TextBody)))
							{
								string sFileName = "";
								byte[] bUucodesAttachment = objUuCodec.Decode(mdecode, ref sFileName);

								if (!string.IsNullOrEmpty(sFileName) && bUucodesAttachment != null)
								{
									string stempFileName = sFileName;
									string sHeader = "";
									string sContentType = message.Body.ContentType.ToString();
									byte[] DataBuffer = bUucodesAttachment;
									foreach (var hederstr in message.Body.Headers)
										sHeader += hederstr.Field + ": " + hederstr.Value + "\r\n";

									CAttachment objTemp = new CAttachment(stempFileName, sHeader, sContentType, DataBuffer);

									if (!string.IsNullOrWhiteSpace(strFileExtension))
									{
										CheckExtensionInAttachment(strFileExtension, stempFileName, ref objCAttachment, ref objTemp);
									}
									else
									{
										objCAttachment.Add(objTemp);
									}
								}
							}
						}
						catch { }
					}

					if (objCAttachment != null && objCAttachment.Count > 0)
						return objCAttachment;
				}
			}
			catch (Exception ex)
			{
				this.sErrorLog = ex.Message + "\r\n" + ex.StackTrace;
			}
			return null;
		}

		private static void CheckExtensionInAttachment(string sFileExtension, string stempfilename, ref List<CAttachment> lstAttachments, ref CAttachment objTemp)
		{
			string[] t_csaExtension = sFileExtension.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
			foreach (string t_csFileExtension in t_csaExtension)
			{
				if (!string.IsNullOrWhiteSpace(t_csFileExtension))
				{
					string t_csTmpFileExtension = t_csFileExtension;
					if (!t_csTmpFileExtension.StartsWith("."))
						t_csTmpFileExtension = "." + t_csTmpFileExtension;

					if (stempfilename.EndsWith(t_csTmpFileExtension, true, System.Globalization.CultureInfo.InvariantCulture))
					{
						lstAttachments.Add(objTemp);
					}
				}
			}
		}

		private Dictionary<string, List<string>> _EmailHeader = new Dictionary<string, List<string>>(StringComparer.InvariantCultureIgnoreCase);
		/// <summary>
		/// Headers of the Email, Dictionary created with StringComparer.InvariantCultureIgnoreCase parameter.
		/// </summary>
		public Dictionary<string, List<string>> EmailHeader
		{
			get { return _EmailHeader; }
			private set { _EmailHeader = value; }

		}

		/// <summary>
		/// To Addresses of the Email
		/// </summary>
		public string ToAddresses { get; private set; }

		/// <summary>
		/// From Addresses of the Email
		/// </summary>
		public string FromAddresses { get; private set; }

		/// <summary>
		/// Cc Addresses of the Email
		/// </summary>
		public string CcAddresses { get; private set; }

		/// <summary>
		/// To and Cc addresses of the Email
		/// </summary>
		public string ToCcAddresses { get; private set; }

		/// <summary>
		/// Received DateTime of the Email
		/// </summary>
		public DateTime EmailDate { get; private set; }

		/// <summary>
		/// Subject of the Email
		/// </summary>
		public string Subject { get; private set; }

		/// <summary>
		/// Email Character Set
		/// </summary>
		public string EmailCharacterSet { get; private set; }

		/// <summary>
		/// Text Body Of the email
		/// </summary>
		public string TextBody { get; private set; }

		/// <summary>
		/// HTML Body Of the email
		/// </summary>
		public string HtmlBody { get; private set; }

		/// <summary>
		/// Error occured during Email Processing
		/// </summary>
		public string sErrorLog { get; private set; }

		public List<CAttachment> AttachmentList = new List<CAttachment>();

		//private Mail_Message t_MailMsg { get; set; }

	}


	/// <summary>
	/// CAttachment class which includes all the Methods and Properties regarding Email attachement Processing (LumiSoft.Net.dll)
	/// </summary>

	public class CAttachment
	{
		/// <summary>
		/// CAttachment Class Constructor
		/// </summary>
		/// <param name="sFileName"> Attachement File name</param>
		/// <param name="sHeader"> Attachment Header</param>
		/// <param name="sContentType"> Attachment Content Type</param>
		/// <param name="dDataBuffer"> Decoded Data Buffer</param>
		public CAttachment(string sFileName, string sHeader, string sContentType, byte[] dDataBuffer)
		{
			FileName = sFileName;
			Header = sHeader;
			ContentType = sContentType;
			DataBuffer = dDataBuffer;

		}

		/// <summary>
		/// Name of the attachment
		/// </summary>
		public string FileName { get; private set; }

		/// <summary>
		/// ContentType of the attachment
		/// </summary>
		public string ContentType { get; private set; }

		/// <summary>
		/// Header of the attachment
		/// </summary>
		public string Header { get; private set; }

		/// <summary>
		/// Decoded data of the attachment
		/// </summary>
		public byte[] DataBuffer { get; private set; }
	}


	public static class ByteExtensions
	{
		public static byte[] ReadFully(this Stream input)
		{
			byte[] buffer = new byte[16 * 1024];
			using (MemoryStream ms = new MemoryStream())
			{
				int read;
				while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
				{
					ms.Write(buffer, 0, read);
				}
				return ms.ToArray();
			}
		}
	}

	//UUencoder class
	public class UUCodec
	{
		private const string m_filenameFmt = @"{0}\{1}{2}.txt";
		private const string m_headerStringFmt = "begin 644 {0}";
		private const int m_bufferLength = 45;

		public UUCodec()
		{

		}


		public byte[] Decode(Stream inFileStream, ref string sFileName)
		{
			System.Text.RegularExpressions.Regex beginRegex = new System.Text.RegularExpressions.Regex("^begin [^ ]+ (.*$)");
			using (MemoryStream outFileStream = new MemoryStream())
			{
				BinaryWriter writer = null;
				string line = string.Empty;
				int bytesDecd = 0;
				int bytesToRead = 0;
				byte[] buffer = new byte[m_bufferLength + (m_bufferLength / 3)];
				byte[] decBuffer = new byte[m_bufferLength];


				using (TextReader reader = new StreamReader(inFileStream))
				{

					line = reader.ReadLine();
					System.Text.RegularExpressions.Match match = beginRegex.Match(line);
					sFileName = match.Groups[1].Value;
					if (match.Groups.Count > 0)
					{
						//outFileStream = new MemoryStream();//File.Create(string.Format(@"{0}\{1}", outputFolder, match.Groups[1]), m_bufferLength);
						writer = new BinaryWriter(outFileStream);
					}


					while ((line = reader.ReadLine()) != null && line != "end")
					{
						if (line.Length > 1)
						{
							bytesToRead = line[0] - 32; // The first byte defines how many bytes to process
							buffer = System.Text.Encoding.ASCII.GetBytes(line.Substring(1));
							if (buffer.Length >= bytesToRead)
							{
								bytesDecd = DecodeLine(buffer, bytesToRead, decBuffer);
								writer.Write(decBuffer, 0, bytesDecd);
							}
						}
					}
					reader.Close();
				}

				inFileStream.Close();


				if (writer != null)
					writer.Close();

				if (outFileStream != null)
					outFileStream.Close();

				return outFileStream.ToArray();
			}
		}

		protected int DecodeLine(byte[] bytes, int numBytes, byte[] outBytes)
		{
			int j = 0;
			int max = numBytes + (numBytes / 3);
			for (int i = 0; i < max; i += 4)
			{
				bytes[i] = (char)bytes[i] == '`' ? (byte)' ' : bytes[i];
				bytes[i + 1] = (char)bytes[i + 1] == '`' ? (byte)' ' : bytes[i + 1];
				bytes[i + 2] = (char)bytes[i + 2] == '`' ? (byte)' ' : bytes[i + 2];
				bytes[i + 3] = (char)bytes[i + 3] == '`' ? (byte)' ' : bytes[i + 3];

				outBytes[j] = (byte)(((bytes[i] - 32) << 2) | (((bytes[i + 1] - 32) & 48) >> 4)); // 48 = 00110000
				outBytes[j + 1] = (byte)((((bytes[i + 1] - 32) & 15) << 4) | (((bytes[i + 2] - 32) & 60) >> 2)); // 15 = 00001111, 60 = 00111100
				outBytes[j + 2] = (byte)((((bytes[i + 2] - 32) & 3) << 6) | ((bytes[i + 3] - 32) & 63)); // 3 = 00000011, 63 = 00111111

				j += 3;
			}

			return j;
		}

	}
}
