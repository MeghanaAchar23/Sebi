using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace AutomationCore
{
	public class PublicationAgents
	{
		/// <summary>
		/// Holds oPublicationAgent array.
		/// </summary>
		private Dictionary<string, PublicationAgent> m_oPublicationAgents = new Dictionary<string, PublicationAgent>();
		private Object m_oSyncLock = new object();

		public SourceStore Store
		{
			get;
			set;
		}

		/// <summary>
		/// operation to be performed in lock
		/// </summary>
		public void AddPublicationAgent(PublicationAgent oPublicationAgent)
		{
			lock (m_oSyncLock)
			{
				try
				{
					m_oPublicationAgents.Add(oPublicationAgent.ID, oPublicationAgent);
				}
				catch (Exception ex)
				{
					AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				}
			}
		}

		/// <summary>
		/// operation to be performed in lock
		/// </summary>
		/// <param name="sAutomationName">can be blank</param>
		public void AddPublicationAgent(string sID, string sPublisherName, string sUSN)
		{
			AddPublicationAgent(new PublicationAgent { ID = sID, PublisherName = sPublisherName, Usn = sUSN });
		}

		/// <summary>
		/// Returns all Agent IDs, operation to be performed in lock
		/// </summary>
		public List<PublicationAgent> GetAllAgents()
		{
			List<PublicationAgent> t_olAllAgents;
			lock (m_oSyncLock)
			{
				t_olAllAgents = m_oPublicationAgents.Values.ToList();
			}
			return t_olAllAgents;
		}

		/// <summary>
		/// operation to be performed in lock.
		/// </summary>
		public PublicationAgent GetPublicationAgent(string sID)
		{
			PublicationAgent oAgent = null;
			lock (m_oSyncLock)
			{
				m_oPublicationAgents.TryGetValue(sID, out oAgent);
			}
			return oAgent;
		}
	}
}
