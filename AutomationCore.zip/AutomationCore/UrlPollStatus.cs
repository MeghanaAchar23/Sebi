using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using EAP.Automation;
using EAP.Core.Models.SourceContents;

namespace AutomationCore
{
	/// <summary>
	/// Stores the information related to the poll made to the source.
	/// </summary>
	public class UrlPollStatus : PollStatus
	{
		//set default values
		/// <summary>
		/// Initializes a new instance of the UrlPollStatus.
		/// </summary>
		public UrlPollStatus()
		{
			Result = false;
			ResponseCode = 0;
			Content = new byte[0];
			IsRequestCompleted = false;
			LatestChunkSize = 0;
			LinkUpdates = new List<Link>();
			ResponseHeaders = new WebHeaderCollection();
			Audit = new AutomationRequestAuditLogBuilder();
			IsPublicationAuditLogged = false;
        }


        public override void LogAudit()
        {
            LogAuditInternal(NLog.LogLevel.Info);
        }

        public override void LogAuditError()
        {
            LogAuditInternal(NLog.LogLevel.Error);
        }

        public override void LogAuditPublication()
		{
			// limit publication audit to single audit as a source may generate multiple publications
            if (IsPublicationAuditLogged)
                return;

            LogAuditInternal(NLog.LogLevel.Info);
            IsPublicationAuditLogged = true;
        }
                
        private void LogAuditInternal(NLog.LogLevel logLevel)
		{			
			AutomationClient.ReutersLogEvents(logLevel, $"Poll Audit, source: {Source.ID}, {Source.Url}, poll id: {PollAttempt.PollID}, response code: {PollAttempt.ResponseCode}", Audit.BuildJson());						
        }

		public bool IsPublicationAuditLogged
		{
			get;
			set;
		}


        /// <summary>
        /// Gets or sets request/response audit
        /// </summary>
        public AutomationRequestAuditLogBuilder Audit
		{
			get;
			set;			
		}

        /// <summary>
        /// Gets or sets a BaseSource object.
        /// </summary>
        public URLSource Source
		{
			get
			{
				return (URLSource)BaseSource;
			}
			set
			{
				BaseSource = value;
			}
		}

		/// <summary>
		/// Gets or sets the result value
		/// </summary>
		public bool Result
		{
			get;
			set;
		}

		/// <summary>
		/// Get or sets the response code of the request made to the source.
		/// </summary>
		public int ResponseCode
		{
			get;
			set;
		}

		/// <summary>
		/// Raw buffer content of the response received from the request ot the source.
		/// </summary>
		public byte[] Content
		{
			get;
			set;
		}

		/// <summary>
		/// Readable content of the response converted from the raw buffer using Encoding.
		/// </summary>
		public string ContentString
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the value specifying the request is complete. _true_ if whole data downloaded from the response.
		/// </summary>
		public bool IsRequestCompleted
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the value of the size of the current chunk downloaded from the response.
		/// </summary>
		public long LatestChunkSize
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the encoding received in the response header/meta charset value.
		/// </summary>
		public Encoding ResponseEncoding
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the Uri from where the response was actually received.
		/// </summary>
		public Uri ResponseUri
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets a collection of the header name/value pair associated with the response.
		/// </summary>
		public WebHeaderCollection ResponseHeaders
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets a list of the Link objects containing the link and/or title of the new URLs found in the response.
		/// </summary>
		public List<Link> LinkUpdates
		{
			get;
			set;
		}

		internal string HttpMethod { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether a change was detected in the content.
		/// </summary>
		public override bool ChangeDetected
		{
			get { return base.ChangeDetected; }
			set
			{
				base.ChangeDetected = value;
				
				if (value && SourceContent == null)
				{
					SourceContent = ChangeDetectionHandler.GenerateSourceContent(Content.Length,
						ResponseHeaders["Content-Type"] ?? "text/html",
						new ProviderSpecificMetadata()
						{
							Automation = new AutomationBase()
							{
								SourceUrl = Source.Url,
								SourceId = Source.ID
							}
						});
				}
			}
		}
	}
}
