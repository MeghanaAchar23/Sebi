using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using EAP.Automation.HttpClient;
using System.Net.Mime;
using Tweetinvi.Core.Extensions;

namespace AutomationCore
{
	public class HttpClientUtils
	{
		private static readonly HttpClientFactory HttpClientFactory = new HttpClientFactoryBuilder().Create();
		private readonly Lazy<HttpClient> _lazyHttpClient;

		private readonly List<string> _existingHeaders = new List<string> { "User-Agent", "Content-Type", "Referer" };

		public HttpClientUtils(URLSource source)
		{
			_lazyHttpClient = new Lazy<HttpClient>(() => HttpClientFactory.Create(CreateHttpHandler(source)));
		}

		private HttpClient Client => _lazyHttpClient.Value;

		private static AutomationHttpHandler CreateHttpHandler(URLSource source)
		{
			var socketsHttpHandler = new SocketsHttpHandler
			{
				AllowAutoRedirect = source.UrlRedirectionHandling,
				AutomaticDecompression = source.GzipCompression
					? DecompressionMethods.All
					: DecompressionMethods.None,
				UseCookies = source.Cookie,
				CookieContainer = source.CookieContainer,
				PooledConnectionLifetime = TimeSpan.FromMilliseconds(source.ConnectionLeaseTimeoutInMs)
			};

			ConfigureCertificate(source, socketsHttpHandler);

			var automationHttpHandler = CreateAutomationHandler(source, socketsHttpHandler);
			AutomationClient.ReutersLog?.Invoke($"Http client handler info." +
												$" IsReliable:{automationHttpHandler is ReliableAutomationHttpHandler}," +
												$" SourceId:{source.ID}, UseCookies: {socketsHttpHandler.UseCookies}," +
												$" AllowAutoRedirect: {socketsHttpHandler.AllowAutoRedirect}," +
												$" AutomaticDecompression {socketsHttpHandler.AutomaticDecompression}," +
												$" HandlerHash: {automationHttpHandler.GetHashCode()}");
			return automationHttpHandler;
		}

		private static AutomationHttpHandler CreateAutomationHandler(URLSource source, SocketsHttpHandler socketsHttpHandler)
		{
			var config = ReliableAutomationHttpHandlerConfig.Resolve(source.ReliableAutomationHttpHandlerConfig,
						ReliableAutomationHttpHandlerConfig.CreateFromEnvVariables(source.ID));

			return config.Enabled switch
			{
				true => new ReliableAutomationHttpHandler(socketsHttpHandler,
					config,
					source.Url.Trim()),

				_ => new AutomationHttpHandler(socketsHttpHandler)
			};
		}


		private static void ConfigureCertificate(URLSource source, SocketsHttpHandler socketsHttpHandler)
		{
			if (!string.IsNullOrEmpty(source.CertificateName))
			{
				try
				{
					var certificatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, source.CertificateName);

					if (File.Exists(certificatePath))
					{
						AutomationClient.ReutersLog?.Invoke($"Adding certificate {certificatePath}");
						var certificate = string.IsNullOrEmpty(source.CertificatePassword)
							? new X509Certificate2(certificatePath)
							: new X509Certificate2(certificatePath, source.CertificatePassword);

						if (socketsHttpHandler.SslOptions.ClientCertificates == null)
						{
							socketsHttpHandler.SslOptions.ClientCertificates = new X509Certificate2Collection();
						}

						socketsHttpHandler.SslOptions.ClientCertificates.Add(certificate);
						socketsHttpHandler.SslOptions.LocalCertificateSelectionCallback = (sender, targetHost,
							localCertificates,
							remoteCertificate, acceptableIssuers) => certificate;
					}
					else
					{
						AutomationClient.ReutersLog?.Invoke($"Couldn't find certificate: {certificatePath}");
					}
				}
				catch (Exception e)
				{
					AutomationClient.ReutersLog?.Invoke($"Couldn't set certificate. {e}");
				}
			}

			socketsHttpHandler.SslOptions.RemoteCertificateValidationCallback = (message, cert, chain, errors) => true;
		}

		protected static bool IsBlob(HttpResponseMessage httpResponseMessage)
		{
			if (!httpResponseMessage.IsSuccessStatusCode) return false;

			var mediaType = httpResponseMessage.Content?.Headers?.ContentType?.MediaType;

			switch (mediaType)
			{
				case null:
				case "":
				case MediaTypeNames.Application.Json:
				case MediaTypeNames.Application.Xml:
				case MediaTypeNames.Application.Soap:
				case MediaTypeNames.Text.Html:
				case MediaTypeNames.Text.Plain:
				case MediaTypeNames.Text.Xml:
				case MediaTypeNames.Text.RichText: return false;
				default: return true;
			}
		}

		public async Task<UrlPollStatus> DoWebRequest(URLSource oUrlSource,
			UrlPollStatus oStatus,
			bool isCallbackEnabled = true,
			bool isHistoryPoll = false)
		{			
			oStatus.ResponseCode = -1;

			if (string.IsNullOrWhiteSpace(oUrlSource.Url))
			{
				oStatus.PollAttempt.LogError("Url can't be empty.");
				return oStatus;
			}

			var enableCompression = oUrlSource.Options.IsEnableCompression();
			var appendSessionId = oUrlSource.Options.IsAppendSessionId();
			var enableKeepAlive = oUrlSource.Options.IsKeepAlive();

			HttpResponseMessage rs = null;
			HttpRequestMessage rq = null;
			try
			{
				var tCsPollUrl = oUrlSource.Url.Trim();
				if (appendSessionId)
				{
					if (!string.IsNullOrWhiteSpace(oUrlSource.AppendUniqueTimestampInUrl))
					{
						tCsPollUrl += oUrlSource.AppendUniqueTimestampInUrl + "=" +
										DateTime.UtcNow.ToString("yyyyMMddHHmmssfffffff");
					}
				}

				var method = HttpMethod.Get;
				if (!string.IsNullOrWhiteSpace(oUrlSource.PostData))
				{
					method = HttpMethod.Post;
				}

				rq = new HttpRequestMessage(method, tCsPollUrl);

                bool hasCustomAcceptHeader = oUrlSource
                    .RequestHeaders
                    .AllKeys
                    .Any(k => string.Compare(k, HttpRequestHeader.Accept.ToString(), true) == 0);
                if (!hasCustomAcceptHeader)
                    rq.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));

                if (oUrlSource.HttpVersion != null)
                    rq.Version = oUrlSource.HttpVersion;

                if (!string.IsNullOrEmpty(oUrlSource.PostData))
				{
					byte[] tCbyPost = Encoding.GetEncoding(1252).GetBytes(oUrlSource.PostData);
					if (tCbyPost.Length > 0)
					{
						rq.Content = new ByteArrayContent(tCbyPost, 0, tCbyPost.Length);
					}
				}

				if (rq.Content != null)
				{
					if (string.IsNullOrEmpty(oUrlSource.RequestHeaders["Content-Type"]) &&
						!string.IsNullOrWhiteSpace(oUrlSource.RequestContentType))
					{
						rq.Content.Headers.TryAddWithoutValidation("Content-Type", oUrlSource.RequestContentType);
					}
					else if (oUrlSource.RequestHeaders["Content-Type"] != null)
					{
						rq.Content.Headers.TryAddWithoutValidation("Content-Type",
							oUrlSource.RequestHeaders["Content-Type"]);
					}

					if (rq.Content.Headers.ContentType == null)
					{
						rq.Content.Headers.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded");
					}
				}

				rq.Headers.CacheControl = new CacheControlHeaderValue { NoCache = oUrlSource.CacheControlNoCache, NoStore = oUrlSource.CacheControlNoStore };
				if (oUrlSource.ProcessCacheResponseHeaders && oUrlSource.ProcessCacheResponse != null && !isHistoryPoll)
				{
					if (!string.IsNullOrWhiteSpace(oUrlSource.ProcessCacheResponse.LastModified))
					{
						rq.Headers.Add("If-Modified-Since", oUrlSource.ProcessCacheResponse.LastModified);
					}

					if (!string.IsNullOrWhiteSpace(oUrlSource.ProcessCacheResponse.ETag))
					{
						rq.Headers.Add("If-None-Match", oUrlSource.ProcessCacheResponse.ETag);
					}
				}

				var userAgent = AutomationClient.ReutersConfig.UserAgentResolver?.Resolve(
					configUserAgents: oUrlSource.RequestHeaders["User-Agent"] != null
						? new string[] { oUrlSource.RequestHeaders["User-Agent"] }
						: oUrlSource.ConfigUserAgents,
					configFullDbResolve: oUrlSource.ConfigFullDbResolve,
					configStrategy: oUrlSource.ConfigResolveStrategyEnum);

				rq.Headers.Add("User-Agent", userAgent);

				if (!string.IsNullOrWhiteSpace(oUrlSource.XRequestorHeader))
				{
					rq.Headers.TryAddWithoutValidation("X-Requestor", oUrlSource.XRequestorHeader);
				}

				if (enableKeepAlive)
				{
					rq.Headers.ConnectionClose = false;
				}
				else
				{
					rq.Headers.ConnectionClose = true;
				}

				rq.Headers.ExpectContinue = oUrlSource.Expect100Continue;

				//set byte range header if required
				try
				{
					if (oUrlSource.StartByteRange != 0 && oUrlSource.EndByteRange == 0)
					{
						rq.Headers.Range =
							new RangeHeaderValue(oUrlSource.StartByteRange, null);
					}
					else if (oUrlSource.EndByteRange > oUrlSource.StartByteRange)
					{
						rq.Headers.Range =
							new RangeHeaderValue(oUrlSource.StartByteRange,
								oUrlSource.EndByteRange);
					}
				}
				catch (Exception rangeException)
				{
					oStatus.PollAttempt.LogError("Error in setting a byte range. Exception message - " +
													rangeException.Message);
				}

				if (string.IsNullOrEmpty(oUrlSource.RequestHeaders["Referer"]) &&
					!string.IsNullOrWhiteSpace(oUrlSource.UrlReferer))
				{
					rq.Headers.Referrer = new Uri(oUrlSource.UrlReferer);
				}
				else if (oUrlSource.RequestHeaders["Referer"] != null)
				{
					rq.Headers.Referrer = new Uri(oUrlSource.RequestHeaders["Referer"]);
				}

				foreach (string key in oUrlSource.RequestHeaders.Keys)
				{
					if (!_existingHeaders.Contains(key))
					{
						rq.Headers.TryAddWithoutValidation(key, oUrlSource.RequestHeaders[key]);
					}
				}

				if (isCallbackEnabled)
				{
					Interlocked.Increment(ref oUrlSource.ActualPollCount);
				}

				var requestTimeoutToken = new CancellationTokenSource(TimeSpan.FromSeconds(oUrlSource.ConnectionTimeout)).Token;				
				var stopWatch = Stopwatch.StartNew();
				rs = await Client.SendAsync(rq, HttpCompletionOption.ResponseHeadersRead, requestTimeoutToken);
				await rs.Content.LoadIntoBufferAsync();
				stopWatch.Stop();

                oStatus.Audit
                    .SetUri(rq.RequestUri)
                    .SetRequestMethod(rq.Method.ToString())
                    .SetRequestHeaders(rq.Headers)
                    .SetRequestTime(stopWatch.Elapsed)
                    .SetStatusCode((int)rs.StatusCode)
                    .SetResponseCookies(oUrlSource.CookieContainer.GetCookies(rq.RequestUri))
                    .SetResponseHeaders(rs.Headers?.Concat(rs.Content.Headers));
                    

				var responseContent = await rs.Content.ReadAsByteArrayAsync() ?? Array.Empty<byte>();
				var contentString = oUrlSource.Encoding.GetString(responseContent);
				var currentContentSize = responseContent.LongCount();

				if (oUrlSource.PollManager is URLPollManager pollManager)
				{
					oStatus.Audit
						.SetResponseContentSize(currentContentSize);

					if (!IsBlob(rs))
					{
						oStatus.Audit.SetBody(contentString);
					}

				}

				oUrlSource.AuditEvent?.RequestTimeMs.Set(stopWatch.ElapsedMilliseconds);
				oUrlSource.AuditEvent?.SuccessTimeMs.Set(stopWatch.ElapsedMilliseconds);

				oStatus.ResponseCode = Convert.ToInt16(rs.StatusCode);
				oStatus.PollAttempt.ResponseCode = oStatus.ResponseCode.ToString();

				oStatus.ResponseHeaders = new WebHeaderCollection();
				foreach (var header in rs.Headers)
				{
					try
					{
						string value = string.Join(", ", header.Value);
						oStatus.ResponseHeaders[header.Key] = new string(value.Where(c => !char.IsControl(c)).ToArray());
					}
					catch (Exception ex)
					{
						oStatus.PollAttempt.LogError(ex.ToString());
						oStatus.LogAuditError();                        
                    }
				}

				if (rs.Content != null)
				{
					foreach (var header in rs.Content.Headers)
					{
						try
						{
							string value = string.Join(", ", header.Value);
							oStatus.ResponseHeaders[header.Key] = new string(value.Where(c => !char.IsControl(c)).ToArray());
						}
						catch (Exception ex)
						{
							oStatus.PollAttempt.LogError(ex.ToString());
							oStatus.LogAuditError();
                        }
					}
				}				

				oStatus.ResponseUri = rs.RequestMessage.RequestUri;

				oUrlSource.AuditEvent?.SuccessTimeMs.Set(stopWatch.ElapsedMilliseconds);
				oUrlSource.AuditEvent?.SuccessfulRequests.Set(1);

				var pollStatus = oStatus;
				var isTextType = (pollStatus.ResponseHeaders?["Content-Type"] ?? "").ToLower().Contains("text");

				rs.EnsureSuccessStatusCode();

				if (oUrlSource.ProcessCacheResponseHeaders && !isHistoryPoll)
				{
					if (oUrlSource.ProcessCacheResponse == null)
					{
						oUrlSource.ProcessCacheResponse = new ProcessCacheResponse();
					}
					oUrlSource.ProcessCacheResponse.LastModified = oStatus.ResponseHeaders.Get("Last-Modified");
					oUrlSource.ProcessCacheResponse.ETag = oStatus.ResponseHeaders.Get("ETag");

					oUrlSource.ProcessCacheResponse.LastStatusCode = (int)rs.StatusCode;
				}

				long chunkId = 0;
				oStatus.Content = responseContent;
                oStatus.IsRequestCompleted = true;	

				if(oStatus.Content == null || oStatus.Content?.Length == 0)
				{
                    oStatus.PollAttempt.LogError("Zero bytes read from the response steam");
                    oStatus.LogAuditError();
                }

				oStatus.ContentString = contentString;
				oStatus.ResponseEncoding = oUrlSource.Encoding;

				if (oUrlSource.AlternateEncodingProcessing && !responseContent.IsEmpty())
				{
					Encoding pageEncoding = GetPageEncoding(oStatus.ContentString);
					if (pageEncoding == null)
					{
						try
						{
							var charset = rs.Content?.Headers?.ContentType?.CharSet;
							if (string.IsNullOrWhiteSpace(charset) || charset.ToLower() == "utf8")
							{
								charset = "UTF-8";
							}

							pageEncoding = Encoding.GetEncoding(charset);
						}
						catch (Exception ex)
						{
							oStatus.PollAttempt.LogError(ex.ToString());
							oStatus.LogAuditError();
						}
					}

					oStatus.ResponseEncoding = pageEncoding;

					if (isTextType && pageEncoding != null && pageEncoding.CodePage != oUrlSource.Encoding.CodePage)
					{
						oStatus.ContentString = pageEncoding.GetString(responseContent);
					}
				}

				if (isCallbackEnabled && oUrlSource.PollManager.IsPollingActive)
				{
					chunkId++;
					oStatus.ChunkAttempt = oStatus.PollAttempt.NewChunkAttempt(chunkId.ToString());
					oStatus.ChunkAttempt.LogComment("Using encoding: " + oStatus.ResponseEncoding.WebName);
					if (oStatus.Content != null && oStatus.Content?.Length != 0L) 
					{
						oStatus.ChunkAttempt.ChunkSize = currentContentSize;
						pollStatus.LatestChunkSize = currentContentSize;
					}

					if (oUrlSource.AutoLinkExtraction)
					{
						oStatus.LinkUpdates = oUrlSource.HtmlSource.CheckUpdates(oStatus);
					}

					oStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;

					oUrlSource.OnChangeDetectionCheck(oStatus);
					
					oStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;
				}

				if (!responseContent.IsEmpty())
				{
					oStatus.Result = true;
				}
			}
			catch (Exception ex)
			{
				oUrlSource.AuditEvent?.FailedRequests.Set(1);
				oStatus.PollAttempt.LogError(ex.ToString());
                oStatus.LogAuditError();
            }
			finally
			{
				rs?.Dispose();
				rq?.Dispose();
			}
			return oStatus;
		}

		public Encoding GetPageEncoding(string sContent)
		{
			if (string.IsNullOrWhiteSpace(sContent))
			{
				return null;
			}

			try
			{
				sContent = Regex.Replace(sContent, @"<!--.*?-->", "", RegexOptions.Singleline);
				Regex tCregxMeta = new Regex(@"<meta\s+[^>]*charset\s*=[\s'""]*([^\\'"">]+)",
					RegexOptions.Singleline | RegexOptions.IgnoreCase);
				Match mt = tCregxMeta.Match(sContent);
				if (mt.Success)
				{
					var charset = mt.Groups[1].Value.Trim();
					if (charset.ToLower() == "utf8")
					{
						charset = "UTF-8";
					}

					return Encoding.GetEncoding(charset);
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

			return null;
		}

		public string GetCharacterSet(string header)
		{
			var charset = "UTF-8";
			Regex tCregxContentType = new Regex(@"[; ]charset\s*?=\s*(([^;]*?);|(.*?)$)",
				RegexOptions.Multiline | RegexOptions.IgnoreCase);
			var mt = tCregxContentType.Match(header);
			if (mt.Success)
			{
				charset = mt.Groups[1].Value.Trim();
			}

			return charset;
		}
	}
}
