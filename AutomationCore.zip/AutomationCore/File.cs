using System;
using Newtonsoft.Json.Linq;

namespace AutomationCore.IO
{
	public class File
	{
		public static bool Exists(string path)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.File.Exists(path);
			return true;
		}

		public static void Move(string sourceFileName, string destFileName)
		{
			if (sourceFileName.ToLower().StartsWith("/tmp/") && destFileName.ToLower().StartsWith("/tmp/"))
				System.IO.File.Move(sourceFileName, destFileName);
		}

		public static byte[] ReadAllBytes(string path)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.File.ReadAllBytes(path);

			try
			{
				//read email
				if (path.ToLower().Contains("bucketname"))
				{
					var obj = JObject.Parse(path);

					byte[] email = AutomationClient.EapEmailPollClient.Client?.ReadEmailAsync((string)obj["bucketname"], (string)obj["objectkey"]).GetAwaiter().GetResult();
					return email;
				}
			}
			catch (Exception ex) { AutomationClient.ForceLog(ex.ToString(), LogLevel.Error); }

			return null;
			/*
			_client.Timeout = TimeSpan.FromSeconds(30);
			byte[] content = _client.GetByteArrayAsync(path).Result;
			return content;*/
		}
	}
}
