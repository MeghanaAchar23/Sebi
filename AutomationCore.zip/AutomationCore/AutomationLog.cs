using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Concurrent;
using System.Runtime.Serialization;
using System.Threading;

namespace AutomationCore
{
	public class LogLevel
	{
		public static object Off => NLog.LogLevel.Off;
		public static object Trace => NLog.LogLevel.Trace;
		public static object Debug => NLog.LogLevel.Debug;
		public static object Info => NLog.LogLevel.Info;
		public static object Warn => NLog.LogLevel.Warn;
		public static object Error => NLog.LogLevel.Error;
		public static object Fatal => NLog.LogLevel.Fatal;
	}

	public class LogOptions
	{
		public const string LogCommentToAmazon = "LogCommentToAmazon";
		public const string LogCommentToEmSure = "LogCommentToEmSure";
		public const string OperatorLogToAmazon = "OperatorLogToAmazon";
		public const string OperatorLogToEmSure = "OperatorLogToEmSure";
		public const string PollEventsToAmazon = "PollEventsToAmazon";
		public const string PollEventsToEmSure = "PollEventsToEmSure";
		public const string PerformanceLogToAmazon = "PerformanceLogToAmazon";
		public const string PerformanceLogToEmSure = "PerformanceLogToEmSure";
		public const string LibraryInternalLogToAmazon = "LibraryInternalLogToAmazon";
		public const string LibraryInternalLogToEmSure = "LibraryInternalLogToEmSure";
		public const string LogWorkflowConfigToAmazon = "LogWorkflowConfigToAmazon";
		public const string LogWorkflowConfigToEmSure = "LogWorkflowConfigToEmSure";
		public const string LogSettingsToEmSure = "LogSettingsToEmSure";
		public const string PublicationGeneratedLogToAmazon = "PublicationGeneratedLogToAmazon";
		public const string PublicationGeneratedLogToEmSure = "PublicationGeneratedLogToEmSure";
		public const string UcdpPublicationLogToAmazon = "UcdpPublicationLogToAmazon";
	}

	public class AutomationLog
	{
		[DataMember(EmitDefaultValue = false)]
		public string HostingServerName;

		[DataMember(EmitDefaultValue = false)]
		public string AutomationName;
		
		public ConcurrentQueue<RecommendedNextRunSettingValue> RecommendedNextRunSettingValues;				

		public DateTime AutomationStartDateTime { get; set; }
		public DateTime AutomationStopDateTime { get; set; }

		private object _syncLock = new object();

		public AutomationLog()
		{						
			RecommendedNextRunSettingValues = new ConcurrentQueue<RecommendedNextRunSettingValue>();			
		}

		public void LogComment(string Comment)
		{
			LogComment(Comment, LogLevel.Info);
		}

		public void LogComment(string Comment, params object[] args)
		{			
			AutomationClient.ReutersLog(Comment, args);
		}

		public void LogError(string message)
		{
			LogComment(message, LogLevel.Error);
		}		

		public void AddRecommendedNextRunSettingValue(string SettingID, string SettingValue)
		{
			try
			{
				RecommendedNextRunSettingValue NextRunRecommendedSettingValue = new RecommendedNextRunSettingValue();
				NextRunRecommendedSettingValue.SettingID = SettingID;
				NextRunRecommendedSettingValue.SettingValue = Setting.GetDecodedValue(SettingValue);

				RecommendedNextRunSettingValues.Enqueue(NextRunRecommendedSettingValue);

				AutomationClient.ReutersLog(string.Format("Recommendation added: will be set when automation gracefully stops, Key: {0}, Value: {1}", SettingID, SettingValue), LogLevel.Trace);
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error); }
		}

		public bool RemoveRecommendedNextRunSettingValue(string SettingID)
		{
			lock (_syncLock)
			{
				bool blg = false;
				ConcurrentQueue<RecommendedNextRunSettingValue> tempQueue = Interlocked.Exchange(ref RecommendedNextRunSettingValues, new ConcurrentQueue<RecommendedNextRunSettingValue>());
				try
				{
					List<RecommendedNextRunSettingValue> list = tempQueue.ToList<RecommendedNextRunSettingValue>();
					int cnt = list.RemoveAll((item) => item.SettingID == SettingID);
					if (cnt > 0)
					{
						tempQueue = new ConcurrentQueue<RecommendedNextRunSettingValue>(list);
						blg = true;
					}
				}
				catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error); }
				finally
				{
					Interlocked.Exchange(ref RecommendedNextRunSettingValues, tempQueue);
				}
				return blg;
			}
		}

		public bool AddOrUpdateRecommendedNextRunSettingValue(string settingId, string value)
		{
			lock (_syncLock)
			{
				bool blg = false;
				try
				{
					if (!RecommendedNextRunSettingValues.Any(r => r.SettingID == settingId))
						AddRecommendedNextRunSettingValue(settingId, value);

					var setting = RecommendedNextRunSettingValues.Single(r => r.SettingID == settingId);
					setting.SettingValue = value;
				}
				catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error); }
				return blg;
			}
		}

		public void LogPublicationGeneratedAtttempt(string PublicationID, string PollID, string ChunkID, DateTime GeneratedAt, string SourceID, string PublicationContent)
		{
			try
			{
				Publication objPublication = new Publication();
				objPublication.PublicationID = PublicationID;
				objPublication.PollID = PollID;
				objPublication.ChunkID = ChunkID;
				objPublication.SourceID = SourceID;
				objPublication.PublicationContent = PublicationContent;
				objPublication.GeneratedAt = GeneratedAt;

				if (AutomationClient.LogOptions.Contains(LogOptions.PublicationGeneratedLogToAmazon))
					AutomationClient.ForceLog($"Publication generated, publicationmessageid: {PublicationID}, data: {objPublication.ToJson()}", LogLevel.Info);				
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), LogLevel.Error); }
		}
	}

	[DataContract]
	public class SourceObject
	{
		[DataMember]
		public string ID;

		[DataMember]
		public string Resource;

		[DataMember(EmitDefaultValue = false)]
		public DateTime? ActivatedAt;

		[DataMember(EmitDefaultValue = false)]
		public DateTime? DeactivatedAt;

		public SourceObject()
		{
			ID = "";
			Resource = "";
		}
	}

	public class RecommendedNextRunSettingValue
	{
		public string SettingID;
		public string SettingValue;

		public RecommendedNextRunSettingValue()
		{
			SettingID = "";
			SettingValue = "";
		}
	}

	public class PollAttempt
	{
		public string PollID;
		public string SourceID;
		public DateTime PollStartTime;
		public DateTime RequestStartTime;
		public DateTime RequestEndTime;
		public string ResponseCode;
		public ConcurrentQueue<string> DevComments;
		public ConcurrentQueue<ChunkAttempt> ChunkAttempts;
		public string PollType { get; set; }

		private bool IsLogEnabled
		{
			get { return AutomationClient.IsLogEnabled; }
		}

		public PollAttempt()
		{
			DevComments = new ConcurrentQueue<string>();
			ChunkAttempts = new ConcurrentQueue<ChunkAttempt>();
			PollType = "";
		}

		public void LogComment(string Comment)
		{
			LogComment(Comment, LogLevel.Info);
			if (AutomationClient.LogOptions.Contains(LogOptions.LogCommentToAmazon))
				EAP.Core.Logging.Emsure.Polling.Poll.PollComment(SourceID, PollID, "", Comment);
		}

		public void LogComment(string Comment, params object[] args)
		{
			DevComments.Enqueue(DateTime.UtcNow.ToString("dd-MMM-yyyy HH:mm:ss.fff") + ": " + Comment);
		}

		public void LogError(string message)
		{
			LogComment(message, LogLevel.Error);
			if (AutomationClient.LogOptions.Contains(LogOptions.LogCommentToAmazon))
				EAP.Core.Logging.Emsure.Polling.Poll.PollError(SourceID, PollID, "", message);
		}

		public ChunkAttempt NewChunkAttempt(string ChunkID)
		{
			ChunkAttempt objChunkAttempt = new ChunkAttempt();
			objChunkAttempt.SourceID = SourceID;
			objChunkAttempt.PollID = PollID;
			objChunkAttempt.ChunkID = ChunkID;
			try
			{
				ChunkAttempts.Enqueue(objChunkAttempt);
			}
			catch { }
			return objChunkAttempt;
		}
	}

	public class ChunkAttempt
	{
		public string SourceID;
		public string PollID;
		public string ChunkID;
		public DateTime ProcessStartTime;
		public DateTime ProcessEndTime;
		public ConcurrentQueue<string> DevComments;
		public long ChunkSize;

		private bool IsLogEnabled
		{
			get { return AutomationClient.IsLogEnabled; }
		}

		public ChunkAttempt()
		{
            DevComments = new ConcurrentQueue<string>();
		}

		public void LogComment(string Comment)
		{
			LogComment(Comment, LogLevel.Info);
			if (AutomationClient.LogOptions.Contains(LogOptions.LogCommentToAmazon))
				EAP.Core.Logging.Emsure.Polling.Poll.ChunkComment(SourceID, PollID, ChunkID, Comment);
		}

		public void LogComment(string Comment, params object[] args)
		{
			DevComments.Enqueue(DateTime.UtcNow.ToString("dd-MMM-yyyy HH:mm:ss.fff") + ": " + Comment);
		}

		public void LogError(string message)
		{
			LogComment(message, LogLevel.Error);
			if (AutomationClient.LogOptions.Contains(LogOptions.LogCommentToAmazon))
				EAP.Core.Logging.Emsure.Polling.Poll.ChunkError(SourceID, PollID, ChunkID, message);
		}
	}

	public class Publication
	{
		public string PollID;
		public string ChunkID;
		public DateTime GeneratedAt;
		public string SourceID;
		public string PublicationContent;
		public string PublicationID;
		public bool IsPublished;

		public Publication()
		{
			IsPublished = false;
		}
	}

	public class PublishedCommand
	{
		[DataMember(EmitDefaultValue = false)]
		public string QuantumServer;

		public string PublicationMessage;
		public DateTime SentTime;

		[DataMember(EmitDefaultValue = false)]
		public DateTime AckReceivedTime;

		public PublishedCommand()
		{

		}

		[DataMember(EmitDefaultValue = false)]
		public string ResponseMessage;

		[DataMember(EmitDefaultValue = false)]
		public string Publisher;
	}
}
