using System.Collections.Generic;
using System.Linq;
using Amazon.S3;
using Amazon.SimpleNotificationService;
using Amazon.SQS;
using Amazon.Textract;
using EAP.FileConversion.SDK.Textract;
using EAP.FileConversion.SDK.Textract.SQS;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using AwsResourceTag = EAP.FileConversion.SDK.Textract.SQS.AwsResourceTag;

namespace AutomationCore
{
    internal class TextractFileConvertorFactory
    {
        public static IPagedTextractAsyncFileConvertor CreateSqsPagedTextractAsyncFileConvertor()
        {
            ServiceCollection services = new();
            services.AddLogging(x => x.AddNLog());
            var serviceProvider = services.BuildServiceProvider();
            ILoggerFactory loggerFactory = serviceProvider.GetRequiredService<ILoggerFactory>();
            return new SqsPagedTextractAsyncFileConvertor(
                textractClient: new AmazonTextractClient(AutomationClient.ReutersConfig.AwsCredentialsProvider, AutomationClient.ReutersConfig.Global?.EC2.Region),
                sqsClient: new AmazonSQSClient(AutomationClient.ReutersConfig.AwsCredentialsProvider, AutomationClient.ReutersConfig.Global?.EC2.Region),
                snsClient: new AmazonSimpleNotificationServiceClient(AutomationClient.ReutersConfig.AwsCredentialsProvider, AutomationClient.ReutersConfig.Global?.EC2.Region),
                s3Client: new AmazonS3Client(AutomationClient.ReutersConfig.AwsCredentialsProvider, AutomationClient.ReutersConfig.Global?.EC2.Region),
                loggerFactory: loggerFactory,
                textractAsyncFileConversionSettings: TextractSettings());
        }

        private static SqsTextractFileConversionSettings TextractSettings()
        {
            string automationId = AutomationClient.ReutersConfig.Global?.Environment?.AutomationId;
            string environment = AutomationClient.ReutersConfig.Global?.Service?.Environment.ToString();
            string region = AutomationClient.ReutersConfig.Global?.EC2.RegionSystemName;
            return new SqsTextractFileConversionSettings(
                BucketName: $"eap-{environment}-{region}-automations",
                TopicPrefix: $"eap-{environment}-txr-{automationId}-",
                QueuePrefix: $"eap-{environment}-txr-{automationId}-",
                S3KeyPrefix: $"{automationId}/texract/",
                RoleArn: $"arn:aws:iam::{AutomationClient.ReutersConfig.Global?.Service?.AWSAccountId}:role/eap-{environment}-{region}-ecs-role",
                SqsAttributes: new Dictionary<string, string>
                                {
                                    { "VisibilityTimeout", "30" },
                                    { "MessageRetentionPeriod", "86400" } // 1 day
			                    },
                SnsAttributes: new Dictionary<string, string>
                                {
                                    { "RawMessageDelivery", "true" }
                                },
                ResourceTags: AwsResourceTags(),
                TextractJobTimeoutInSec: 300,
                MaxNumberOfMessagesInQueue: 10,
                WaitTimeForMessageInSeconds: 20,
                SubscriptionProtocol: "sqs");
        }

        private static List<AwsResourceTag> AwsResourceTags()
        {
            List<AwsResourceTag> resourceTags = new List<AwsResourceTag>();
            if(AutomationClient.ReutersConfig?.Global?.Service?.AwsResourceTags?.Any() == true)
            {
                foreach (var item in AutomationClient.ReutersConfig?.Global?.Service?.AwsResourceTags)
                {
                    resourceTags.Add(new AwsResourceTag(item.Key, item.Value));
                }
            }
            return resourceTags;
        }
    }

}
