using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore
{
	public class PollPatternInfo
	{
		public TimeZoneInfo TimeZone { get; set; }

		/// <summary>
		/// default - empty
		/// </summary>
		private List<PollPattern> m_aoPollPatterns = new List<PollPattern>();


		public string SourceId { get; set; }
		public string ServerName { get; set; }
		public List<PollPattern> PollPatterns
		{
			get { return m_aoPollPatterns; }
		}

		/// <summary>
		/// Add new pattern to the list
		/// </summary>
		/// <remarks>Validate overlapping patterns</remarks>
		public bool AddPattern(string FromTime, string ToTime, int iPollIntervalInMs)
		{
			PollPattern newPattern = new PollPattern(FromTime, ToTime, iPollIntervalInMs);
			return AddPattern(newPattern);
		}

		public bool AddPattern(string FromTime, string ToTime, int iPollIntervalInMs, int iMaxPollAtTime, int iTimeoutInMs)
		{
			PollPattern newPattern = new PollPattern(FromTime, ToTime, iPollIntervalInMs, iMaxPollAtTime, iTimeoutInMs);
			return AddPattern(newPattern);
		}

		public bool AddPattern(PollPattern oPollPattern)
		{
			if (oPollPattern == null)
				return false;

			m_aoPollPatterns.Add(oPollPattern);
			//m_aoPollPatterns = m_aoPollPatterns.OrderBy(pattern => pattern.FromSecond).ToList();
			return true;
		}

		/// <summary>
		/// Add new pattern to the list
		/// </summary>
		/// <returns>true if added.</returns>
		/* public bool AddPattern(PollPattern oPollPattern)
			{
				if (oPollPattern == null)
					return false;

				//TODO: Validate overlapping patterns
				if (ValidatePattern(oPollPattern))
				{
					m_aoPollPatterns.Add(oPollPattern);
					m_aoPollPatterns = m_aoPollPatterns.OrderBy(pattern => pattern.FromSecond).ToList();
					return true;
				}
				else return false;
			}*/

		public long GetCurrentPollInterval()
		{
			long iPollInterval = 0;
			try
			{
				if (m_aoPollPatterns == null || m_aoPollPatterns.Count == 0)
					return iPollInterval;

				DateTime now = DateTime.UtcNow;
				TimeSpan time = now.TimeOfDay;

				PollPattern oPattern = m_aoPollPatterns.FirstOrDefault(pattern => now.Ticks >= pattern.StartTicks && now.Ticks <= pattern.EndTicks);

				if (oPattern != null)
				{
					iPollInterval = oPattern.PollInterval;
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return iPollInterval;
		}

		public PollPattern GetCurrentPollPattern()
		{
			try
			{
				if (m_aoPollPatterns == null || m_aoPollPatterns.Count == 0)
					return null;

				DateTime now = DateTime.UtcNow;
				PollPattern oPattern = m_aoPollPatterns.FirstOrDefault(pattern => now.Ticks >= pattern.StartTicks && now.Ticks <= pattern.EndTicks);
				return oPattern;
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}

	}
}
