using EAP.FileConversion.Service.Client;
using LazyCache;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace AutomationCore
{
	internal class FileConversionServiceClientFactory
	{
		public static Func<Task<IFileConversionServiceClient>> CreateDefaultFactory(int ttlInSeconds, int timedOutInSeconds, int retryCount)
		{
			ServiceCollection services = new();
			services.AddHttpClient("default", client => { client.Timeout = TimeSpan.FromSeconds(timedOutInSeconds); });
			var serviceProvider = services.BuildServiceProvider();
			var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
			var tokenProducer = AutomationClient.ReutersConfig.TokenProvider;
			return async () =>
			{
				HttpClient httpClient = httpClientFactory.CreateClient("default");
				var token = await tokenProducer.GetAsync();
				httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(token.Scheme, token.Value);
				httpClient.BaseAddress = new Uri(AutomationClient.ReutersConfig?.Global?.Service?.FileConversion);
				FileConversionServiceClient simpleClient = new(RestService.For<IFileConversionServiceProxy>(httpClient), new ECSEnvironmentMetadataProvider());
				ReliableFileConversionServiceClient reliableClient = new(simpleClient, retryCount: retryCount);
				return new CachingFileConversionServiceClient(reliableClient, new CachingService(), ttlInSeconds);
			};
		}
	}

}
