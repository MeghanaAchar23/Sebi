using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EAP.Core.Configuration;
using System.Collections.Generic;

namespace AutomationCore
{
	public class EapEmailPollManager : PollManager, ISubscriptionManager
	{
		DateTime lastState = DateTime.UtcNow.AddSeconds(-30);

		//constructor
		public EapEmailPollManager(Source oSource)
			: base(oSource)
		{ }

		public Task StartAsync()
		{
			//attach event
			AutomationClient.EapEmailPollClient.OnEmailReceived += DoNewEmailPoll;
			AutomationClient.EapEmailPollClient.OnEmailProcessCompleted += EmailProcessed;
			return !AutomationClient.EapEmailPollClient.IsRunning
				? AutomationClient.EapEmailPollClient.Start()
				: Task.CompletedTask;
		}

		public void Stop()
		{
			AutomationClient.EapEmailPollClient.OnEmailReceived -= DoNewEmailPoll;
			Source.Store.AutomationClient.TryToStop();
		}

		public void DoNewEmailPoll(string bucketName, string objectKey, string emailsource, List<string> emaildestinations)
		{
			Int64 t_iPollID = 0;
			bool t_bRet = OnPollStart(ref t_iPollID);

			try
			{
				Source.LatestPollDateTime = DateTime.UtcNow;

				PollFunction(Source, t_iPollID, bucketName, objectKey, emailsource, emaildestinations);
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
			}

			OnPollEnd();
		}

		public override Task PollFunction(Source source, Int64 pollId)
		{
			if (AutomationClient.EapEmailPollClient.OnEmailReceived != null)
			{
				AutomationClient.EapEmailPollClient.OnEmailReceived -= DoNewEmailPoll;
			}
			return Task.CompletedTask;
		}

		public void PollFunction(Source source, Int64 pollId, string bucketName, string objectKey, string emailsource, List<string> emaildestinations)
		{
			AutomationClient.ForceLog($"{source.ID}, {pollId}, {bucketName}, {objectKey}");

			FolderSource folderSource = (FolderSource)source;


			FolderPollStatus oPollStatus = new FolderPollStatus();

			//UrlPollEvent oEvent = new UrlPollEvent();
			oPollStatus.PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() };
			oPollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());

			oPollStatus.Source = folderSource;

			//log start time
			oPollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			//oEvent.StartTime = DateTime.UtcNow.Ticks;
			try
			{
				// keep reference to the bucket and object 
				oPollStatus.BucketName = bucketName;
				oPollStatus.ObjectKey = objectKey;
				oPollStatus.EmailSource = emailsource;
				oPollStatus.EmailDestinations = emaildestinations;

				oPollStatus.CreatedOrModifiedFile = new { bucketname = bucketName, objectkey = objectKey }.ToJson();
				oPollStatus.ChunkAttempt = oPollStatus.PollAttempt.NewChunkAttempt("1");
				oPollStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
				oPollStatus.ChunkAttempt.LogComment($"Email: {oPollStatus.CreatedOrModifiedFile}");

				folderSource.OnNewFileFound(oPollStatus);
			}
			catch (WebException ex) { oPollStatus.ChunkAttempt.LogError(ex.ToString()); }
			catch (InvalidOperationException ex) { oPollStatus.ChunkAttempt.LogError(ex.ToString()); }
			catch (ArgumentNullException ex) { oPollStatus.ChunkAttempt.LogError(ex.ToString()); }
			catch (ArgumentException ex) { oPollStatus.ChunkAttempt.LogError(ex.ToString()); }
			catch (Amazon.SQS.AmazonSQSException ex) { oPollStatus.ChunkAttempt.LogError(ex.ToString()); }
			catch (Exception ex)
			{
				oPollStatus.ChunkAttempt.LogError(ex.ToString());
			}

			oPollStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;

			//log end time
			oPollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;

			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(source.ID, pollId.ToString(), 0, oPollStatus.PollAttempt.ToJson());
			}

			if (lastState < DateTime.UtcNow.AddSeconds(-30))
			{
				AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
				lastState = DateTime.UtcNow;
			}

			//FOR DEBUGGING
			//if (iPollID == 5 && oSource.ID == "FastRetailing_EmailSource")
			//    oSource.Deactivate();
		}

		public void EmailProcessed()
		{
			//check if all sources are stopped
			if (!Source.IsSourceBeingPolled)
			{
				if (!Source.Store.Sources.GetAllSources().Any(s => s.IsSourceBeingPolled))
				{
					if (Source.Store.LivePollCount == 0)
					{
						AutomationClient.ForceLog("Stopping automation - all sources stopped polling", LogLevel.Warn);
						Source.Store.AutomationClient.OnAutomationStopped?.Invoke();
					}
				}
			}
		}

		public override Task DoHistoryPoll()
		{
			return Task.CompletedTask;
		}
	}
}
