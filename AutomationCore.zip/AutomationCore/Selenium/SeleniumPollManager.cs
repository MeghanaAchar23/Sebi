using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using EAP.Automation;
using System.Threading;
using EAP.Core.Logging;
using System.IO;

namespace AutomationCore
{
	public class SeleniumPollManager : PollManager, ISubscriptionManager
	{
		private readonly object _webDriverLock = new object();
		private URLSource UrlSource => (URLSource)Source;
		private WebDriverType WebDriverType { get; }
		public bool IsDriverInitialized { get { lock (_webDriverLock) { return Driver != null; } } }
		public IWebDriver Driver { get; private set; }
		public Action WaitUntilCompletionAction { get; set; }

		public SeleniumPollManager(Source source, WebDriverType webDriverType = WebDriverType.FireFox)
			: base(source)
		{
            WebDriverType = webDriverType;            
		}

		public Task StartAsync()
		{
			return Task.Factory.StartNew(async () =>
			{
				try
				{
					AutomationClient.ForceLog?.Invoke($"Starting {UrlSource.ID}", LogLevel.Info);
					CreateDriver();

					while (IsPollingActive)
					{
						await DoPoll(Source);

						if (IsPollingActive)
						{
							// by default start timer using poll time
							var startTimeMs = UrlSource.CurrentPollIntervalInMS;
							// align the polling interval to the wall clock
							if (Source.AlignPollIntervalToWallClock == true)
							{
								// get polling interspersed mode between automation instances, even, random or none
								startTimeMs = AutomationClient.ReutersConfig.GetNextPollStartTimeMilliseconds(Source.ID, Source.CurrentPollIntervalInMS, Source.PollInterspersedMode);
							}

							await Task.Delay(startTimeMs);
						}
					}

					DestroyDriver();
				}
				catch (Exception e)
				{
					AutomationClient.ForceLog?.Invoke(e.ToString(), LogLevel.Error);
				}
			}, default, TaskCreationOptions.LongRunning, TaskScheduler.Default);
		}

		public void Stop()
		{
			Source.IsSourceActive = false;
			DestroyDriver();
			Source.Store.AutomationClient.TryToStop();
		}

		public override Task PollFunction(Source source, long pollId)
		{
			var urlSource = UrlSource;
			var pollStatus = new UrlPollStatus
			{
				PollAttempt = new PollAttempt() { SourceID = source.ID, PollID = pollId.ToString() }
			};
			pollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;
			if (IsReutersPollEventsEnabled) EAP.Core.Logging.Emsure.Polling.Poll.Start(source.ID, pollId.ToString());
			pollStatus.Source = urlSource;
			pollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;
			try
			{
				if (IsPollingActive)
				{
					(string content, string? driverUrlAfterNavigation) =
                        GetRequest(urlSource.Url, pollStatus);

					if (IsPollingActive)
					{
                        if (source.WebDriverFileDownload)
                        {
                            string filePath = string.Empty;
                            try
                            {
                                DirectoryInfo dirInfo = GetDirectory();
                                if (dirInfo.EnumerateFiles().Count() > 0)
                                {
                                    filePath = dirInfo.GetFiles().OrderByDescending(f => f.LastWriteTime).First().FullName;
                                    pollStatus.Content = File.ReadAllBytes(filePath);
                                    File.Delete(filePath);
                                }
                            }
                            catch (Exception ex)
                            {
                                AutomationClient.ForceLog?.Invoke($"Selenium Web Driver IO Operation: error at {UrlSource.Url}. Msg = {ex.Message}", LogLevel.Error);
                                if(filePath.Length > 0)
                                {
                                    File.Delete(filePath);
                                }
                                pollStatus.Content = Encoding.UTF8.GetBytes(content);
                            }
                        }
                        else
                        {
                            pollStatus.Content = Encoding.UTF8.GetBytes(content);
                        }
                        pollStatus.ContentString = content;
						pollStatus.ResponseEncoding = Encoding.UTF8;
						pollStatus.ResponseUri = driverUrlAfterNavigation != null
                            ? new Uri(driverUrlAfterNavigation)
                            : null;
						pollStatus.Result = true;
						pollStatus.IsRequestCompleted = true;
						pollStatus.ChunkAttempt = pollStatus.PollAttempt.NewChunkAttempt("0");
						if (urlSource.AutoLinkExtraction)
						{
							pollStatus.LinkUpdates = urlSource.HtmlSource.CheckUpdates(pollStatus);
						}
						pollStatus.ChunkAttempt.ProcessStartTime = DateTime.UtcNow;
						pollStatus.ChunkAttempt.ChunkSize = pollStatus.Content.LongLength;
						urlSource.OnDataReceived(pollStatus);
						pollStatus.ChunkAttempt.ProcessEndTime = DateTime.UtcNow;
					}
					urlSource.OnRequestCompleted(pollStatus);
				}
			}
			catch (Exception ex)
			{
				pollStatus.PollAttempt.LogError(ex.ToString());
				pollStatus.LogAuditError();
			}
			pollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;
			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(source.ID, pollId.ToString());
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(
					source.ID, pollId.ToString(), pollStatus.ResponseCode, pollStatus.PollAttempt.ToJson());
			}

			return Task.CompletedTask;
		}

		public override Task DoHistoryPoll()
		{            
			var urlSource = (URLSource)Source;

			if (IsReutersPollEventsEnabled && !IsPollInitialiseSent)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Initialise(urlSource.ID, urlSource.GetResource());
				IsPollInitialiseSent = true;
			}
            var pollStatus = new UrlPollStatus
            {
                PollAttempt = new PollAttempt() { SourceID = urlSource.ID, PollID = "0" }
			};
			if (IsReutersPollEventsEnabled)
				EAP.Core.Logging.Emsure.Polling.Poll.Start(urlSource.ID, pollStatus.PollAttempt.PollID);
			pollStatus.PollAttempt.PollStartTime = DateTime.UtcNow;
			pollStatus.Source = urlSource;
			pollStatus.PollAttempt.RequestStartTime = DateTime.UtcNow;

			try
			{
                CreateDriver();

                (string content, string? driverUrlAfterNavigation)
                    = GetRequest(urlSource.Url, pollStatus);
				pollStatus.Content = Encoding.UTF8.GetBytes(content);
				pollStatus.ContentString = content;
				pollStatus.ResponseEncoding = Encoding.UTF8;
                pollStatus.ResponseUri = driverUrlAfterNavigation != null
                    ? new Uri(driverUrlAfterNavigation)
                    : null;
                pollStatus.Result = true;
				pollStatus.IsRequestCompleted = true;
			}
			catch (Exception ex)
			{
				pollStatus.PollAttempt.LogError(ex.ToString());
				pollStatus.LogAuditError();
			}
			pollStatus.PollAttempt.RequestEndTime = DateTime.UtcNow;
			pollStatus.PollAttempt.ResponseCode = pollStatus.ResponseCode.ToString();
			pollStatus.ChunkAttempt = new ChunkAttempt
			{
				SourceID = urlSource.ID,
				PollID = pollStatus.PollAttempt.PollID,
				ChunkID = "0"
			};
			urlSource.History = pollStatus;
			if (IsReutersPollEventsEnabled)
			{
				EAP.Core.Logging.Emsure.Polling.Poll.Stop(urlSource.ID, pollStatus.PollAttempt.PollID);
				EAP.Core.Logging.Emsure.Polling.Poll.Complete(
					urlSource.ID, pollStatus.PollAttempt.PollID, pollStatus.ResponseCode, pollStatus.PollAttempt.ToJson());
			}
			return Task.CompletedTask;
		}

		private DateTime? _DriverCreated = null;
        private string _FileDownloadFolder = string.Empty;

		private (string Content, string? DriverUrlAfterNavigation) LoadPage(IWebDriver webDriver, UrlPollStatus pollStatus)
		{
			string content = null;
            string driverUrlAfterNavigation = null;
			var contentSize = 0;
			
			var stopwatch = Stopwatch.StartNew();
			try
			{
				pollStatus.Audit.SetUri(new Uri(UrlSource.Url));
                AutomationClient.ForceLog?.Invoke($"Selenium: navigating to {UrlSource.Url}",
                     LogLevel.Info);

                webDriver?.Navigate().GoToUrl(UrlSource.Url);
                
                if (UrlSource.SeleniumPagePostLoadWaitInMs.HasValue)
                    Thread.Sleep(TimeSpan.FromMilliseconds(UrlSource.SeleniumPagePostLoadWaitInMs.Value));

                WaitUntil();

                driverUrlAfterNavigation = Driver?.Url;
                content = Driver?.PageSource ?? string.Empty;
                AutomationClient.ForceLog?.Invoke($"Selenium: wait at {UrlSource.Url} is completed",
                    LogLevel.Info);

                var cookies = webDriver?.Manage().Cookies.AllCookies.ToArray() ?? Array.Empty<Cookie>();
                pollStatus.Audit.SetResponseCookies(JArray.FromObject(cookies));

				contentSize = Encoding.UTF8.GetByteCount(content);
				UrlSource.AuditEvent?.SuccessTimeMs.Set(stopwatch.ElapsedMilliseconds);
				UrlSource.AuditEvent?.SuccessfulRequests.Set(1);
				UrlSource.AuditEvent?.ResponseSizeBytes.Set(Encoding.UTF8.GetByteCount(content, 0, content.Length));
				if (_DriverCreated != null && UrlSource.ConnectionLeaseTimeoutInMs != -1 && DateTime.UtcNow.Subtract((DateTime)_DriverCreated).TotalMilliseconds > UrlSource.ConnectionLeaseTimeoutInMs)
				{
					AutomationClient.ForceLog($"ConnectionLeaseTimeoutInMs {UrlSource.ConnectionLeaseTimeoutInMs} expired, resetting driver", LogLevel.Info);
					ResetWebDriver();
				}

				return (content, driverUrlAfterNavigation);
			}
			catch(Exception exc)
			{
                AutomationClient.ForceLog?.Invoke($"Selenium: error at {UrlSource.Url}. Msg = {exc.Message}",
                    LogLevel.Error);

                UrlSource.AuditEvent?.FailedRequests.Set(1);
				throw;
			}
			finally
			{
				UrlSource.AuditEvent?.RequestTimeMs.Set(stopwatch.ElapsedMilliseconds);
                pollStatus.Audit.SetRequestTime(stopwatch.Elapsed);
				if (!string.IsNullOrWhiteSpace(content))
				{
                    pollStatus.Audit
                            .SetResponseContentSize(contentSize)
                            .SetBody(content);

					if (IsNewContentDetected(contentSize, PreviousContentSize, out var percentageOfContentSizeChange))
					{                        
						AutomationClient.ReutersLogEvents(NLog.LogLevel.Info,
							$"New Content Detected: {UrlSource.ID} {pollStatus.HttpMethod} {UrlSource.Url} " +
							$"Content size differs by {Math.Round(percentageOfContentSizeChange, 1)}% " +
							$"Current content size: {contentSize}. " +
							$"Previous content size: {PreviousContentSize}",
                            pollStatus.Audit.BuildJson());
						PreviousContentSize = contentSize;
					}
					else
					{
						AutomationClient.ReutersLogEvents(NLog.LogLevel.Trace,
                            $"No difference with the previous content: " +
							$"{pollStatus.Source.ID} {pollStatus.HttpMethod} {pollStatus.Source.Url} " +
							$"Content size differs by {percentageOfContentSizeChange}% " +
							$"Current content size: {contentSize} Previous content size: {PreviousContentSize}",
                            pollStatus.Audit.BuildJson());
                    }
				}
			}
		}

		private (string Content, string? DriverUrlAfterNavigation) GetRequest(string url, UrlPollStatus pollStatus)
		{
			try
			{
				lock (_webDriverLock)
				{
					if (Driver == null)
						throw new ArgumentNullException(nameof(Driver), "Driver isn't initialized");

					if (Driver != null)
					{
						return LoadPage(Driver, pollStatus);
					}
				}
			}
			catch (WebDriverTimeoutException ex)
			{
				pollStatus?.PollAttempt?.LogError(ex.ToString());
			}
			catch (Exception ex)
			{
				pollStatus?.PollAttempt?.LogError(ex.ToString());
				ResetWebDriver();
			}
			return (string.Empty, null);
		}

		private void ResetWebDriver()
		{
			lock (_webDriverLock)
			{
				DestroyDriver();
				if (IsPollingActive)
					CreateDriver();
			}
		}

		private void WaitUntilComplete()
		{
			lock (_webDriverLock)
			{
				if (Driver != null)
				{
					var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(UrlSource.ConnectionTimeout));
					wait.Until((webDriver) =>
					{
                        if (Source.WebDriverFileDownload)
                        {
                            DirectoryInfo dirInfo = GetDirectory();
                            return dirInfo.EnumerateFiles().Count() > 0;
                        }
                        else
                        {
                            if (!IsPollingActive) return false;
                            return ((IJavaScriptExecutor)webDriver).ExecuteScript("return document.readyState").Equals("complete");
                        }   
					});
				}
			}
		}

        private DirectoryInfo GetDirectory()
        {
            string userPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloadPath = Path.Combine(userPath, $"downloads{Path.DirectorySeparatorChar}{_FileDownloadFolder}");
            DirectoryInfo dirInfo = new DirectoryInfo(downloadPath);
            return dirInfo;
        }

        private void WaitUntil()
		{
			lock (_webDriverLock)
			{
				if (Driver != null)
				{
					if (WaitUntilCompletionAction == null)
					{
						WaitUntilComplete();
					}
					else
					{
                        WaitUntilCompletionAction.Invoke();
                    }
				}
			}
		}

		private readonly WebDriverFactory _factory = new WebDriverFactory();
		private void CreateDriver()
		{
			lock (_webDriverLock)
			{
				if (Driver == null)
				{
                    _FileDownloadFolder = Guid.NewGuid().ToString();

                    if (WebDriverType == WebDriverType.FireFox)
					{
						Driver = _factory.GetFireFoxDriver(TimeSpan.FromSeconds(120), Source.WebDriverFileDownload, _FileDownloadFolder);
					}
					else
					{
						Driver = _factory.GetChromeDriver(TimeSpan.FromSeconds(120), Source.WebDriverFileDownload, _FileDownloadFolder);
					}

					Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
					Driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(UrlSource.ConnectionTimeout);
					Driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromSeconds(UrlSource.ConnectionTimeout);
					_DriverCreated = DateTime.UtcNow;
				}
			}
		}

		private void DestroyDriver()
		{
			lock (_webDriverLock)
			{
				if (Driver != null)
				{
					AutomationClient.ForceLog?.Invoke($"Quit driver {UrlSource.ID}", LogLevel.Info);
					Driver?.Dispose();
					Driver = null;
                    if (Source.WebDriverFileDownload)
                    {
                        DirectoryInfo dirInfo = GetDirectory();
                        dirInfo.Delete(true);
                    }
				}
			}
		}
	}
}
