using System;
using System.IO;
using System.Linq;
using System.Text;
using EAP.Automation.Proxy;
using EAP.Core.Configuration;
using EAP.Core.Types;
using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System.Collections.Generic;

namespace AutomationCore
{
	public enum WebDriverType
	{
		Chrome,
		FireFox
	}

	internal class LuminatiConfig
	{
		[JsonProperty("proxies")]
		public LuminatiProxy[] Proxies { get; set; }
	}

	internal class LuminatiProxy
	{
		[JsonProperty("port")]
		public int Port { get; set; }
	}

    public class WebDriverFactory : EAP.Core.Logging.EapLoggerImpl
    {
        private const int DEFAULT_PROXY_PORT = 22226;

        public IWebDriver GetChromeDriver(TimeSpan commandTimeout, bool webDriverFileDownload, string folderName)
        {
            return GetWebDriver(WebDriverType.Chrome, commandTimeout, webDriverFileDownload, folderName);
        }

        public IWebDriver GetFireFoxDriver(TimeSpan commandTimeout, bool webDriverFileDownload, string folderName)
        {
            return GetWebDriver(WebDriverType.FireFox, commandTimeout, webDriverFileDownload, folderName);
        }

        public IWebDriver GetWebDriver(WebDriverType driverType, TimeSpan commandTimeout, bool webDriverFileDownload, string folderName)
        {
            switch (driverType)
            {
                case WebDriverType.Chrome:
                    return ChromeDriverCreate(commandTimeout, webDriverFileDownload, folderName);
                case WebDriverType.FireFox:
                    return FirefoxDriverCreate(commandTimeout, webDriverFileDownload, folderName);
                default:
                    throw new ArgumentOutOfRangeException(nameof(driverType), driverType, null);
            }
        }

        private static Proxy CreateProxy()
        {
            var scheduleProxy = GetScheduleProxy();
            var proxy = GetProxyType();

            if (scheduleProxy == null || proxy == null)
            {
                Logger.Trace("No environment variables passed, no proxy needed");
                return null;
            }

            if (scheduleProxy.Enabled != true || proxy.Enabled != true)
            {
                // Proxy is disabled, no need to subscribe for queues
                Logger.Trace("Proxy is disabled, no proxy needed");
                return null;
            }

            var result = new Proxy
            {
                Kind = ProxyKind.Manual,
                IsAutoDetect = false,
                SslProxy = $"{proxy.Address}:{proxy.Port}",
                HttpProxy = $"{proxy.Address}:{proxy.Port}"
            };

            if (scheduleProxy.BypassList != null)
            {
                result.AddBypassAddresses(scheduleProxy.BypassList);
            }

            Logger.Info($"Create Selenium proxy- Provider: {proxy.Provider} " +
                            $"Kind: {result.Kind}, IsAutoDetect: {result.IsAutoDetect}, " +
                            $"SslProxy: {result.SslProxy}, HttpProxy: {result.HttpProxy} " +
                            $"BypassProxyAddresses: {result.BypassProxyAddresses}");
            return result;
        }

        private static ScheduleProxy GetScheduleProxy()
        {
            var scheduleProxyJson = Environment.GetEnvironmentVariable(EnvVariableNames.SCHEDULE_PROXY);
            return !string.IsNullOrWhiteSpace(scheduleProxyJson) ? JsonConvert.DeserializeObject<ScheduleProxy>(scheduleProxyJson) : null;
        }

        private static ProxyType GetProxyType()
        {
            var proxyJson = Environment.GetEnvironmentVariable(EnvVariableNames.PROXY);
            if (string.IsNullOrWhiteSpace(proxyJson))
            {
                return null;
            }

            var proxy = JsonConvert.DeserializeObject<ProxyType>(proxyJson);
            if (proxy.Provider == EAP.Core.Constants.ProxyProviders.LUMINATI)
            {
                proxy.Address = "127.0.0.1";
                proxy.Port = GetLuminatiProxyPort();
            }
            else if (proxy.Provider == EAP.Core.Constants.ProxyProviders.EAP)
            {
                proxy.Address = proxy.Address.Replace("http://", "");
                proxy.Port = EapProxy.Instance.Endpoint.Port;
            }
            else
            {
                // strip the scheme off 
                proxy.Address = proxy.Address.Replace("http://", "");
                proxy.Address = proxy.Address.Replace("https://", "");
            }

            return proxy;
        }

        private static int GetLuminatiProxyPort()
        {
            var cfgString = Environment.GetEnvironmentVariable(AutomationCore.Constants.EnvironmentVariables.LUMINATI_CONFIG);

            if (string.IsNullOrWhiteSpace(cfgString))
            {
                Logger.Error($"Can not find {AutomationCore.Constants.EnvironmentVariables.LUMINATI_CONFIG}");
                return DEFAULT_PROXY_PORT;
            }

            var config = JsonConvert.DeserializeObject<LuminatiConfig>(cfgString);
            if (config?.Proxies == null || !config.Proxies.Any())
            {
                Logger.Error($"The Proxies array from Luminati config is empty. {cfgString}");
                return DEFAULT_PROXY_PORT;
            }

            //The port can be found in the json file at proxies[0].port
            return config.Proxies.First().Port;
        }

        private static IWebDriver ChromeDriverCreate(TimeSpan commandTimeout, bool webDriverFileDownload, string folderName)
        {
            var options = new ChromeOptions
            {
                AcceptInsecureCertificates = true,
                PageLoadStrategy = PageLoadStrategy.None,
                Proxy = CreateProxy()
            };
            

            var headlessDisabled = Environment.GetEnvironmentVariable(AutomationCore.Constants.EnvironmentVariables.SELENIUM_HEADLESS_DISABLED);
            if (string.IsNullOrWhiteSpace(headlessDisabled))
            {
                headlessDisabled = "false";
            }

            if (headlessDisabled.ToLower() != "true")
            {
                options.AddArgument("--headless=new");
            }

            //disables indication that browser is controlled by automation.
            options.AddExcludedArguments("enable-automation");
            //disables navigator.webdriver == true
            options.AddArgument("--disable-blink-features=AutomationControlled");

            options.AddArgument("--disable-infobars");
            options.AddArgument("--disable-gpu");
            options.AddArgument("--disable-extensions");
            options.AddArgument("--no-sandbox");

            options.AddArgument("--blink-settings=imagesEnabled=false");
            options.AddArgument("--disable-http-cache");
            options.AddArgument("-–disable-application-cache");
            options.AddArgument("-–media-cache-size=1");
            options.AddArgument("-–disk-cache-size=1");

            if(Logger.IsDebugEnabled)
                options.AddArgument("-–log-level=DEBUG");
            else
                options.AddArgument("-–log-level=INFO");

            options.AddUserProfilePreference("profile.default_content_settings.images", 2);
            options.AddUserProfilePreference("profile.managed_default_content_settings.images", 2);
            options.AddUserProfilePreference("profile.managed_default_content_settings.stylesheets", 2);
            options.AddUserProfilePreference("profile.managed_default_content_settings.media_stream", 2);
            options.AddUserProfilePreference("profile.managed_default_content_settings.popups", 2);
            options.AddUserProfilePreference("profile.managed_default_content_settings.notifications", 2);

            if (webDriverFileDownload)
            {
                string downloadPath = GetDownloadPath(folderName);
                options.AddUserProfilePreference("download.default_directory", downloadPath);
                options.AddUserProfilePreference("download.prompt_for_download", false);
                options.AddUserProfilePreference("download.directory_upgrade", true);
                options.AddUserProfilePreference("plugins.always_open_pdf_externally", true);
            }

            ChromeDriverService chromeService = ChromeDriverService.CreateDefaultService();
            
            IWebDriver driver = new ChromeDriver(chromeService, options, commandTimeout);

            ChromeOverrideUserAgent(driver);

            return driver;
        }

        private static void ChromeOverrideUserAgent(IWebDriver driver)
        {
            ((ChromeDriver)driver).ExecuteCdpCommand("Network.setUserAgentOverride",
                new Dictionary<string, object>
                {
                    { "userAgent", ((string)((ChromeDriver)driver).ExecuteScript("return navigator.userAgent")).Replace("Headless", "") }
                }
            );
        }

        private static string GetDownloadPath(string folderName)
        {
            string userPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloadPath = Path.Combine(userPath, $"downloads{Path.DirectorySeparatorChar}{folderName}");
            DirectoryInfo dirInfo = new DirectoryInfo(downloadPath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }

            return downloadPath;
        }

        private static IWebDriver FirefoxDriverCreate(TimeSpan commandTimeout, bool webDriverFileDownload, string folderName)
		{            
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            
            var options = new FirefoxOptions
			{
				AcceptInsecureCertificates = true,
				LogLevel = Logger.IsDebugEnabled ? FirefoxDriverLogLevel.Debug : FirefoxDriverLogLevel.Default,
				PageLoadStrategy = PageLoadStrategy.None,
				Proxy = CreateProxy()
			};
            
			string headless_disabled = Environment.GetEnvironmentVariable(AutomationCore.Constants.EnvironmentVariables.SELENIUM_HEADLESS_DISABLED);
			if (string.IsNullOrWhiteSpace(headless_disabled))
				headless_disabled = "false";

			if (headless_disabled.ToLower() != "true")
				options.AddArgument("--headless");

			//options.SetPreference("webgl.disabled", true);

			options.SetPreference("browser.tabs.remote.autostart", false);
			options.SetPreference("browser.tabs.remote.autostart2", false);
			options.SetPreference("permissions.default.stylesheet", 2);//disable css
			options.SetPreference("permissions.default.image", 2);//disable images
			options.SetPreference("plugin.state.flash", 0);//disable flash
			options.SetPreference("browser.cache.disk.enable", false);
			options.SetPreference("browser.cache.memory.enable", false);
			options.SetPreference("browser.cache.offline.enable", false);
			options.SetPreference("network.http.use-cache", false);
			options.SetPreference("security.tls.version.min", 1); // set tls 1.0 as min for older websites

            if (webDriverFileDownload)
            {
                string downloadPath = GetDownloadPath(folderName);
                options.SetPreference("browser.download.folderList", 2);
                options.SetPreference("browser.download.manager.showWhenStarting", false);
                options.SetPreference("browser.download.dir", downloadPath);
                //Handling mimetypes for .pdf, doc\x, xls\x -- from https://www.freeformatter.com/mime-types-list.html
                options.SetPreference("browser.helperApps.neverAsk.saveToDisk",
                  "application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                options.SetPreference("pdfjs.disabled", true);
            }

            IWebDriver driver = new FirefoxDriver(FirefoxDriverService.CreateDefaultService(), options, commandTimeout);
			return driver;
		}
	}
}
