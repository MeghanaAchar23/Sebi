using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using AutomationCore.Handbrake;

namespace AutomationCore
{
	public class OnDemandPublisher
	{
		private const int m_iDefaultReadBufferLength = 4096;
		private TcpClient m_oClient;

		private int m_iTimeoutInMS;
		public int ServerPort
		{
			get;
			set;
		}

		public string ServerIP
		{
			get
			{
				return m_aoAddresses[0].ToString();
			}
		}

		/// <summary>
		/// default - 90000
		/// </summary>
		public int TimeoutInMS
		{
			get
			{
				return m_iTimeoutInMS == 0 ? 90000 : m_iTimeoutInMS;
			}
			set
			{
				m_iTimeoutInMS = value == 0 ? 90000 : value;

				if (this.m_oClient != null)
				{
					this.m_oClient.SendTimeout = m_iTimeoutInMS;
					this.m_oClient.ReceiveTimeout = m_iTimeoutInMS;
				}
			}
		}

		public string LocalIPToBind
		{
			get;
			set;
		}

		public string Name
		{
			get;
			set;
		}

		public string SendingSystemID
		{
			get;
			set;
		}

		private readonly int m_iClientReadBufferLength;

		private IPAddress[] m_aoAddresses;

		/// <summary>
		/// default - new Object()
		/// </summary>
		private Object m_oSyncLock = new object();

		private object m_oSyncLockMessage = new object();
		private object m_oSyncLockAddPublisher = new object();
		private object m_oSyncLockConnect = new object();

		public bool IsConnected
		{
			get;
			private set;
		}

		public bool IsConnecting
		{
			get;
			private set;
		}

		public bool IsStopped
		{
			get;
			private set;
		}

		public string AccessToken
		{
			get;
			set;
		}

		public SourceStore Store
		{
			get;
			set;
		}


		public OnDemandPublisher(string sHostNameOrAddress, int iPort, string sLocalIPToBind, string sAccessToken, string sSendingSystemID, int iClientReadBufferLength = m_iDefaultReadBufferLength)
			: this(iPort, sLocalIPToBind, sAccessToken, sSendingSystemID, iClientReadBufferLength)
		{
			this.m_aoAddresses = Dns.GetHostAddresses(sHostNameOrAddress);
		}

		public OnDemandPublisher(IPAddress[] oAddresses, int iPort, string sLocalIPToBind, string sAccessToken, string sSendingSystemID, int iClientReadBufferLength = m_iDefaultReadBufferLength)
			: this(iPort, sLocalIPToBind, sAccessToken, sSendingSystemID, iClientReadBufferLength)
		{
			this.m_aoAddresses = oAddresses;
		}

		public OnDemandPublisher(IPAddress oAddress, int iPort, string sLocalIPToBind, string sAccessToken, string sSendingSystemID, int iClientReadBufferLength = m_iDefaultReadBufferLength)
			: this(new[] { oAddress }, iPort, sLocalIPToBind, sAccessToken, sSendingSystemID, iClientReadBufferLength)
		{

		}

		private OnDemandPublisher(int iPort, string sLocalIPToBind, string sAccessToken, string sSendingSystemID, int iClientReadBufferLength)
		{
			this.LocalIPToBind = sLocalIPToBind;
			if (string.IsNullOrWhiteSpace(sLocalIPToBind))
				this.m_oClient = new TcpClient();
			else
				this.m_oClient = new TcpClient(new IPEndPoint(IPAddress.Parse(sLocalIPToBind), 0));
			this.m_oClient.SendTimeout = TimeoutInMS;
			this.m_oClient.ReceiveTimeout = TimeoutInMS;

			this.ServerPort = iPort;
			this.Name = "";
			this.SendingSystemID = sSendingSystemID;
			this.AccessToken = sAccessToken;
			this.m_iClientReadBufferLength = iClientReadBufferLength;
		}

		public void Connect()
		{
			//Commented: Let publisher connect even if automation is stopped, may be some alert(s) were not sent yet
			//if (IsStopped)
			//    return;

			lock (m_oSyncLockConnect)
			{
				try
				{
					//Store.AutomationClient.OperatorLog(this.Name + ": Connecting");

					IsConnected = false;

					if (string.IsNullOrWhiteSpace(LocalIPToBind))
						this.m_oClient = new TcpClient();
					else
						this.m_oClient = new TcpClient(new IPEndPoint(IPAddress.Parse(LocalIPToBind), 0));

					this.m_oClient.SendTimeout = TimeoutInMS;
					this.m_oClient.ReceiveTimeout = TimeoutInMS;

					bool success = true;
					var asyncResult = this.m_oClient.BeginConnect(this.m_aoAddresses, this.ServerPort, null, success);

					//Timeout if not connected in specified time
					success = asyncResult.AsyncWaitHandle.WaitOne(TimeoutInMS, false);

					//Task tskConnect = this.m_oClient.ConnectAsync(this.m_aoAddresses, this.ServerPort);
					//tskConnect.Wait(TimeoutInMS);

					//if (tskConnect.IsCompleted)

					if (this.m_oClient.Connected)
					{
						this.m_oClient.EndConnect(asyncResult);
						IsConnected = InitConnection();
					}
				}
				catch (Exception ex)
				{
					AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);

					if (m_oClient != null)
						m_oClient.Close();
				}
			}
		}

		public void Disconnect()
		{
			try
			{
				if (m_oClient != null)
				{
					m_oClient.Close();
					m_oClient = null;
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			IsConnected = false;
		}

		public void Stop()
		{
			IsStopped = true;
			try
			{
				Disconnect();
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
		}

		/// <summary>
		/// makes connection, send RSET command and set IsConnected to true only if it receives positive response
		/// </summary>
		public bool InitConnection()
		{
			string sToken = "";

			if (!string.IsNullOrWhiteSpace(AccessToken))
				sToken = AccessToken.Trim();
			string sInit = "RSET|" + sToken + "#";
			if (Send(Encoding.ASCII.GetBytes(sInit)))
			{
				string sResponse = Receive();
				if (sResponse.StartsWith("+"))
				{
					return true;
				}
			}

			return false;
		}

		public bool Send(byte[] buffer)
		{
			try
			{
				NetworkStream networkStream = this.m_oClient.GetStream();
				networkStream.Write(buffer, 0, buffer.Length);
				//Store.AutomationClient.OperatorLog(this.Name + ": " + Encoding.UTF8.GetString(buffer));
				return true;
			}
			catch (Exception ex)
			{
				AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error);
				return false;
			}
			finally
			{
				//Disconnect();
			}
		}

		public string Receive()
		{
			StringBuilder sRead = new StringBuilder("");
			try
			{
				NetworkStream networkStream = this.m_oClient.GetStream();
				byte[] buffer = new byte[m_iClientReadBufferLength];
				do
				{
					int read = networkStream.Read(buffer, 0, buffer.Length);
					/*if (read == 0)
					{
						Disconnect();
						break;
					}*/
					sRead.Append(Encoding.ASCII.GetString(buffer, 0, read));
				} while (networkStream.DataAvailable);
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }
			return sRead.ToString();
		}
	}
}
