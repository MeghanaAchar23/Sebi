using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using EAP.FileConversion.SDK.Common.ProcessRunner;
using EAP.FileConversion.SDK.PDF.XPDF;

namespace AutomationCore.Pdf
{
	public class XPDFToText
	{
		private const string XPDF_TOOL_FILENAME = "pdftotext";
		private readonly IAsyncPdfToTextFileConvertor convertor;

		public XPDFToText()
		{
			var defaultProcessRunner = new DefaultProcessRunner();
			convertor = new AsyncPdfToTextFileConvertor(defaultProcessRunner);
		}

		/// <summary>
		/// First page to convert. Will convert all pages by default.
		/// </summary>
		public int? FirstPage { get; init; }

		/// <summary>
		/// Last page to convert. Will convert all pages by default.
		/// </summary>
		public int? LastPage { get; init; }

		/// <summary>
		/// Output text encoding. Default is "UTF-8".
		/// </summary>
		public string Encoding { get; init; } = "UTF-8";

		/// <summary>
		/// Layout specification.
		/// </summary>
		public string Layout { get; init; } = "layout";

		/// <summary>
		/// Advanced options for the XPDF tool.
		/// </summary>
		public string XpdfAdvancedOptions { get; init; }

		/// <summary>
		/// Converts a PDF file to text using XPDF.
		/// </summary>
		/// <param name="pdfFileStream">PDF file stream</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>Converted PDF file as string</returns>
		public async Task<string> ConvertAsync(Stream pdfFileStream, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("Starting PDF conversion using XPDF");

			try
			{
				var options = GetPdfToTextOptions();

				var result = await convertor.ConvertAsync(options, pdfFileStream, cancellationToken);
				AutomationClient.ForceLog("Finished converting PDF file");

				return result;
			}
			catch (Exception ex)
			{
				AutomationClient.ForceLog($"PDF conversion failed with error: {ex.Message}", NLog.LogLevel.Error);
				throw;
			}
		}

		/// <summary>
		/// Converts a PDF file to text using XPDF.
		/// </summary>
		/// <param name="pdfFilePath">Path to PDF file</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>Converted PDF file as string</returns>
		public async Task<string> ConvertAsync(string pdfFilePath, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("Starting PDF conversion using XPDF");

			try
			{
				var options = GetPdfToTextOptions();

				var result = await convertor.ConvertAsync(options, pdfFilePath, cancellationToken);
				AutomationClient.ForceLog("Finished converting PDF file");

				return result;
			}
			catch (Exception ex)
			{
				AutomationClient.ForceLog($"PDF conversion failed with error: {ex.Message}", NLog.LogLevel.Error);
				throw;
			}
		}

		/// <summary>
		/// Converts a PDF file to text using XPDF.
		/// </summary>
		/// <param name="bytes">PDF byte array.</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>Converted PDF file as string</returns>
		public async Task<string> ConvertAsync(byte[] bytes, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("Starting PDF conversion using XPDF");

			try
			{
				using var pdfFileStream = new MemoryStream(bytes);
				var options = GetPdfToTextOptions();

				var result = await convertor.ConvertAsync(options, pdfFileStream, cancellationToken);
				AutomationClient.ForceLog("Finished converting PDF file");

				return result;
			}
			catch (Exception ex)
			{
				AutomationClient.ForceLog($"PDF conversion failed with error: {ex.Message}", NLog.LogLevel.Error);
				throw;
			}
		}

		private static string GetFullPathToXpdfTool()
		{
			var isWin = System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows);
			var fileName = isWin ? $@"c:\windows\system32\{XPDF_TOOL_FILENAME}.exe" : $"/usr/bin/{XPDF_TOOL_FILENAME}";

			return new FileInfo(fileName).FullName;
		}

		private PdfToTextOptions GetPdfToTextOptions()
		{
			var xpdfFullPath = GetFullPathToXpdfTool();
			var options = new PdfToTextOptions(xpdfFullPath)
			{
				Encoding = Encoding,
				Layout = Layout,
				FirstPage = FirstPage,
				LastPage = LastPage,
				XPDFAdvancedOptions = XpdfAdvancedOptions,
			};

			return options;
		}
	}
}
