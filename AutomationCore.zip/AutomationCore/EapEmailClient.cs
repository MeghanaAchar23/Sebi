using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using EAP.Core;
using EAP.Core.Configuration;
using MimeKit;
using System.Collections.Generic;
using System.Linq;

namespace AutomationCore
{
	public delegate void EapEmailNotificationReceived(string bucketName, string objectKey, string emailsource, List<string> emaildestinations);
	public delegate void EapEmailProcessCompleted();

	public class EapEmailClient
	{
		public EapEmailNotificationReceived OnEmailReceived;
		public EapEmailProcessCompleted OnEmailProcessCompleted;

		public int WaitInSeconds { get; set; } = 20;
		public bool IsRunning { get; set; }

		private CancellationTokenSource tokenSource;
		private IEmailClient _client;

		public IEmailClient Client => _client;

		public Task Start(bool loadHistory = false)
		{
			IsRunning = true;
			tokenSource = new CancellationTokenSource();
			return Task.Factory.StartNew(() => Run(loadHistory), tokenSource.Token,
				TaskCreationOptions.LongRunning, TaskScheduler.Default);
		}

		public void Stop()
		{
			try
			{
				AutomationClient.ForceLog("Stopping EapEmailClient");
				tokenSource?.Cancel();
			}
			catch (Exception e)
			{
				AutomationClient.ForceLog(e.ToString(), LogLevel.Error);
			}
		}

		private void Run(bool loadHistory)
		{
			if (_client == null)
				_client = AutomationClient.ReutersConfig.GetEmailClientAsync().GetAwaiter().GetResult();

			while (!tokenSource.Token.IsCancellationRequested)
			{
				try
				{
					AutomationClient.ForceLog("Requesting GetNextEmailAsync");

					AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));

					Task<EmailNotification> asyncNotification = _client.GetNextEmailAsync(WaitInSeconds);

					asyncNotification.Wait();

					if (asyncNotification.IsCompleted)
					{
						if ((asyncNotification.Result == null || string.IsNullOrEmpty(asyncNotification.Result?.ReceiptHandle)) && loadHistory)
						{
							AutomationClient.ForceLog("Breaking out of GetNextEmailAsync loop");
							break;
						}
					}

					if (asyncNotification.IsCompletedSuccessfully && asyncNotification.Result?.Content != null)
					{
						MessageContent notification = asyncNotification.Result.Content;

						AutomationClient.ForceLog($"Message content: {notification.Mail.ToJson()}");

						string bucketName = notification.Receipt.Action.BucketName;
						string objectKey = notification.Receipt.Action.ObjectKey;
						string emailsource = notification.Mail.Source;

						AutomationClient.ForceLog($"Email notification, source:{emailsource} bucket:{bucketName}, objectKey:{objectKey}");

						if (!loadHistory)
						{
							OnEmailReceived?.Invoke(bucketName, objectKey, emailsource, notification.Mail.Destination.Union(notification.Receipt.Recipients, StringComparer.OrdinalIgnoreCase).ToList<string>());
						}
						else
						{
							byte[] email = _client.ReadEmailAsync(bucketName, objectKey).GetAwaiter().GetResult();
							try
							{
								using (var ms = new MemoryStream(email))
								{
									var message = MimeMessage.Load(ms);
									AutomationClient.ForceLog($"Historical email: from: {message.From}, subject: {message.Subject}");
								}
							}
							catch { }
						}

						try
						{
							//delete email
							AutomationClient.ForceLog($"Deleting email, bucket:{bucketName}, objectKey:{objectKey}");
							_client.DeleteEmailAsync(asyncNotification.Result).GetAwaiter().GetResult();
						}
						catch (Exception ex)
						{
							AutomationClient.ForceLog("Exception while deleting email: " + ex.ToString(), LogLevel.Error);
						}

						OnEmailProcessCompleted?.Invoke();
					}
				}
				catch (Exception ex)
				{
					AutomationClient.ForceLog("Exception while email request: " + ex.ToString(), LogLevel.Error);
					if (!tokenSource.Token.IsCancellationRequested)
						Thread.Sleep(5000);
				}
			}
		}
	}
}
