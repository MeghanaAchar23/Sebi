using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Loader;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EAP.Automation.Ucdp;
using EAP.Core.Configuration;
using EAP.Core.Types;
using EAP.Core.UCDP;
using MetadataApi.GrpcClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AutomationCore
{
	public delegate void OperatorLogDelegate(string message, params object[] args);
	public delegate void OperatorLogEventsDelegate(NLog.LogLevel level, string message, string json);

	public delegate void AutomationStoppedDelegate();

	// preinitialize -> initialize -> loadhistory -> startpolling -> writeperflog
	public sealed class AutomationExecutionCommands
	{
		public const string PREINITIALIZE = "preinitialize";
		public const string INITIALIZE = "initialize";
		public const string LOADHISTORY = "loadhistory";
		public const string STARTPOLLING = "startpolling";
		public const string WRITEPERFLOG = "writeperflog";
	}

	public enum ExecutionState
	{
		LoadHistoryPending,
		LoadHistoryCompleted,
		PollActivationPending,
		PollActivationCompleted
	}

	/// <summary>
	/// Provides method to create and load SourceStore from xml and executes commands received from AutomationMain. This is an abstract class.
	/// </summary>
	/// <remarks>
	/// Any automation must have a Main class which inherits AutomationClient class. AutomationClient provides the LoadSourceStore method to initialize and return an user defined SourceStore object.
	/// Calls ExecuteCommand method for the commands received from the AutomationMain object which in turn might be received from the Automation Controller or the Spider service.
	/// </remarks>
	/// <example>
	/// Example
	/// =======
	/// Following code shows how to write Main class which inherits AutomationClient class.
	/// <code>
	/// //All automation DLL MUST need to have class Main and derive it from AutomationClient
	/// public class Main : AutomationClient
	/// {
	///    //All automation DLL MUST need to have this function.
	///    public override SourceStore LoadSourceStore(Config config)
	///    {
	///        //Store is the object of MySourceStore class which is inherited from SourceStore class.
	///        MySourceStore Store = new MySourceStore(this.GetType().Assembly.Location, config);
	///
	///        //Specifiy the default execution sequence. This will create the default exceution sequence as "preinitialize,initialize,loadhistory,startpolling".
	///        DefaultCommandExecutionSequence = "loadhistory,startpolling";
	///
	///        return Store;
	///    }
	/// }
	/// </code>
	/// </example>
	public abstract class AutomationClient
	{
		public static AutomationConfiguration ReutersConfig { get; set; }
		public static List<ScheduleUserData> UserData { get; set; }
		public static IGrpcClientProvider GrpcClientProvider { get; set; }
		public static IPublicationRegionEndpointSelector EndpointSelector { get; set; }

		public static bool IsLogEnabled { get; set; }

		public static List<string> LogOptions { get; set; } = new List<string>();

		/// <summary>
		/// Initializes a new instance of AutomationClient class.
		/// </summary>
		protected AutomationClient()
		{
			Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

			_lastCommandExecuted = AutomationExecutionCommands.PREINITIALIZE;
			IsLoadedFromController = false;
			AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
		}

		void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception ex = (Exception)e.ExceptionObject;
		}

		private string _defaultCommandExecutionSequence;
		private string _lastCommandExecuted;
		public OperatorLogDelegate OperatorLog;

		public AutomationStoppedDelegate OnAutomationStopped;

		public static OperatorLogDelegate ReutersLog;
		public static OperatorLogDelegate ForceLog;
		public static OperatorLogEventsDelegate ReutersLogEvents;

		public UcdpManager UcdpManager { get; private set; }

		public static EapEmailClient EapEmailPollClient { get; set; } = new EapEmailClient();

		private bool _isAlreadyStopped;
		private readonly object _syncRoot = new object();

		public ExecutionState GlobalExecutionState { get; private set; }

		public void TryToStop(Func<int, bool> livePollCountCheck = null)
		{
			lock (_syncRoot)
			{
				// can be stopped by current method or AssemblyLoadContext.Default.Unloading
				if (_isAlreadyStopped) return;

				var anyEnabled = GlobalStore?.Sources?.GetAllActiveSources()?.Any() ?? false;
				var anyBeingPolled =
					anyEnabled && (GlobalStore?.Sources?.GetAllActiveSources()?.Any(s => s?.IsSourceBeingPolled ?? false) ?? false);

				if (anyEnabled && anyBeingPolled) return;

				ForceLog?.Invoke(
					"All sources are deactivated. " +
					$"Last command executed - {LastCommandExecuted}. " +
					$"Polls in the completion phase - {GlobalStore?.LivePollCount ?? 0}.",
					LogLevel.Info);

				if (GlobalStore == null || (livePollCountCheck?.Invoke(GlobalStore.LivePollCount) ?? GlobalStore.LivePollCount <= 0))
				{
					ForceLog?.Invoke(
						"Stopping automation - all sources stopped polling",
						LogLevel.Warn);

					_isAlreadyStopped = true;
					OnAutomationStopped?.Invoke();
				}
			}
		}

		/// <summary>
		/// Specifies if the automation was loaded from a standalone controller.
		/// </summary>
		public bool IsLoadedFromController
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the object to access properties/methods available in SourceStore.
		/// </summary>
		public SourceStore GlobalStore
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the default sequence of the automation execution process.
		/// </summary>
		/// <remarks>
		/// This property specifies the command sequence in which the automation must execute. "preinitialize" and "initalize" commands are added by default.
		/// That means the value to set will be the expected command sequence after "initialize". i.e., "startpolling" or "loadhistory,startpolling".
		/// </remarks>
		public string DefaultCommandExecutionSequence
		{
			get => string.IsNullOrWhiteSpace(_defaultCommandExecutionSequence)
				? $"{AutomationExecutionCommands.PREINITIALIZE},{AutomationExecutionCommands.INITIALIZE}"
				: _defaultCommandExecutionSequence;
			set
			{
				var sValue = value;
				if (!string.IsNullOrWhiteSpace(sValue))
					sValue = "," + sValue;
				_defaultCommandExecutionSequence =
					$"{AutomationExecutionCommands.PREINITIALIZE},{AutomationExecutionCommands.INITIALIZE}" + sValue;
			}
		}

		/// <summary>
		/// Gets or sets the last executed command name. Returns "preinitialize" for the first time or the value is empty.
		/// </summary>
		public string LastCommandExecuted
		{
			get => string.IsNullOrWhiteSpace(_lastCommandExecuted) ? AutomationExecutionCommands.PREINITIALIZE : _lastCommandExecuted;
			private set => _lastCommandExecuted = value;
		}

		void LoadEmailClient()
		{
			GlobalStore.EmailClient = new Email.EmailClient();
		}

		/// <summary>
		/// Executes command based on the command name passed in &lt;command> parameter in `xmlConfiguration`.
		/// </summary>
		/// <remarks>
		/// Returns _false_ if command name is empty or specified some other name before "initialize".
		/// Following commands are supported currently:
		///
		/// - initialize
		/// ------------
		/// Loads xml configuration in Config object and loads the SourceStore object. Executes LoadSourceStore method which will linitalize other components if defined in the method implementation.
		/// Loads PublicationClients and EmailClient objects in store. At this point automation will have all the required components initialized for the automation.
		///
		/// - loadhistory
		/// -------------
		/// Executes LoadHistory method of all the active sources added in the `Sources` object in GlobalStore. Calls OnHistoryLoaded method of GlobalStore if all the sources had successfully executed LoadHistory.
		///
		/// - startpolling
		/// --------------
		/// Excecutes StartPolling method of the GlobalStore. Which will in turn start polling of all the active sources.
		///
		/// - writelogtoxmlfile
		/// -------------------
		/// Write the xml serialized log to datetime wise file in Log folder in the same local directory from where the automation controller was run.
		/// </remarks>
		/// <param name="xmlConfiguration"></param>
		/// <returns>Boolean</returns>
		public virtual async Task<bool> ExecuteCommand(string jsonConfig)
		{
			var jDoc = JObject.Parse(jsonConfig);

			string sCommand = Utils.GetSingleValue(jDoc, "$.command").Trim().ToLower();

			if (_isAlreadyStopped)
			{
				ForceLog(
					$"Ignored to execute '{sCommand}' command as the termination of automation was started");
				return false;
			}

			string sHostingServerName = Utils.GetSingleValue(jDoc, "$.server_name").Trim().ToLower();

			string sAutomationDll = Utils.GetSingleValue(jDoc, "$.generals.spider_id").Trim();
			string sAutomationFullName = Utils.GetSingleValue(jDoc, "$.generals.spider_name").Trim();

			if (string.IsNullOrWhiteSpace(sCommand) || (sCommand != "initialize" && GlobalStore == null))
			{
				ForceLog("Invalid command as configurations are not loaded yet.");
				return false;
			}
			ForceLog($"DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");
			if (sCommand == AutomationExecutionCommands.INITIALIZE)
			{
				//Jay : 14-Sep-2015 : Error message when no publisher get connected in Initialize
				bool t_bPermanentPublisherUnableToConnect = false;

				ForceLog("Processing command - initialize");

				if (IsCommandInCorrectSequence(AutomationExecutionCommands.INITIALIZE))
				{
					Config oConfig = new Config(jsonConfig);

					OperatorLog("Loading source store...");
					GlobalStore = LoadSourceStore(oConfig);

					if (GlobalStore != null)
					{
						GlobalStore.AutomationClient = this;
						GlobalStore.AutomationFullName = sAutomationFullName;
						GlobalStore.AutomationName = sAutomationDll;
						GlobalStore.SetHostingServerName(sHostingServerName);
					}

					OperatorLog("Loading publication configurations...");

					await InitializeUcdp();

					LoadEmailClient();

					//set service point manager max connection limit
					ServicePointManager.DefaultConnectionLimit = 20;

					//Ignore certificate checks in ssl sites
					ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => { return true; };

					//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | (SecurityProtocolType)768 | (SecurityProtocolType)3072 | SecurityProtocolType.Ssl3;
					ServicePointManager.SecurityProtocol = SecurityProtocolType.SystemDefault | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

					//ServicePointManager.DnsRefreshTimeout = 30000;

					ThreadPool.SetMinThreads(100, 100);

					//AppDomain.CurrentDomain.ProcessExit += CurrentDomain_ProcessExit;
					AssemblyLoadContext.Default.Unloading += ctx =>
					{
						try
						{
							ForceLog("AssemblyLoadContext.Default.Unloading invoked");
							_isAlreadyStopped = true;

							var events = GlobalStore.Sources.GetAllSources()
								.Where(source => source is URLSource urlSource && urlSource.AuditEvent != null)
								.Select(source => ((URLSource)source).AuditEvent)
								.ToList();

							ReutersLogEvents(NLog.LogLevel.Info,
								$"Audit: Automation {sAutomationFullName} statistics",
								JsonConvert.SerializeObject(events, Formatting.None));

							OnAutomationStopped?.Invoke();
						}
						catch (Exception e)
						{
							ForceLog(e.ToString(), LogLevel.Error);
						}
					};
					Console.CancelKeyPress += Console_CancelKeyPress;

					LastCommandExecuted = AutomationExecutionCommands.INITIALIZE;
					ForceLog("Initialization completed successfully.");
				}
				else
					ForceLog(
						$"Invalid command sequence. Current command - '{sCommand}'." +
						$" DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");

				if (t_bPermanentPublisherUnableToConnect == true && IsLoadedFromController == false)
					ForceLog("(Publisher not connected) - Finished processing command - initialize");
				else
					ForceLog("Finished processing command - initialize");
			}
			else if (sCommand == AutomationExecutionCommands.LOADHISTORY)
			{
				if (!TryExecuteLoadHistory(sCommand))
				{
					_isAlreadyStopped = true;
					OnAutomationStopped?.Invoke();
				}
			}
			else if (sCommand == AutomationExecutionCommands.STARTPOLLING)
			{
				if (!TryExecuteStartPolling(sCommand))
				{
					_isAlreadyStopped = true;
					OnAutomationStopped?.Invoke();
				}
			}
			else if (sCommand == AutomationExecutionCommands.WRITEPERFLOG)
			{
				if (IsCommandInCorrectSequence(sCommand))
				{
					//code will go here to write performance log
					LastCommandExecuted = sCommand;
				}
				else
					OperatorLog("Invalid command sequence.");
			}
			else
			{
				ForceLog("Unknown command - " + sCommand);
			}
			return true;
		}

		private bool TryExecuteLoadHistory(string command)
		{
			GlobalExecutionState = ExecutionState.LoadHistoryPending;
			ForceLog($"Processing command - {AutomationExecutionCommands.LOADHISTORY}. " +
						$"DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");

			if (IsCommandInCorrectSequence(command))
			{
				var sources = GlobalStore?.Sources?.GetAllActiveSources();

				if (sources?.Any() != true)
				{
					ForceLog("All sources are disabled or sources list is empty", LogLevel.Warn);
					return false;
				}

				var allHistoricalDataLoaded = true;
				foreach (var source in sources)
				{
                    if (source.UseHistoryPolling == false)
                    {
                        ForceLog("Load history not enabled for source " + source.ID, LogLevel.Info);
                    }
                    else
                    {
                        if (!source.LoadHistory())
                        {
                            allHistoricalDataLoaded = false;
                            ForceLog("Load history failed for source " + source.ID, LogLevel.Warn);
                            break;
                        }
                    }
				}

				if (allHistoricalDataLoaded)
				{
					GlobalStore.OnHistoryLoaded();
					LastCommandExecuted = AutomationExecutionCommands.LOADHISTORY;
					GlobalExecutionState = ExecutionState.LoadHistoryCompleted;
					ForceLog($"Finished processing command - {AutomationExecutionCommands.LOADHISTORY}");
					return true;
				}

				ForceLog("Not all historical data was successfully loaded", LogLevel.Warn);
			}
			else
			{
				ForceLog(
					$"Invalid command sequence or '{AutomationExecutionCommands.LOADHISTORY}' step was skipped. " +
					$"Current command - '{command}'. DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");
				return true;
			}

			return false;
		}

		private bool TryExecuteStartPolling(string command)
		{
			GlobalExecutionState = ExecutionState.PollActivationPending;
			ForceLog($"Processing command - {AutomationExecutionCommands.STARTPOLLING}. " +
						$"DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");

			if (IsCommandInCorrectSequence(command))
			{
				if (GlobalStore != null)
				{
					if (LogOptions.Contains(AutomationCore.LogOptions.PollEventsToAmazon))
					{
						EAP.Core.Logging.Emsure.Polling.Start();
					}

					GlobalStore.StartPolling();
					LastCommandExecuted = AutomationExecutionCommands.STARTPOLLING;
					GlobalExecutionState = ExecutionState.PollActivationCompleted;
					ForceLog($"Finished processing command - {AutomationExecutionCommands.STARTPOLLING}");
					return true;
				}
			}
			else
			{
				ForceLog(
					$"Invalid command sequence. Current command - '{command}'. " +
					$"DefaultCommandExecutionSequence - '{DefaultCommandExecutionSequence}'");
				return true;
			}

			return false;
		}

		private void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
		{
			e.Cancel = true;

			try
			{
				if (GlobalStore != null)
					GlobalStore.PerformanceLog.LogComment($"{e.SpecialKey.ToString()} received");
			}
			catch { }

			try
			{
				AutomationClient.ForceLog("Cancel break received", LogLevel.Warn);
				OnAutomationStopped?.Invoke();
			}
			catch { }
		}

		private void CurrentDomain_ProcessExit(object sender, EventArgs e)
		{
			try
			{
				ForceLog("CurrentDomain_ProcessExit invoked");
				OnAutomationStopped?.Invoke();
			}
			catch { }
		}

		public async Task InitializeUcdp()
		{
			var publicationRegion = ReutersConfig
				.Schedule
				.Deployment
				.PublicationRegion;

			var regionEndpoint = await EndpointSelector.GetPublicationEndpointAsync(
                ReutersConfig.Global.AwsRegion,
				publicationRegion);

			UcdpManager = new(regionEndpoint);

			bool bConnected = await UcdpManager.InitializeWithForeverRetry(ReutersConfig.Global);
			if (!bConnected)
			{
				ReutersLog("UcdpManager couldn't initialize or not connected", LogLevel.Error);
			}
		}

		/// <summary>
		/// Stops the automation execution.
		/// </summary>
		/// <remarks>
		/// Calls GlobalStore.StopPolling method to stop all sources. Incomplete polls of the source may be continue running.
		/// Executes Disconnect method of all the PublicationClients. It will then wait for 2 minutes to let all threads stop automatically. After that
		/// GlobalStore.PerformExit method will be executed to process final operations.
		/// </remarks>
		public virtual void StopAutomation()
		{
			ForceLog("Processing command - Stop");

			if (GlobalStore != null)
			{
				GlobalStore.StopPolling();
			}

			ForceLog("Wait till all threads are completed OR 20 seconds whichever triggers first");
			DateTime OperationStartTime = DateTime.UtcNow;

			try
			{
				while (true)
				{
					//checking if all threads are terminated.
					System.Threading.Thread.Sleep(1000);
					if (GlobalStore == null || GlobalStore.LivePollCount <= 1)
					{
						ForceLog("All threads are completed.");
						break;
					}

					//checking if 2 minutes are elapsed
					TimeSpan TimeSpan = DateTime.UtcNow - OperationStartTime;
					if (TimeSpan.TotalSeconds > 20)
					{
						ForceLog("20 seconds elapsed, exiting without waiting for all threads to terminate.");
						break;
					}
				}
			}
			catch (Exception ex) { AutomationClient.ReutersLog(ex.ToString(), NLog.LogLevel.Error); }

			if (GlobalStore != null)
			{
				GlobalStore.PerformExit();
			}

			if (AutomationClient.LogOptions.Contains(AutomationCore.LogOptions.PollEventsToAmazon))
				EAP.Core.Logging.Emsure.Polling.Stop();

			if (UcdpManager != null)
			{
				UcdpManager.Stop();
				UcdpManager = null;
			}

			ForceLog("Finished processing command - Stop");
		}

		/// <summary>
		/// Determines if command was sent in correct sequence.
		/// </summary>
		/// <remarks>
		/// Returns _true_ if command was sent in correct sequence; otherwise _false_.
		/// </remarks>
		/// <param name="Command">Command name</param>
		/// <returns>Boolean</returns>
		public bool IsCommandInCorrectSequence(string Command)
		{

			//If Command is next to LastCommandExecuted in DefaultCommandExecutionSequence Then
			//    return true;
			//Else
			//    return false;
			string sCommandToCheck = LastCommandExecuted + "," + Command;
			sCommandToCheck = sCommandToCheck.ToLower().Replace(" ", "");
			string sDefaultCommandSequence = DefaultCommandExecutionSequence.ToLower().Replace(" ", "");
			if (sDefaultCommandSequence.Contains(sCommandToCheck))
				return true;
			return false;
		}

		/// <summary>
		/// Initializes and returns an object of a child class derived from SourceStore class. This is an abstract method.
		/// </summary>
		/// <param name="config"></param>
		/// <returns>SourceStore</returns>
		public abstract SourceStore LoadSourceStore(Config config);
	}
}
