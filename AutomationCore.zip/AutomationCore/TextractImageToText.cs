using System.Collections.Generic;
using System.IO;
using System.Threading;
using EAP.FileConversion.SDK.Image.Textract;
using EAP.FileConversion.SDK.Textract.Models;

namespace AutomationCore
{
    public class TextractImageToText
	{
        private IPagedImageAsyncFileConvertor pagedImageAsyncFileConvertor;

        private TextractImageToText()
        {

        }

        public static TextractImageToText CreateSqsPagedPdfAsyncFileConvertor()
        {
            return new TextractImageToText()
            {
                pagedImageAsyncFileConvertor = new PagedImageAsyncFileConvertor(TextractFileConvertorFactory.CreateSqsPagedTextractAsyncFileConvertor())
            };
        }

        public IAsyncEnumerable<PageResponseModel> GetImageToTextObjectAsync(byte[] imageBytesBuffer, ImageType imageType, List<string> queries = null, CancellationToken cancellationToken = default)
          => pagedImageAsyncFileConvertor.ConvertAsync(new ImageToTextOptions(new TextractOptions(queries), imageType), new MemoryStream(imageBytesBuffer), cancellationToken);

        public IAsyncEnumerable<PageResponseModel> GetImageToTextObjectAsync(Stream imageContentStream, ImageType imageType, List<string> queries = null, CancellationToken cancellationToken = default)
           => pagedImageAsyncFileConvertor.ConvertAsync(new ImageToTextOptions(new TextractOptions(queries), imageType), imageContentStream, cancellationToken);

        public IAsyncEnumerable<PageResponseModel> GetImageToTextObjectAsync(string imageFilePath, ImageType imageType, List<string> queries = null, CancellationToken cancellationToken = default)
           => pagedImageAsyncFileConvertor.ConvertAsync(new ImageToTextOptions(new TextractOptions(queries), imageType), imageFilePath, cancellationToken);

    }
}
