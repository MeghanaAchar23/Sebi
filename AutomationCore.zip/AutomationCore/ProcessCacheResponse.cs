namespace AutomationCore
{
	public class ProcessCacheResponse
	{
		public string LastModified { get; set; }
		public string ETag { get; set; }
		public int LastStatusCode { get; set; }
	}
}
