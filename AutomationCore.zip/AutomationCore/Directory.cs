using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace AutomationCore.IO
{
	public class Directory
	{
		public static bool Exists(string path)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.Directory.Exists(path);
			return true;
		}

		public static DirectoryInfo CreateDirectory(string path)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.Directory.CreateDirectory(path);
			return default(DirectoryInfo);
		}

		public static string[] GetFiles(string path)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.Directory.GetFiles(path);
			return new string[] { };
		}

		public static string[] GetFiles(string path, string searchPattern)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.Directory.GetFiles(path, searchPattern);
			return new string[] { };
		}

		public static string[] GetFiles(string path, string searchPattern, SearchOption searchOption)
		{
			if (path.ToLower().StartsWith("/tmp/"))
				return System.IO.Directory.GetFiles(path, searchPattern, searchOption);
			return new string[] { };
		}
	}
}
