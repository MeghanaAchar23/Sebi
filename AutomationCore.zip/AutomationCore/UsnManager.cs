using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationCore
{
	class UsnManager
	{
		public static string GetUsnId()
		{
			return GetUsnId(false);
		}

		public static string GetUsnId(bool withDelay)
		{
			string sUsnId = "";
			if (withDelay)
				System.Threading.Thread.Sleep(100);
			int iUsnBaseNumber = Convert.ToInt32(DateTime.UtcNow.ToString("ddHHmmssf"));
			ConvertNumberToBase36(iUsnBaseNumber, ref sUsnId);
			return sUsnId;
		}

		private static void ConvertNumberToBase36(int iNum, ref string sBase36Number)
		{
			sBase36Number = "";
			if (iNum >= 2147483647 || iNum <= -2147483646)
				return;

			string sChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			int iBaseType = 36;
			int iRadix;

			while (iNum >= iBaseType)
			{
				iRadix = iNum % iBaseType;
				sBase36Number = sChars[iRadix] + sBase36Number;
				iNum = iNum / iBaseType;
			}

			sBase36Number = sChars[iNum] + sBase36Number;

			if (sBase36Number.Length > 6)
				return;

			sBase36Number = sBase36Number.PadLeft(6, '0');
		}
	}
}
