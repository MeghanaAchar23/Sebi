using EAP.FileConversion.Service.Client;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.IO;
using FCSClient = EAP.FileConversion.Service.Client;
using LazyCache;
using System.Threading.Tasks;
using System.Threading;

namespace AutomationCore
{
	/// <summary>
	/// ExcelConnectionString Enumeration
	/// </summary>
	public enum ExcelConnectionString
	{
		/// <summary>
		/// Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=No;IMEX=1'
		/// IMEX=1 is safe way to retrieve data from mixed data colmns
		/// It will provide coumn header even though HRD=No in case Data column is numeric, Date, etc
		/// </summary>
		ACE12Excel8IMEX1,

		/// <summary>
		/// Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=No;IMEX=0'
		/// IMEX=0 retrieve data accoding to type of data colmns.
		/// For example it will not give text if data column is numeric or Date.
		/// 
		/// This connection string  will not give header in case  data type is numeric/date/time/Timestamp/etc and header contains Text.
		/// </summary>
		ACE12Excel8IMEX0,

		/// <summary>
		/// Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0;HDR=No;IMEX=1'
		/// IMEX=1 is safe way to retrieve data from mixed data colmns
		/// It will provide coumn header even though HRD=No in case Data column is numeric/Date/Time/TimeStamp etc
		/// </summary>
		ACE12Excel12IMEX1,

		/// <summary>
		/// Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0;HDR=No;IMEX=0'
		/// IMEX=0 retrieve data accoding to type of data colmns.
		/// For example it will not give text if data column is numeric or Date.
		/// 
		/// This connection string  will not give header in case  data type is numeric/date/time/Timestamp/etc and header contains Text.
		/// </summary>
		ACE12Excel12IMEX0,

		/// <summary>
		/// Excel file type ODS
		/// </summary>
		ExcelTypeODS,

	}
	public class ExcelToText
	{
		private readonly Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory;

		/// <summary>
		/// Retry count to call each web service: Default value is 5.
		/// </summary>
		public int RetryCount { get; set; } = 5;
		/// <summary>
		/// Timed out in seconds to call web service, default value is 30 seconds.
		/// </summary>
		public int TimedOutInSeconds { get; set; } = 30;

		public ExcelConnectionString enumExcelConncetionString = ExcelConnectionString.ACE12Excel12IMEX1;
		public string sFileExtension { get; set; } = ".xls";
		public string sColumnSeparator { get; set; } = "\t";
		public string sRowSeparator { get; set; } = "\r\n";
		public string sExcelSheetName { get; set; } = "";

		public string SetCultureDateTimeFormat_ShortDatePattern { get; set; } = null;
		public string SetCultureDateTimeFormat_LongDatePattern { get; set; } = null;
		public string SetCultureDateTimeFormat_ShortTimePattern { get; set; } = null;
		public string SetCultureDateTimeFormat_LongTimePattern { get; set; } = null;
		public string SetCultureDateTimeFormat_DateSeparator { get; set; } = null;
		public string SetCultureDateTimeFormat_TimeSeparator { get; set; } = null;
		public string SetCultureDateTimeFormat_FullDateTimePattern { get; set; } = null;

		/// <summary>
		/// Creates an instance of ExcelToText that uses an in-memory cache for the conversion results.
		/// </summary>
		/// <param name="ttlInSeconds">This parameter controls the time to live in the cache.</param>
		public ExcelToText(int ttlInSeconds = 24 * 3600)
		{
			this.fileConversionServiceClientFactory = FileConversionServiceClientFactory.CreateDefaultFactory(ttlInSeconds, TimedOutInSeconds, RetryCount);
		}

		public ExcelToText(Func<Task<IFileConversionServiceClient>> fileConversionServiceClientFactory)
		{
			this.fileConversionServiceClientFactory = fileConversionServiceClientFactory ?? throw new ArgumentNullException(nameof(fileConversionServiceClientFactory));
		}

		#region ExcelToText Methods
		/// <summary>
		///  Excel To Text of particular Excel Sheet using enum ExcelConnectionString as well as User defined Column or Row Separator
		/// </summary>
		/// <param name="excelBuffer">Excel file buffer</param>
		/// <param name="sExcelSheetName">Excel Sheet Name</param>      
		/// <param name="sColumnSeparator">Column Separator in Excel File</param>
		/// <param name="sRowSeparator">Row Separator in Excel File</param>
		/// <param name="enumExcelConncetionString">Excel Connection string passed through enum ExcelConnectionString</param>
		/// <param name="sConvertedText">Converted Text</param>
		/// <param name="sErrorlog">Error occured when converting into Text</param>                
		/// <returns>True or False</returns>		
		public bool GetExcelToText(byte[] excelBuffer, string sExcelSheetName, string sColumnSeparator, string sRowSeparator, ExcelConnectionString enumExcelConncetionString, out string sConvertedText, out string sErrorlog)
		{
			this.sColumnSeparator = sColumnSeparator;
			this.sRowSeparator = sRowSeparator;
			this.sExcelSheetName = sExcelSheetName;
			this.enumExcelConncetionString = enumExcelConncetionString;
			sConvertedText = sErrorlog = "";
			return GetExcelToText(excelBuffer, out sConvertedText, out sErrorlog);
		}

		/// <summary>
		/// Excel To Text of particular Excel Sheet using enum ExcelConnectionString(Column Seprator=\t, Row Seprator=\r\n)
		/// </summary>
		/// <param name="excelBuffer">Excel file buffer</param>
		/// <param name="sExcelSheetName">Excel Sheet Name</param>      
		/// <param name="enumExcelConncetionString">Excel Connection string passed through enum ExcelConnectionString</param>
		/// <param name="sConvertedText">Converted Text</param>
		/// <param name="sErrorlog">Error occured when converting into Text</param>               
		/// <returns>True or False</returns>		
		public bool GetExcelToText(byte[] excelBuffer, string sExcelSheetName, ExcelConnectionString enumExcelConncetionString, out string sConvertedText, out string sErrorlog)
		{
			sColumnSeparator = "\t";
			sRowSeparator = "\r\n";
			this.sExcelSheetName = sExcelSheetName;
			this.enumExcelConncetionString = enumExcelConncetionString;
			sConvertedText = sErrorlog = "";
			return GetExcelToText(excelBuffer, out sConvertedText, out sErrorlog);
		}

		/// <summary>
		/// Excel To Text of whole Excel Sheet using enum ExcelConnectionString
		/// </summary>
		/// <param name="excelBuffer">Excel file buffer</param>
		/// <param name="enumExcelConncetionString">Excel Connection string passed through enum ExcelConnectionString</param>
		/// <param name="sConvertedText">Converted Text</param>
		/// <param name="sErrorlog">Error occured when converting into Text</param>                
		/// <returns>True or False</returns>		
		public bool GetExcelToText(byte[] excelBuffer, ExcelConnectionString enumExcelConncetionString, out string sConvertedText, out string sErrorlog)
		{
			sColumnSeparator = "\t";
			sRowSeparator = "\r\n";
			sExcelSheetName = "";
			this.enumExcelConncetionString = enumExcelConncetionString;
			sConvertedText = sErrorlog = "";
			return GetExcelToText(excelBuffer, out sConvertedText, out sErrorlog);
		}

		/// <summary>
		/// Excel To Text of whole Excel Sheet using enum ExcelConnectionString as well as User defined Column or Row Separator
		/// </summary>
		/// <param name="excelBuffer">Excel file buffer</param>
		/// <param name="sColumnSeparator">Column Separator in Excel File</param>
		/// <param name="sRowSeparator">Row Separator in Excel File</param>
		/// <param name="enumExcelConncetionString">Excel Connection string passed through enum ExcelConnectionString</param>
		/// <param name="sConvertedText">Converted Text</param>
		/// <param name="sErrorlog">Error occured when converting into Text</param>               
		/// <returns>True or False</returns>		
		public bool GetExcelToText(byte[] excelBuffer, string sColumnSeparator, string sRowSeparator, ExcelConnectionString enumExcelConncetionString, out string sConvertedText, out string sErrorlog)
		{
			this.sColumnSeparator = sColumnSeparator;
			this.sRowSeparator = sRowSeparator;
			sExcelSheetName = "";
			this.enumExcelConncetionString = enumExcelConncetionString;
			sConvertedText = sErrorlog = "";
			return GetExcelToText(excelBuffer, out sConvertedText, out sErrorlog);
		}

		#endregion

		public bool GetExcelToText(byte[] excelBuffer, out string sConvertedText, out string sErrorlog)
		{
			sConvertedText = sErrorlog = "";
			try
			{
				switch (enumExcelConncetionString)
				{
					case ExcelConnectionString.ExcelTypeODS:
						sConvertedText = GetExcelToTextODSAsync(new MemoryStream(excelBuffer))
							.GetAwaiter()
							.GetResult();
						break;
					default:
						sConvertedText = GetExcelToTextOleDbAsync(new MemoryStream(excelBuffer))
							.GetAwaiter()
							.GetResult();
						break;
				}
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sErrorlog) == false)
					sErrorlog += "\r\n";
				sErrorlog += ex.ToString();
			}
			return false;
		}

		public bool GetExcelToTextNPOI(byte[] excelBuffer, string sExcelFileExtension, out string sConvertedText, out string sErrorlog)
		{
			if (string.IsNullOrEmpty(sExcelFileExtension))
			{
				throw new ArgumentNullException(nameof(sExcelFileExtension));
			}

			sFileExtension = sExcelFileExtension;
			sConvertedText = sErrorlog = "";
			try
			{
				sConvertedText = GetExcelToTextNPOIAsync(new MemoryStream(excelBuffer))
					.GetAwaiter()
					.GetResult();

				return true;
			}
			catch (Exception ex)
			{
				if (string.IsNullOrWhiteSpace(sErrorlog) == false)
					sErrorlog += "\r\n";
				sErrorlog += ex.ToString();
			}

			return false;
		}

		public async Task<string> GetExcelToTextNPOIAsync(Stream excelFileStream, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("ExcelToText.GetExcelToTextNPOI started");

			FCSClient.ConnectionType connectionType = (FCSClient.ConnectionType)(int)enumExcelConncetionString;
			FCSClient.NPOIExcelToTextOptions defaultTemplate = new();

			var client = await fileConversionServiceClientFactory();

			string text = await client.ConvertExcelViaNPOIAsync(excelFileStream,
				new FCSClient.NPOIExcelToTextOptions()
				{
					RowSeparator = string.IsNullOrEmpty(sRowSeparator) ? defaultTemplate.RowSeparator : sRowSeparator,
					ColumnSeparator = string.IsNullOrEmpty(sColumnSeparator) ? defaultTemplate.ColumnSeparator : sColumnSeparator,
					SheetsToConvert = string.IsNullOrEmpty(sExcelSheetName) ? null : new List<string> { sExcelSheetName }
				},
				cancellationToken);

			AutomationClient.ForceLog("ExcelToText.GetExcelToTextNPOI finished");

			return text;
		}

		public async Task<string> GetExcelToTextODSAsync(Stream excelFileStream, CancellationToken cancellationToken = default)
		{
			AutomationClient.ForceLog("ExcelToText.GetExcelToTextODS started");

			FCSClient.ConnectionType connectionType = (FCSClient.ConnectionType)(int)enumExcelConncetionString;
			FCSClient.ODSExcelToTextOptions defaultTemplate = new();

			var client = await fileConversionServiceClientFactory();

			string text = await client.ConvertExcelViaODSAsync(excelFileStream,
				new FCSClient.ODSExcelToTextOptions
				{
					RowSeparator = string.IsNullOrEmpty(sRowSeparator) ? defaultTemplate.RowSeparator : sRowSeparator,
					ColumnSeparator = string.IsNullOrEmpty(sColumnSeparator) ? defaultTemplate.ColumnSeparator : sColumnSeparator,
					SheetsToConvert = string.IsNullOrEmpty(sExcelSheetName) ? null : new List<string> { sExcelSheetName }
				},
				cancellationToken);

			AutomationClient.ForceLog("ExcelToText.GetExcelToTextODS finished");

			return text;
		}

		public async Task<string> GetExcelToTextOleDbAsync(Stream excelFileStream, CancellationToken cancellationToken = default)
		{
			if (enumExcelConncetionString == ExcelConnectionString.ExcelTypeODS)
			{
				throw new NotSupportedException("For ExcelTypeODS use GetExcelToTextODS method");
			}

			FCSClient.ConnectionType connectionType = (FCSClient.ConnectionType)(int)enumExcelConncetionString;
			FCSClient.OleDbExcelToTextOptions defaultOptionsTemplate = new(connectionType);
			FCSClient.ExcelCultureSettings defaultCultureSettingsTemplate = new();

			var client = await fileConversionServiceClientFactory();

			AutomationClient.ForceLog("ExcelToText.GetExcelToTextAsync started");

			string text = await client.ConvertExcelViaOleDbAsync(excelFileStream,
				new FCSClient.OleDbExcelToTextOptions(connectionType)
				{
					RowSeparator = string.IsNullOrEmpty(sRowSeparator) ? defaultOptionsTemplate.RowSeparator : sRowSeparator,
					ColumnSeparator = string.IsNullOrEmpty(sColumnSeparator) ? defaultOptionsTemplate.ColumnSeparator : sColumnSeparator,
					SheetsToConvert = string.IsNullOrEmpty(sExcelSheetName) ? null : new List<string> { sExcelSheetName }
				},
				new FCSClient.ExcelCultureSettings
				{
					ShortDatePattern = string.IsNullOrEmpty(SetCultureDateTimeFormat_ShortDatePattern) ? defaultCultureSettingsTemplate.ShortDatePattern : SetCultureDateTimeFormat_ShortDatePattern,
					LongDatePattern = string.IsNullOrEmpty(SetCultureDateTimeFormat_LongDatePattern) ? defaultCultureSettingsTemplate.LongDatePattern : SetCultureDateTimeFormat_LongDatePattern,
					ShortTimePattern = string.IsNullOrEmpty(SetCultureDateTimeFormat_ShortTimePattern) ? defaultCultureSettingsTemplate.ShortTimePattern : SetCultureDateTimeFormat_ShortTimePattern,
					LongTimePattern = string.IsNullOrEmpty(SetCultureDateTimeFormat_LongTimePattern) ? defaultCultureSettingsTemplate.LongTimePattern : SetCultureDateTimeFormat_LongTimePattern,
					DateSeparator = string.IsNullOrEmpty(SetCultureDateTimeFormat_DateSeparator) ? defaultCultureSettingsTemplate.DateSeparator : SetCultureDateTimeFormat_DateSeparator,
					TimeSeparator = string.IsNullOrEmpty(SetCultureDateTimeFormat_TimeSeparator) ? defaultCultureSettingsTemplate.TimeSeparator : SetCultureDateTimeFormat_TimeSeparator,
					FullDateTimePattern = string.IsNullOrEmpty(SetCultureDateTimeFormat_FullDateTimePattern) ? defaultCultureSettingsTemplate.FullDateTimePattern : SetCultureDateTimeFormat_FullDateTimePattern
				},
				cancellationToken);

			AutomationClient.ForceLog("ExcelToText.GetExcelToTextAsync finished");

			return text;
		}
	}
}
