namespace AutomationCore
{
	public abstract class FolderSource : Source
	{
		public FolderSource()
			: base()
		{
			PollManager = new EapEmailPollManager(this);
		}

		public FolderSource(PollManager oPollManager)
			: base()
		{
			PollManager = oPollManager;
		}

		public string Path
		{
			get;
			set;
		}

		public string Filter
		{
			get;
			set;
		}

		public override bool LoadHistory()
		{
			return OnHistoryLoaded();
		}

		public override bool OnHistoryLoaded()
		{
			return true;
		}

		public override string GetResource()
		{
			return Path;
		}

		public abstract void OnNewFileFound(FolderPollStatus oFolderPollStatus);
	}
}
