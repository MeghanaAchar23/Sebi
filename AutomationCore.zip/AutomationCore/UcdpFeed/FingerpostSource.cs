using EAP.Feed.Client.Models;

namespace AutomationCore.UcdpFeed
{
	public abstract class FingerpostSource : UcdpBasedSource
	{
		protected FingerpostSource()
		{
			PollManager = new FingerpostPollManager(this);
		}

		public abstract void OnNewMessageReceived(FingerpostPollStatus pollStatus);
	}

	public class FingerpostPollStatus : PollStatus
	{
		public FingerpostSource Source
		{
			get => (FingerpostSource)BaseSource;
			set => BaseSource = value;
		}

		public RawFeedMessage Message { get; set; }
	}
}
