using EAP.Feed.Client.Models;

namespace AutomationCore.UcdpFeed
{
	public abstract class UcdpSource : UcdpBasedSource
	{
		protected UcdpSource()
		{
			PollManager = new UcdpFeedPollManager(this);
		}

		public abstract void OnNewMessageReceived(UcdpFeedPollStatus pollStatus);
	}

	public class UcdpFeedPollStatus : PollStatus
	{
		public UcdpSource Source
		{
			get => (UcdpSource)BaseSource;
			set => BaseSource = value;
		}

		public UcdpFeedMessage<object> Message { get; set; }
	}
}
