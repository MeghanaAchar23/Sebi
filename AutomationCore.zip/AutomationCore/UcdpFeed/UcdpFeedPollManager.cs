using System;
using EAP.Feed.Client;

namespace AutomationCore.UcdpFeed
{
	public class UcdpFeedPollManager : UcdpPollManager
	{
		public UcdpFeedPollManager(Source oSource) : base(oSource)
		{ }

		private UcdpSource UcdpSource => (UcdpSource)Source;

		protected override IDisposable CreateSubscription(IFeedReceiverFactory feedReceiverFactory)
		{
			var ucdpReceiver = feedReceiverFactory.UcdpFeedReceiverCreate<object>();

			return ucdpReceiver
				.MessageReceived
				.Subscribe(message =>
				{
					long _ = 0;
					OnPollStart(ref _);

					if (IsReutersPollEventsEnabled)
						EAP.Core.Logging.Emsure.Polling.Poll.Start(UcdpSource.ID, message.MessageId);

					AutomationClient.ReutersLog?.Invoke($"Ucdp feed message: {message}", LogLevel.Info);

					var pollStatus = new UcdpFeedPollStatus
					{
						Message = message,
						Source = UcdpSource,
						PollAttempt = new PollAttempt
						{
							SourceID = UcdpSource.ID
						},
						ChunkAttempt = new ChunkAttempt
						{
							SourceID = UcdpSource.ID
						}
					};

					try
					{
						UcdpSource.OnNewMessageReceived(pollStatus);
						if (IsReutersPollEventsEnabled)
						{
							EAP.Core.Logging.Emsure.Polling.Poll.Stop(UcdpSource.ID, message.MessageId);
							EAP.Core.Logging.Emsure.Polling.Poll.Complete(UcdpSource.ID, message.MessageId, 200, pollStatus.PollAttempt.ToJson());
						}
					}
					catch (Exception e)
					{
						LogError("An error occurred while parsing message by automation", e);
					}

					OnPollEnd();
				}, e =>
				{
					LogError("An error occurred while receiving message", e);
					OnPollEnd();
				});
		}
	}
}
