using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using EAP.Extensions.Authorization.AwsCognito;
using EAP.Feed.Client;
using EAP.Feed.Client.Models;
using Microsoft.Extensions.DependencyInjection;
using MimeKit;
using NLog.Extensions.Logging;

namespace AutomationCore.UcdpFeed
{
	public abstract class UcdpPollManager : PollManager, ISubscriptionManager
	{
		private readonly CancellationTokenSource _pollStoppedCts = new CancellationTokenSource();
		private IFeedClient _ucdpFeedClient;
		private IDisposable _messageSubscription;

		public UcdpPollManager(Source oSource) : base(oSource)
		{ }

		private UcdpBasedSource UcdpSource => (UcdpBasedSource)Source;

		private CancellationToken PollStoppedCancellationToken => _pollStoppedCts.Token;

		public override Task PollFunction(Source source, long pollId)
		{
			return Task.CompletedTask;
		}

		public override Task DoHistoryPoll()
		{
			return Task.CompletedTask;
		}

		public void Initialize()
		{
			var baseUrl = AutomationClient.ReutersConfig.Global.Service.UcdpFeedHandlerUrl;
			AutomationClient.ReutersLog?.Invoke($"UcdpFeedHandler url - {baseUrl}", LogLevel.Info);

			var cognitoUser = AutomationClient.ReutersConfig.CognitoUser
								?? throw new Exception("Couldn't not get auth credentials from the environment variables");

			var serviceProvider = new ServiceCollection()
				.AddUcdpFeedClient(new FeedClientOptions
				{
					BaseUrl = baseUrl,
					AutoReconnect = true,
					AuthOptions = new CognitoUserAuthOptions
					{
						ClientId = cognitoUser.ClientId,
						Password = cognitoUser.Password,
						Region = cognitoUser.Region,
						UserName = cognitoUser.Username,
						UserPoolId = cognitoUser.UserPoolId
					}
				})
				.AddLogging(x => x.AddNLog())
				.BuildServiceProvider();

			_ucdpFeedClient = serviceProvider.GetRequiredService<IFeedClient>();

			_ucdpFeedClient.Reconnected += InitializeSubscriptionsAndSayHelloAsync;

			var ucdpReceiverFactory = serviceProvider.GetRequiredService<IFeedReceiverFactory>();

			_messageSubscription = CreateSubscription(ucdpReceiverFactory);

			AutomationClient.ReutersLog?.Invoke($"{this.GetType().Name} initialized", LogLevel.Info);
		}

		public async Task StartAsync()
		{
			AutomationClient.ReutersLog?.Invoke(
				$"UcdpSourceID {UcdpSource.ID} before starting connection with UcdpFeedHandler",
				LogLevel.Info);

			await _ucdpFeedClient.StartAsync(PollStoppedCancellationToken);
			await InitializeSubscriptionsAndSayHelloAsync();
		}

		public void Stop()
		{
			AutomationClient.ReutersLog?.Invoke(
				$"UcdpSourceID {UcdpSource.ID} before stopping connection with UcdpFeedHandler",
				LogLevel.Info);

			try
			{
				if (_ucdpFeedClient != null)
				{
					_ucdpFeedClient.Reconnected -= InitializeSubscriptionsAndSayHelloAsync;
					_ucdpFeedClient.Dispose();
				}

				_messageSubscription?.Dispose();
				AutomationClient.ReutersLog?.Invoke("UcdpSourceID stopped connection with UcdpFeedHandler", LogLevel.Info);
				_pollStoppedCts.Cancel();
			}
			catch (Exception e)
			{
				AutomationClient.ReutersLog?.Invoke(
					$"UcdpSourceID {UcdpSource.ID} could not gracefully stop. Error {e}",
					LogLevel.Warn);
			}

			Source.Store.AutomationClient.TryToStop();
		}

		protected abstract IDisposable CreateSubscription(IFeedReceiverFactory feedReceiverFactory);

		protected void LogError(string message, Exception exception) =>
				AutomationClient.ForceLog?.Invoke($"{message}. {exception}", LogLevel.Error);

		private async Task InitializeSubscriptionsAndSayHelloAsync()
		{
			AutomationClient.ReutersLog?.Invoke("UcdpSourceID initializing subscriptions", LogLevel.Info);

			var configuration = AutomationClient.ReutersConfig.Global;

			await _ucdpFeedClient.SayHelloAsync(new SayHelloModel
			{
				ClientInfo = new
				{
					configuration.Environment.AutomationId,
					configuration.Environment.AutomationName,
					configuration.Environment.AutomationVersion,
					configuration.Environment.AutomationUUID,
					configuration.Environment.ScheduleId,
					configuration.Environment.ScheduleName,
					configuration.Container.TaskARN,
					DockerContainerId = configuration.Container.ContainerID,
					DockerImage = configuration.Container.ImageName,
					Region = configuration.EC2.Region.DisplayName
				}
			}, PollStoppedCancellationToken);

			var filters = new List<ClientFeedFilter>();
			foreach (var topic in UcdpSource.TopicNames.Where(topic => !string.IsNullOrEmpty(topic)).ToArray())
			{
				var filter = new ClientFeedFilter(topic);
				if (!string.IsNullOrWhiteSpace(UcdpSource.MimeType))
				{
					filter.MimeType = UcdpSource.MimeType;
				}
				filters.Add(new ClientFeedFilter(topic));
			}

			var result = await _ucdpFeedClient.SubscribeAsync(new SubscribeCommand
			{
				Filters = filters
			}, PollStoppedCancellationToken);

			AutomationClient.ReutersLog?.Invoke($"Forbidden feed(s): {string.Join(", ", result.ForbiddenFilters.Select(x => $"{x.Key.FullTopicName} - {x.Value}"))}", LogLevel.Info);
		}
	}
}
