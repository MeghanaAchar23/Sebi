namespace AutomationCore.UcdpFeed
{
	public abstract class UcdpBasedSource : Source
	{
		public string[] TopicNames { get; set; }
		public string MimeType { get; set; }

		public void Initialize()
		{
			((UcdpPollManager)PollManager).Initialize();
		}
	}
}
