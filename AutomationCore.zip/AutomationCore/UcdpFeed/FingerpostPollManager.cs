using System;
using EAP.Feed.Client;

namespace AutomationCore.UcdpFeed
{
	public class FingerpostPollManager : UcdpPollManager
	{
		public FingerpostPollManager(Source oSource) : base(oSource)
		{ }

		private FingerpostSource FingerpostSource => (FingerpostSource)Source;

		protected override IDisposable CreateSubscription(IFeedReceiverFactory feedReceiverFactory)
		{
			var fingerpostReceiver = feedReceiverFactory.FingerpostFeedReceiverCreate();

			return fingerpostReceiver
				.MessageReceived
				.Subscribe(message =>
				{
					long _ = 0;
					OnPollStart(ref _);

					if (IsReutersPollEventsEnabled)
						EAP.Core.Logging.Emsure.Polling.Poll.Start(FingerpostSource.ID, message.Metadata.MessageId);

					AutomationClient.ReutersLog?.Invoke($"Fingerpost message: {message}", LogLevel.Info);

					var pollStatus = new FingerpostPollStatus
					{
						Message = message,
						Source = FingerpostSource,
						PollAttempt = new PollAttempt
						{
							SourceID = FingerpostSource.ID
						},
						ChunkAttempt = new ChunkAttempt
						{
							SourceID = FingerpostSource.ID
						}
					};

					try
					{
						FingerpostSource.OnNewMessageReceived(pollStatus);
						if (IsReutersPollEventsEnabled)
						{
							EAP.Core.Logging.Emsure.Polling.Poll.Stop(FingerpostSource.ID, message.Metadata.MessageId);
							EAP.Core.Logging.Emsure.Polling.Poll.Complete(FingerpostSource.ID, message.Metadata.MessageId, 200, pollStatus.PollAttempt.ToJson());
						}
					}
					catch (Exception e)
					{
						LogError("An error occurred while parsing message by automation", e);
					}

					OnPollEnd();
				}, e =>
				{
					LogError("An error occurred while receiving message", e);
					OnPollEnd();
				});
		}
	}
}
