namespace IndiaSEBI1
{
    static class Constants
    {
        public const string DEFAULT_COMMAND_EXECUTION_SEQUENCE = "loadhistory,startpolling";
        public const string TimeZone = "Asia/Kolkata";
        public const string usnApacDefaultEnglish = "USN_APAC_DEFAULT_ENGLISH";

        public const string forceFilingSwitch = "FORCE_FILING_SWITCH";
        public const string ForceFilingDate = "FORCE_FILING_DATE";
        public const string ForceFillingReleaseList = "FORCE_FILLING_URL_ALL_RELEASE_LIST";
        public const string forceFillingUrlCircularsList = "FORCE_FILLING_URL_CIRCULARS_LIST";
        public const string forceFillingUrlReportsList = "FORCE_FILLING_URL_REPORTS_LIST";
        public const string forceFillingUrlOrdersList = "FORCE_FILLING_URL_ORDERS_list";
        public const string forceFillingUrlPressReleaseList = "FORCE_FILLING_URL_PRESS_RELEASE_LIST";

        public const string REPORTS = "Reports";
        public const string CIRCULARS = "Circulars";
        public const string PRESSRELEASE = "Press Releases";
        public const string ORDERS = "Orders";

        public const string STORY = "Story";
        public const string ALERT = "Circular_Alert";

        public const string ALL_RELEASE_LIST = "ALL_RELEASE_LIST";
        public const string CIRCULARS_LIST = "CIRCULARS_LIST";
        public const string REPORTS_LIST = "REPORTS_LIST";
        public const string ORDERS_LIST = "ORDERS_list";
        public const string PRESS_RELEASE_LIST = "PRESS_RELEASE_LIST";

        public const string PRESS_RELEASE_KEYWORDS = "PRESS_RELEASE_KEYWORDS";
        public const string CIRCULAR_KEYWORDS = "CIRCULAR_KEYWORDS";
    }
}
