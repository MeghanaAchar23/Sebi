using AutomationCore;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace IndiaSEBI1
{
    public class MySourceStore : SourceStore
    {
        public DateTime RunDate;
        public string CircularKeywords = string.Empty;
        public string PressReleaseKeywords = string.Empty;
        private readonly object _lockObj = new object();

        public MySourceStore(string dllPath, Config config)
            : base(dllPath, config)
        {
        }

        public override void OnHistoryLoaded() { }
        public override void OnPollingStopped() { }

        internal void HandleAndPublish(PublicationData data, UrlPollStatus pollStatus)
        {
            if (data.Stories.Count == 0)
                return;

            foreach (var item in data.Stories)
            {
                var headlineKey = item.Headline.ToUpperInvariant();
                if (!StoreData.AllStoriesHeadlines.ContainsKey(headlineKey))
                  StoreData.AllStoriesHeadlines.Add(headlineKey, false);

                switch (item.Type)
                {
                    case Constants.CIRCULARS:
                        //PublishStory(pollStatus, item.Text, item.Headline);
                        if (!string.IsNullOrEmpty(CircularKeywords) &&
                            Regex.IsMatch(item.Headline, CircularKeywords, RegexOptions.IgnoreCase | RegexOptions.Multiline))
                        {
                            if (!StoreData.AllAlertText.ContainsKey(headlineKey))
                                StoreData.AllAlertText.Add(headlineKey, false);

                            PublishAlert(pollStatus, item.Headline);
                        }
                        else
                        {
                            AutomationClient.OperatorLog($"Circular Alert not published for {item.Headline} (keywords: {CircularKeywords.Replace(@"\W*", string.Empty)})");
                        }
                        break;

                    case Constants.PRESSRELEASE:
                        if (!string.IsNullOrEmpty(PressReleaseKeywords) &&
                            Regex.IsMatch(item.Headline, PressReleaseKeywords, RegexOptions.IgnoreCase | RegexOptions.Multiline))
                        {
                            PublishStory(pollStatus, item.Text, item.Headline);
                        }
                        else
                        {
                            AutomationClient.OperatorLog($"Press Release Alert not published for {item.Headline} (keywords: {PressReleaseKeywords.Replace(@"\W*", string.Empty)})");
                        }
                        break;

                    case Constants.REPORTS:
                    case Constants.ORDERS:
                        PublishStory(pollStatus, item.Text, item.Headline);
                        break;
                }
            }
        }

        private void PublishAlert(UrlPollStatus pollStatus, string alertText)
        {
            var alertMsg = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage(Constants.ALERT);

            if (alertMsg == null)
                return;

            alertMsg.IsSent = false;
            var alertBuilder = new StringBuilder(alertMsg.AlertTemplate);
            alertBuilder.Replace("{alert}", alertText);

            lock (_lockObj)
            {
                var key = alertText.ToUpperInvariant();
                if (!StoreData.AllAlertText[key])
                {
                    StoreData.AllAlertText[key] = alertMsg.Send(alertBuilder.ToString(), pollStatus);
                }
            }
        }

        public void PublishStory(UrlPollStatus pollStatus, string body, string headline)
        {
            var storyMsg = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage(Constants.STORY);

            if (storyMsg == null)
                return;

            storyMsg.IsSent = false;

            var headlineBuilder = new StringBuilder(storyMsg.HeadlineTemplate);
            headlineBuilder.Replace("{headline}", headline);
            headlineBuilder.Replace("Click here to provide your comments", string.Empty);

            var bodyBuilder = new StringBuilder(storyMsg.StoryTextTemplate);
            bodyBuilder.Replace("{body}", body);

            lock (_lockObj)
            {
                var key = headline.ToUpperInvariant();
                if (!StoreData.AllStoriesHeadlines[key])
                {
                    StoreData.AllStoriesHeadlines[key] = storyMsg.Send(headlineBuilder.ToString(), bodyBuilder.ToString(), pollStatus);
                }
            }
        }
    }
}