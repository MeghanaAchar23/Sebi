﻿using System.Collections.Generic;

namespace IndiaSEBI1
{
    internal static class StoreData
    {
        public static Dictionary<string, bool> AllStoriesHeadlines { get; } = new Dictionary<string, bool>();
        public static Dictionary<string, bool> AllAlertText { get; } = new Dictionary<string, bool>();
    }
}