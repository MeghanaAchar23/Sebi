﻿using HtmlAgilityPack;
using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace IndiaSEBI1
{
    internal class GeneralListExtractor
    {
        private readonly string _htmlContent;
        private readonly string[] _dateFormats = { "MMMM dd, yyyy", "MMM dd, yyyy", "MM dd, yyyy", "MMMM dd, yy", "MMM dd, yyyy" };
        private readonly string _baseUrl = @"https://www.sebi.gov.in/";

        public GeneralListExtractor(string htmlContent)
        {
            _htmlContent = htmlContent;
        }

        internal PublicationData ExtractStories(DateTime targetDate)
        {
            //targetDate = new DateTime(2025, 7, 24);
            var result = new PublicationData();
            var doc = new HtmlDocument();
            doc.LoadHtml(_htmlContent);

            var tableNode = doc.DocumentNode
                .SelectSingleNode("//div[contains(@class, 'table-scrollable')]//table");

            if (tableNode == null)
                return result;

            var headers = tableNode.Descendants("th").Select(th => th.InnerText.Trim()).ToArray();
            int titleIdx = Array.IndexOf(headers, "Title");
            int dateIdx = Array.IndexOf(headers, "Date");
            int typeIdx = Array.IndexOf(headers, "Type");

            if (titleIdx < 0 || dateIdx < 0 || typeIdx < 0)
                return result;

            var datePattern = $@"({targetDate:MMMM}|{targetDate:MMM}|{targetDate:MM}|{targetDate:M})\W*({targetDate:dd}|{targetDate:d})\W*({targetDate:yyyy}|{targetDate:yy})";

            var validRows = tableNode.Descendants("tr")
                .Select(tr => tr.Descendants("td").ToArray())
                .Where(tds => tds.Length > Math.Max(titleIdx, Math.Max(dateIdx, typeIdx)))
                .Where(tds =>
                {
                    var dateText = tds[dateIdx].InnerText.Trim();
                    var typeText = tds[typeIdx].InnerText.Trim();
                    return
                        !string.IsNullOrEmpty(dateText) &&
                        Regex.IsMatch(dateText, datePattern, RegexOptions.IgnoreCase | RegexOptions.Multiline) &&
                        new[] {
                            Constants.REPORTS,
                            Constants.CIRCULARS,
                            Constants.ORDERS,
                            Constants.PRESSRELEASE
                        }.Any(t => typeText.Equals(t, StringComparison.OrdinalIgnoreCase));
                });

            foreach (var tds in validRows)
            {
                if (DateTime.TryParseExact(tds[dateIdx].InnerText, _dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime rowDate))
                {
                    if (rowDate.Date > targetDate.Date)
                        continue;
                    if (rowDate.Date < targetDate.Date)
                        break;

                    var typeText = tds[typeIdx].InnerText.Trim();
                    var storyType = typeText switch
                    {
                        var t when t.Equals(Constants.REPORTS, StringComparison.OrdinalIgnoreCase) => Constants.REPORTS,
                        var t when t.Equals(Constants.CIRCULARS, StringComparison.OrdinalIgnoreCase) => Constants.CIRCULARS,
                        var t when t.Equals(Constants.ORDERS, StringComparison.OrdinalIgnoreCase) => Constants.ORDERS,
                        var t when t.Equals(Constants.PRESSRELEASE, StringComparison.OrdinalIgnoreCase) => Constants.PRESSRELEASE,
                        _ => null
                    };

                    if (storyType != null)
                    {
                        result.Stories.Add(BuildStory(tds, storyType, titleIdx));
                    }
                }
            }

            return result;
        }

        private Story BuildStory(HtmlNode[] tds, string type, int titleIdx)
        {
            var headlineNode = tds[titleIdx];
            var headlineText = headlineNode.InnerText.Trim();
            var storyText = GetStoryDetails(headlineNode);

            return new Story
            {
                Headline = headlineText,
                Type = type,
                Text = storyText
            };
        }

        private string GetStoryDetails(HtmlNode headlineNode)
        {
            var linkNode = headlineNode.Descendants("a").FirstOrDefault();
            var href = linkNode?.GetAttributeValue("href", string.Empty) ?? string.Empty;
            var fullUrl = !string.IsNullOrEmpty(href) ? new Uri(new Uri(_baseUrl), href).AbsoluteUri : string.Empty;

            var sb = new StringBuilder();
            sb.Append(headlineNode.InnerText.Trim());
            if (!string.IsNullOrEmpty(fullUrl))
            {
                sb.Append(" [Details: ");
                sb.Append(fullUrl);
                sb.Append("]");
            }
            sb.Replace("Click here to provide your comments", string.Empty);

            return sb.ToString().Trim();
        }
    }
}