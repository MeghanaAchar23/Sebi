﻿using AutomationCore;
using System;
using System.Text;
using TimeZoneConverter;

namespace IndiaSEBI1
{
    internal static class ConfigHelper
    {
        internal static string FormatException(Exception ex)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Exception occurred:");
            sb.AppendLine(ex.Message);
            sb.AppendLine("Stack trace:");
            sb.AppendLine(ex.StackTrace);
            return sb.ToString();
        }

        internal static string GetValue(string key, MySourceStore store)
        {
            var setting = store.Settings.GetSetting(key);
            return setting?.Value?.Trim() ?? string.Empty;
        }

        public static DateTime GetLocalTime(string tzCode)
        {
            var utcNow = DateTime.UtcNow;
            var tzInfo = TZConvert.GetTimeZoneInfo(tzCode);
            return TimeZoneInfo.ConvertTimeFromUtc(utcNow, tzInfo);
        }
    }
}
