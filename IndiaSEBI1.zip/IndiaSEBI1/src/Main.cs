using System;
using System.Globalization;
using System.Net;
using AutomationCore;

namespace IndiaSEBI1
{
    public class Main : AutomationClient
    {
        public override SourceStore LoadSourceStore(Config config)
        {
            var storeInstance = new MySourceStore(this.GetType().Assembly.Location, config);
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
                ServicePointManager.ServerCertificateValidationCallback += (_, _, _, _) => true;

                string runDateRaw = ConfigHelper.GetValue(Constants.ForceFilingDate, storeInstance);

                storeInstance.CircularKeywords = ConfigHelper.GetValue(Constants.CIRCULAR_KEYWORDS, storeInstance).Replace(" ", @"\W+");
                storeInstance.PressReleaseKeywords = ConfigHelper.GetValue(Constants.PRESS_RELEASE_KEYWORDS, storeInstance).Replace(" ", @"\W+");

                storeInstance.RunDate = !string.IsNullOrWhiteSpace(runDateRaw)
                    ? DateTime.ParseExact(runDateRaw, "dd-MM-yyyy", CultureInfo.InvariantCulture)
                    : ConfigHelper.GetLocalTime(Constants.TimeZone);

                string forceSwitch = ConfigHelper.GetValue(Constants.forceFilingSwitch, storeInstance).Trim().ToLowerInvariant();

                // Define all possible sources and their config keys
                var sourceDefinitions = new[]
                {
                    (Constants.ALL_RELEASE_LIST, typeof(GeneralList), Constants.ForceFillingReleaseList),
                    (Constants.CIRCULARS_LIST, typeof(UniqueList), Constants.forceFillingUrlCircularsList),
                    (Constants.REPORTS_LIST, typeof(UniqueList), Constants.forceFillingUrlReportsList),
                    (Constants.ORDERS_LIST, typeof(UniqueList), Constants.forceFillingUrlOrdersList),
                    (Constants.PRESS_RELEASE_LIST, typeof(UniqueList), Constants.forceFillingUrlPressReleaseList)
                };

                if (forceSwitch == "on")
                {
                    foreach (var (id, handlerType, urlKey) in sourceDefinitions)
                    {
                        string url = ConfigHelper.GetValue(urlKey, storeInstance);
                        if (!string.IsNullOrWhiteSpace(url))
                        {
                            Source source = (Source)Activator.CreateInstance(handlerType);
                            storeInstance.LoadURLSource(id, (URLSource)source); // Cast for LoadURLSource
                            ((URLSource)source).Url = url;                      // Cast for Url property
                            storeInstance.Sources.AddSource(id, ref source);    // ref Source is now valid
                        }
                    }
                }
                else
                {
                    foreach (var (id, handlerType, _) in sourceDefinitions)
                    {
                        Source source = (Source)Activator.CreateInstance(handlerType);
                        storeInstance.LoadURLSource(id, (URLSource)source);
                        storeInstance.Sources.AddSource(id, ref source);
                    }
                }

                DefaultCommandExecutionSequence = Constants.DEFAULT_COMMAND_EXECUTION_SEQUENCE;
            }
            
            catch (Exception ex)
            {
                storeInstance.PerformanceLog.LogError(ConfigHelper.FormatException(ex));
            }

            return storeInstance;
        }

        
    }
}