using AutomationCore;
using System;

namespace IndiaSEBI1
{
    public class GeneralList : URLSource
    {
        public override void OnDataReceived(UrlPollStatus pollStatus)
        {
            if (!pollStatus.IsRequestCompleted)
                return;

            var storeRef = (MySourceStore)Store;

            if (!string.IsNullOrWhiteSpace(pollStatus.ContentString))
            {
                try
                {
                    var extractor = new GeneralListExtractor(pollStatus.ContentString);
                    var extractedData = extractor.ExtractStories(storeRef.RunDate);

                    if (extractedData.Stories.Count > 0)
                    {
                        storeRef.HandleAndPublish(extractedData, pollStatus);
                    }
                    else
                    {
                        pollStatus.ChunkAttempt.LogComment($"No stories found for {pollStatus.Source.Url}");
                    }
                }
                catch (Exception ex)
                {
                    Store.AutomationClient.OperatorLog(ConfigHelper.FormatException(ex));
                }
            }
        }
    }
}