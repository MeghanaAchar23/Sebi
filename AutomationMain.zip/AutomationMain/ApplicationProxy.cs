using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using AutomationCore;
using EAP.Core.Configuration;

namespace AutomationMainDll
{
	/// <summary>
	/// Provides proxy class for getting AutomationClient object from the automation dll using reflection.
	/// </summary>
	public class ApplicationProxy
	{
		/// <summary>
		/// Creates an instance of the AutomationClient class by dynamically loading the dll file.
		/// </summary>
		/// <remarks>
		/// Automation dll must have the class `Main` which inherits AutomationClient class. This method will load the automation dll assembly as specified in `assemblyFile` and try to create the instance of the `Main` class from the automation dll assembly and return it as an object of base class `AutomationClient`.
		/// </remarks>
		/// <returns>AutomationClient</returns>
		public AutomationClient GetAutomationClient(string assemblyFile)
		{
			/*Assembly oAssembly = Assembly.Load(new AssemblyName()
			{
				CodeBase = assemblyFile
			});*/
			Assembly oAssembly = Assembly.LoadFrom(assemblyFile);

			object oMain = null;
			Type t = null;
			foreach (Type type in oAssembly.GetTypes())
			{
				if (type.IsClass)
				{
					if (type.FullName.EndsWith(".Main"))
					{
						t = type;
						oMain = Activator.CreateInstance(type);
						return (AutomationClient)oMain;
					}
				}
			}
			return null;
		}
	}
}

