using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomationMainDll
{
	public class AutomationExactPolls
	{
		public string AutomationName { get; set; }
		public List<UrlPollLog> Urls { get; set; }
		public DateTime TimePostedToAspx { get; set; }

		public AutomationExactPolls()
		{
			Urls = new List<UrlPollLog>();
		}
	}

	public class UrlPollLog
	{
		public string SourceId { get; set; }
		public string Url { get; set; }
		public int PollFrequency { get; set; }
		public DateTime FirstPollStartTime { get; set; }
		public DateTime LatestPollStartTime { get; set; }
		public long NumberOfPollsAttempted { get; set; }
		public long NumberOfPollsMade { get; set; }
	}
}
