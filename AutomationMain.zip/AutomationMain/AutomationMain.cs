using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutomationCore;
using System.IO;
using System.Timers;
using System.Net;
using System.Runtime.Serialization;
using Newtonsoft.Json.Linq;
using EAP.Core.Configuration;
using EAP.Core.Logging;
using System.Threading.Tasks;

namespace AutomationMainDll
{
	/// <summary>
	/// Works as an entry point to the automation. Inherits AutomationBase class of UniversalSpider.AutomationLibrary.
	/// </summary>
	/// <remarks>
	/// BaseCoreBridge class works as an entry point to the automation. This class inherits AutomationBase class of UniversalSpider.AutomationLibrary which provides basic functions to override and execute commands.
	/// Overrides AutomationMain method which sends and executes commands sent from AutomationController or Spider Controller. Overrides AutomationStop method which stops the automation and indicates the UniversalSpider to stop execution.
	/// </remarks>
	public class BaseCoreBridge
	{
		AutomationClient client;
		public AutomationStoppedDelegate OnAutomationStopped;
		public AutomationConfiguration AutomationConfiguration;

		Timer _timer;
		Timer _exactPollsTimer;
		Timer _passTimer;

		public string AutomationName { get; set; }
		public string HostName { get; set; }
		public string Xml { get; set; }
		public string PathToDll { get; set; }
		public bool IsLogEnabled { get; set; } = true;

		object m_syncLock = new object();
		object m_syncLock2 = new object();

		int passTimerInterval = 30000;

		EapLogger _logger;

		/// <summary>
		/// Initializes a new instance of BaseCoreBridge class.
		/// </summary>
		public BaseCoreBridge(AutomationConfiguration automationConfiguration)
		{
			AutomationConfiguration = automationConfiguration;
			AutomationClient.ReutersConfig = AutomationConfiguration;

			AutomationClient.ForceLog += new OperatorLogDelegate(Log);

			AutomationClient.ReutersLogEvents += new OperatorLogEventsDelegate(LogEvents);

			_logger = EapLogger.GetLogger();

			try
			{
				AutomationClient.IsLogEnabled = true;

                AutomationClient.LogOptions = new List<string> {
                    LogOptions.OperatorLogToAmazon,
                    LogOptions.LibraryInternalLogToAmazon,
                    LogOptions.LogCommentToAmazon,
                    LogOptions.LogWorkflowConfigToAmazon,
                    LogOptions.PerformanceLogToAmazon,
                    LogOptions.PollEventsToAmazon,
                    LogOptions.PublicationGeneratedLogToAmazon };


                if (AutomationClient.LogOptions.Contains(LogOptions.LibraryInternalLogToAmazon))
					AutomationClient.ReutersLog += new OperatorLogDelegate(Log);
				else
					AutomationClient.ReutersLog += new OperatorLogDelegate(EmptyLog);
			}
			catch { }
		}

		public void EmptyLog(string log, params object[] args)
		{

		}

		public void Log(string log, params object[] args)
		{
			if (!IsLogEnabled)
				return;
			NLog.LogLevel level = NLog.LogLevel.Info;
			if (args != null && args.Length > 0 && args[0] is NLog.LogLevel)
				level = args[0] as NLog.LogLevel;

			_logger.Log(level, log);
		}

		public void LogEvents(NLog.LogLevel level, string message, string json)
		{
			if (!IsLogEnabled)
				return;

			_logger.LogEvents(level, message, json);
		}

		public void AmazonOperatorLog(string log, params object[] args)
		{
			if (!IsLogEnabled)
				return;

			Log(log, args);
		}

		public void EmSureOperatorLog(string log, params object[] args)
		{

		}

		/// <summary>
		/// Specifies a method to execute commands to the automation.
		/// </summary>
		/// <remarks>
		/// Remarks
		/// =======
		/// AutomationMain method is overriden from UniversalSpider.AutomationLibrary.AutomationBase class. The method provides the xmlConfiguration sent from the AutomationController or Spider Controller.
		/// This method will validate the xml against the library version provided and dll version, automation will not continue if they are not matched.
		/// It will then get the reference to `client` object of AutomationClient class from the library using AutomationProxy.GetAutomationClient method and executes the ExecuteCommand method of the object.
		/// </remarks>
		/// <param name="xmlConfiguration"></param>
		public async Task AutomationMain(string xmlConfiguration)
		{
			/*
				* Load the XMl Configuration from what was hosted in the textbox.
				* It will look for the root element as <host> then extract children of it
				*/

			var jDoc = JObject.Parse(xmlConfiguration);

			string sCommand = Utils.GetSingleValue(jDoc, "$.command").Trim().ToLower();

			string sAutomationLibVersion = Utils.GetSingleValue(jDoc, "$.global_execution_parameters.spider_library_version").Trim();

			{
				if (string.IsNullOrWhiteSpace(sCommand) || (sCommand != "initialize" && client == null))
				{
					Log($"Invalid command sequence. Current command - '{sCommand}'.", LogLevel.Error);
					return;
				}

				if (sCommand == "initialize" && client != null)
				{
					Log($"Invalid command sequence. Current command - '{sCommand}'. Automation is already initialized.",
						NLog.LogLevel.Error);
					return;
				}

				if (sCommand == "initialize")
				{
					if (string.IsNullOrWhiteSpace(PathToDll))
					{
						Log("PathToDll is missing/empty.", NLog.LogLevel.Error);
						return;
					}

					if (string.IsNullOrWhiteSpace(sAutomationLibVersion))
					{
						Log("library version is missing/empty.", NLog.LogLevel.Error);
						return;
					}

					string sDllFullName = PathToDll;

					ApplicationProxy proxy = new ApplicationProxy();
					client = proxy.GetAutomationClient(sDllFullName);

					if (AutomationClient.LogOptions.Contains(LogOptions.OperatorLogToAmazon))
						client.OperatorLog += new OperatorLogDelegate(AmazonOperatorLog);
					if (AutomationClient.LogOptions.Contains(LogOptions.OperatorLogToEmSure))
						client.OperatorLog += new OperatorLogDelegate(EmSureOperatorLog);

					if (client.OperatorLog == null)
						client.OperatorLog += new OperatorLogDelegate(EmptyLog);

					client.IsLoadedFromController = true;

					if (OnAutomationStopped != null)
						client.OnAutomationStopped += OnAutomationStopped;

					await client.ExecuteCommand(xmlConfiguration);
				}
				else
				{
					if (sCommand == AutomationExecutionCommands.STARTPOLLING)
					{
						if (client.GlobalStore != null)
						{
							if (!client.GlobalStore.Sources.GetAllActiveSources().Any(s => s.DefaultPollIntervalInMS < 30000) && _passTimer == null)
							{
								_passTimer = new Timer(passTimerInterval);
								_passTimer.Elapsed += _passTimer_Elapsed;
								_passTimer.Start();
							}
						}
					}

					await client.ExecuteCommand(xmlConfiguration);
				}
			}
		}

		private void _passTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			AutomationClient.ReutersConfig.SetAutomationState(new AutomationState("Polling", AutomationState.state.Pass));
		}

		void _exactPollsTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (_exactPollsTimer != null)
				_exactPollsTimer.Stop();

			lock (m_syncLock2)
			{
				PostPollLog();
			}

			if (_exactPollsTimer != null)
				_exactPollsTimer.Start();
		}

		void _timer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (_timer != null)
				_timer.Stop();

			lock (m_syncLock)
			{
				PostConfig();
			}

			if (_timer != null)
				_timer.Start();
		}

		void PostConfig()
		{
			if (string.IsNullOrWhiteSpace(AutomationName) || string.IsNullOrWhiteSpace(HostName) || string.IsNullOrWhiteSpace(Xml))
				return;
			try
			{
				//TODO: Get POST_XML_URL from config
				string sPostUrl = "";// System.Configuration.ConfigurationManager.AppSettings["POST_XML_URL"] ?? "";
				if (string.IsNullOrWhiteSpace(sPostUrl))
					return;
				using (WebClient webClient = new WebClient())
				{
					string sPostData = Xml;
					webClient.Headers[HttpRequestHeader.ContentType] = "application/xml";
					var response = webClient.UploadData(new Uri(sPostUrl), "POST", Encoding.UTF8.GetBytes(sPostData));
				}
			}
			catch (Exception ex)
			{
				Log("ERROR POST XML -> " + ex.ToString(), NLog.LogLevel.Error);
			}
		}

		void PostPollLog()
		{
			try
			{
				if (client != null && client.GlobalStore != null)
				{
					var store = client.GlobalStore;
					if (store.Sources != null)
					{
						var sources = store.Sources.GetAllSources().Where(s => s is URLSource && s.StartDateTime != DateTime.MinValue).Select(x => x).ToList();
						if (sources.Any())
						{
							try
							{
								//TODO: Get POST_EXACT_POLL_LOG_URL from config
								string sPostUrl = ""; // System.Configuration.ConfigurationManager.AppSettings["POST_EXACT_POLL_LOG_URL"] ?? "";
								if (string.IsNullOrWhiteSpace(sPostUrl))
									return;
								using (WebClient webClient = new WebClient())
								{
									byte[] byPostData = GetExactPollLog(sources);
									if (byPostData != null)
									{
										webClient.Headers[HttpRequestHeader.ContentType] = "application/xml";
										var response = webClient.UploadData(new Uri(sPostUrl), "POST", byPostData);
									}
								}
							}
							catch (Exception ex)
							{
								Log("ERROR EXACT LOG -> " + ex.ToString(), NLog.LogLevel.Error);
							}

						}
					}

				}
			}
			catch { }
		}

		private byte[] GetExactPollLog(List<Source> sources)
		{
			try
			{
				if (sources == null)
					return null;
				var urlLog = sources.Select(s => new UrlPollLog { SourceId = s.ID, Url = (s as URLSource).Url, PollFrequency = s.RandomIntervalRangeStart > 0 ? s.RandomIntervalRangeStart : s.CurrentPollIntervalInMS, FirstPollStartTime = s.StartDateTime, LatestPollStartTime = s.LatestPollDateTime, NumberOfPollsAttempted = s.PollAttemptCount, NumberOfPollsMade = s.ActualPollCount });
				var log = new AutomationExactPolls { AutomationName = AutomationName, Urls = urlLog.ToList(), TimePostedToAspx = DateTime.UtcNow };
				MemoryStream mStream = new MemoryStream();

				DataContractSerializer Serializer = new DataContractSerializer(typeof(AutomationExactPolls));
				Serializer.WriteObject(mStream, log);
				return mStream.ToArray();
			}
			catch (Exception ex) { Log(ex.ToString(), NLog.LogLevel.Error); }
			return null;
		}

		/// <summary>
		///  Executes StopAutomation of `client` object.
		/// </summary>
		/// <remarks>
		/// Overrides AutomationStop method of AutomationBase class of UniversalSpider.AutomationLibrary.
		/// </remarks>
		public void AutomationStop()
		{
			if (client == null)
			{
				Log("Invalid command sequence.", NLog.LogLevel.Error);
			}
			else
			{
				client.StopAutomation();

			}
		}

		public void StopPassTimer()
		{
			try
			{
				if (_passTimer != null)
				{
					_passTimer.Stop();
					_passTimer.Dispose();
					_passTimer = null;
				}
			}
			catch { }
		}
	}
}
