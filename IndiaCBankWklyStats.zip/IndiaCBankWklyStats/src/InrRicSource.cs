﻿using AutomationCore.Idn;
using System.Linq;

namespace IndiaCBankWklyStats
{
  public class InrRicSource : IdnSource
  {
    public override void OnDataReceived(IdnPollStatus pollStatus)
    {
      if (pollStatus?.Result?.FirstOrDefault()?.Data?.Values == null)
      {
        return;
      }

      if (pollStatus.Result.First().Data.TryGetDouble(pollStatus.Source.Fields.FirstOrDefault(), out double result))
      {
        var store = (MySourceStore)Store;

        lock (store.locker)
        {
          store.strCurrencyValue = result.ToString();
        }

        pollStatus.ChunkAttempt.LogComment($"Currency value was received: {store.strCurrencyValue}");
      }
    }

    public override bool OnHistoryLoaded()
    {

      return true;
    }
  }
}
