﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndiaCBankWklyStats.LLM
{
	public class AlertDetailsFromLLM
	{
		public string CentralGovtOutstandingLoans { get; set; }
		public string LatestDateLiabilitiesAssets { get; set; }
		public string BankCreditGrowthPercent { get; set; }
		public string BankCreditOutstandingAsofDate { get; set; }
		public string AggregateDepositsGrowthPercent { get; set; }
		public string AggregateDeopositsOutstandingAsofDate { get; set; }
		public string TotalForexReserves { get; set; }
		public string TotalForexReservesDate { get; set; }
		public string TotalSalesUnderOMO { get; set; }
		public string TotalPurchaseUnderOMO { get; set; }
		public string TotalSalesPurchaseAsOfDate { get; set; }
		public List<OMOOutright> OMOOutrights { get; set; }
		public List<GrowthPercent> GrowthPercent { get; set; }
	}

	public class JsonContent
	{
		public string JsonCentralGovtOutstandingLoans { get; set; }
		public string JsonLatestDateLiabilitiesAssets { get; set; }
		public string JsonBankCreditGrowthPercent { get; set; }
		public string JsonBankCreditOutstandingAsofDate { get; set; }
		public string JsonAggregateDepositsGrowthPercent { get; set; }
		public string JsonAggregateDeopositsOutstandingAsofDate { get; set; }
		public List<OMOOutright> OMOOutrights { get; set; }
		public List<GrowthPercent> GrowthPercent { get; set; }
	}

	public class OMOOutright
	{
		public string SalesUnderOMO { get; set; }
		public string PurchaseUnderOMO { get; set; }
		public string LastestPurchaseAsOfDate { get; set; }
	}

	public class GrowthPercent
	{
		public string BankCredit { get; set; }
		public string AggregateDeposit { get; set; }
	}
}
