﻿using AutomationCore;
using AutomationCore.Handbrake;
using Nest;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using String = System.String;

namespace IndiaCBankWklyStats.LLM
{
	public class LlmSourceStore
	{
		public object objLlmLock = new object();
		MySourceStore Store;
		UrlPollStatus oUrlPollStatus;
		NEWSource NEWSource = new NEWSource();
		Global global = new Global();

		public void LlmAlertTemplate(AlertDetailsFromLLM alertDetailsFromLLM, AlertPublicationMessage objAlertLiaAssetLLM, AlertPublicationMessage objAlertForexLLM, AlertPublicationMessage objAlertbankloanLLM,
			AlertPublicationMessage objAlertbankDepositLLM, AlertPublicationMessage objAlertOMOLLM, MySourceStore mySourceStore, DateTime dtDate, UrlPollStatus oUrlPollStatus)
		{
			try
			{
				this.Store = mySourceStore;
				this.oUrlPollStatus = oUrlPollStatus;
				string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
				decimal dclTotReserve = Convert.ToDecimal(alertDetailsFromLLM.TotalForexReserves.Replace(",", ""));
				bool isHandBreak = Store.Settings.GetSetting("ENABLE_LLM_HANDBRAKE_YES_NO").Value == "YES" ? true : false;

				if (dclTotReserve > 0)
				{
					Store.PerformanceLog.LogComment("Sending Handbreak LLM alert for: " + objAlertForexLLM.ID);
					StringBuilder sbAlertForexLLM = new StringBuilder(objAlertForexLLM.AlertTemplate);

					string strP_TotalReserve = null;
					decimal dclTotReservebln = dclTotReserve / 1000;
					DateTime dtDateFilling = Convert.ToDateTime(alertDetailsFromLLM.TotalForexReservesDate);

					if (!string.IsNullOrWhiteSpace(Store.Settings.GetSetting("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE").Value))
					{
						string strSetting = Store.Settings.GetSetting("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE").Value;
						Match matchPTotRes = Regex.Match(strSetting.Trim(), @"TOTAL\s*RESERVE.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
						if (matchPTotRes.Success)
						{
							string[] strArrSplitTotRes = Regex.Split(matchPTotRes.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
							strP_TotalReserve = strArrSplitTotRes[1];

							decimal dclP_TotReserve = Convert.ToDecimal(strP_TotalReserve.Replace(",", ""));
							decimal dclP_TotReservebln = dclP_TotReserve / 1000;
							if (dclP_TotReservebln > 0)
							{
								if (dclTotReservebln >= 1000)
								{
									dclTotReservebln = dclTotReservebln / 1000;
									sbAlertForexLLM.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
									sbAlertForexLLM.Replace("{X_BLN/TRLN}", "TRLN");
								}
								else
								{
									sbAlertForexLLM.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
									sbAlertForexLLM.Replace("{X_BLN/TRLN}", "BLN");
								}
								if (dclP_TotReservebln >= 1000)
								{
									dclP_TotReservebln = dclP_TotReservebln / 1000;
									sbAlertForexLLM.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
									sbAlertForexLLM.Replace("{Y_BLN/TRLN}", "TRLN");
								}
								else
								{
									sbAlertForexLLM.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
									sbAlertForexLLM.Replace("{Y_BLN/TRLN}", "BLN");
								}
								sbAlertForexLLM.Replace("{WEEK_DATE}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim().ToUpper() + " " + dtDateFilling.Day);
								oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling (Alert) : " + dtDateFilling.ToString());

								if (!isHandBreak)
								{
									if (objAlertForexLLM.IsSent == false)
									{
										objAlertForexLLM.IsLLM = true;
										objAlertForexLLM.Send(sbAlertForexLLM.ToString(), oUrlPollStatus);
									}
								}
								else
								{
									var handbrakeAlertForexLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertForexLLM.PublicationAgent, objAlertForexLLM.AutomationName, objAlertForexLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
									handbrakeAlertForexLLM.Add(new Alert
									{
										Id = $"{objAlertForexLLM.ID}-{Guid.NewGuid()}",
										Text = sbAlertForexLLM.ToString()
									});
									handbrakeAlertForexLLM.IsActive = true;
									handbrakeAlertForexLLM.IsLLM = true;
									//if (!string.IsNullOrEmpty(item.ProductCodes))
									handbrakeAlertForexLLM.PCodes = removedupes(String.Join(" ", objAlertForexLLM.ProductCodes), "");
									//if (!string.IsNullOrEmpty(item.TopicCodes))
									handbrakeAlertForexLLM.TCodes = removedupes(String.Join(" ", objAlertForexLLM.TopicCodes), "");
									if (!string.Equals(objAlertForexLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
										handbrakeAlertForexLLM.RICCodes = objAlertForexLLM.RicReferences;

									handbrakeAlertForexLLM.SendHandbrake();
									Store.IshandbrakeAlertForexLLM = true;
									//handbrake.PCodes = string.Empty;
									//handbrake.TCodes = string.Empty;
								}
							}
						}
						else return;
					}
					else return;
				}
				else
				{
					Store.IshandbrakeAlertForexLLM = true;
					objAlertForexLLM.IsSent = true;
					oUrlPollStatus.PollAttempt.LogComment("LLMResponce: Any of the required value is 0 or negative in Forex table.");
				}
				if (!string.IsNullOrWhiteSpace(alertDetailsFromLLM.AggregateDepositsGrowthPercent))
				{
					if (DateTime.Compare(DateTime.Parse(alertDetailsFromLLM.AggregateDeopositsOutstandingAsofDate).Date, dtDate.AddDays(-7).Date) == 0)
					{
						string strReturn = null;
						DateTime dtDateFilling = Convert.ToDateTime(alertDetailsFromLLM.AggregateDeopositsOutstandingAsofDate);
						decimal dclDeposit = Convert.ToDecimal(alertDetailsFromLLM.AggregateDepositsGrowthPercent.Replace(",", ""));
						StringBuilder sbDepositLLM = new StringBuilder(objAlertbankDepositLLM.AlertTemplate);

						if (dclDeposit > 0)
						{
							sbDepositLLM.Replace("{ROSE/FELL/UNCHANGED}", "ROSE");
							sbDepositLLM.Replace("{VALUE PCT}", dclDeposit.ToString("0.#") + "%");
							strReturn = dclDeposit.ToString("0.#");
						}
						else if (dclDeposit < 0)
						{
							sbDepositLLM.Replace("{ROSE/FELL/UNCHANGED}", "FELL");
							sbDepositLLM.Replace("{VALUE PCT}", dclDeposit.ToString("0.#").TrimStart('-') + "%");
							strReturn = dclDeposit.ToString("0.#");
						}
						else if (dclDeposit == 0)
						{
							sbDepositLLM.Replace("{ROSE/FELL/UNCHANGED}", "UNCHANGED");
							sbDepositLLM.Replace(" {VALUE PCT}", "");
							strReturn = "0";
						}

						sbDepositLLM.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim().ToUpper() + " " + dtDateFilling.Day);

						if (!isHandBreak)
						{
							if (objAlertbankDepositLLM.IsSent == false)
							{
								objAlertbankDepositLLM.IsLLM = true;
								objAlertbankDepositLLM.Send(sbDepositLLM.ToString(), oUrlPollStatus);
							}
						}
						else
						{
							var handbrakeAlertbankDepositLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertbankDepositLLM.PublicationAgent, objAlertbankDepositLLM.AutomationName, objAlertbankDepositLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
							handbrakeAlertbankDepositLLM.Add(new Alert
							{
								Id = $"{objAlertbankDepositLLM.ID}-{Guid.NewGuid()}",
								Text = sbDepositLLM.ToString()
							});
							handbrakeAlertbankDepositLLM.IsActive = true;
							handbrakeAlertbankDepositLLM.IsLLM = true;
							//if (!string.IsNullOrEmpty(item.ProductCodes))
							handbrakeAlertbankDepositLLM.PCodes = removedupes(String.Join(" ", objAlertbankDepositLLM.ProductCodes), "");
							//if (!string.IsNullOrEmpty(item.TopicCodes))
							handbrakeAlertbankDepositLLM.TCodes = removedupes(String.Join(" ", objAlertbankDepositLLM.TopicCodes), "");
							if (!string.Equals(objAlertbankDepositLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
								handbrakeAlertbankDepositLLM.RICCodes = objAlertbankDepositLLM.RicReferences;

							handbrakeAlertbankDepositLLM.SendHandbrake();
							Store.IshandbrakeAlertbankDepositLLM = true;
							//handbrake.PCodes = string.Empty;
							//handbrake.TCodes = string.Empty;
						}
					}
					else
					{
						objAlertbankDepositLLM.IsSent = true;
						Store.IshandbrakeAlertbankDepositLLM = true;
						oUrlPollStatus.PollAttempt.LogComment("LLMResponce: deposit Date is not fortnight date for Scheduled Commercial Banks table");
					}
				}
				else
				{
					objAlertbankDepositLLM.IsSent = true;
					Store.IshandbrakeAlertbankDepositLLM = true;
					oUrlPollStatus.PollAttempt.LogComment("LLMResponce: deposit value is empty for Scheduled Commercial Banks table");
				}

				if (!string.IsNullOrWhiteSpace(alertDetailsFromLLM.BankCreditGrowthPercent))
				{
					if (DateTime.Compare(DateTime.Parse(alertDetailsFromLLM.BankCreditOutstandingAsofDate).Date, dtDate.AddDays(-7).Date) == 0)
					{
						string strReturn = null;
						DateTime dtDateFilling = Convert.ToDateTime(alertDetailsFromLLM.BankCreditOutstandingAsofDate);
						decimal dclCredit = Convert.ToDecimal(alertDetailsFromLLM.BankCreditGrowthPercent.Replace(",", ""));
						StringBuilder sbBankLoanLLM = new StringBuilder(objAlertbankloanLLM.AlertTemplate);

						if (dclCredit > 0)
						{
							sbBankLoanLLM.Replace("{ROSE/FELL/UNCHANGED}", "ROSE");
							sbBankLoanLLM.Replace("{VALUE PCT}", dclCredit.ToString("0.#") + "%");
							strReturn = dclCredit.ToString("0.#");
						}
						else if (dclCredit < 0)
						{
							sbBankLoanLLM.Replace("{ROSE/FELL/UNCHANGED}", "FELL");
							sbBankLoanLLM.Replace("{VALUE PCT}", dclCredit.ToString("0.#").TrimStart('-') + "%");
							strReturn = dclCredit.ToString("0.#");
						}
						else if (dclCredit == 0)
						{
							sbBankLoanLLM.Replace("{ROSE/FELL/UNCHANGED}", "UNCHANGED");
							sbBankLoanLLM.Replace("{VALUE PCT}", "");
							strReturn = "0";
						}
						sbBankLoanLLM.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim().ToUpper() + " " + dtDateFilling.Day);

						if (!isHandBreak)
						{
							if (objAlertbankloanLLM.IsSent == false)
							{
								objAlertbankloanLLM.IsLLM = true;
								objAlertbankloanLLM.Send(sbBankLoanLLM.ToString(), oUrlPollStatus);
							}
						}
						else
						{
							var handbrakeAlertbankloanLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertbankloanLLM.PublicationAgent, objAlertbankloanLLM.AutomationName, objAlertbankloanLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
							handbrakeAlertbankloanLLM.Add(new Alert
							{
								Id = $"{objAlertbankloanLLM.ID}-{Guid.NewGuid()}",
								Text = sbBankLoanLLM.ToString()
							});
							handbrakeAlertbankloanLLM.IsActive = true;
							handbrakeAlertbankloanLLM.IsLLM = true;
							//if (!string.IsNullOrEmpty(item.ProductCodes))
							handbrakeAlertbankloanLLM.PCodes = removedupes(String.Join(" ", objAlertbankloanLLM.ProductCodes), "");
							//if (!string.IsNullOrEmpty(item.TopicCodes))
							handbrakeAlertbankloanLLM.TCodes = removedupes(String.Join(" ", objAlertbankloanLLM.TopicCodes), "");
							if (!string.Equals(objAlertbankloanLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
								handbrakeAlertbankloanLLM.RICCodes = objAlertbankloanLLM.RicReferences;

							handbrakeAlertbankloanLLM.SendHandbrake();
							Store.IshandbrakeAlertbankloanLLM = true;
							//handbrake.PCodes = string.Empty;
							//handbrake.TCodes = string.Empty;
						}
					}
					else
					{
						objAlertbankloanLLM.IsSent = true;
						Store.IshandbrakeAlertbankloanLLM = true;
						oUrlPollStatus.PollAttempt.LogComment("LLMResponce: deposit date is not fortnight date for Scheduled Commercial Banks table");
					}
				}
				else
				{
					objAlertbankloanLLM.IsSent = true;
					Store.IshandbrakeAlertbankloanLLM = true;
					oUrlPollStatus.PollAttempt.LogComment("LLMResponce: deposit value is empty for Scheduled Commercial Banks table");
				}

				// if (!String.IsNullOrEmpty(alertDetailsFromLLM.TotalSalesUnderOMO) || !String.IsNullOrEmpty(alertDetailsFromLLM.TotalPurchaseUnderOMO))
				// {
				// 	StringBuilder sbAlertOMOLLM = new StringBuilder(objAlertOMOLLM.AlertTemplate);
				// 	DateTime dtDateFilling = Convert.ToDateTime(alertDetailsFromLLM.TotalSalesPurchaseAsOfDate);
				// 	decimal dclTotalSale = Convert.ToDecimal(alertDetailsFromLLM.TotalSalesUnderOMO.Replace(",", ""));
				// 	decimal dclTotalPurchase = Convert.ToDecimal(alertDetailsFromLLM.TotalPurchaseUnderOMO.Replace(",", ""));

				// 	if (dclTotalPurchase > 0)
				// 	{
				// 		if (dclTotalSale >= 1000)
				// 		{
				// 			dclTotalSale = dclTotalSale / 1000;
				// 			sbAlertOMOLLM.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
				// 			sbAlertOMOLLM.Replace("{X_BLN/MLN/TRLN}", "TRLN");
				// 		}
				// 		else if (dclTotalSale < 1)
				// 		{
				// 			dclTotalSale = dclTotalSale * 1000;
				// 			sbAlertOMOLLM.Replace("{X.XX}", dclTotalSale.ToString("0.0", CultureInfo.InvariantCulture));
				// 			sbAlertOMOLLM.Replace("{X_BLN/MLN/TRLN}", "MLN");
				// 		}
				// 		else
				// 		{
				// 			sbAlertOMOLLM.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
				// 			sbAlertOMOLLM.Replace("{X_BLN/MLN/TRLN}", "BLN");
				// 		}
				// 		sbAlertOMOLLM.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtDateFilling.Month - 1].ToUpper().Trim() + " " + dtDateFilling.Day);

				// 		if (dclTotalPurchase > 0)
				// 		{
				// 			if (dclTotalPurchase >= 1000)
				// 			{
				// 				dclTotalPurchase = dclTotalPurchase / 1000;
				// 				sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " TRLN RUPEES OF BONDS");
				// 			}
				// 			else if (dclTotalPurchase < 1)
				// 			{
				// 				dclTotalPurchase = dclTotalPurchase * 1000;
				// 				sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.0", CultureInfo.InvariantCulture) + " MLN RUPEES OF BONDS");
				// 			}
				// 			else
				// 			{
				// 				sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " BLN RUPEES OF BONDS");
				// 			}
				// 		}
				// 		else
				// 		{
				// 			sbAlertOMOLLM.Replace(", {RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "");
				// 		}

				// 		if (!isHandBreak)
				// 		{
				// 			if (objAlertOMOLLM.IsSent == false)
				// {
				//				objAlertOMOLLM.IsLLM = true;
				// 				objAlertOMOLLM.Send(sbAlertOMOLLM.ToString(), oUrlPollStatus);
				// }
				// 		}
				// 		else
				// 		{
				// 			var handbrakeAlertOMOLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertOMOLLM.PublicationAgent, objAlertOMOLLM.AutomationName, objAlertOMOLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
				// 			handbrakeAlertOMOLLM.Add(new Alert
				// 			{
				// 				Id = $"{objAlertOMOLLM.ID}-{Guid.NewGuid()}",
				// 				Text = sbAlertOMOLLM.ToString()
				// 			});
				// 			handbrakeAlertOMOLLM.IsActive = true;
				// 			handbrakeAlertOMOLLM.IsLLM = true;
				// 			//if (!string.IsNullOrEmpty(item.ProductCodes))
				// 			handbrakeAlertOMOLLM.PCodes = removedupes(String.Join(" ", objAlertOMOLLM.ProductCodes), "");
				// 			//if (!string.IsNullOrEmpty(item.TopicCodes))
				// 			handbrakeAlertOMOLLM.TCodes = removedupes(String.Join(" ", objAlertOMOLLM.TopicCodes), "");
				// 			if (!string.Equals(objAlertOMOLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
				// 				handbrakeAlertOMOLLM.RICCodes = objAlertOMOLLM.RicReferences;

				// 			handbrakeAlertOMOLLM.SendHandbrake();
				// 			Store.IshandbrakeAlertOMOLLM = true;
				// 			//handbrake.PCodes = string.Empty;
				// 			//handbrake.TCodes = string.Empty;
				// 		}
				// 	}
				// 	else if ((dclTotalPurchase > 0))
				// 	{
				// 		sbAlertOMOLLM.Replace("RBI SOLD {X.XX} {X_BLN/MLN/TRLN} RUPEES OF BONDS, ", "");
				// 		sbAlertOMOLLM.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtDateFilling.Month - 1].ToUpper().Trim() + " " + dtDateFilling.Day);

				// 		if (dclTotalPurchase >= 1000)
				// 		{
				// 			dclTotalPurchase = dclTotalPurchase / 1000;
				// 			sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00") + " TRLN RUPEES OF BONDS");
				// 		}
				// 		else if (dclTotalPurchase < 1)
				// 		{
				// 			dclTotalPurchase = dclTotalPurchase * 1000;
				// 			sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.0") + " MLN RUPEES OF BONDS");
				// 		}
				// 		else
				// 		{
				// 			sbAlertOMOLLM.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00") + " BLN RUPEES OF BONDS");
				// 		}
				// 		if (!isHandBreak)
				// 		{
				// 			if (objAlertOMOLLM.IsSent == false)
				// {
					//				objAlertOMOLLM.IsLLM = true;
					// 				objAlertOMOLLM.Send(sbAlertOMOLLM.ToString(), oUrlPollStatus);
				// }
				// 		}
				// 		else
				// 		{
				// 			var handbrakeAlertOMOLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertOMOLLM.PublicationAgent, objAlertOMOLLM.AutomationName, objAlertOMOLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
				// 			handbrakeAlertOMOLLM.Add(new Alert
				// 			{
				// 				Id = $"{objAlertOMOLLM.ID}-{Guid.NewGuid()}",
				// 				Text = sbAlertOMOLLM.ToString()
				// 			});
				// 			handbrakeAlertOMOLLM.IsActive = true;
				// 			handbrakeAlertOMOLLM.IsLLM = true;
				// 			//if (!string.IsNullOrEmpty(item.ProductCodes))
				// 			handbrakeAlertOMOLLM.PCodes = removedupes(String.Join(" ", objAlertOMOLLM.ProductCodes), "");
				// 			//if (!string.IsNullOrEmpty(item.TopicCodes))
				// 			handbrakeAlertOMOLLM.TCodes = removedupes(String.Join(" ", objAlertOMOLLM.TopicCodes), "");
				// 			if (!string.Equals(objAlertOMOLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
				// 				handbrakeAlertOMOLLM.RICCodes = objAlertOMOLLM.RicReferences;

				// 			handbrakeAlertOMOLLM.SendHandbrake();
				// 			Store.IshandbrakeAlertOMOLLM = true;
				// 			//handbrake.PCodes = string.Empty;
				// 			//handbrake.TCodes = string.Empty;
				// 		}
				// 	}
				// 	if ((dclTotalSale == 0))
				// 	{
				// 		objAlertOMOLLM.IsSent = true;
				// 		Store.IshandbrakeAlertOMOLLM = true;
				// 	}
				// }
				// else
				// {
				// 	objAlertOMOLLM.IsSent = true;
				// 	Store.IshandbrakeAlertOMOLLM = true;
				// 	oUrlPollStatus.PollAttempt.LogComment("LLMResponce: Total Sales and Total Purchase value is Empty in OMO table.");
				// }

				if (!string.IsNullOrEmpty(alertDetailsFromLLM.CentralGovtOutstandingLoans))
				{
					DateTime dtDateFilling = DateTime.MinValue;
					if (!string.IsNullOrEmpty(alertDetailsFromLLM.LatestDateLiabilitiesAssets))
					{
						dtDateFilling = Convert.ToDateTime(alertDetailsFromLLM.LatestDateLiabilitiesAssets);

						if (dtDateFilling.Date != dtDate.Date)
						{
							dtDateFilling = dtDate;
						}
					}
					else
					{
						dtDateFilling = dtDate;
					}
					//decimal dclCentralGovtOutstandingLoans = Convert.ToDecimal(alertDetailsFromLLM.CentralGovtOutstandingLoans.Replace(",", ""));
					StringBuilder sbAlertLiaAssetLLM = new StringBuilder(objAlertLiaAssetLLM.AlertTemplate);

					if ((alertDetailsFromLLM.CentralGovtOutstandingLoans.Trim() == "-") || (alertDetailsFromLLM.CentralGovtOutstandingLoans.Trim() == "NO OUTSTANDING") || (alertDetailsFromLLM.CentralGovtOutstandingLoans.Trim() == "0"))//|| (strCentralValue.Trim().ToUpper() == "NA") || (strCentralValue.Trim().ToUpper() == "N/A"))
					{
						sbAlertLiaAssetLLM.Replace("{CURRENT_VALUE}", "NO");
						sbAlertLiaAssetLLM.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].ToUpper().Trim() + " " + dtDate.Day);

						if (!isHandBreak)
						{
							objAlertLiaAssetLLM.IsLLM = true;
							objAlertLiaAssetLLM.Send(sbAlertLiaAssetLLM.ToString(), oUrlPollStatus);
						}
						else
						{
							var handbrakeAlertLiaAssetLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertLiaAssetLLM.PublicationAgent, objAlertLiaAssetLLM.AutomationName, objAlertLiaAssetLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
							handbrakeAlertLiaAssetLLM.Add(new Alert
							{
								Id = $"{objAlertLiaAssetLLM.ID}-{Guid.NewGuid()}",
								Text = sbAlertLiaAssetLLM.ToString()
							});
							handbrakeAlertLiaAssetLLM.IsActive = true;
							handbrakeAlertLiaAssetLLM.IsLLM = true;
							//if (!string.IsNullOrEmpty(item.ProductCodes))
							handbrakeAlertLiaAssetLLM.PCodes = removedupes(String.Join(" ", objAlertLiaAssetLLM.ProductCodes), "");
							//if (!string.IsNullOrEmpty(item.TopicCodes))
							handbrakeAlertLiaAssetLLM.TCodes = removedupes(String.Join(" ", objAlertLiaAssetLLM.TopicCodes), "");
							if (!string.Equals(objAlertLiaAssetLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
								handbrakeAlertLiaAssetLLM.RICCodes = objAlertLiaAssetLLM.RicReferences;

							handbrakeAlertLiaAssetLLM.SendHandbrake();
							Store.IshandbrakeAlertLiaAssetLLM = true;
							//handbrake.PCodes = string.Empty;
							//handbrake.TCodes = string.Empty;
						}
					}
					else
					{
						decimal dclCentralValue = Convert.ToDecimal(alertDetailsFromLLM.CentralGovtOutstandingLoans.Replace(",", ""));

						if (dclCentralValue > 0)
						{
							if (dclCentralValue >= 1000)
							{
								dclCentralValue = dclCentralValue / 1000;
								sbAlertLiaAssetLLM.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " TRLN RUPEES");//trillion
							}
							else if (dclCentralValue < 1)
							{
								dclCentralValue = dclCentralValue * 1000;
								sbAlertLiaAssetLLM.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " MLN RUPEES");//trillion
							}
							else
								sbAlertLiaAssetLLM.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " BLN RUPEES");
						}
						if (dclCentralValue == 0)
							return;
						if (dclCentralValue < 0)
							return;

						sbAlertLiaAssetLLM.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].ToUpper().Trim() + " " + dtDate.Day);

						if (!isHandBreak)
						{
							objAlertLiaAssetLLM.IsLLM = true;
							objAlertLiaAssetLLM.Send(sbAlertLiaAssetLLM.ToString(), oUrlPollStatus);
						}
						else
						{
							var handbrakeAlertLiaAssetLLM = new HandbrakeMessage(PublicationMessageType.Handbrake, objAlertLiaAssetLLM.PublicationAgent, objAlertLiaAssetLLM.AutomationName, objAlertLiaAssetLLM.ID, sHandbrakeName: String.Empty, sHandbrakePostUrl: String.Empty);
							handbrakeAlertLiaAssetLLM.Add(new Alert
							{
								Id = $"{objAlertLiaAssetLLM.ID}-{Guid.NewGuid()}",
								Text = sbAlertLiaAssetLLM.ToString()
							});
							handbrakeAlertLiaAssetLLM.IsActive = true;
							handbrakeAlertLiaAssetLLM.IsLLM = true;
							//if (!string.IsNullOrEmpty(item.ProductCodes))
							handbrakeAlertLiaAssetLLM.PCodes = removedupes(String.Join(" ", objAlertLiaAssetLLM.ProductCodes), "");
							//if (!string.IsNullOrEmpty(item.TopicCodes))
							handbrakeAlertLiaAssetLLM.TCodes = removedupes(String.Join(" ", objAlertLiaAssetLLM.TopicCodes), "");
							if (!string.Equals(objAlertLiaAssetLLM.RicReferences, "<NO RIC>", StringComparison.InvariantCultureIgnoreCase))
								handbrakeAlertLiaAssetLLM.RICCodes = objAlertLiaAssetLLM.RicReferences;

							handbrakeAlertLiaAssetLLM.SendHandbrake();
							Store.IshandbrakeAlertLiaAssetLLM = true;
							//handbrake.PCodes = string.Empty;
							//handbrake.TCodes = string.Empty;
						}
					}

				}
				else
				{
					objAlertLiaAssetLLM.IsSent = true;
					Store.IshandbrakeAlertLiaAssetLLM = true;
					oUrlPollStatus.PollAttempt.LogComment("LLMResponce: Central Govt Outstanding Loans value is 0 or negative in Scheduled Commercial Banks table.");
				}
			}
			catch (Exception ex)
			{
				Store.AutomationClient.OperatorLog(ex.Message);
			}
		}
		public string removedupes(string s, string exclude)
		{
			List<string> found = new List<string>();
			List<string> excludeCode = exclude.Split(" ").ToList();
			foreach (string c in s.Split(" "))
			{
				if (c.Trim() != string.Empty)
				{
					if (found.Contains(c.Trim()) || excludeCode.Contains(c))
						continue;
					found.Add(c.Trim());
				}
			}
			return String.Join(" ", found);
		}
	}
}
