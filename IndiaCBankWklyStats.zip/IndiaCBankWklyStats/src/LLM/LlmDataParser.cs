﻿using AutomationCore;
using EAP.Core.LLM.Models;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndiaCBankWklyStats.LLM
{
	public class LlmDataParser
	{
		public async Task<AlertDetailsFromLLM> GetLLMResponse(string inputText, MySourceStore myStore)
		{
			string llmPromptString = "LLM_PROMPT";
			string placeholderReleaseWeek = "{Release_Week}";
			string placeholderYear = "{Year}";
			string dtReleaseWeekYear = Convert.ToDateTime(myStore.ReleaseWeekDate).Year.ToString();

			string prompt = myStore.Settings.GetSetting(llmPromptString).Value;
			if (prompt == null)
			{
				myStore.AutomationClient.OperatorLog("Prompt not found from config!");
			}

			AlertDetailsFromLLM alertDetailsFromLLM = new AlertDetailsFromLLM();
			OpenAiLlmFactory openAiLlmFactory = OpenAiLlmFactory.CreateOpenAILLMService();
				
			try
			{
				JObject jsonPrompt = JsonConvert.DeserializeObject<JObject>(prompt);
				if (jsonPrompt != null && inputText != null)
				{
					jsonPrompt = UpdateJsonValues(jsonPrompt, placeholderReleaseWeek, placeholderYear, dtReleaseWeekYear, myStore);
					List<Field> fields = GetListOfFields(jsonPrompt);
					LlmRequest llmRequest = new LlmRequest(fields, inputText);

					myStore.AutomationClient.OperatorLog("Requesting LLM API now..");
					myStore.llmCounter += 1;
					myStore.AutomationClient.OperatorLog("LLM Request Counter is called: " + myStore.llmCounter);
					LlmResponse response = await openAiLlmFactory.GetOpenAIAPIResponse(llmRequest);
					if (response != null)
					{
						myStore.AutomationClient.OperatorLog("LLM Response recieved");
						myStore.AutomationClient.OperatorLog("LLM Context - " + response.Context.ToString());
						string llmResponse = response.Response.Split("json\n")[1].Split("```")[0];
						myStore.AutomationClient.OperatorLog("LLM response - " + llmResponse);
						JObject jsonRes = JsonConvert.DeserializeObject<JObject>(llmResponse);
						myStore.AutomationClient.OperatorLog("LLM response json - " + jsonRes);
						if (jsonRes != null)
						{
							alertDetailsFromLLM = DeserializeLLMResponse(alertDetailsFromLLM, jsonRes);
							myStore.AutomationClient.OperatorLog("LLM response is now deserialized.." + alertDetailsFromLLM);
						}
					}
					else
					{
						myStore.AutomationClient.OperatorLog("LLM Response failed!");
					}
				}
				else
				{
					alertDetailsFromLLM = null;
					myStore.AutomationClient.OperatorLog("Prompt not found from config");
				}
			}
			catch (Exception ex)
			{
				myStore.AutomationClient.OperatorLog(ex.Message);
			}
			return alertDetailsFromLLM;
		}

		private List<Field> GetListOfFields(JObject jsonPrompt)
		{
			List<Field> fields = new List<Field>();
			foreach (var jsonObj in jsonPrompt["Fields"])
			{
				Field field = JsonConvert.DeserializeObject<Field>(jsonObj.ToString());
				fields.Add(field);
			}
			return fields;
		}

		private JObject UpdateJsonValues(JObject jsonPrompt, string placeholderReleaseWeek, string placeholderYear, string dtReleaseWeekYear, MySourceStore myStore)
		{
			foreach (var jsonObj in jsonPrompt["Fields"])
			{
				string des = jsonObj["Prompt"].ToString();
				if (des.Contains(placeholderReleaseWeek))
				{
					des = des.Replace(placeholderReleaseWeek, myStore.ReleaseWeekDate.Trim());
				}
				if (des.Contains(placeholderYear))
				{
					des = des.Replace(placeholderYear, dtReleaseWeekYear.Trim());
				}
				jsonObj["Prompt"] = des;
			}
			return jsonPrompt;
		}

		private static AlertDetailsFromLLM DeserializeLLMResponse(AlertDetailsFromLLM alertDetailsFromLLM, JObject jsonRes)
		{
			if (jsonRes["CentralGovtOutstandingLoans"] != null && jsonRes["CentralGovtOutstandingLoans"].ToString() != "NIL")
			{
				alertDetailsFromLLM.CentralGovtOutstandingLoans = jsonRes["CentralGovtOutstandingLoans"].ToString();
			}
			if (jsonRes["LatestDateLiabilitiesAssets"] != null && jsonRes["LatestDateLiabilitiesAssets"].ToString() != "NIL")
			{
				alertDetailsFromLLM.LatestDateLiabilitiesAssets = jsonRes["LatestDateLiabilitiesAssets"].ToString();
			}
			if (jsonRes["BankCreditOutstandingAsofDate"] != null && jsonRes["BankCreditOutstandingAsofDate"].ToString() != "NIL")
			{
				alertDetailsFromLLM.BankCreditOutstandingAsofDate = jsonRes["BankCreditOutstandingAsofDate"].ToString();
			}
			if (jsonRes["AggregateDeopositsOutstandingAsofDate"] != null && jsonRes["AggregateDeopositsOutstandingAsofDate"].ToString() != "NIL")
			{
				alertDetailsFromLLM.AggregateDeopositsOutstandingAsofDate = jsonRes["AggregateDeopositsOutstandingAsofDate"].ToString();
			}
			if (jsonRes["TotalForexReserves"] != null && jsonRes["TotalForexReserves"].ToString() != "NIL")
			{
				alertDetailsFromLLM.TotalForexReserves = jsonRes["TotalForexReserves"].ToString();
			}
			if (jsonRes["TotalForexReservesDate"] != null && jsonRes["TotalForexReservesDate"].ToString() != "NIL")
			{
				alertDetailsFromLLM.TotalForexReservesDate = jsonRes["TotalForexReservesDate"].ToString();
			}

			if (jsonRes.ContainsKey("OMOOutrights") && jsonRes["OMOOutrights"] != null && jsonRes["OMOOutrights"].ToList().Count > 0)
			{
				List<OMOOutright> omoOutrights = new List<OMOOutright>();
				var totalSales = 0;
				var totalPurchase = 0;
				var nestedJson = jsonRes["OMOOutrights"];
				if (nestedJson != null && nestedJson.HasValues)
				{
					foreach (var jsonObj in nestedJson.Children().ToList())
					{
						OMOOutright omoOutright = new OMOOutright();

						if (!jsonObj["SalesUnderOMO"].ToString().Equals("NIL", StringComparison.CurrentCultureIgnoreCase))
						{
							omoOutright.SalesUnderOMO = jsonObj["SalesUnderOMO"].ToString();
						}
						if (!jsonObj["PurchaseUnderOMO"].ToString().Equals("NIL", StringComparison.CurrentCultureIgnoreCase))
						{
							omoOutright.PurchaseUnderOMO = jsonObj["PurchaseUnderOMO"].ToString();
						}
						if (!jsonObj["LastestPurchaseAsOfDate"].ToString().Equals("NIL", StringComparison.CurrentCultureIgnoreCase))
						{
							omoOutright.LastestPurchaseAsOfDate = jsonObj["LastestPurchaseAsOfDate"].ToString();
						}
						omoOutrights.Add(omoOutright);
					}

					totalSales = omoOutrights.Sum(x => Convert.ToInt32(x.SalesUnderOMO));
					totalPurchase = omoOutrights.Sum(x => Convert.ToInt32(x.PurchaseUnderOMO));
					alertDetailsFromLLM.TotalSalesUnderOMO = totalSales.ToString();
					alertDetailsFromLLM.TotalPurchaseUnderOMO = totalPurchase.ToString();
					alertDetailsFromLLM.TotalSalesPurchaseAsOfDate = omoOutrights.LastOrDefault().LastestPurchaseAsOfDate;
				}
			}
			else
			{
				alertDetailsFromLLM.OMOOutrights = null;
			}

			if (jsonRes.ContainsKey("GrowthPercent") && jsonRes["GrowthPercent"] != null && jsonRes["GrowthPercent"].ToList().Count > 0)
			{
				List<GrowthPercent> growthPercents = new List<GrowthPercent>();
				var nestedJson = jsonRes["GrowthPercent"];
				GrowthPercent growthPercent = new GrowthPercent();

				if (nestedJson != null && nestedJson["BankCredit"] != null && !nestedJson["BankCredit"].ToString().Equals("NIL", StringComparison.CurrentCultureIgnoreCase) &&
					nestedJson["AggregateDeposits"] != null && !nestedJson["AggregateDeposits"].ToString().Equals("NIL", StringComparison.CurrentCultureIgnoreCase))
				{
					growthPercent.BankCredit = nestedJson["BankCredit"].ToString();
					growthPercent.AggregateDeposit = nestedJson["AggregateDeposits"].ToString();
				}
				growthPercents.Add(growthPercent);

				alertDetailsFromLLM.AggregateDepositsGrowthPercent = growthPercents.LastOrDefault()?.AggregateDeposit;
				alertDetailsFromLLM.BankCreditGrowthPercent = growthPercents.LastOrDefault()?.BankCredit;
			}
			else
			{
				alertDetailsFromLLM.GrowthPercent = null;
			}

			return alertDetailsFromLLM;
		}
	}
}

