﻿using AutomationCore;
using AutomationCore.Email;
using AutomationCore.Handbrake;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using AutomationCore.Pdf;
using IndiaCBankWklyStats.LLM;
using System.Threading.Tasks;

namespace IndiaCBankWklyStats
{
    public class MySourceStore : SourceStore
    {
        public bool isEnable = false;

        public string strRecommendValues = "";
        public object locker_Recommend = new object();
        public string strCurrencyValue = null;
        public int m_iTotalAlertLinks = 0;
        public int iCnt = 0;
        public List<Source> lstobjSource = new List<Source>();
        public List<string> lstNewLink = new List<string>();
        public object locker = new object();
        public string strUrl = null;
        public int iMaxId = 0;
        public string sDate_FORCE_FILE_FOR_QA = "";
        public DateTime dtCurrent_FORCE_FILE_FOR_QA = DateTime.MinValue;
        public bool IsForeignExchangeLLMRequestSent = false;
        public int llmCounter = 0;
        public bool IsLLMReqSent = false;
        public bool IshandbrakeAlertbankDepositLLM = false;
        public bool IshandbrakeAlertbankloanLLM = false;
        public bool IshandbrakeAlertLiaAssetLLM = false;
        public bool IshandbrakeAlertOMOLLM = false;
        public bool IshandbrakeAlertForexLLM = false;
        public string ReleaseWeekDate = string.Empty;
        public string PreviousWeekDate = string.Empty;
        public List<string> newLinks = new List<string>();

        public MySourceStore(string sAutomationDllFullPath, Config oConfig)
            : base(sAutomationDllFullPath, oConfig)
        {

        }
        public override void OnHistoryLoaded()
        {


        }
        public override void OnPollingStopped()
        {
            //Polling of all sources is stopped, you can perform any required action.
        }
    }

    public class Main : AutomationClient
    {
        public override SourceStore LoadSourceStore(Config config)
        {
            MySourceStore Store = new MySourceStore(this.GetType().Assembly.Location, config);

            if (Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY") != null)
                Store.ReleaseWeekDate = Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY").Value;

            if (Store.Settings.GetSetting("PREVIOUS_WEEK_DD-MMM-YYYY") != null)
                Store.PreviousWeekDate = Store.Settings.GetSetting("PREVIOUS_WEEK_DD-MMM-YYYY").Value;

            Setting sEnablePredicted = Store.Settings.GetSetting("ENABLE_PREDICTED_URL");
            if ((sEnablePredicted != null) && (!string.IsNullOrWhiteSpace(sEnablePredicted.Value)))
            {
                if (sEnablePredicted.Value.Trim().ToLower() == "yes")
                    Store.isEnable = true;
            }

            if ((Store.Settings.GetSetting("FORCE_FILE_FOR_QA") != null) && (!string.IsNullOrWhiteSpace(Store.Settings.GetSetting("FORCE_FILE_FOR_QA").Value)))
            {
                OperatorLog("WARNING! Automation is running with force filing feature(FORCE_FILE_FOR_QA)");
                Store.sDate_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_FOR_QA").Value.Split(new char[] { '|' }, StringSplitOptions.None)[0];
                Store.dtCurrent_FORCE_FILE_FOR_QA = DateTime.ParseExact(Store.sDate_FORCE_FILE_FOR_QA, "dd-MM-yy", CultureInfo.InvariantCulture);
                string sUrl_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_FOR_QA").Value.Split(new char[] { '|' }, StringSplitOptions.None)[1];
                Source urlHtmlpage = new NEWSource();
                Store.LoadURLSource("NEW_SOURCE", (NEWSource)urlHtmlpage);
                ((NEWSource)urlHtmlpage).Url = sUrl_FORCE_FILE_FOR_QA;
                Store.Sources.AddSource("NEW_SOURCE", ref urlHtmlpage);
            }
            else if ((Store.Settings.GetSetting("FORCE_FILE_PRESSRELEASE_URL") != null) && (!string.IsNullOrWhiteSpace(Store.Settings.GetSetting("FORCE_FILE_PRESSRELEASE_URL").Value)))
            {
                OperatorLog("WARNING! Automation is running with force filing feature(FORCE_FILE_PRESSRELEASE_URL)");
                Store.sDate_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_PRESSRELEASE_URL").Value.Split(new char[] { '|' }, StringSplitOptions.None)[0];
                Store.dtCurrent_FORCE_FILE_FOR_QA = DateTime.ParseExact(Store.sDate_FORCE_FILE_FOR_QA, "dd-MM-yy", CultureInfo.InvariantCulture);
                string sUrl_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_PRESSRELEASE_URL").Value.Split(new char[] { '|' }, StringSplitOptions.None)[1];
                Source PressSource = new PressReleasePage();
                Store.LoadURLSource("PRESS_RELEASE", (PressReleasePage)PressSource);
                ((PressReleasePage)PressSource).Url = sUrl_FORCE_FILE_FOR_QA;
                Store.Sources.AddSource("PRESS_RELEASE", ref PressSource);
            }
            else if ((Store.Settings.GetSetting("FORCE_FILE_RBIHOME_URL") != null) && (!string.IsNullOrWhiteSpace(Store.Settings.GetSetting("FORCE_FILE_RBIHOME_URL").Value)))
            {
                OperatorLog("WARNING! Automation is running with force filing feature(FORCE_FILE_RBIHOME_URL)");
                Store.sDate_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_RBIHOME_URL").Value.Split(new char[] { '|' }, StringSplitOptions.None)[0];
                Store.dtCurrent_FORCE_FILE_FOR_QA = DateTime.ParseExact(Store.sDate_FORCE_FILE_FOR_QA, "dd-MM-yy", CultureInfo.InvariantCulture);
                string sUrl_FORCE_FILE_FOR_QA = Store.Settings.GetSetting("FORCE_FILE_RBIHOME_URL").Value.Split(new char[] { '|' }, StringSplitOptions.None)[1];
                Source rbiHomeSource = new RBIHomePage();
                Store.LoadURLSource("RBI_HOMEPAGE", (RBIHomePage)rbiHomeSource);
                ((RBIHomePage)rbiHomeSource).Url = sUrl_FORCE_FILE_FOR_QA;
                Store.Sources.AddSource("RBI_HOMEPAGE", ref rbiHomeSource);
            }
            else
            {
                Source urlReleasepage = new ReleaseSource();
                Store.LoadURLSource("RELEASE_SOURCE", (ReleaseSource)urlReleasepage);
                //var pollManageHTMLSource = ((ReleaseSource)urlReleasepage).PollManager as SeleniumPollManager;
                //pollManageHTMLSource.WaitUntilCompletionAction = ((ReleaseSource)urlReleasepage).WaitUntilComplete;
                Store.Sources.AddSource("RELEASE_SOURCE", ref urlReleasepage);

                Source urlaspx = new ReleaseSource();
                Store.LoadURLSource("RBI_CUSTOMIZE_ASPX", (ReleaseSource)urlaspx);
                Store.Sources.AddSource("RBI_CUSTOMIZE_ASPX", ref urlaspx);

                Source PressSource = new PressReleasePage();
                Store.LoadURLSource("PRESS_RELEASE", (PressReleasePage)PressSource);
                Store.Sources.AddSource("PRESS_RELEASE", ref PressSource);

                Source rbiHomeSource = new RBIHomePage();
                Store.LoadURLSource("RBI_HOMEPAGE", (RBIHomePage)rbiHomeSource);
                Store.Sources.AddSource("RBI_HOMEPAGE", ref rbiHomeSource);
            }

            //if believe functionality from ElekronPollManager then REUTERSCURRENCY_INR is ric: INR=, fid: 22
            const string idnSourceId = "INR_TO_USD_CONVERSION_SOURCE";
            Source inrRicSource = new InrRicSource();
            Store.LoadIdnSource(idnSourceId, (InrRicSource)inrRicSource);
            Store.Sources.AddSource(idnSourceId, ref inrRicSource);

            if (Store.Settings.GetSetting("REUTERSCURRENCY_INR") != null)
                ((MySourceStore)Store).strCurrencyValue = Store.Settings.GetSetting("REUTERSCURRENCY_INR").Value;



            DefaultCommandExecutionSequence = "loadhistory,startpolling";

            return Store;
        }

    }



    public class ReleaseSource : URLSource
    {
        // int m_iTotalAlertLinks = 0;
        HtmlToText objHtmlToText = new HtmlToText();
        HtmlSource hs = new HtmlSource();
        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            try
            {
                Global objGlobal = new Global();
                objGlobal.Store = this.Store;
                MySourceStore mystore = (MySourceStore)Store;
                string strContent = oUrlPollStatus.ContentString;

                // oUrlPollStatus.ChunkAttempt.LogComment("Start structured");
                #region Structured
                strContent = strContent.Replace("\0", " ");
                strContent = Regex.Replace(strContent, @"&nbsp;", " ", RegexOptions.IgnoreCase);
                strContent = objHtmlToText.ConvertToText(ref strContent);
                bool isStructured = false;
                //  oUrlPollStatus.ChunkAttempt.LogComment("start table");
                MatchCollection matchTable = Regex.Matches(strContent, @"@@@@.*?\|\|\|\|.*?&&&&", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                // oUrlPollStatus.ChunkAttempt.LogComment("end table");
                foreach (Match mat in matchTable)
                {
                    string[] strSplitRow = Regex.Split(mat.Value, @"\%\%\%\%", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    for (int i = 0; i < strSplitRow.Count(); i++)
                    {
                        string[] strSplitColumn = Regex.Split(strSplitRow[i], @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (strSplitColumn.Count() >= 2)
                        {
                            if (isStructured == false)
                            {
                                if (Regex.Match(strSplitRow[i], @"(prid|rbidocs?|rdocs?|pdfs?)", RegexOptions.IgnoreCase | RegexOptions.Singleline).Success)
                                    isStructured = true;
                            }
                        }
                        //  oUrlPollStatus.PollAttempt.LogComment("start end row");
                        List<Link> lstLinks = hs.GetLinksFromContent(this.Url, strSplitRow[i]);
                        //   oUrlPollStatus.PollAttempt.LogComment("Start BOP");
                        Match matchBOP = Regex.Match(strSplitRow[i], @"\b+Bulletin|Weekly|Statistical|Supplement|Extract\b+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        // oUrlPollStatus.ChunkAttempt.LogComment("End BOP");
                        if (matchBOP.Success)
                        {
                            oUrlPollStatus.PollAttempt.LogComment("Title found");
                            foreach (Link item in lstLinks)
                                ActivateSource(mystore, item, objGlobal);
                        }
                        else
                        {
                            if (Regex.Match(strSplitRow[i], @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Singleline).Success)
                            {
                                int iCount = strSplitColumn.Where(x => string.IsNullOrWhiteSpace(x)).Select(x => x).Count();
                                if (lstLinks.Count == 0 || iCount > 0)
                                    objGlobal.ValidationFailureMail_Attachment(oUrlPollStatus, oUrlPollStatus.ContentString, "Rows does not contains 2 column");
                            }
                        }
                    }
                }
                #endregion
                // oUrlPollStatus.ChunkAttempt.LogComment("End structured");
                if (isStructured == false)
                {
                    List<Link> lstUpdates = oUrlPollStatus.LinkUpdates;
                    //  oUrlPollStatus.PollAttempt.LogComment("Not structured");

                    foreach (Link item in lstUpdates)
                        ActivateSource(mystore, item, objGlobal);
                }
                //  oUrlPollStatus.ChunkAttempt.LogComment("end activate");
            }
            catch (Exception ex)
            {
                oUrlPollStatus.PollAttempt.LogComment("Exception in Release source " + ex.Message + " Stacktrace : " + ex.StackTrace);
            }
        }
        private void ActivateSource(MySourceStore mystore, Link item, Global objGlobal)
        {
            #region Activate
            lock (mystore.locker)
            {
                if (!mystore.lstNewLink.Contains(item.Url))
                {
                    AddToGlobleListWithVariations(mystore, item.Url);


                    Match mat = Regex.Match(item.Url, @"(rbidocs?|rdocs?|pdfs?)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (mat.Success)
                    {
                        Match mathttp = Regex.Match(item.Url, @"https?(.*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (mathttp.Success)
                        {
                            string id = "NEWLINK_PDFSOURCE";
                            // objGlobal.ActivatePDFSource(mystore, mathttp, id);
                            Source PDFurl = new NEWSource();
                            Store.LoadURLSource("NEW_SOURCE", (NEWSource)PDFurl);
                            ((NEWSource)PDFurl).Url = "https" + mathttp.Groups[1].Value.Trim();//item.Url.Trim();
                            int i = mystore.m_iTotalAlertLinks++;

                            string Url_Id = "NEWLINK_PDFSOURCE" + i.ToString();
                            PDFurl.ID = Url_Id;
                            Store.Sources.AddSource(Url_Id, ref PDFurl);
                            PDFurl.Activate();


                            //Source PDFurl2 = new NEWSource();
                            //Store.LoadURLSource("NEW_SOURCE", (NEWSource)PDFurl2);
                            //((NEWSource)PDFurl2).Url = "https" + mathttp.Groups[1].Value.Trim();// item.Url.Trim();
                            //string Url_Id2 = "NEWLINK_PDFSOURCE" + i.ToString() + "_" + i.ToString();
                            //PDFurl2.ID = Url_Id2;
                            //Store.Sources.AddSource(Url_Id2, ref PDFurl2);
                            //PDFurl2.Activate();
                        }
                    }
                    else
                    {
                        if (Regex.Match(item.Title, @"\b+Bulletin|Weekly|Statistical|Supplement|Extract\b+", RegexOptions.IgnoreCase | RegexOptions.Multiline).Success)
                        {
                            Source Htmlurl = new NEWSource();
                            Store.LoadURLSource("NEW_SOURCE", (NEWSource)Htmlurl);
                            ((NEWSource)Htmlurl).Url = item.Url.Trim();
                            string Url_Id = "NEWLINK_HTMLSOURCE" + mystore.m_iTotalAlertLinks++.ToString();
                            Htmlurl.ID = Url_Id;
                            Store.Sources.AddSource(Url_Id, ref Htmlurl);
                            Htmlurl.Activate();
                        }
                    }

                }
            }
            #endregion
        }
        public override bool OnHistoryLoaded()
        {
            MySourceStore mystore = (MySourceStore)Store;
            List<Link> lstLink = History.LinkUpdates;
            for (int i = 0; i < lstLink.Count(); i++)
            {
                AddToGlobleListWithVariations(mystore, lstLink[i].Url);
                //mystore.lstNewLink.Add(lstLink[i].Url);
            }
            if (((MySourceStore)Store).isEnable == true)
            {


                List<int> lstId = new List<int>();

                foreach (Link item in lstLink)
                {
                    string prid = null;
                    if (this.ID != "RELEASE_SOURCE")
                    {
                        Match matchPrid = Regex.Match(item.Url, @"prid\s*\=\s*(\d+)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (matchPrid.Success)
                            prid = matchPrid.Groups[1].Value.Trim();

                    }
                    else
                    {
                        var uri = new Uri(item.Url);
                        var query = HttpUtility.ParseQueryString(uri.Query);
                        prid = query.Get("prid");
                        if (!string.IsNullOrWhiteSpace(prid))
                        {
                            if (string.IsNullOrWhiteSpace(((MySourceStore)Store).strUrl))
                                ((MySourceStore)Store).strUrl = this.Url;
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(prid))
                    {
                        lstId.Add(Convert.ToInt32(prid));
                        //if (string.IsNullOrWhiteSpace(((MySourceStore)Store).strUrl))
                        //    ((MySourceStore)Store).strUrl = this.Url;
                        // ((MySourceStore)Store).strUrl = uri.GetLeftPart(UriPartial.Path);

                    }
                }

                if (lstId.Count() != 0)
                {
                    ((MySourceStore)Store).iMaxId = lstId.Max();
                    //  ((MySourceStore)Store).iMaxId =39850;
                    for (int i = 0; i < 3; i++)
                    {
                        CallNewSource(++((MySourceStore)Store).iMaxId);
                    }
                }
            }
            return true;
        }

        private void AddToGlobleListWithVariations(MySourceStore mystore, string url)
        {
            string sHome1_Url = url;
            AddToGlobalList(mystore, sHome1_Url);
            if (sHome1_Url.Contains("https://www.rbi.org.in/"))
            {
                AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "http://www.rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "http://rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "https://rbi.org.in/"));
            }
            else if (sHome1_Url.Contains("http://www.rbi.org.in/"))
            {

                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://www.rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "http://rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://rbi.org.in/"));
            }
            else if (sHome1_Url.Contains("https://rbi.org.in/"))
            {
                AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "http://rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "http://www.rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "https://www.rbi.org.in/"));
            }
            else if (sHome1_Url.Contains("http://www.rbi.org.in/"))
            {

                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://www.rbi.org.in/"));
                AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "http://www.rbi.org.in/"));
            }
        }

        private void AddToGlobalList(MySourceStore mystore, string url)
        {
            try
            {
                mystore.lstNewLink.Add(url);
                mystore.lstNewLink.Add(HttpUtility.UrlDecode(url));
                mystore.lstNewLink.Add(HttpUtility.UrlEncode(url));

                url = url.ToLower();
                mystore.lstNewLink.Add(url);
                mystore.lstNewLink.Add(HttpUtility.UrlDecode(url));
                mystore.lstNewLink.Add(HttpUtility.UrlEncode(url));
            }
            catch { }
        }

        public void CallNewSource(int iMaxId)
        {
            if (((MySourceStore)Store).iCnt < 3)
            {
                Source urlNewSoure = new NEWSource();
                Store.LoadURLSource("NEW_SOURCE", (NEWSource)urlNewSoure);

                int i = ((MySourceStore)Store).iCnt;
                string Url_Id = "NEW_SOURCE" + i.ToString();
                ((NEWSource)urlNewSoure).Url = ((MySourceStore)Store).strUrl.Trim() + "?prid=" + iMaxId;
                urlNewSoure.ID = Url_Id;
                Store.Sources.AddSource(Url_Id, ref urlNewSoure);

                if (!((MySourceStore)Store).lstNewLink.Contains(((NEWSource)urlNewSoure).Url))
                {
                    //((MySourceStore)Store).lstNewLink.Add(((NEWSource)urlNewSoure).Url);
                    AddToGlobleListWithVariations(((MySourceStore)Store), ((NEWSource)urlNewSoure).Url);

                }
                ((MySourceStore)Store).lstobjSource.Add(urlNewSoure);
                ((MySourceStore)Store).iCnt++;

            }
        }

        internal void WaitUntilComplete()
        {
            var seleniumPollManager = (SeleniumPollManager)PollManager;

            var fluentWait = new DefaultWait<IWebDriver>(seleniumPollManager.Driver);
            fluentWait.Timeout = TimeSpan.FromSeconds(ConnectionTimeout);
            fluentWait.PollingInterval = TimeSpan.FromMilliseconds(250);
            fluentWait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            fluentWait.Until(x =>
            {
                if (x == null || !seleniumPollManager.IsDriverInitialized) return true;
                return x.FindElement(By.ClassName("footer")) != null;
            });
        }
    }

    public class NEWSource : Global
    {
        HtmlSource obj = new HtmlSource();
        private double iRegxTimeout = 10;

        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            try
            {
                MySourceStore mystore = (MySourceStore)Store;
                if ((Path.GetExtension(this.Url.Trim().ToUpper()) == ".XLSX") || (Path.GetExtension(oUrlPollStatus.ResponseUri.ToString().Trim().ToUpper()) == ".XLSX") ||
                    (Path.GetExtension(this.Url.Trim().ToUpper()) == ".XLS") || (Path.GetExtension(oUrlPollStatus.ResponseUri.ToString().Trim().ToUpper()) == ".XLS"))
                {
                    if (oUrlPollStatus.IsRequestCompleted)
                    {
                        if (this.Url != null && this.IsSourceBeingPolled)
                            this.Deactivate();
                        //Match matchID = Regex.Match(this.ID, @"^([^\d]*)(\d+)_(\2)\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        //if (matchID.Success)
                        //{
                        //    if (this.Url != null && this.IsSourceBeingPolled)
                        //        this.Deactivate();
                        //    string strID = matchID.Groups[1].Value + matchID.Groups[2].Value;
                        //    Source PDFsource = Store.Sources.GetSource(strID);
                        //    if (PDFsource != null && PDFsource.IsSourceBeingPolled)
                        //        PDFsource.Deactivate();
                        //}
                        //else
                        //{
                        //    Match matchID2 = Regex.Match(this.ID, @"^([^\d]*)(\d+)\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

                        //    if (this.Url != null && this.IsSourceBeingPolled)
                        //        this.Deactivate();
                        //    string strID = matchID.Groups[1].Value + matchID.Groups[2].Value + "_" + matchID.Groups[2].Value;
                        //    Source PDFsource = Store.Sources.GetSource(strID);
                        //    if (PDFsource != null && PDFsource.IsSourceBeingPolled)
                        //        PDFsource.Deactivate();
                        //}
                    }

                }
                if ((Path.GetExtension(this.Url.Trim().ToUpper()) == ".PDF") || (Path.GetExtension(oUrlPollStatus.ResponseUri.ToString().Trim().ToUpper()) == ".PDF") || (oUrlPollStatus?.ResponseHeaders[System.Net.HttpResponseHeader.ContentType]?.ToLower().Contains("pdf") == true))
                {
                    PDFNewSource(oUrlPollStatus, mystore);

                }
                else
                {
                    string strContent = oUrlPollStatus.ContentString;
                    HTMLNewSource(oUrlPollStatus, strContent, mystore);
                    string strBaseUrl = obj.GetBaseUri(strContent);
                    string strUrl = null;
                    if (!string.IsNullOrWhiteSpace(strBaseUrl))
                        strUrl = strBaseUrl;
                    else
                        strUrl = this.Url;

                    List<Link> lstLinks = obj.GetLinksFromContent(strUrl, strContent);

                    foreach (Link item in lstLinks)
                    {
                        Match mat = Regex.Match(item.Url, @"\s*(rbidocs?|rdocs?|pdfs?)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (mat.Success)
                        {
                            lock (mystore.locker)
                            {
                                if (!mystore.lstNewLink.Contains(item.Url, StringComparer.OrdinalIgnoreCase))
                                {
                                    AddToGlobleListWithVariations(mystore, item.Url);
                                    // mystore.lstNewLink.Add(item.Url);
                                    Match mathttp = Regex.Match(item.Url, @"https?(.*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    if (mathttp.Success)
                                    {
                                        Source PDFurl = new NEWSource();
                                        Store.LoadURLSource("NEW_SOURCE", (NEWSource)PDFurl);
                                        ((NEWSource)PDFurl).Url = "https" + mathttp.Groups[1].Value.Trim();//item.Url.Trim();
                                        int i = mystore.m_iTotalAlertLinks++;
                                        string Url_Id = "NEWLINK_PDFSOURCE_FROM_HTML" + i.ToString();
                                        PDFurl.ID = Url_Id;
                                        Store.Sources.AddSource(Url_Id, ref PDFurl);
                                        PDFurl.Activate();

                                        //Source PDFurl2 = new NEWSource();
                                        //Store.LoadURLSource("NEW_SOURCE", (NEWSource)PDFurl2);
                                        //((NEWSource)PDFurl2).Url = "https" + mathttp.Groups[1].Value.Trim();// item.Url.Trim();
                                        //string Url_Id2 = "NEWLINK_PDFSOURCE_FROM_HTML" + i.ToString() + "_" + i.ToString();
                                        //PDFurl2.ID = Url_Id2;
                                        //Store.Sources.AddSource(Url_Id2, ref PDFurl2);
                                        //PDFurl2.Activate();
                                    }
                                }

                            }//lock()
                        }
                    }

                }

            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in New source: " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        private void AddToGlobleListWithVariations(MySourceStore mystore, string url)
        {
            try
            {
                string sHome1_Url = url;
                AddToGlobalList(mystore, sHome1_Url);
                if (sHome1_Url.Contains("https://www.rbi.org.in/"))
                {
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "http://www.rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "http://rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://www.rbi.org.in/", "https://rbi.org.in/"));
                }
                else if (sHome1_Url.Contains("http://www.rbi.org.in/"))
                {

                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://www.rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "http://rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://rbi.org.in/"));
                }
                else if (sHome1_Url.Contains("https://rbi.org.in/"))
                {
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "http://rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "http://www.rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("https://rbi.org.in/", "https://www.rbi.org.in/"));
                }
                else if (sHome1_Url.Contains("http://www.rbi.org.in/"))
                {

                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "https://www.rbi.org.in/"));
                    AddToGlobalList(mystore, sHome1_Url.Replace("http://www.rbi.org.in/", "http://www.rbi.org.in/"));
                }
            }
            catch { }
        }

        private void AddToGlobalList(MySourceStore mystore, string url)
        {
            try
            {
                mystore.lstNewLink.Add(url);
                mystore.lstNewLink.Add(HttpUtility.UrlDecode(url));
                mystore.lstNewLink.Add(HttpUtility.UrlEncode(url));

                url = url.ToLower();
                mystore.lstNewLink.Add(url);
                mystore.lstNewLink.Add(HttpUtility.UrlDecode(url));
                mystore.lstNewLink.Add(HttpUtility.UrlEncode(url));
            }
            catch { }
        }
        private void HTMLNewSource(UrlPollStatus oUrlPollStatus, string strContent, MySourceStore mystore)
        {
            try
            {
                if (!oUrlPollStatus.IsRequestCompleted)
                {
                    return;
                }
                if (string.IsNullOrWhiteSpace(strContent))
                    oUrlPollStatus.PollAttempt.LogComment("Content in html source is null or empty");
                else
                {
                    LlmDataParser llmDataParser = new LlmDataParser();
                    LlmSourceStore llmSourceStore = new LlmSourceStore();
                    var htmlContent = strContent;

                    strContent = Regex.Replace(strContent, @"₹", "");
                    strContent = Regex.Replace(strContent, @"&nbsp;", " ", RegexOptions.IgnoreCase);
                    strContent = System.Web.HttpUtility.HtmlDecode(strContent);
                    strContent = Regex.Replace(strContent, @"<!--(.|\s)*?-->", "", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
                    strContent = Regex.Replace(strContent, "<(script|style).*?>.*?</(script|style)[\\s]*>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
                    strContent = Regex.Replace(strContent, @"[\r\n]+", " ", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"<table[^>]*>", "****\r\n", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"</table>", "####\r\n", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"</tr>", "||||\r\n", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"</td>\s*</tr>", "@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"</td>", "@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"</th>", "@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"<[a-zA-Z\/][^>]*>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    strContent = Regex.Replace(strContent, @"–", "-", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    Match matchHeader;
                    matchHeader = Regex.Match(strContent, @"^\s*date\W+(\d{1,2})\W*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{4})\s*(\@){4}\s*(\|){4}[\r\n]+\s*^.*?weekly\s*statistical\s*supplement", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (!matchHeader.Success)
                        matchHeader = Regex.Match(strContent, @"^\s*date\W+(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4})\s*(\@){4}\s*(\|){4}[\r\n]+\s*^.*?weekly\s*statistical\s*supplement", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (!matchHeader.Success)
                        matchHeader = Regex.Match(strContent, @"Published\s*on\W+(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4}).*?weekly\s*statistical\s*supplement", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchHeader.Success)
                    {
                        string Code = "India Standard Time";
                        DateTime dtDate = new DateTime();
                        if (DateTime.TryParseExact(Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY").Value.Trim().Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDate) == true)
                        {
                            DateTime dtReleaseDate = new DateTime();
                            string strReleaseDate = Convert.ToDateTime(matchHeader.Groups[1].Value.Trim() + " " + matchHeader.Groups[2].Value.Trim() + " " + matchHeader.Groups[3].Value.Trim()).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture);
                            if (DateTime.TryParseExact(strReleaseDate.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtReleaseDate) == true)
                            {
                                DateTime dtNow = Convert.ToDateTime(GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store).ToShortDateString());

                                DateTime dtWeeklastDate = dtReleaseDate.AddDays(7);
                                oUrlPollStatus.PollAttempt.LogComment(dtNow.ToShortDateString());
                                oUrlPollStatus.PollAttempt.LogComment(dtWeeklastDate.ToShortDateString());
                                oUrlPollStatus.PollAttempt.LogComment(dtReleaseDate.ToShortDateString());
                                if ((dtNow >= dtReleaseDate) && (dtNow < dtWeeklastDate))
                                {
                                    AlertPublicationMessage objAlertLiaAsset = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_LOAN_ADV");
                                    StoryPublicationMessage objStoryLiaAsset = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_LOAN_ADV");

                                    AlertPublicationMessage objAlertForex = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_FOREX");
                                    StoryPublicationMessage objStoryForex = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_FOREX");
                                    EconPublicationMessage objEconForex = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INFXR=ECI");

                                    AlertPublicationMessage objAlertbankloan = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKLOAN");
                                    AlertPublicationMessage objAlertbankDeposit = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKDEPOSIT");
                                    StoryPublicationMessage objStorybank = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_BANK");
                                    EconPublicationMessage objEconLoan = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INLOAN=ECI");
                                    EconPublicationMessage objEconDeposit = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INDEP=ECI");

                                    AlertPublicationMessage objAlertOMO = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_OMO");
                                    StoryPublicationMessage objStoryOMO = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_OMO");

                                    AlertPublicationMessage objAlertLiaAssetLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_LOAN_ADV_LLM");
                                    AlertPublicationMessage objAlertForexLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_FOREX_LLM");
                                    AlertPublicationMessage objAlertbankloanLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKLOAN_LLM");
                                    AlertPublicationMessage objAlertbankDepositLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKDEPOSIT_LLM");
                                    AlertPublicationMessage objAlertOMOLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_OMO_LLM");

									Task.Run(async () =>
                                    {
                                        AlertDetailsFromLLM alertDetailsFromLLM = null;

                                        if (!mystore.IsLLMReqSent && !string.IsNullOrEmpty(htmlContent) && oUrlPollStatus.IsRequestCompleted && oUrlPollStatus.Content.Length > 50000)
                                        {
                                            mystore.IsLLMReqSent = true;
                                            alertDetailsFromLLM = await llmDataParser.GetLLMResponse(htmlContent, mystore);

                                            if (alertDetailsFromLLM != null)
                                            {
                                                llmSourceStore.LlmAlertTemplate(alertDetailsFromLLM, objAlertLiaAssetLLM, objAlertForexLLM, objAlertbankloanLLM, objAlertbankDepositLLM, objAlertOMOLLM, mystore, dtDate, oUrlPollStatus);
                                            }
                                        }
                                        else
                                        {
                                            mystore.AutomationClient.OperatorLog("LLM Request already sent once!");
                                        }
                                        //if (objAlertLiaAssetLLM.AlertTemplate != null && objAlertForexLLM.AlertTemplate != null && objAlertbankloanLLM.AlertTemplate != null && objAlertbankDepositLLM.AlertTemplate != null && objAlertOMOLLM.AlertTemplate != null)
                                        //	{

                                        //}
                                    });

                                    LiabilitesAssets(strContent, oUrlPollStatus, dtDate, objAlertLiaAsset, objStoryLiaAsset);
                                    // string strRecommendValues = null;
                                    ForeignExchangeReserve(strContent, oUrlPollStatus, dtDate, objAlertForex, objStoryForex, objEconForex);
                                    CommericalBank(strContent, oUrlPollStatus, dtDate, objAlertbankDeposit, objAlertbankloan, objStorybank, objEconLoan, objEconDeposit);
                                    LiquidityOMONew(strContent, oUrlPollStatus, dtDate, objAlertOMO, objStoryOMO);

                                    Deactivate_Recommend(dtDate, objAlertLiaAsset, objStoryLiaAsset, objAlertForex, objStoryForex, objEconForex, objAlertbankloan, objAlertbankDeposit, objStorybank, objEconLoan, objEconDeposit, objAlertOMO, objStoryOMO, objAlertLiaAssetLLM, objAlertForexLLM, objAlertbankloanLLM, objAlertbankDepositLLM, objAlertOMOLLM, mystore);
                                }
                            }
                        }
                    }
                    else
                    {
                        //ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Release header not found");
                        oUrlPollStatus.PollAttempt.LogComment("Release header not found");
                        if (oUrlPollStatus.IsRequestCompleted)
                        {
                            //MySourceStore mystore = (MySourceStore)Store;
                            if (this.Url != null && this.IsSourceBeingPolled)
                            {
                                Match matchPress = Regex.Match(strContent, @"press\W*release\W*\d+\W*\d+", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                if (matchPress.Success)
                                {
                                    Deactivate();
                                    if (mystore.isEnable == true)
                                    {
                                        if (mystore.iMaxId != 0)
                                        {
                                            for (int k = 0; k < mystore.lstobjSource.Count; k++)
                                            {
                                                Source urlNewSoure = mystore.lstobjSource[k];
                                                lock (mystore.locker)
                                                {
                                                    if (urlNewSoure.IsSourceBeingPolled == false)
                                                    {
                                                        urlNewSoure.PollManager = new URLPollManager(urlNewSoure);
                                                        string strURL = ((MySourceStore)Store).strUrl.Trim() + "?prid=" + ++mystore.iMaxId;
                                                        ((NEWSource)urlNewSoure).Url = strURL;
                                                        //bool flag = false;
                                                        //lock (mystore.locker)
                                                        //{
                                                        if (!mystore.lstNewLink.Contains(((NEWSource)urlNewSoure).Url, StringComparer.OrdinalIgnoreCase))
                                                        {
                                                            //mystore.lstNewLink.Add(((NEWSource)urlNewSoure).Url);
                                                            AddToGlobleListWithVariations(mystore, ((NEWSource)urlNewSoure).Url);
                                                            Store.PerformanceLog.LogComment(strURL + "===>" + urlNewSoure.ID);
                                                            ((NEWSource)urlNewSoure).Activate();
                                                        }
                                                        break;
                                                    }
                                                }
                                            }//for
                                        }
                                    }
                                }
                            }
                        }
                    }
                }//is null or empty
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Html source: " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }

        private void Deactivate_Recommend(DateTime dtDate, AlertPublicationMessage objAlertLiaAsset, StoryPublicationMessage objStoryLiaAsset, AlertPublicationMessage objAlertForex, StoryPublicationMessage objStoryForex, EconPublicationMessage objEconForex, AlertPublicationMessage objAlertbankloan, AlertPublicationMessage objAlertbankDeposit, StoryPublicationMessage objStorybank, EconPublicationMessage objEconLoan, EconPublicationMessage objEconDeposit, AlertPublicationMessage objAlertOMO, StoryPublicationMessage objStoryOMO,
            AlertPublicationMessage objAlertLiaAssetLLM, AlertPublicationMessage objAlertForexLLM, AlertPublicationMessage objAlertbankloanLLM, AlertPublicationMessage objAlertbankDepositLLM, AlertPublicationMessage objAlertOMOLLM, MySourceStore mySourceStore
            )
        {
            if ((objAlertForex.IsSent == true) && (objStoryForex.IsSent == true) && (objEconForex.IsSent == true) && (!string.IsNullOrWhiteSpace(((MySourceStore)Store).strRecommendValues)))
            {
                Store.PerformanceLog.AddOrUpdateRecommendedNextRunSettingValue("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE", ((MySourceStore)Store).strRecommendValues);
            }
            if ((objAlertLiaAsset.IsSent == true) || (objStoryLiaAsset.IsSent == true)
                || (objAlertbankloan.IsSent == true) || (objAlertbankDeposit.IsSent == true) || (objStorybank.IsSent == true)
                || (objEconDeposit.IsSent == true) || (objEconLoan.IsSent == true)
                || (objAlertOMO.IsSent == true) || (objStoryOMO.IsSent == true)
                || (objAlertForex.IsSent == true) || (objStoryForex.IsSent == true) || (objEconForex.IsSent == true)
                || (objAlertLiaAssetLLM.IsSent == true) || (objAlertForexLLM.IsSent == true) || (objAlertbankDepositLLM.IsSent == true) || (objAlertOMOLLM.IsSent == true)
                )
            {
                Store.PerformanceLog.AddOrUpdateRecommendedNextRunSettingValue("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY", dtDate.AddDays(7).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture));
                Store.PerformanceLog.AddOrUpdateRecommendedNextRunSettingValue("PREVIOUS_WEEK_DD-MMM-YYYY", dtDate.ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture));
            }
            if ((objAlertLiaAsset.IsSent == true) && (objStoryLiaAsset.IsSent == true)
                && (objAlertbankloan.IsSent == true) && (objAlertbankDeposit.IsSent == true) && (objStorybank.IsSent == true)
                && (objEconDeposit.IsSent == true) && (objEconLoan.IsSent == true)
                && (objAlertOMO.IsSent == true) && (objStoryOMO.IsSent == true)
                && (objAlertForex.IsSent == true) && (objStoryForex.IsSent == true) && (objEconForex.IsSent == true)
                && (objAlertLiaAssetLLM.IsSent == true) && (objAlertForexLLM.IsSent == true) && (objAlertbankDepositLLM.IsSent == true) && (objAlertOMOLLM.IsSent == true)
                )
            {
                foreach (Source source in Store.Sources.GetAllSources())
                {
                    if (source != null && source.IsSourceBeingPolled)
                    {
                        source.Deactivate();
                    }
                }


            }
            else if ((objAlertLiaAsset.IsSent == true) && (objStoryLiaAsset.IsSent == true)
                && (objAlertbankloan.IsSent == true) && (objAlertbankDeposit.IsSent == true) && (objStorybank.IsSent == true)
                && (objEconDeposit.IsSent == true) && (objEconLoan.IsSent == true)
                && (objAlertOMO.IsSent == true) && (objStoryOMO.IsSent == true)
                && (objAlertForex.IsSent == true) && (objStoryForex.IsSent == true) && (objEconForex.IsSent == true)
                && (mySourceStore.IshandbrakeAlertbankDepositLLM == true) && (mySourceStore.IshandbrakeAlertbankDepositLLM == true) && (mySourceStore.IshandbrakeAlertbankloanLLM == true) && (mySourceStore.IshandbrakeAlertLiaAssetLLM == true)
                )
            {
                foreach (Source source in Store.Sources.GetAllSources())
                {
                    if (source != null && source.IsSourceBeingPolled)
                    {
                        source.Deactivate();
                    }
                }


            }

        }
        private void PDFNewSource(UrlPollStatus oUrlPollStatus, MySourceStore mystore)
        {
            if (!oUrlPollStatus.IsRequestCompleted)
            {
                return;
            }

            PDFToText objpdftotext = new PDFToText();
            byte[] buffercontent = null;
            string strConverted_Text = null;
            string strError = "";
            buffercontent = oUrlPollStatus.Content;
            LlmDataParser llmDataParser = new LlmDataParser();
            LlmSourceStore llmSourceStore = new LlmSourceStore();


            if (buffercontent != null)
            {
                oUrlPollStatus.PollAttempt.LogComment("PDf start");

                objpdftotext.PDFVersionType = PDFVerionTypeEnum.WinnovativePDFTOText_2012;
                objpdftotext.GetPDFTotext(buffercontent, ref strConverted_Text, ref strError);

                // strConverted_Text = objpdftotext.PdfToText(buffercontent, ref strError);
                oUrlPollStatus.PollAttempt.LogComment("PDf end");

            }
            //strConverted_Text = Encoding.GetString(oUrlPollStatus.Content);
            //strConverted_Text = Regex.Replace(strConverted_Text, @"₹", "");
            //strConverted_Text = Regex.Replace(strConverted_Text, @"–", "-", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            if (!string.IsNullOrWhiteSpace(strConverted_Text))
            {
                if (string.IsNullOrWhiteSpace(strError))
                {
                    strConverted_Text = Regex.Replace(strConverted_Text, @"₹", "");
                    strConverted_Text = Regex.Replace(strConverted_Text, @"##########==========----------X----------=========##########", "\r\n\r\n");
                    strConverted_Text = Regex.Replace(strConverted_Text, @"–", " -", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    string strDate = @"^\s*(?:date\W+)?(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4})\s*[\r\n]+\s*^.*?weekly\s*statistical\s*supplement";
                    Match matchHeader = null;
                    Match matchDatePageHeader = Regex.Match(strConverted_Text, strDate, RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (!matchDatePageHeader.Success)
                    {
                        strDate = @"^\s*(?:date\W+)?(\d{1,2})\W*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{4})\s*[\r\n]+\s*^.*?weekly\s*statistical\s*supplement";
                        matchDatePageHeader = Regex.Match(strConverted_Text, strDate, RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        matchHeader = matchDatePageHeader;
                    }
                    else
                        matchHeader = matchDatePageHeader;
                    if (matchHeader.Success)
                    {
                        string Code = "India Standard Time";
                        DateTime dtDate = new DateTime();
                        if (DateTime.TryParseExact(Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY").Value.Trim().Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDate) == true)
                        {
                            DateTime dtReleaseDate = new DateTime();
                            string strReleaseDate = Convert.ToDateTime(matchHeader.Groups[1].Value.Trim() + " " + matchHeader.Groups[2].Value.Trim() + " " + matchHeader.Groups[3].Value.Trim()).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture);
                            if (DateTime.TryParseExact(strReleaseDate.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtReleaseDate) == true)
                            {
                                AlertPublicationMessage objAlertLiaAsset = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_LOAN_ADV");
                                StoryPublicationMessage objStoryLiaAsset = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_LOAN_ADV");

                                AlertPublicationMessage objAlertForex = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_FOREX");
                                StoryPublicationMessage objStoryForex = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_FOREX");
                                EconPublicationMessage objEconForex = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INFXR=ECI");

                                AlertPublicationMessage objAlertbankloan = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKLOAN");
                                AlertPublicationMessage objAlertbankDeposit = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKDEPOSIT");
                                StoryPublicationMessage objStorybank = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_BANK");
                                EconPublicationMessage objEconLoan = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INLOAN=ECI");
                                EconPublicationMessage objEconDeposit = (EconPublicationMessage)PublicationMessages.GetPublicationMessage("INDEP=ECI");

                                AlertPublicationMessage objAlertOMO = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_OMO");
                                StoryPublicationMessage objStoryOMO = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage("STORY_OMO");

                                AlertPublicationMessage objAlertLiaAssetLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_LOAN_ADV_LLM");
                                AlertPublicationMessage objAlertForexLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_FOREX_LLM");
                                AlertPublicationMessage objAlertbankloanLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKLOAN_LLM");
                                AlertPublicationMessage objAlertbankDepositLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_BANKDEPOSIT_LLM");
                                AlertPublicationMessage objAlertOMOLLM = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage("ALERT_OMO_LLM");

                                DateTime dtNow = Convert.ToDateTime(GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store).ToShortDateString());

                                DateTime dtWeeklastDate = dtReleaseDate.AddDays(7);
								var ABC = oUrlPollStatus.Content.Length;
								if ((dtNow >= dtReleaseDate) && (dtNow < dtWeeklastDate))
                                {
                                    Task.Run(async () =>
                                    {
                                        AlertDetailsFromLLM alertDetailsFromLLM = null;

                                        if (!mystore.IsLLMReqSent && !string.IsNullOrEmpty(strConverted_Text) && oUrlPollStatus.IsRequestCompleted && oUrlPollStatus.Content.Length > 100000)
                                        {
                                            mystore.IsLLMReqSent = true;
                                            alertDetailsFromLLM = await llmDataParser.GetLLMResponse(strConverted_Text, mystore);

                                            if (alertDetailsFromLLM != null)
                                            {
                                                llmSourceStore.LlmAlertTemplate(alertDetailsFromLLM, objAlertLiaAssetLLM, objAlertForexLLM, objAlertbankloanLLM, objAlertbankDepositLLM, objAlertOMOLLM, mystore, dtDate, oUrlPollStatus);
                                            }
                                        }
                                        else
                                        {
                                            mystore.AutomationClient.OperatorLog("LLM Request already sent once!");
                                        }
                                        //if (objAlertLiaAssetLLM.AlertTemplate != null && objAlertForexLLM.AlertTemplate != null && objAlertbankloanLLM.AlertTemplate != null && objAlertbankDepositLLM.AlertTemplate != null && objAlertOMOLLM.AlertTemplate != null)
                                        //	{

                                        //}
                                    });
                                    //         oUrlPollStatus.PollAttempt.LogComment("outstanding loan start");
                                    PDF_LiabilitiesAsset_OutstandingTable(dtDate, oUrlPollStatus, strConverted_Text, objAlertLiaAsset, objStoryLiaAsset);
                                    // oUrlPollStatus.PollAttempt.LogComment("outstanding loan end");
                                    // string strRecommendValues = null;
                                    // oUrlPollStatus.PollAttempt.LogComment("Forex start");
                                    PDF_ForexTableExtraction(oUrlPollStatus, strConverted_Text, objAlertForex, objStoryForex, objEconForex);
                                    // oUrlPollStatus.PollAttempt.LogComment("Forex end");
                                    // oUrlPollStatus.PollAttempt.LogComment("Commercial start");
                                    PDF_ScheduledBank(oUrlPollStatus, strConverted_Text, dtDate, objEconDeposit, objAlertbankDeposit, objEconLoan, objAlertbankloan, objStorybank);
                                    // oUrlPollStatus.PollAttempt.LogComment("Commercial end");
                                    //oUrlPollStatus.PollAttempt.LogComment("OMO start");
                                    PDF_LiquidityOMO(oUrlPollStatus, strConverted_Text, dtDate, objAlertOMO, objStoryOMO);
                                    // oUrlPollStatus.PollAttempt.LogComment("OMO end");
                                    Deactivate_Recommend(dtDate, objAlertLiaAsset, objStoryLiaAsset, objAlertForex, objStoryForex, objEconForex, objAlertbankloan, objAlertbankDeposit, objStorybank, objEconLoan, objEconDeposit, objAlertOMO, objStoryOMO, objAlertLiaAssetLLM, objAlertForexLLM, objAlertbankloanLLM, objAlertbankDepositLLM, objAlertOMOLLM, mystore);
                                    //if ((objAlertLiaAsset.IsSent == true) && (objStoryLiaAsset.IsSent == true)
                                    //    && (objAlertbankloan.IsSent == true) && (objAlertbankDeposit.IsSent == true) && (objStorybank.IsSent == true)
                                    //    && (objEconDeposit.IsSent == true) && (objEconLoan.IsSent == true)
                                    //    && (objAlertOMO.IsSent == true) && (objStoryOMO.IsSent == true)
                                    //    && (objAlertForex.IsSent = true) && (objStoryForex.IsSent == true) && (objEconForex.IsSent == true))
                                    //{
                                    //    foreach (Source source in Store.Sources.GetAllActiveSources())
                                    //    {
                                    //        if (source != null && source.IsSourceBeingPolled)
                                    //        {
                                    //            source.Deactivate();
                                    //        }
                                    //    }
                                    //    Store.PerformanceLog.AddRecommendedNextRunSettingValue("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY", dtDate.AddDays(7).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture));
                                    //    Store.PerformanceLog.AddRecommendedNextRunSettingValue("PREVIOUS_WEEK_DD-MMM-YYYY", dtDate.ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture));
                                    //    Store.PerformanceLog.AddRecommendedNextRunSettingValue("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE", strRecommendValues);
                                    //}
                                }
                                else
                                    ValidationFailureMail(oUrlPollStatus, strConverted_Text, "Date is not between range in PDF source");
                            }
                            else
                                oUrlPollStatus.PollAttempt.LogComment("Header date parsing error");
                        }
                        else
                            oUrlPollStatus.PollAttempt.LogComment("Setting date parsing error");
                    }
                    else
                    {
                        oUrlPollStatus.PollAttempt.LogComment("Page header doesnot match from PDF source=== URL : " + oUrlPollStatus.Source.Url);
                        // ValidationFailureMail(oUrlPollStatus, strConverted_Text, "Page header doesnot match");
                        if (oUrlPollStatus.IsRequestCompleted)
                        {
                            if (this.Url != null && this.IsSourceBeingPolled)
                                this.Deactivate();
                            //Match matchID = Regex.Match(this.ID, @"^([^\d]*)(\d+)_(\2)\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            //if (matchID.Success)
                            //{
                            //    if (this.Url != null && this.IsSourceBeingPolled)
                            //        this.Deactivate();
                            //    string strID = matchID.Groups[1].Value + matchID.Groups[2].Value;
                            //    Source PDFsource = Store.Sources.GetSource(strID);
                            //    if (PDFsource != null && PDFsource.IsSourceBeingPolled)
                            //        PDFsource.Deactivate();
                            //}
                            //else
                            //{
                            //    Match matchID2 = Regex.Match(this.ID, @"^([^\d]*)(\d+)\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

                            //    if (this.Url != null && this.IsSourceBeingPolled)
                            //        this.Deactivate();
                            //    string strID = matchID.Groups[1].Value + matchID.Groups[2].Value + "_" + matchID.Groups[2].Value;
                            //    Source PDFsource = Store.Sources.GetSource(strID);
                            //    if (PDFsource != null && PDFsource.IsSourceBeingPolled)
                            //        PDFsource.Deactivate();
                            //}
                        }
                    }
                }
                else
                    oUrlPollStatus.PollAttempt.LogComment("Error in Converting PDF to Text in Result source: " + strError);
            }
            else
                oUrlPollStatus.PollAttempt.LogComment("ERROR in Result source : PDF Converted text is null or empty");
        }

        private void LiabilitesAssets(string strContent, UrlPollStatus oUrlPollStatus, DateTime dtDate, AlertPublicationMessage objAlertLiaAsset, StoryPublicationMessage objStoryLiaAsset)
        {
            try
            {
                MySourceStore mystore = (MySourceStore)Store;
                LlmDataParser llmDataParser = new LlmDataParser();
                LlmSourceStore LlmStore = new LlmSourceStore();

                bool cbIsUnitCrore = false;
                // string strRegex_liabilites = @"(\*){4}\s*.*?Liabilit(ies|y)\s*and\s*Assets?.*?[\r\n]+([^#]*[\r\n]+){1,}\s*####";
                string strRegex_liabilites = @"(\*){4}\s*.*?Liabilit(ies|y)\s*and\s*Assets?.*?[\r\n]+(.*?)\s*####";
                Match matchLiabilitiestable = Regex.Match(strContent, strRegex_liabilites, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchLiabilitiestable.Success)
                {

                    Match matchUnit = Regex.Match(matchLiabilitiestable.Value, @"^\s*(\()?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*(\))?\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchUnit.Success)
                    {
                        string csUnit = matchUnit.Groups[2].Captures[0].Value.Trim();
                        if (csUnit.ToLower().Contains("cr"))
                            cbIsUnitCrore = true;
                        string strRegex = @"(\d+)?\s*Loans?\s*(?:and|&)\s*Advance(s)?.*?[\r\n]+\s*(\d+)?\W*(\d+)?\s*(central|state)\s*(governments?|govt).*?[\r\n]+\s*(\d+)?\W*(\d+)?\s*(central|state)\s*(governments?|govt).*?[\r\n]+";
                        Match match = Regex.Match(matchLiabilitiestable.Value, strRegex, RegexOptions.Multiline | RegexOptions.IgnoreCase);
                        if (match.Success)
                        {
                            MatchCollection matchYear;
                            if (dtDate.Month == 12)
                            {
                                DateTime dtStartDecWeek = new DateTime(dtDate.Year, dtDate.Month, 24);
                                DateTime dtEndDecWeek = new DateTime(dtDate.AddYears(1).Year, dtDate.AddMonths(1).Month, 10);
                                if ((dtDate >= dtStartDecWeek) && (dtDate <= dtEndDecWeek))
                                    matchYear = Regex.Matches(matchLiabilitiestable.Value, @"(?:" + (Convert.ToInt32(dtDate.Year) - 1).ToString() + "|" + dtDate.Year + ")" + @"\s*(\@){4}\s*" + dtDate.Year, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                else
                                    matchYear = Regex.Matches(matchLiabilitiestable.Value, (Convert.ToInt32(dtDate.Year) - 1).ToString() + @"\s*(\@){4}\s*" + dtDate.Year, RegexOptions.IgnoreCase | RegexOptions.Multiline);

                            }
                            else
                                matchYear = Regex.Matches(matchLiabilitiestable.Value, (Convert.ToInt32(dtDate.Year) - 1).ToString() + @"\s*(\@){4}\s*" + dtDate.Year, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchYear.Count == 1)
                            {
                                string strRegex_Week = @"^.*?((january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*\d{1,2}\W*(\@){4}\s*){1,}.*?(\|){4}";
                                MatchCollection matchWeek = Regex.Matches(matchLiabilitiestable.Value, strRegex_Week, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                if (matchWeek.Count == 1)
                                {
                                    MatchCollection matchState = Regex.Matches(match.Value, @"States?\s*(?:governments?|govt)\s*(\@){4}(.*?)(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    MatchCollection matchCentral = Regex.Matches(match.Value, @"Central\s*(?:governments?|govt)\s*(\@){4}(.*?)(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    if ((matchState.Count == 1) && (matchCentral.Count == 1))
                                    {
                                        string[] strArrCentral = null;
                                        string[] strArrState = null;
                                        string[] strarrWeek = Regex.Split(matchWeek[0].Value, "@@@@");
                                        if (csUnit.ToLower().Contains("cr"))
                                        {
                                            strArrCentral = Regex.Split(matchCentral[0].Groups[2].Value, "@@@@");
                                            strArrState = Regex.Split(matchState[0].Groups[2].Value, "@@@@");
                                            strArrCentral = GetValuesinBillions(strArrCentral);
                                            strArrState = GetValuesinBillions(strArrState);
                                        }
                                        else
                                        {
                                            strArrCentral = Regex.Split(matchCentral[0].Groups[2].Value, "@@@@");
                                            strArrState = Regex.Split(matchState[0].Groups[2].Value, "@@@@");
                                        }
                                        if ((strarrWeek.Count() == strArrCentral.Count()) && (strArrCentral.Count() == strArrState.Count()) && (matchWeek[0].Groups[1].Captures.Count == 3))
                                        {
                                            int iPosWeekint = Array.FindLastIndex(strarrWeek, x => Regex.Match(x, @"(" + dtDate.ToString("MMM", CultureInfo.InvariantCulture) + "|" + dtDate.ToString("MMMM", CultureInfo.InvariantCulture) + @")\W*" + "(" + dtDate.Day + "|" + dtDate.ToString("dd", CultureInfo.InvariantCulture) + ")", RegexOptions.IgnoreCase).Success);
                                            if (iPosWeekint != -1)
                                            {
                                                string strCentralValue = strArrCentral[iPosWeekint].Trim();
                                                string strStateValue = strArrState[iPosWeekint].Trim();
                                                string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
                                                if (objAlertLiaAsset.IsSent == false)
                                                    AlertFilling_LiabilitiesAsset(oUrlPollStatus, dtDate, strCentralValue, str_arrShortEngMonth, objAlertLiaAsset);
                                                StoryFiliingLiaAsset(oUrlPollStatus, dtDate, objStoryLiaAsset, strarrWeek, strArrCentral, strCentralValue, strArrState, strStateValue, str_arrShortEngMonth);


                                            }//cweek index=-1
                                        }
                                        else
                                        {
                                            ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Array count not equal for table Liabilities and asset");
                                        }
                                    }
                                    else
                                    {
                                        ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Central or state government not found from table Liabilities and asset");
                                    }
                                }
                                else
                                {
                                    ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Week dates not found from table Liabilities and asset");
                                }
                            }
                            else
                            {
                                ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Year not found from table Liabilities and asset");
                            }
                        }
                        else
                        {
                            ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Loans and advance header not found from table Liabilities and asset");
                        }
                    }
                    else
                    {
                        ValidationFailureMail(oUrlPollStatus, matchLiabilitiestable.Value, "Unit(Billion) not found from table Liabilities and asset");
                    }
                }
                else
                {
                    oUrlPollStatus.PollAttempt.LogComment("Liabilities and asset table not found");
                    // ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Liabilities and asset table not found");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in LiabilitesAssets : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        private void ForeignExchangeReserve(string strContent, UrlPollStatus oUrlPollStatus, DateTime dtDate, AlertPublicationMessage objAlertForex, StoryPublicationMessage objStoryForex, EconPublicationMessage objEconForex)
        {
            try
            {
                string strRegex_ForexTable = @"(\*){4}\s*\d{1,}\W*(Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?.*?[\r\n]+([^#]*[\r\n]+){1,}\W*####";
                Match matchForexTable = Regex.Match(strContent, strRegex_ForexTable, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchForexTable.Success)
                {
                    oUrlPollStatus.ChunkAttempt.LogComment("Forex table content : " + matchForexTable.Value);
                    Match matchForexHeader = null;
                    string strRegxForexHeader = @"^(.*?)As\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\W*(\d{1,2})\W+(\d{4})\s*(\@){4}.*?[\r\n]+";
                    Match matchForexHeader1 = Regex.Match(matchForexTable.Value, strRegxForexHeader, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchForexHeader1.Success)
                        matchForexHeader = matchForexHeader1;
                    else
                    {
                        Match matchForexHeader2 = Regex.Match(matchForexTable.Value, @"^(.*?)As\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\W*(\d{1,2})\W*(?:\@){4}.*?[\r\n]+\s*(\d{4})\s*(\@){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matchForexHeader2.Success)
                            matchForexHeader = matchForexHeader2;
                    }
                    if (matchForexHeader.Success)
                    {
                        string strPickedmonth = Regex.Replace(matchForexHeader.Groups[2].Value.Trim(), @"^sept$", "sep", RegexOptions.IgnoreCase);
                        oUrlPollStatus.ChunkAttempt.LogComment("Forex table header : " + matchForexHeader.Value);
                        DateTime dtDateFilling = Convert.ToDateTime(matchForexHeader.Groups[3].Value.Trim() + " " + strPickedmonth.Trim() + " " + matchForexHeader.Groups[4].Value.Trim());
                        oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling : " + dtDateFilling.ToString());
                        int iFirsttd = 0;
                        bool blnUnitFlag = false;

                        MatchCollection matches = Regex.Matches(matchForexHeader.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matches.Count == 1)
                            iFirsttd++;
                        Match matchUnit = Regex.Match(matchForexTable.Value.Trim(), @"^(.*?)`?\s*(bn|bln|billions|crore|crores|cr?)\W*(\@){4}\s*us\s*\$\s*(Mn|mln|millions?)\W*(\@){4}.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matchUnit.Success)
                        {
                            MatchCollection matchesunitSPlit = Regex.Matches(matchUnit.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchesunitSPlit.Count == 1)
                            {
                                iFirsttd++;
                                blnUnitFlag = true;
                            }
                            Match matchExtraline = Regex.Match(matchForexTable.Value, @"^(.*?)week\s*(\@){4}.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchExtraline.Success)
                            {
                                MatchCollection matchesExtralineSPlit = Regex.Matches(matchExtraline.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                if (matchesunitSPlit.Count == 1)
                                    iFirsttd++;
                            }

                            if (iFirsttd == 1)
                            {
                                if (((blnUnitFlag == true) && (string.IsNullOrWhiteSpace(matchForexTable.Groups[1].Value))) || (blnUnitFlag == false) && (!string.IsNullOrWhiteSpace(matchForexTable.Groups[1].Value)))
                                {
                                    Match matchTotalReserve = Regex.Match(matchForexTable.Value.Trim(), @"Total\s*Reserves?\s*#?\s*(\@){4}(.*?)(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    Match matchForeignCurrencyAsset = Regex.Match(matchForexTable.Value.Trim(), @"Foreign\s*Currency\s*Assets?\s*#?\s*(\@){4}(.*?)(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    Match matchGold = Regex.Match(matchForexTable.Value.Trim(), @"gold\s*#?\s*(\@){4}(.*?)(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    Match matchSDR = Regex.Match(matchForexTable.Value.Trim(), @"SDRs?\s*#?\s*(\@){4}(.*?)(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    Match matchIMF = Regex.Match(matchForexTable.Value.Trim(), @"Reserves?\s*Positions?\s*in\s*(the)?\s*IMF?\s*#?\s*(\@){4}(.*?)(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    if ((matchTotalReserve.Success) && (matchForeignCurrencyAsset.Success) && (matchGold.Success) && (matchSDR.Success) && (matchIMF.Success))
                                    {
                                        string[] strArrTotalReserve = Regex.Split(matchTotalReserve.Groups[2].Value.Trim(), @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        string[] strArrForeignCurrencyAsset = Regex.Split(matchForeignCurrencyAsset.Groups[2].Value.Trim(), @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        string[] strArrGold = Regex.Split(matchGold.Groups[2].Value.Trim(), @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        string[] strArrSDR = Regex.Split(matchSDR.Groups[2].Value.Trim(), @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        string[] strArrIMF = Regex.Split(matchIMF.Groups[3].Value.Trim(), @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        if ((strArrTotalReserve.Count() == strArrForeignCurrencyAsset.Count()) && (strArrForeignCurrencyAsset.Count() == strArrGold.Count()) && (strArrGold.Count() == strArrSDR.Count()) && (strArrSDR.Count() == strArrIMF.Count()))
                                        {
                                            string strTotalReserve = strArrTotalReserve[1];
                                            string strForex = strArrForeignCurrencyAsset[1];
                                            string strGold = strArrGold[1];
                                            string strSDR = strArrSDR[1];
                                            string strIMF = strArrIMF[1];
                                            if ((!string.IsNullOrWhiteSpace(strTotalReserve)) && (!string.IsNullOrWhiteSpace(strForex)) && (!string.IsNullOrWhiteSpace(strGold)) && (!string.IsNullOrWhiteSpace(strSDR)) && (!string.IsNullOrWhiteSpace(strIMF)))
                                            {
                                                if ((strTotalReserve.Trim() != "-") && (strForex.Trim() != "-") && (strGold.Trim() != "-") && (strSDR.Trim() != "-") && (strIMF.Trim() != "-"))
                                                    Filling_ForexReserve(oUrlPollStatus, objEconForex, objAlertForex, objStoryForex, dtDateFilling, strTotalReserve, strForex, strGold, strSDR, strIMF);
                                            }
                                            else
                                            {
                                                oUrlPollStatus.PollAttempt.LogComment("Any of the required value is empty in a Forex table");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ValidationFailureMail(oUrlPollStatus, matchForexTable.Value, "One of the row not found from foreign exchange reserve table");
                                    }
                                }

                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Columns are not in proper order in forex table>");
                            }
                        }
                    }
                    else
                    {
                        ValidationFailureMail(oUrlPollStatus, matchForexHeader.Value, "Foreign exchange reserves table header not found");
                    }
                }
                else
                {
                    ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Foreign exchange reserves table not found");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Foreign exchange reserve : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }



        public void Filling_ForexReserve(UrlPollStatus oUrlPollStatus, EconPublicationMessage objEconForex, AlertPublicationMessage objAlertForex, StoryPublicationMessage objStoryForex, DateTime dtDateFilling, string strTotalReserve, string strForex, string strGold, string strSDR, string strIMF)
        {
            try
            {
                oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling before story inside function : " + dtDateFilling.ToString());
                FormatFigure(strTotalReserve, oUrlPollStatus);
                Match mTot = Regex.Match(strTotalReserve, @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match mforex = Regex.Match(strForex, @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match mGold = Regex.Match(strGold, @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match mIMF = Regex.Match(strIMF, @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match mSDR = Regex.Match(strSDR, @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);

                if ((mTot.Success) && (mforex.Success) && (mGold.Success) && (mSDR.Success) && (mIMF.Success))
                {
                    decimal dclTotReserve = Convert.ToDecimal(strTotalReserve.Replace(",", ""));
                    decimal dclForex = Convert.ToDecimal(strForex.Replace(",", ""));
                    decimal dclGold = Convert.ToDecimal(strGold.Replace(",", ""));
                    decimal dclSDR = Convert.ToDecimal(strSDR.Replace(",", ""));
                    decimal dclIMF = Convert.ToDecimal(strIMF.Replace(",", ""));
                    HandbrakeMessage hbForex = (HandbrakeMessage)Store.PublicationMessages.GetPublicationMessage("HANDBRAKE_FOREX");
                    if (hbForex != null)
                        hbForex.Description = hbForex.Description.Replace("{ALERT_URL}", "<a href=\"" + oUrlPollStatus.Source.Url + "\" target=\"_blank\">");
                    if (dclTotReserve > 0)
                    {
                        string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
                        StringBuilder sbAlert = new StringBuilder(objAlertForex.AlertTemplate);

                        StringBuilder sbHeadline = new StringBuilder(objStoryForex.HeadlineTemplate);
                        StringBuilder sbStoryText = new StringBuilder(objStoryForex.StoryTextTemplate);

                        string strP_TotalReserve = null;
                        decimal dclTotReservebln = dclTotReserve / 1000;
                        if (objEconForex.IsSent == false)
                            objEconForex.Send(dclTotReservebln.ToString("0.00"), null, oUrlPollStatus);
                        if (Store.Settings.GetSetting("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE") != null)
                        {
                            if (!string.IsNullOrWhiteSpace(Store.Settings.GetSetting("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE").Value))
                            {
                                string strSetting = Store.Settings.GetSetting("PREVIOUS_WEEK_VALUE_FOR_FOREX-RESERVE").Value;
                                Match matchPTotRes = Regex.Match(strSetting.Trim(), @"TOTAL\s*RESERVE.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                if (matchPTotRes.Success)
                                {
                                    string[] strArrSplitTotRes = Regex.Split(matchPTotRes.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    strP_TotalReserve = strArrSplitTotRes[1];

                                    decimal dclP_TotReserve = Convert.ToDecimal(strP_TotalReserve.Replace(",", ""));
                                    decimal dclP_TotReservebln = dclP_TotReserve / 1000;
                                    if (dclP_TotReservebln > 0)
                                    {
                                        if (dclTotReservebln >= 1000)
                                        {
                                            dclTotReservebln = dclTotReservebln / 1000;
                                            sbAlert.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
                                            sbAlert.Replace("{X_BLN/TRLN}", "TRLN");

                                            sbHeadline.Replace("{BLN/TRLN}", "trln");
                                            sbHeadline.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));

                                            sbStoryText.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
                                            sbStoryText.Replace("{X_billion/trillion}", "trillion");
                                        }
                                        else
                                        {
                                            sbAlert.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
                                            sbAlert.Replace("{X_BLN/TRLN}", "BLN");

                                            sbHeadline.Replace("{BLN/TRLN}", "bln");
                                            sbHeadline.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));

                                            sbStoryText.Replace("{XX.XX}", dclTotReservebln.ToString("0.00"));
                                            sbStoryText.Replace("{X_billion/trillion}", "billion");
                                        }
                                        if (dclP_TotReservebln >= 1000)
                                        {
                                            dclP_TotReservebln = dclP_TotReservebln / 1000;
                                            sbAlert.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
                                            sbAlert.Replace("{Y_BLN/TRLN}", "TRLN");

                                            sbStoryText.Replace("{Y_billion/trillion}", "trillion");
                                            sbStoryText.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
                                        }
                                        else
                                        {
                                            sbAlert.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
                                            sbAlert.Replace("{Y_BLN/TRLN}", "BLN");
                                            sbStoryText.Replace("{Y_billion/trillion}", "billion");
                                            sbStoryText.Replace("{YY.YY}", dclP_TotReservebln.ToString("0.00"));
                                        }
                                        sbAlert.Replace("{WEEK_DATE}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim().ToUpper() + " " + dtDateFilling.Day);
                                        oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling (Alert) : " + dtDateFilling.ToString());
                                        if (objAlertForex.IsSent == false)
                                            objAlertForex.Send(sbAlert.ToString(), oUrlPollStatus);
                                    }
                                    if ((dclTotReserve > 0) && (dclForex > 0) && (dclGold > 0) && (dclSDR > 0) && (dclIMF > 0))
                                    {
                                        if (Math.Round(dclTotReservebln, 2) > Math.Round(dclP_TotReservebln, 2))
                                        {
                                            sbHeadline.Replace("{RISE/FALL/REMAIN UNCHANGED}", "rise");
                                            sbStoryText.Replace("{ROSE/FELL/REMAIN UNCHANGED}", "rose");
                                            sbHeadline.Replace("{AT/TO}", "to");
                                            sbStoryText.Replace("{AT/TO}", "to");
                                        }
                                        else if (Math.Round(dclTotReservebln, 2) < Math.Round(dclP_TotReservebln, 2))
                                        {
                                            sbHeadline.Replace("{RISE/FALL/REMAIN UNCHANGED}", "fall");
                                            sbStoryText.Replace("{ROSE/FELL/REMAIN UNCHANGED}", "fell");
                                            sbHeadline.Replace("{AT/TO}", "to");
                                            sbStoryText.Replace("{AT/TO}", "to");
                                        }
                                        else if (Math.Round(dclTotReservebln, 2) == Math.Round(dclP_TotReservebln, 2))
                                        {
                                            sbHeadline.Replace(" {RISE/FALL/REMAIN UNCHANGED}", "");
                                            sbStoryText.Replace(" {ROSE/FELL/REMAIN UNCHANGED}", "");
                                            sbHeadline.Replace("{AT/TO}", "at");
                                            sbStoryText.Replace("{AT/TO}", "at");
                                            //sbStoryText.Replace(" compared with ${YY.YY} billion a week earlier,", "");
                                        }
                                        else
                                            return;
                                        oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling (story) : " + dtDateFilling.ToString());
                                        sbHeadline.Replace("{WEEK_DATE}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim() + " " + dtDateFilling.Day);
                                        sbStoryText.Replace("{WEEK_DATE}", str_arrShortEngMonth[dtDateFilling.Month - 1].Trim() + " " + dtDateFilling.Day);
                                        string Code = "India Standard Time";
                                        DateTime dtNow = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                                        sbStoryText.Replace("{DATELINE}", str_arrShortEngMonth[dtNow.Month - 1].Trim() + " " + dtNow.Day);
                                        sbStoryText.Replace("{WEEKDAY}", dtNow.DayOfWeek.ToString());
                                        // sbStoryText.Replace("{SOURCE_TEXT}", "Source text: (" + oUrlPollStatus.Source.Url + ")");
                                        Match matchSettingF = Regex.Match(strSetting.Trim(), @"FOREIGN\s*CURRENCY.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                        Match matchSettingGold = Regex.Match(strSetting.Trim(), @"Gold.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                        Match matchSettingSDR = Regex.Match(strSetting.Trim(), @"SDR.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                        Match matchSettingIMF = Regex.Match(strSetting.Trim(), @"RESERVEs?.*?IMF.*?$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                        if ((matchSettingF.Success) && (matchSettingGold.Success) && (matchSettingIMF.Success) && (matchSettingSDR.Success))
                                        {
                                            string[] strArrSplitPAsset = Regex.Split(matchSettingF.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            string strP_FA = strArrSplitPAsset[1];

                                            string[] strArrSplitGold = Regex.Split(matchSettingGold.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            string strP_gold = strArrSplitGold[1];

                                            string[] strArrSplitSDR = Regex.Split(matchSettingSDR.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            string strP_SDR = strArrSplitSDR[1];

                                            string[] strArrSplitIMF = Regex.Split(matchSettingIMF.Value.Trim(), @"\|\|\|\|", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            string strP_IMF = strArrSplitIMF[1];

                                            if ((!string.IsNullOrWhiteSpace(strP_FA)) && (!string.IsNullOrWhiteSpace(strP_gold)) && (!string.IsNullOrWhiteSpace(strP_SDR)) && (!string.IsNullOrWhiteSpace(strP_IMF)))
                                            {
                                                decimal dclP_Forex = Convert.ToDecimal(strP_FA.Replace(",", ""));
                                                decimal dclP_Gold = Convert.ToDecimal(strP_gold.Replace(",", ""));
                                                decimal dclP_SDR = Convert.ToDecimal(strP_SDR.Replace(",", ""));
                                                decimal dclP_IMF = Convert.ToDecimal(strP_IMF.Replace(",", ""));
                                                if ((dclP_Forex > 0) && (dclP_Gold > 0) && (dclP_SDR > 0) && (dclP_IMF > 0))
                                                {
                                                    int iPad = 10;
                                                    sbStoryText.Replace("{C_F_XX,XXX}", FormatFigure(strForex.Trim(), oUrlPollStatus).Trim().PadLeft(iPad));
                                                    sbStoryText.Replace("{P_F_XX,XXX}", FormatFigure(strP_FA.Trim(), oUrlPollStatus).PadLeft(13));

                                                    sbStoryText.Replace("{C_G_XX,XXX}", FormatFigure(strGold.Trim(), oUrlPollStatus).Trim().PadLeft(iPad));
                                                    sbStoryText.Replace("{P_G_XX,XXX}", FormatFigure(strP_gold.Trim(), oUrlPollStatus).PadLeft(13));

                                                    sbStoryText.Replace("{C_S_XX,XXX}", FormatFigure(strSDR.Trim(), oUrlPollStatus).Trim().PadLeft(iPad));
                                                    sbStoryText.Replace("{P_S_XX,XXX}", FormatFigure(strP_SDR.Trim(), oUrlPollStatus).PadLeft(13));

                                                    sbStoryText.Replace("{C_R_XX,XXX}", FormatFigure(strIMF.Trim(), oUrlPollStatus).Trim().PadLeft(iPad));
                                                    sbStoryText.Replace("{P_R_XX,XXX}", FormatFigure(strP_IMF.Trim(), oUrlPollStatus).PadLeft(13));

                                                    sbStoryText.Replace("{C_T_XX,XXX}", FormatFigure(strTotalReserve.Trim(), oUrlPollStatus).Trim().PadLeft(iPad));
                                                    sbStoryText.Replace("{P_T_XX,XXX}", FormatFigure(strP_TotalReserve.Trim(), oUrlPollStatus).PadLeft(13));

                                                    sbStoryText.Replace("{C_WEEKDATE}", (str_arrShortEngMonth[dtDateFilling.Month - 1].Trim() + " " + dtDateFilling.ToString("dd", CultureInfo.InvariantCulture)).PadLeft(36));

                                                    DateTime dtP_Date = new DateTime();
                                                    if (DateTime.TryParseExact(Store.Settings.GetSetting("PREVIOUS_WEEK_DD-MMM-YYYY").Value.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtP_Date) == true)
                                                    {
                                                        sbStoryText.Replace("{P_WEEKDATE}", (str_arrShortEngMonth[dtP_Date.Month - 1].Trim() + " " + dtP_Date.ToString("dd", CultureInfo.InvariantCulture)).PadLeft(13));
                                                        sbStoryText.Replace("{C_YYYY}", dtDateFilling.ToString("yyyy").PadLeft(35));
                                                        sbStoryText.Replace("{P_YYYY}", dtP_Date.ToString("yyyy").PadLeft(13));
                                                        MySourceStore mystore = (MySourceStore)Store;
                                                        lock (mystore.locker)
                                                        {

                                                            if (objStoryForex.IsSent == false)
                                                                objStoryForex.Send(sbHeadline.ToString(), sbStoryText.ToString(), oUrlPollStatus);
                                                        }
                                                        lock (mystore.locker_Recommend)
                                                        {
                                                            //                                                            mystore.strRecommendValues = "TOTAL RESERVE||||" + FormatFigure(strTotalReserve.Trim(), oUrlPollStatus) + Environment.NewLine; -ROBOTCHANGE-20180316
                                                            mystore.strRecommendValues = "TOTAL RESERVE||||" + FormatFigure(strTotalReserve.Trim(), oUrlPollStatus) + "\r\n";
                                                            //                                                            mystore.strRecommendValues = mystore.strRecommendValues + "FOREIGN CURRENCY||||" + FormatFigure(strForex.Trim(), oUrlPollStatus) + Environment.NewLine; -ROBOTCHANGE-20180316
                                                            mystore.strRecommendValues = mystore.strRecommendValues + "FOREIGN CURRENCY||||" + FormatFigure(strForex.Trim(), oUrlPollStatus) + "\r\n";
                                                            //                                                            mystore.strRecommendValues = mystore.strRecommendValues + "GOLD||||" + FormatFigure(strGold.Trim(), oUrlPollStatus) + Environment.NewLine; -ROBOTCHANGE-20180316
                                                            mystore.strRecommendValues = mystore.strRecommendValues + "GOLD||||" + FormatFigure(strGold.Trim(), oUrlPollStatus) + "\r\n";
                                                            //                                                            mystore.strRecommendValues = mystore.strRecommendValues + "SDR||||" + FormatFigure(strSDR.Trim(), oUrlPollStatus) + Environment.NewLine; -ROBOTCHANGE-20180316
                                                            mystore.strRecommendValues = mystore.strRecommendValues + "SDR||||" + FormatFigure(strSDR.Trim(), oUrlPollStatus) + "\r\n";
                                                            mystore.strRecommendValues = mystore.strRecommendValues + "RESERVE POSITION IN IMF||||" + FormatFigure(strIMF.Trim(), oUrlPollStatus).Trim();
                                                        }
                                                    }
                                                    else
                                                        return;

                                                }
                                            }
                                        }
                                    }
                                }
                                else return;
                            }
                            else return;
                        }
                        else return;
                    }
                    else
                    {
                        oUrlPollStatus.PollAttempt.LogComment("Any of the required value is 0 or negative in Forex table.");
                    }
                }
                else
                {
                    oUrlPollStatus.PollAttempt.LogComment("Any of the required value is non digit");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Foreign exchange reserve Filling : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        public string FormatFigure(string strTotalReserve, UrlPollStatus oUrlPollStatus)
        {
            string[] splitFigure = strTotalReserve.Replace(",", "").Split('.');
            int figure = Convert.ToInt32(splitFigure[0]);
            if (splitFigure.Count() == 2)
                return figure.ToString("#,#", CultureInfo.InvariantCulture) + "." + splitFigure[1];
            else
                return figure.ToString("#,#", CultureInfo.InvariantCulture);

        }
        private void CommericalBank(string strContent, UrlPollStatus oUrlPollStatus, DateTime dtDate, AlertPublicationMessage objAlertbankDeposit, AlertPublicationMessage objAlertbankloan, StoryPublicationMessage objStorybank, EconPublicationMessage objEconLoan, EconPublicationMessage objEconDeposit)
        {
            try
            {
                MySourceStore mystore = (MySourceStore)Store;
                bool cbIsUnitCrore = false;
                string strRegexCommercialTable = @"(\*){4}\s*\d{1,}\W*Scheduled\s*Commercial\s*Banks?.*?[\r\n]+([^#]*[\r\n]+){1,}\s*####";
                Match matchCommercialTable = Regex.Match(strContent, strRegexCommercialTable, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                if (matchCommercialTable.Success)
                {
                    Match matchUnit = Regex.Match(matchCommercialTable.Value, @"^\s*(\()?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*(\))?\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchUnit.Success)
                    {
                        string csUnit = matchUnit.Groups[2].Captures[0].Value.Trim();
                        if (csUnit.ToLower().Contains("cr"))
                            cbIsUnitCrore = true;
                        int iFirstTD = 0;
                        string strRegexOutstanding = @"^(.*?)Outstanding\s*As\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+(\d{4})\s*(\@){4}.*?[\r\n]+";
                        Match matchOutstanding = Regex.Match(matchCommercialTable.Value.Trim(), strRegexOutstanding, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matchOutstanding.Success)
                        {
                            Match matchesFortnight = Regex.Match(matchCommercialTable.Value.Trim(), @"^(.*?)Fortnight\s*(\@){4}.*?((year\W*(on|over)\W*year)|(yoy)|(y\W*y)|(year\W*year))\s*(\@){4}\s*(\|){4}[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchesFortnight.Success)
                            {
                                Match matchYear = Regex.Match(matchCommercialTable.Value.Trim(), @"^(.*?)\d{4}\s*\-\s*\d{2}\s*(\@){4}.*?[\r\n]+", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                if (matchYear.Success)
                                {
                                    MatchCollection matchesOSSPlit = Regex.Matches(matchOutstanding.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    if (matchesOSSPlit.Count == 1)
                                        iFirstTD++;
                                    MatchCollection matchesFortnightSPlit = Regex.Matches(matchesFortnight.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    if (matchesFortnightSPlit.Count == 1)
                                        iFirstTD++;
                                    MatchCollection matchesYearSPlit = Regex.Matches(matchYear.Groups[1].Value.Trim(), "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                    if (matchesYearSPlit.Count == 1)
                                        iFirstTD++;
                                    if (iFirstTD == 1)
                                    {
                                        string strMonth = Convert.ToDateTime(matchOutstanding.Groups[2].Value.Trim() + " " + matchOutstanding.Groups[3].Value.Trim() + " " + matchOutstanding.Groups[4].Value.Trim()).ToString("MMMM");
                                        string strDay = Convert.ToDateTime(matchOutstanding.Groups[2].Value.Trim() + " " + matchOutstanding.Groups[3].Value.Trim() + " " + matchOutstanding.Groups[4].Value.Trim()).ToString("dd");
                                        string strDateFound = strDay + "-" + strMonth + "-" + matchOutstanding.Groups[4].Value.Trim();
                                        DateTime dtFound = new DateTime();
                                        if (DateTime.TryParseExact(strDateFound.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtFound) == true)
                                        {
                                            if (dtDate.AddDays(-7) == dtFound)
                                            {
                                                string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
                                                string strYear = Regex.Replace(matchYear.Value.Trim(), @" {1,}", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                strYear = Regex.Replace(strYear.Trim(), @"(\|){4}", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                string[] strSplit = { "@@@@", };
                                                string[] strArrayYear = strYear.Split(strSplit, StringSplitOptions.RemoveEmptyEntries);
                                                if (strArrayYear[strArrayYear.Count() - 1].Trim() == dtDate.AddDays(-7).ToString("yyyy", CultureInfo.InvariantCulture).Trim())
                                                {
                                                    int iMonth = dtFound.Month;
                                                    Match matchDeposit = Regex.Match(matchCommercialTable.Value.Trim(), @"Liabilit(ies|y)\s*to\s*Others?.*?(bank\s*credit|demand|time|borrowing|investment)\s*(\@){4}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                    Match matchloan = Regex.Match(matchCommercialTable.Value.Trim(), @"bank\s*credit[\s\*]*(\@){4}.*?(food\s*credit|non\W*food\s*credit)[\s\*]*(\@){4}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                    string strDepositValue = null;
                                                    string strLoanValue = null;
                                                    if (matchDeposit.Success)
                                                    {
                                                        string strRegexDepGrowth = @"growth\s*\(?(per\s*cent|\%|pct|cent|percentage)\)?\s*(\@){4}\s*(.*?(\|){4})";
                                                        Match matchgrowth = Regex.Match(matchDeposit.Value.Trim(), strRegexDepGrowth, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                        if (matchgrowth.Success)
                                                        {
                                                            string growth = Regex.Replace(matchgrowth.Groups[3].Value.Trim(), @"@@@@\s*\|\|\|\|", "", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                            string[] strArrDeposit = Regex.Split(growth, "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                            if (strArrDeposit.Count() == 6)
                                                            {
                                                                string strPCTVALUE = strArrDeposit[5];
                                                                strDepositValue = Alert_BankDeposit(oUrlPollStatus, objEconDeposit, objAlertbankDeposit, str_arrShortEngMonth, iMonth, dtFound, strPCTVALUE);
                                                            }
                                                            else
                                                            {
                                                                oUrlPollStatus.PollAttempt.LogComment("Deposit array count not equal 6 for Scheduled Commercial Banks table");

                                                            }
                                                        }
                                                        else
                                                        {
                                                            ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Growth(%) not found for deposits");

                                                        }
                                                        // strDepositValue = AlertFilling_BankDeposit(oUrlPollStatus, objEconDeposit, objAlertbankDeposit, matchCommercialTable, str_arrShortEngMonth, iMonth, matchDeposit, dtFound);
                                                    }
                                                    else
                                                        ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Deposit part not found from Scheduled Commercial Banks table");

                                                    if (matchloan.Success)
                                                    {
                                                        string strRegexDepGrowth = @"growth\s*\(?(per\s*cent|\%|pct|cent|percentage)\)?\s*(\@){4}\s*(.*?(\|){4})";
                                                        Match matchgrowth = Regex.Match(matchloan.Value.Trim(), strRegexDepGrowth, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                        if (matchgrowth.Success)
                                                        {
                                                            string growth = Regex.Replace(matchgrowth.Groups[3].Value.Trim(), @"@@@@\s*\|\|\|\|", "", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                            string[] strArrLoan = Regex.Split(growth, "@@@@", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                                            if (strArrLoan.Count() == 6)
                                                            {
                                                                string strPCTVALUE = strArrLoan[5];
                                                                strLoanValue = Alert_BankLoan(oUrlPollStatus, objEconLoan, objAlertbankloan, str_arrShortEngMonth, iMonth, dtFound, strPCTVALUE);
                                                            }
                                                            else
                                                            {
                                                                oUrlPollStatus.PollAttempt.LogComment("Deposit array count not equal 6 for Scheduled Commercial Banks table");
                                                                // return null;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Growth(%) not found for deposits");
                                                            // return null;
                                                        }
                                                        // strLoanValue = AlertFilling_BankLoan(oUrlPollStatus, objEconLoan, objAlertbankloan, matchCommercialTable, str_arrShortEngMonth, iMonth, matchloan, dtFound);
                                                    }
                                                    else
                                                        ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Loan part not found from Scheduled Commercial Banks table");
                                                    if ((!string.IsNullOrWhiteSpace(strDepositValue)) && (!string.IsNullOrWhiteSpace(strLoanValue)))
                                                    {
                                                        StoryExtraction_CommercialBank(oUrlPollStatus, objStorybank, matchCommercialTable, str_arrShortEngMonth, iMonth, dtFound, matchDeposit, matchloan, strDepositValue, strLoanValue, cbIsUnitCrore);

                                                    }
                                                    else
                                                    {
                                                        oUrlPollStatus.PollAttempt.LogComment("Growth % values for loan or deposits are null");
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Outstanding date does not match from Scheduled Commercial Banks table");
                                                if (oUrlPollStatus.IsRequestCompleted)
                                                {
                                                    objAlertbankDeposit.IsSent = true;
                                                    objAlertbankloan.IsSent = true;
                                                    objStorybank.IsSent = true;
                                                    objEconLoan.IsSent = true;
                                                    objEconDeposit.IsSent = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Year row not found from Scheduled Commercial Banks table");
                                }
                            }
                            else
                            {
                                ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Fortnight row not found from Scheduled Commercial Banks table");
                            }
                        }
                        else
                        {
                            ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value.Trim(), "Outstanding row not found from Scheduled Commercial Banks table");
                        }
                    }
                    else
                    {
                        ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Unit not found from Scheduled Commercial Banks table");
                    }
                }
                else
                {
                    ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Scheduled Commercial Banks table not found");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Commerical Bank : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        private void LiquidityOMONew(string strContent, UrlPollStatus oUrlPollStatus, DateTime dtDate, AlertPublicationMessage objAlertOMO, StoryPublicationMessage objStoryOMO)
        {
            try
            {
                bool cbIsUnitCrore = false;
                //string strRegexOMO = @"(\*){4}\s*\d{1,}\W*Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|Reserve\W*bank\W*(?:of)?\W*india).*?[\r\n]+([^#]*[\r\n]+){1,}\s*####";
                string strRegexOMO = @"Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|Reserve\W*bank\W*(?:of)?\W*india).*?\s*####";
                Match matchOMOTable = Regex.Match(strContent, strRegexOMO, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchOMOTable.Success)
                {
                    Match matchColheader = Regex.Match(matchOMOTable.Value, @"Liquidity\s*Adjustment\s*Facilit(?:y|ies).*?OMO", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    Match matchUnit = Regex.Match(matchOMOTable.Value, @"^\s*(\()?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*(\))?\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if ((matchUnit.Success) && (matchColheader.Success))
                    {
                        string csUnit = matchUnit.Groups[2].Captures[0].Value.Trim();
                        if (csUnit.ToLower().Contains("cr"))
                            cbIsUnitCrore = true;

                        bool flagSalPur = false;
                        bool flagAbsorption = false;

                        bool flagSPFound = false;

                        Match matchSalePur = null;
                        string strContentTemp = Regex.Replace(matchOMOTable.Value, @"@@@@\s*\|\|\|\|", "\r\n", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        matchSalePur = Regex.Match(strContentTemp, @"^[^\n]*\s+sales?\s*@@@@\s*purchases?[^\n]*\n", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matchSalePur.Success)
                        {
                            string[] strarrSalPur = Regex.Split(matchSalePur.Value, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            // string[] strarrSalPur = Regex.Split(strline, @" {2,}", RegexOptions.IgnoreCase);
                            Match matchSale = Regex.Match(strarrSalPur[strarrSalPur.Count() - 3], @"sales?", RegexOptions.IgnoreCase);
                            Match matchPur = Regex.Match(strarrSalPur[strarrSalPur.Count() - 2], @"Purchases?", RegexOptions.IgnoreCase);
                            if (matchSale.Success && matchSalePur.Success)
                            {
                                flagSalPur = true;

                            }

                            Match matchSalePur1 = Regex.Match(matchSalePur.Value, @"\s+sales?\s*@@@@\s*purchases?\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchSalePur1.Success)
                            {
                                flagSPFound = true;

                            }
                        }
                        Match matAbsorption = Regex.Match(strContentTemp, @"(?:net|injection|absorption|(\d+\W+){1,})\W*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matAbsorption.Success)
                            flagAbsorption = true;
                        if ((flagAbsorption == true) && (flagSPFound == true))
                            flagSalPur = true;
                        if (flagSalPur == true)
                        {
                            #region FigureExtraction
                            Match matchdate = Regex.Match(matchOMOTable.Value, @"((" + dtDate.ToString("MMM") + @"|" + dtDate.AddMonths(-1).ToString("MMM") + ").*?)####", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchdate.Success)
                            {
                                StringReader reader = new StringReader(matchdate.Groups[1].Value.Trim());
                                string strline = null;
                                decimal dclTotalSale = 0;
                                decimal dclTotalPurchase = 0;
                                List<DateTime> lstDate = new List<DateTime>();
                                while ((strline = reader.ReadLine()) != null)
                                {
                                    strline = Regex.Replace(strline, @"@@@@\s*\|\|\|\|", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    string[] strArr_splitcolumn = Regex.Split(strline, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    string strValueSale = null;
                                    string strValuePur = null;
                                    if (!string.IsNullOrWhiteSpace(strline))
                                    {
                                        // ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strArr_splitcolumn);
                                        if (strArr_splitcolumn.Count() >= 3)
                                        {
                                            int iColCount = strArr_splitcolumn.Count();
                                            strValueSale = strArr_splitcolumn[iColCount - 3];
                                            strValuePur = strArr_splitcolumn[iColCount - 2];
                                            if (iColCount >= 12)
                                            {
                                                strValueSale = strArr_splitcolumn[8];
                                                strValuePur = strArr_splitcolumn[9];
                                            }
                                            ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strArr_splitcolumn);
                                        }
                                    }
                                }//while
                                if (csUnit.ToLower().Contains("cr"))
                                {
                                    dclTotalSale = dclTotalSale / 100;
                                    dclTotalPurchase = dclTotalPurchase / 100;

                                }
                                OMOFilling(oUrlPollStatus, objAlertOMO, objStoryOMO, ref dclTotalSale, ref dclTotalPurchase, lstDate);
                            }
                            else
                                oUrlPollStatus.PollAttempt.LogComment("Month not found in html source");
                            #endregion
                        }
                    }
                    else
                        ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Unit or column header does not match from OMO table");
                }
                else
                    ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "OMO table not found from the content");
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Liquidity table : " + e.Message + "   StackTrace : " + e.StackTrace);
                return;
            }
        }
        private void LiquidityOMO(string strContent, UrlPollStatus oUrlPollStatus, DateTime dtDate, AlertPublicationMessage objAlertOMO, StoryPublicationMessage objStoryOMO)
        {
            try
            {
                string strRegexOMO = @"(\*){4}\s*\d{1,}\W*Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|Reserve\W*bank\W*(?:of)?\W*india).*?[\r\n]+([^#]*[\r\n]+){1,}\s*####";
                Match matchOMOTable = Regex.Match(strContent, strRegexOMO, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                if (matchOMOTable.Success)
                {
                    Match matchUnit = Regex.Match(matchOMOTable.Value, @"^\s*(\()?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*(\))?\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchUnit.Success)
                    {
                        Match matchHeader2 = null;


                        string strRegexHeader = @"^\s*Date\s*(\@){4}\s*Liquidity\s*Adjustment\s*Facilit(ies|y)\s*(\@){4}\s*MSF\s*(\@){4}\s*Standing\s*Liquidity\s*Facilit(ies|y)\s*(\@){4}\s*OMO\s*\(\s*Outright\s*\)\s*(\@){4}\s*Net\s*Injection.*?Absorption.*?(\@){4}\s*(\|){4}( ){0,}[\r\n]+\s*Repo\s*(\@){4}\s*Reverse\s*Repo\s*(\@){4}\s*Variable\s*Rate\s*Repo\s*(\@){4}\s*Variable\s*Rate\s*Reverse\s*Repo\s*(\@){4}\s*Sale\s*(\@){4}\s*Purchase\s*(\@){4}\s*(\|){4}";
                        // string strRegexHeader = @"^\s*Date\s*(\@){4}\s*Liquidity\s*Adjustment\s*Facilit(ies|y)\s*(\@){4}\s*MSF\s*(\@){4}\s*Standing\s*Liquidity\s*Facilit(ies|y)\s*(\@){4}\s*OMO\s*\(\s*Outright\s*\)\s*(\@){4}\s*Net\s*Injection.*?Absorption.*?(\@){4}\s*(\|){4}( ){0,}[\r\n]+\s*Repo\s*(\@){4}\s*Reverse\s*Repo\s*(\@){4}\s*Term\s*Repo\s*/?\s*Overnight\s*Variable\s*Rate\s*Repo\s*(\@){4}\s*Term\s*Reverse\s*Repo\s*/?\s*Overnight\s*Variable\s*Rate\s*Reverse\s*Repo\s*(\@){4}\s*Sale\s*(\@){4}\s*Purchase\s*(\@){4}\s*(\|){4}";
                        Match matchHeader = Regex.Match(matchOMOTable.Value, strRegexHeader, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (!matchHeader.Success)
                        {
                            matchHeader = Regex.Match(matchOMOTable.Value, @"^\s*Date\s*(\@){4}\s*Liquidity\s*Adjustment\s*Facilit(ies|y)\s*(\@){4}\s*MSF\s*(\@){4}\s*Standing\s*Liquidity\s*Facilit(ies|y)\s*(\@){4}\s*OMO\s*\(\s*Outright\s*\)\s*(\@){4}\s*Net\s*Injection.*?Absorption.*?(\@){4}\s*(\|){4}( ){0,}[\r\n]+\s*Repo\s*(\@){4}\s*Reverse\s*Repo\s*(\@){4}\s*Term\s*Repo\s*/?\s*Overnight\s*Variable\s*Rate\s*Repo\s*(\@){4}\s*Term\s*Reverse\s*Repo\s*/?\s*Overnight\s*Variable\s*Rate\s*Reverse\s*Repo\s*(\@){4}\s*Sale\s*(\@){4}\s*Purchase\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            // 

                            if (!matchHeader.Success)
                                matchHeader2 = Regex.Match(matchOMOTable.Value, @"^\s*Date\s*(\@){4}\s*Liquidity\s*Adjustment\s*Facilit(ies|y)\s*(\@){4}\s*MSF\s*(\@){4}\s*Standing\s*Liquidity\s*Facilit(ies|y)\s*(\@){4}\s*OMO\s*\(\s*Outright\s*\)\s*(\@){4}\s*Net\s*Injection.*?Absorption.*?(\@){4}\s*(\|){4}( ){0,}[\r\n]+\s*Repo\s*(\@){4}\s*Reverse\s*Repo\s*(\@){4}\s*Term\s*Repo\s*(\@){4}\s*Sale\s*(\@){4}\s*Purchase\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            //matchHeader2 = Regex.Match(matchOMOTable.Value, @"^\s*Date\s*(\@){4}\s*Liquidity\s*Adjustment\s*Facilit(ies|y)\s*(\@){4}\s*MSF\s*(\@){4}\s*Standing\s*Liquidity\s*Facilit(ies|y)\s*(\@){4}\s*OMO\s*\(\s*Outright\s*\)\s*(\@){4}\s*Net\s*Injection.*?Absorption.*?(\@){4}\s*(\|){4}( ){0,}[\r\n]+\s*Repo\s*(\@){4}\s*Reverse\s*Repo\s*(\@){4}\s*Variable\s*Rate\s*Repo\s*(\@){4}\s*Variable\s*Rate\s*Reverse\s*Repo\s*(\@){4}\s*Sale\s*(\@){4}\s*Purchase\s*(\@){4}\s*(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        }
                        if ((matchHeader.Success) || (matchHeader2.Success))
                        {
                            #region FigureExtraction
                            Match matchdate = Regex.Match(matchOMOTable.Value, @"((" + dtDate.ToString("MMM") + @"|" + dtDate.AddMonths(-1).ToString("MMM") + ").*?)####", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchdate.Success)
                            {
                                StringReader reader = new StringReader(matchdate.Groups[1].Value.Trim());
                                string strline = null;
                                decimal dclTotalSale = 0;
                                decimal dclTotalPurchase = 0;
                                List<DateTime> lstDate = new List<DateTime>();
                                while ((strline = reader.ReadLine()) != null)
                                {
                                    strline = Regex.Replace(strline, @"@@@@\s*\|\|\|\|", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    string[] strArr_splitcolumn = Regex.Split(strline, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    string strValueSale = null;
                                    string strValuePur = null;
                                    if (matchHeader.Success)
                                    {
                                        if (strArr_splitcolumn.Count() == 10)
                                        {
                                            strValueSale = strArr_splitcolumn[7];
                                            strValuePur = strArr_splitcolumn[8];
                                        }
                                        else if (strArr_splitcolumn.Count() >= 11)
                                        {
                                            strValueSale = strArr_splitcolumn[8];
                                            strValuePur = strArr_splitcolumn[9];
                                        }
                                    }
                                    else if (matchHeader2.Success)
                                    {
                                        if (strArr_splitcolumn.Count() == 9)
                                        {
                                            strValueSale = strArr_splitcolumn[6];
                                            strValuePur = strArr_splitcolumn[7];
                                        }
                                        else if (strArr_splitcolumn.Count() >= 12)
                                        {
                                            strValueSale = strArr_splitcolumn[8];
                                            strValuePur = strArr_splitcolumn[9];
                                        }
                                    }
                                    else
                                        return;

                                    ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strArr_splitcolumn);

                                }//while
                                OMOFilling(oUrlPollStatus, objAlertOMO, objStoryOMO, ref dclTotalSale, ref dclTotalPurchase, lstDate);
                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Month not found in html source");
                            }
                            #endregion
                        }
                        else
                            ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Header does not match from OMO table");
                    }
                    else
                    {
                        ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "Unit does not match from OMO table");
                    }
                }
                else
                {
                    ValidationFailureMail(oUrlPollStatus, oUrlPollStatus.ContentString, "OMO table not found from the content");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Liquidity table : " + e.Message + "   StackTrace : " + e.StackTrace);
                return;
            }
        }

        public void OMOFilling(UrlPollStatus oUrlPollStatus, AlertPublicationMessage objAlertOMO, StoryPublicationMessage objStoryOMO, ref decimal dclTotalSale, ref decimal dclTotalPurchase, List<DateTime> lstDate)
        {
            HandbrakeMessage hbOMO = (HandbrakeMessage)Store.PublicationMessages.GetPublicationMessage("HANDBRAKE_OMO");
            if (hbOMO != null)
                hbOMO.Description = hbOMO.Description.Replace("{ALERT_URL}", "<a href=\"" + oUrlPollStatus.Source.Url + "\" target=\"_blank\">");

            StringBuilder sb = new StringBuilder(objAlertOMO.AlertTemplate);
            StringBuilder sbstory = new StringBuilder(objStoryOMO.StoryTextTemplate);
            StringBuilder sbheadline = new StringBuilder(objStoryOMO.HeadlineTemplate);
            string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
            if ((dclTotalSale > 0) && (lstDate.Count != 0))
            {
                DateTime dtMax = lstDate.Max();

                if (dclTotalSale >= 1000)
                {
                    dclTotalSale = dclTotalSale / 1000;
                    sb.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sb.Replace("{X_BLN/MLN/TRLN}", "TRLN");

                    sbheadline.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "trln");

                    sbstory.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sbstory.Replace("{X_billion/milion/trillion}", "trillion");

                }
                else if (dclTotalSale < 1)
                {
                    dclTotalSale = dclTotalSale * 1000;
                    sb.Replace("{X.XX}", dclTotalSale.ToString("0.0", CultureInfo.InvariantCulture));
                    sb.Replace("{X_BLN/MLN/TRLN}", "MLN");

                    sbheadline.Replace("{X.XX}", dclTotalSale.ToString("0.0", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "mln");

                    sbstory.Replace("{X.XX}", dclTotalSale.ToString("0.0", CultureInfo.InvariantCulture));
                    sbstory.Replace("{X_billion/milion/trillion}", "million");
                }
                else
                {
                    sb.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sb.Replace("{X_BLN/MLN/TRLN}", "BLN");

                    sbheadline.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "bln");

                    sbstory.Replace("{X.XX}", dclTotalSale.ToString("0.00", CultureInfo.InvariantCulture));
                    sbstory.Replace("{X_billion/milion/trillion}", "billion");
                }
                sb.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim().ToUpper() + " " + dtMax.Day);
                if (dclTotalPurchase > 0)
                {
                    if (dclTotalPurchase >= 1000)
                    {
                        dclTotalPurchase = dclTotalPurchase / 1000;
                        sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " TRLN RUPEES OF BONDS");
                        sbstory.Replace("{RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " trillion rupees of bonds");
                    }
                    else if (dclTotalPurchase < 1)
                    {
                        dclTotalPurchase = dclTotalPurchase * 1000;
                        sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.0", CultureInfo.InvariantCulture) + " MLN RUPEES OF BONDS");
                        sbstory.Replace("{RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.0", CultureInfo.InvariantCulture) + " million rupees of bonds");
                    }
                    else
                    {
                        sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " BLN RUPEES OF BONDS");
                        sbstory.Replace("{RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture) + " billion rupees of bonds");
                    }
                }
                else
                {
                    sb.Replace(", {RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "");
                    sbstory.Replace(", {RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "");
                }
                if (objAlertOMO.IsSent == false)
                    objAlertOMO.Send(sb.ToString(), oUrlPollStatus);


                sbheadline.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim() + " " + dtMax.Day);


                sbstory.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim() + " " + dtMax.Day);

                string Code = "India Standard Time";
                DateTime dtNow = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                sbstory.Replace("{DATELINE}", str_arrShortEngMonth[dtNow.Month - 1].Trim() + " " + dtNow.Day);
                // sbstory.Replace("{SOURCE_TEXT}", "Source text: (" + oUrlPollStatus.Source.Url + ")");
                MySourceStore mystore = (MySourceStore)Store;
                lock (mystore.locker)
                {
                    if (objStoryOMO.IsSent == false)
                        objStoryOMO.Send(sbheadline.ToString(), sbstory.ToString(), oUrlPollStatus);
                }
            }
            else if ((dclTotalPurchase > 0) && (lstDate.Count != 0))
            {
                DateTime dtMax = lstDate.Max();
                sb.Replace("RBI SOLD {X.XX} {X_BLN/MLN/TRLN} RUPEES OF BONDS, ", "");
                sb.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim().ToUpper() + " " + dtMax.Day);
                if (dclTotalPurchase >= 1000)
                {
                    dclTotalPurchase = dclTotalPurchase / 1000;
                    sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00") + " TRLN RUPEES OF BONDS");

                    sbstory.Replace("RBI sold {X.XX} {X_billion/milion/trillion} rupees of bonds, {RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.00") + " trillion rupees of bonds");
                    sbheadline.Replace("{X.XX}", dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "trln");
                }
                else if (dclTotalPurchase < 1)
                {
                    dclTotalPurchase = dclTotalPurchase * 1000;
                    sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.0") + " MLN RUPEES OF BONDS");
                    sbstory.Replace("RBI sold {X.XX} {X_billion/milion/trillion} rupees of bonds, {RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.0") + " million rupees of bonds");
                    sbheadline.Replace("{X.XX}", dclTotalPurchase.ToString("0.0", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "mln");

                }
                else
                {
                    sb.Replace("{RBI BOUGHT Y.YY {Y_BLN/MLN/TRLN} RUPEES OF BONDS}", "RBI BOUGHT " + dclTotalPurchase.ToString("0.00") + " BLN RUPEES OF BONDS");
                    sbstory.Replace("RBI sold {X.XX} {X_billion/milion/trillion} rupees of bonds, {RBI bought Y.YY {Y_billion/milion/trillion} rupees of bonds}", "RBI bought " + dclTotalPurchase.ToString("0.00") + " billion rupees of bonds");
                    sbheadline.Replace("{X.XX}", dclTotalPurchase.ToString("0.00", CultureInfo.InvariantCulture));
                    sbheadline.Replace("{bln/mln/trln}", "bln");
                }
                if (objAlertOMO.IsSent == false)
                    objAlertOMO.Send(sb.ToString(), oUrlPollStatus);


                sbheadline.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim() + " " + dtMax.Day);
                sbheadline.Replace("sells", "bought");

                sbstory.Replace("{MONTH_DAY}", str_arrShortEngMonth[dtMax.Month - 1].Trim() + " " + dtMax.Day);

                string Code = "India Standard Time";
                DateTime dtNow = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                sbstory.Replace("{DATELINE}", str_arrShortEngMonth[dtNow.Month - 1].Trim() + " " + dtNow.Day);
                // sbstory.Replace("{SOURCE_TEXT}", "Source text: (" + oUrlPollStatus.Source.Url + ")");
                MySourceStore mystore = (MySourceStore)Store;
                lock (mystore.locker)
                {
                    if (objStoryOMO.IsSent == false)
                        objStoryOMO.Send(sbheadline.ToString(), sbstory.ToString(), oUrlPollStatus);
                }
            }
            if (oUrlPollStatus.IsRequestCompleted)
            {
                if ((dclTotalSale == 0) && (lstDate.Count == 0))
                {
                    objAlertOMO.IsSent = true;
                    objStoryOMO.IsSent = true;
                }
            }
        }

        public void ExtractOMOFigures(UrlPollStatus oUrlPollStatus, string strValueSale, string strValuePur, ref decimal dclTotalSale, ref decimal dclTotalPurchase, List<DateTime> lstDate, string[] strArr_splitcolumn)
        {

            Match matchDateCol = Regex.Match(strArr_splitcolumn[0], @"(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+(\d{4})", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            if (matchDateCol.Success)
            {
                string strMonth = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("MMMM");
                string strDay = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("dd");
                string strD = strDay + "-" + strMonth + "-" + matchDateCol.Groups[3].Value.Trim();
                //if (strArr_splitcolumn.Count() >= 3)
                //{
                //    int iColCount = strArr_splitcolumn.Count();
                //    strValueSale = strArr_splitcolumn[iColCount - 3];
                //    strValuePur = strArr_splitcolumn[iColCount - 2];
                //    // ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strArr_splitcolumn);
                //}
                #region Sales

                if (!string.IsNullOrWhiteSpace(strValueSale))
                {
                    Match matchdigit = Regex.Match(strValueSale.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchdigit.Success)
                    {
                        //strValueSale = strValueSale.Replace(",", "");
                        decimal dclValueSale = Convert.ToDecimal(strValueSale.Trim());
                        if (dclValueSale != 0 && (!strValueSale.Contains(",")))
                        {
                            dclTotalSale = dclTotalSale + dclValueSale;

                            // string strMonth = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("MMMM");
                            // string strDay = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("dd");
                            //  string strD = strDay + "-" + strMonth + "-" + matchDateCol.Groups[3].Value.Trim();

                            //  string strD = (Convert.ToInt32(matchDateCol.Groups[2].Value.Trim())).ToString("00") + "-" + matchDateCol.Groups[1].Value.Trim() + "-" + matchDateCol.Groups[3].Value.Trim();
                            DateTime dtDatesale = new DateTime();
                            if (DateTime.TryParseExact(strD.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDatesale) == true)
                            {
                                if (!lstDate.Contains(dtDatesale))
                                    lstDate.Add(dtDatesale);
                            }
                            // }
                            //else
                            //{
                            //    oUrlPollStatus.PollAttempt.LogComment("Total sale = 0 or list of date count = 0");
                            //    // return;
                            //}
                        }
                    }
                }//if null or empty
                #endregion

                #region Purchase
                if (!string.IsNullOrWhiteSpace(strValuePur))
                {
                    Match matchdigit = Regex.Match(strValuePur.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchdigit.Success)
                    {
                        //strValuePur = strValuePur.Replace(",", ""); //EAP-7120: Remove this code as "," will potentiall pull a date as well.
                        decimal dclValuePur = Convert.ToDecimal(strValuePur.Trim());
                        if (dclValuePur != 0 && (!strValuePur.Contains(",")))
                        {
                            dclTotalPurchase = dclTotalPurchase + dclValuePur;
                            //Match matchDateCol = Regex.Match(strArr_splitcolumn[0], @"(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+(\d{4})", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            //if (matchDateCol.Success)
                            // {
                            // string strMonth = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("MMMM");
                            // string strDay = Convert.ToDateTime(matchDateCol.Groups[2].Value.Trim() + " " + matchDateCol.Groups[1].Value.Trim() + " " + matchDateCol.Groups[3].Value.Trim()).ToString("dd");
                            // string strD = strDay + "-" + strMonth + "-" + matchDateCol.Groups[3].Value.Trim();

                            //  string strD = (Convert.ToInt32(matchDateCol.Groups[2].Value.Trim())).ToString("00") + "-" + matchDateCol.Groups[1].Value.Trim() + "-" + matchDateCol.Groups[3].Value.Trim();
                            DateTime dtDatesale = new DateTime();
                            if (DateTime.TryParseExact(strD.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDatesale) == true)
                            {
                                if (!lstDate.Contains(dtDatesale))
                                    lstDate.Add(dtDatesale);
                            }
                            //  }
                            // else
                            // {
                            // oUrlPollStatus.PollAttempt.LogComment("Total sale = 0 or list of date count = 0");
                            // return;
                            //}
                        }
                    }
                }
                #endregion
            }
            else
            {
                oUrlPollStatus.PollAttempt.LogComment("Date validation for row fails");
                // return;
            }
        }
        public string Alert_BankDeposit(UrlPollStatus oUrlPollStatus, EconPublicationMessage objEconDeposit, AlertPublicationMessage objAlertbankDeposit, string[] str_arrShortEngMonth, int iMonth, DateTime dtFound, string strPCTVALUE)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(strPCTVALUE))
                {
                    string strReturn = null;
                    Match matchPCT = Regex.Match(strPCTVALUE.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchPCT.Success)
                    {
                        strPCTVALUE = strPCTVALUE.Replace(",", "");
                        strPCTVALUE = Regex.Replace(strPCTVALUE, " {1,}", "");
                        decimal dclDeposit = Convert.ToDecimal(strPCTVALUE);
                        StringBuilder sbDeposit = new StringBuilder(objAlertbankDeposit.AlertTemplate);
                        if (dclDeposit > 0)
                        {
                            sbDeposit.Replace("{ROSE/FELL/UNCHANGED}", "ROSE");
                            sbDeposit.Replace("{VALUE PCT}", dclDeposit.ToString("0.#") + "%");
                            strReturn = dclDeposit.ToString("0.#");
                        }
                        else if (dclDeposit < 0)
                        {
                            sbDeposit.Replace("{ROSE/FELL/UNCHANGED}", "FELL");
                            sbDeposit.Replace("{VALUE PCT}", dclDeposit.ToString("0.#").TrimStart('-') + "%");
                            strReturn = dclDeposit.ToString("0.#");
                        }
                        else if (dclDeposit == 0)
                        {
                            sbDeposit.Replace("{ROSE/FELL/UNCHANGED}", "UNCHANGED");
                            sbDeposit.Replace(" {VALUE PCT}", "");
                            strReturn = "0";
                        }
                        else
                            return null;
                        sbDeposit.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[iMonth - 1].Trim().ToUpper() + " " + dtFound.Day);
                        if (objEconDeposit.IsSent == false)
                            objEconDeposit.Send(dclDeposit.ToString("0.00"), null, oUrlPollStatus);
                        if (objAlertbankDeposit.IsSent == false)
                            objAlertbankDeposit.Send(sbDeposit.ToString(), oUrlPollStatus);
                        return strReturn;
                    }
                    else
                        return null;
                }
                else
                {
                    oUrlPollStatus.PollAttempt.LogComment("deposit value is empty for Scheduled Commercial Banks table");
                    return null;
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Commerical Bank Deposit Alert filling : " + e.Message + "   StackTrace : " + e.StackTrace);
                return null;
            }
        }

        public string Alert_BankLoan(UrlPollStatus oUrlPollStatus, EconPublicationMessage objEconLoan, AlertPublicationMessage objAlertbankLoan, string[] str_arrShortEngMonth, int iMonth, DateTime dtFound, string strPCTVALUE)
        {
            if (!string.IsNullOrWhiteSpace(strPCTVALUE))
            {
                Match matchPCT = Regex.Match(strPCTVALUE.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchPCT.Success)
                {
                    strPCTVALUE = strPCTVALUE.Replace(",", "");
                    strPCTVALUE = Regex.Replace(strPCTVALUE, " {1,}", "");
                    string strReturn = null;
                    decimal dclLoan = Convert.ToDecimal(strPCTVALUE);
                    StringBuilder sbLoan = new StringBuilder(objAlertbankLoan.AlertTemplate);
                    if (dclLoan > 0)
                    {
                        sbLoan.Replace("{ROSE/FELL/UNCHANGED}", "ROSE");
                        sbLoan.Replace("{VALUE PCT}", dclLoan.ToString("0.#") + "%");
                        strReturn = dclLoan.ToString("0.#");
                    }
                    else if (dclLoan < 0)
                    {
                        sbLoan.Replace("{ROSE/FELL/UNCHANGED}", "FELL");
                        sbLoan.Replace("{VALUE PCT}", dclLoan.ToString("0.#").TrimStart('-') + "%");
                        strReturn = dclLoan.ToString("0.#");
                    }
                    else if (dclLoan == 0)
                    {
                        sbLoan.Replace("{ROSE/FELL/UNCHANGED}", "UNCHANGED");
                        sbLoan.Replace(" {VALUE PCT}", "");
                        strReturn = "0";
                    }
                    else
                        return null;
                    sbLoan.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[iMonth - 1].Trim().ToUpper() + " " + dtFound.Day);
                    if (objEconLoan.IsSent == false)
                        objEconLoan.Send(dclLoan.ToString("0.00"), null, oUrlPollStatus);
                    if (objAlertbankLoan.IsSent == false)
                        objAlertbankLoan.Send(sbLoan.ToString(), oUrlPollStatus);
                    return strReturn;
                }
                else
                    return null;
            }
            else
            {
                oUrlPollStatus.PollAttempt.LogComment("depostit value is empty for Scheduled Commercial Banks table");
                return null;
            }
        }
        private void StoryExtraction_CommercialBank(UrlPollStatus oUrlPollStatus, StoryPublicationMessage objStoryBank, Match matchCommercialTable, string[] str_arrShortEngMonth, int iMonth, DateTime dtFound, Match matchDeposit, Match matchloan, string strDepositValue, string strLoanValue, bool cbIsUnitCrore)
        {
            try
            {
                MySourceStore mystore = (MySourceStore)Store;

                string strCurrency = mystore.strCurrencyValue;
                // decimal dclCurrency = Convert.ToDecimal(strCurrency.Trim());

                Match matchDepositValue = Regex.Match(matchDeposit.Value.Trim(), @"deposits\s*(\@){4}(.*?(\|){4})", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                string strDFigure = null;
                string strDChangeValue = null;
                string strFoodFigure = null;
                string strFoodChange = null;
                string strnonFoodFigure = null;
                string strnonFoodChange = null;
                string strloanFigure = null;
                string strloanChange = null;
                HandbrakeMessage hbBankLoan = (HandbrakeMessage)Store.PublicationMessages.GetPublicationMessage("HANDBRAKE_BANKLOAN");
                if (hbBankLoan != null)
                    hbBankLoan.Description = hbBankLoan.Description.Replace("{ALERT_URL}", "<a href=\"" + oUrlPollStatus.Source.Url + "\" target=\"_blank\">");
                if (matchDepositValue.Success)
                {
                    string strDepositFigure = Regex.Replace(matchDepositValue.Groups[2].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                    strDepositFigure = Regex.Replace(strDepositFigure.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                    string[] arrDeposit = Regex.Split(strDepositFigure, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (cbIsUnitCrore)
                    {
                        strDFigure = GetValuesinBillions(arrDeposit[0]);
                        strDChangeValue = GetValuesinBillions(arrDeposit[1]);
                    }
                    else
                    {
                        strDFigure = arrDeposit[0];
                        strDChangeValue = arrDeposit[1];
                    }
                    string[] arrfood = null;
                    string[] arrnonfood = null;
                    Match matchBankCredit = Regex.Match(matchCommercialTable.Value, @"bank\s*credit[\s\*]*(\@){4}.*?(food\s*credit|non\W*food\s*credit).*?(food\s*credit|non\W*food\s*credit).*?(\|){4}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchBankCredit.Success)
                    {
                        Match matchFood = Regex.Match(matchBankCredit.Value.Trim(), @"food\s*credit\s*(\@){4}(.*?(\|){4}).*?non\W+food\s*credit\s*(\@){4}(.*?(\|){4})", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                        if (matchFood.Success)
                        {
                            string strFood = Regex.Replace(matchFood.Groups[2].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            strFood = Regex.Replace(strFood.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            arrfood = Regex.Split(strFood, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (cbIsUnitCrore)
                            {

                                strFoodFigure = GetValuesinBillions(arrfood[0]);
                                strFoodChange = GetValuesinBillions(arrfood[1]);
                            }
                            else
                            {
                                strFoodFigure = arrfood[0];
                                strFoodChange = arrfood[1];
                            }

                            string strnonFood = Regex.Replace(matchFood.Groups[5].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            strnonFood = Regex.Replace(strnonFood.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            arrnonfood = Regex.Split(strnonFood, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (cbIsUnitCrore)
                            {
                                strnonFoodFigure = GetValuesinBillions(arrnonfood[0]);
                                strnonFoodChange = GetValuesinBillions(arrnonfood[1]);
                            }
                            else
                            {
                                strnonFoodFigure = arrnonfood[0];
                                strnonFoodChange = arrnonfood[1];
                            }

                        }
                        else
                        {
                            Match matchFood2 = Regex.Match(matchBankCredit.Value.Trim(), @"non\W+food\s*credit\s*(\@){4}(.*?(\|){4}).*?food\s*credit\s*(\@){4}(.*?(\|){4})", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                            if (matchFood2.Success)
                            {
                                string strFood = Regex.Replace(matchFood.Groups[5].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                                strFood = Regex.Replace(strFood.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                                arrfood = Regex.Split(strFood, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                //strFoodFigure = arrfood[0];
                                //strFoodChange = arrfood[1];
                                if (cbIsUnitCrore)
                                {

                                    strFoodFigure = GetValuesinBillions(arrfood[0]);
                                    strFoodChange = GetValuesinBillions(arrfood[1]);
                                }
                                else
                                {
                                    strFoodFigure = arrfood[0];
                                    strFoodChange = arrfood[1];
                                }
                                string strnonFood = Regex.Replace(matchFood.Groups[2].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                                strnonFood = Regex.Replace(strnonFood.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                                arrnonfood = Regex.Split(strnonFood, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            }
                            else
                            {
                                ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value, "Food credit and non food credit text not found from Scheduled commercial bank");
                            }
                        }
                        Match matchBCredit = Regex.Match(matchBankCredit.Value.Trim(), @"bank\s*credits?[\s\*]*(\@){4}(.*?(\|){4})", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                        if (matchBCredit.Success)
                        {
                            string strBC = Regex.Replace(matchBCredit.Groups[2].Value.Trim(), @"@@@@\s*(\|){4}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            strBC = Regex.Replace(strBC.Trim(), @" {1,}", "", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            string[] arrBankCredit = Regex.Split(strBC, @"@@@@", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (cbIsUnitCrore)
                            {
                                strloanFigure = GetValuesinBillions(arrBankCredit[0]);
                                strloanChange = GetValuesinBillions(arrBankCredit[1]);
                            }
                            else
                            {
                                strloanFigure = arrBankCredit[0];
                                strloanChange = arrBankCredit[1];
                            }
                            if ((arrBankCredit.Count() == 6) && (arrfood.Count() == 6) && (arrnonfood.Count() == 6) && (arrDeposit.Count() == 6))
                            {
                                Story_Commercialbank(oUrlPollStatus, objStoryBank, str_arrShortEngMonth, iMonth, dtFound, strDepositValue, strLoanValue, strCurrency, ref strDFigure, ref strDChangeValue, ref strFoodFigure, ref strFoodChange, ref strnonFoodFigure, ref strnonFoodChange, ref strloanFigure, ref strloanChange);

                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Array counts are not equal 6");
                            }
                        }
                        else
                        {
                            ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value, "Bank Credit not found from Scheduled commercial bank");
                        }
                    }
                    else
                    {
                        ValidationFailureMail(oUrlPollStatus, matchCommercialTable.Value, "Bank Credit range not found from Scheduled commercial bank");
                    }
                }
                else
                {
                    ValidationFailureMail(oUrlPollStatus, matchDeposit.Value, "Deposits figure not found from Scheduled commercial bank");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Commerical Bank story filling : " + e.Message + "   StackTrace : " + e.StackTrace);

            }
        }

        public void Story_Commercialbank(UrlPollStatus oUrlPollStatus, StoryPublicationMessage objStoryBank, string[] str_arrShortEngMonth, int iMonth, DateTime dtFound, string strDepositValue, string strLoanValue, string strCurrency, ref string strDFigure, ref string strDChangeValue, ref string strFoodFigure, ref string strFoodChange, ref string strnonFoodFigure, ref string strnonFoodChange, ref string strloanFigure, ref string strloanChange)
        {
            try
            {
                if ((!string.IsNullOrWhiteSpace(strDFigure)) && (!string.IsNullOrWhiteSpace(strDChangeValue))
                    && (!string.IsNullOrWhiteSpace(strFoodFigure)) && (!string.IsNullOrWhiteSpace(strFoodChange))
                    && (!string.IsNullOrWhiteSpace(strnonFoodFigure)) && (!string.IsNullOrWhiteSpace(strnonFoodChange))
                    && (!string.IsNullOrWhiteSpace(strloanFigure)) && (!string.IsNullOrWhiteSpace(strloanChange))
                    && (!string.IsNullOrWhiteSpace(strDepositValue)) && (!string.IsNullOrWhiteSpace(strLoanValue)))
                {

                    StringBuilder sb = new StringBuilder(objStoryBank.StoryTextTemplate);
                    StringBuilder sbHeader = new StringBuilder(objStoryBank.HeadlineTemplate);

                    decimal dclLoan = Convert.ToDecimal(strLoanValue.Trim());
                    if (dclLoan > 0)
                    {
                        sbHeader.Replace("{ROSE/FELL/UNCHANGED}", "rose");
                        sb.Replace("{LPCT_ROSE/FELL/WERE UNCHANGED}", "rose");
                        sbHeader.Replace("{VALUE PCT}", dclLoan.ToString("0.#") + "%");
                        sb.Replace("{LOAN VALUE PERCENT}", dclLoan.ToString("0.#") + "%");
                    }
                    else if (dclLoan < 0)
                    {
                        sbHeader.Replace("{ROSE/FELL/UNCHANGED}", "fell");
                        sb.Replace("{LPCT_ROSE/FELL/WERE UNCHANGED}", "fell");
                        sbHeader.Replace("{VALUE PCT}", dclLoan.ToString("0.#").TrimStart('-') + "%");
                        sb.Replace("{LOAN VALUE PERCENT}", dclLoan.ToString("0.#").TrimStart('-') + "%");
                    }
                    else if (dclLoan == 0)
                    {
                        sbHeader.Replace("{ROSE/FELL/UNCHANGED}", "unchanged");
                        sb.Replace("{LPCT_ROSE/FELL/WERE UNCHANGED}", "were unchanged");
                        sbHeader.Replace(" {VALUE PCT}", "");
                        sb.Replace(" {LOAN VALUE PERCENT}", "");
                    }
                    else
                        return;
                    sbHeader.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[iMonth - 1].Trim() + " " + dtFound.Day);

                    decimal dclDeposit = Convert.ToDecimal(strDepositValue.Trim());
                    if (dclDeposit > 0)
                    {

                        sb.Replace("{DPCT_ROSE/FELL/WERE UNCHANGED}", "rose");
                        sb.Replace("{DEPOSITS VALUE PERCENT}", dclDeposit.ToString("0.#") + "%");
                    }
                    else if (dclDeposit < 0)
                    {
                        sb.Replace("{DPCT_ROSE/FELL/WERE UNCHANGED}", "fell");
                        sb.Replace("{DEPOSITS VALUE PERCENT}", dclDeposit.ToString("0.#").TrimStart('-') + "%");
                    }
                    else if (dclDeposit == 0)
                    {
                        sb.Replace("{DPCT_ROSE/FELL/WERE UNCHANGED}", "were unchanged");
                        sb.Replace(" {DEPOSITS VALUE PERCENT}", "");
                    }
                    else
                        return;
                    Match matchLoanFigure = Regex.Match(strloanFigure.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchLoanFigure.Success)
                    {
                        strloanFigure = strloanFigure.Trim().Replace(",", "");
                        strloanFigure = Regex.Replace(strloanFigure, " {1,}", "");
                        decimal dclloanFigure = Convert.ToDecimal(strloanFigure);
                        if (dclloanFigure > 0)
                        {
                            if (dclloanFigure >= 1000)
                            {//trillion
                                dclloanFigure = dclloanFigure / 1000;
                                sb.Replace("{BANK_CERDIT_VALUE}", dclloanFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{L_TRILLION/BILLION/MILLION}", "trillion");
                            }
                            else if (dclloanFigure < 1)
                            {
                                dclloanFigure = dclloanFigure * 1000;
                                sb.Replace("{BANK_CERDIT_VALUE}", dclloanFigure.ToString("0.0", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{L_TRILLION/BILLION/MILLION}", "million");
                            }
                            else
                            {
                                sb.Replace("{BANK_CERDIT_VALUE}", dclloanFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{L_TRILLION/BILLION/MILLION}", "billion");
                            }
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchLoanValue = Regex.Match(strloanChange.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchLoanValue.Success)
                    {
                        strloanChange = strloanChange.Trim().Replace(",", "");
                        strloanChange = Regex.Replace(strloanChange, " {1,}", "");
                        decimal dclLoanValue = Convert.ToDecimal(strloanChange);
                        if (dclLoanValue != 0)
                        {
                            if (dclLoanValue > 0)
                                sb.Replace("{L_ROSE/FELL/REMAIN UNCHANGED}", "rose");
                            else
                            {
                                sb.Replace("{L_ROSE/FELL/REMAIN UNCHANGED}", "fell");
                                dclLoanValue = Math.Abs(dclLoanValue);
                            }
                            sb.Replace("{L_TO/AT}", "to");
                            if (dclLoanValue >= 1000)
                            {//trillion
                                dclLoanValue = dclLoanValue / 1000;
                                if (!string.IsNullOrWhiteSpace(strCurrency))
                                {
                                    decimal dclConvertedValue = dclLoanValue / Convert.ToDecimal(strCurrency.Trim());
                                    if (dclConvertedValue >= 1)
                                        sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion)");
                                    else
                                    {
                                        dclConvertedValue = dclConvertedValue * 1000;
                                        sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                    }
                                }
                                else
                                    sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                            }
                            else if (dclLoanValue < 1)
                            {
                                dclLoanValue = dclLoanValue * 1000;
                                if (!string.IsNullOrWhiteSpace(strCurrency))
                                {
                                    decimal dclConvertedValue = dclLoanValue / Convert.ToDecimal(strCurrency.Trim());
                                    sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                }
                                else
                                    sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");
                            }
                            else
                            {
                                if (!string.IsNullOrWhiteSpace(strCurrency))
                                {
                                    decimal dclConvertedValue = dclLoanValue / Convert.ToDecimal(strCurrency.Trim());
                                    if (dclConvertedValue >= 1)
                                        sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                    else
                                    {
                                        dclConvertedValue = dclConvertedValue * 1000;
                                        sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " million)");
                                    }
                                }
                                else
                                    sb.Replace("{BANK_CREDIT_CHANGEVALUE}", dclLoanValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                            }

                        }
                        else if (dclLoanValue == 0)
                        {
                            sb.Replace("{L_ROSE/FELL/REMAIN UNCHANGED}", "remained same");
                            sb.Replace("{L_TO/AT}", "at");
                            sb.Replace(" {BANK_CREDIT_CHANGEVALUE}", "");
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchNFfigure = Regex.Match(strnonFoodFigure.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchNFfigure.Success)
                    {
                        strnonFoodFigure = strnonFoodFigure.Trim().Replace(",", "");
                        strnonFoodFigure = Regex.Replace(strnonFoodFigure, " {1,}", "");
                        decimal dclnonfoodFigure = Convert.ToDecimal(strnonFoodFigure);
                        if (dclnonfoodFigure > 0)
                        {
                            if (dclnonfoodFigure >= 1000)
                            {//trillion
                                dclnonfoodFigure = dclnonfoodFigure / 1000;
                                sb.Replace("{NF_CREDIT_VALUE}", dclnonfoodFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{NF_TRILLION/BILLION/MILLION}", "trillion");
                            }
                            else if (dclnonfoodFigure < 1)
                            {
                                dclnonfoodFigure = dclnonfoodFigure * 1000;
                                sb.Replace("{NF_CREDIT_VALUE}", dclnonfoodFigure.ToString("0.0", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{NF_TRILLION/BILLION/MILLION}", "million");
                            }
                            else
                            {
                                sb.Replace("{NF_CREDIT_VALUE}", dclnonfoodFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{NF_TRILLION/BILLION/MILLION}", "billion");
                            }
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchnonFoodChange = Regex.Match(strnonFoodChange.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchnonFoodChange.Success)
                    {
                        strnonFoodChange = strnonFoodChange.Trim().Replace(",", "");
                        strnonFoodChange = Regex.Replace(strnonFoodChange, " {1,}", "");
                        decimal dclNonFoodChange = Convert.ToDecimal(strnonFoodChange);
                        if (dclNonFoodChange != 0)
                        {
                            if (dclNonFoodChange > 0)

                                sb.Replace("{NF_ROSE/FELL/REMAIN UNCHANGED}", "rose");
                            else
                            {
                                dclNonFoodChange = Math.Abs(dclNonFoodChange);
                                sb.Replace("{NF_ROSE/FELL/REMAIN UNCHANGED}", "fell");
                            }
                            sb.Replace("{NF_TO/AT}", "to");
                            if (dclNonFoodChange >= 1000)
                            {//trillion
                                dclNonFoodChange = dclNonFoodChange / 1000;
                                sb.Replace("{NF_CREDIT_CHANGEVALUE}", dclNonFoodChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                            }
                            else if (dclNonFoodChange < 1)
                            {
                                dclNonFoodChange = dclNonFoodChange * 1000;
                                sb.Replace("{NF_CREDIT_CHANGEVALUE}", dclNonFoodChange.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");
                            }
                            else
                            {
                                sb.Replace("{NF_CREDIT_CHANGEVALUE}", dclNonFoodChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                            }

                        }

                        else if (dclNonFoodChange == 0)
                        {
                            sb.Replace("{NF_ROSE/FELL/REMAIN UNCHANGED}", "remained same");
                            sb.Replace("{NF_TO/AT}", "at");
                            sb.Replace(" {NF_CREDIT_CHANGEVALUE}", "");
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchFfigure = Regex.Match(strFoodFigure.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchFfigure.Success)
                    {
                        strFoodFigure = strFoodFigure.Trim().Replace(",", "");
                        strFoodFigure = Regex.Replace(strFoodFigure, " {1,}", "");
                        decimal dclfoodFigure = Convert.ToDecimal(strFoodFigure);
                        if (dclfoodFigure > 0)
                        {
                            if (dclfoodFigure >= 1000)
                            {//trillion
                                dclfoodFigure = dclfoodFigure / 1000;
                                sb.Replace("{F_CREDIT_VALUE}", dclfoodFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{F_TRILLION/BILLION/MILLION}", "trillion");
                            }
                            else if (dclfoodFigure < 1)
                            {
                                dclfoodFigure = dclfoodFigure * 1000;
                                sb.Replace("{F_CREDIT_VALUE}", dclfoodFigure.ToString("0.0", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{F_TRILLION/BILLION/MILLION}", "million");
                            }
                            else
                            {
                                sb.Replace("{F_CREDIT_VALUE}", dclfoodFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{F_TRILLION/BILLION/MILLION}", "billion");
                            }
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchFoodChange = Regex.Match(strFoodChange.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchFoodChange.Success)
                    {
                        strFoodChange = strFoodChange.Trim().Replace(",", "");
                        strFoodChange = Regex.Replace(strFoodChange, " {1,}", "");
                        decimal dclFoodChange = Convert.ToDecimal(strFoodChange);
                        if (dclFoodChange != 0)
                        {
                            if (dclFoodChange > 0)
                                sb.Replace("{F_ROSE/FELL/REMAIN UNCHANGED}", "rose");
                            else
                            {
                                dclFoodChange = Math.Abs(dclFoodChange);
                                sb.Replace("{F_ROSE/FELL/REMAIN UNCHANGED}", "fell");
                            }
                            sb.Replace("{F_TO/AT}", "to");
                            if (dclFoodChange >= 1000)
                            {//trillion
                                dclFoodChange = dclFoodChange / 1000;
                                sb.Replace("{F_CREDIT_CHANGEVALUE}", dclFoodChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                            }
                            else if (dclFoodChange < 1)
                            {
                                dclFoodChange = dclFoodChange * 1000;
                                sb.Replace("{F_CREDIT_CHANGEVALUE}", dclFoodChange.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");
                            }
                            else
                            {
                                sb.Replace("{F_CREDIT_CHANGEVALUE}", dclFoodChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                            }

                        }

                        else if (dclFoodChange == 0)
                        {
                            sb.Replace("{F_ROSE/FELL/REMAIN UNCHANGED}", "remained same");
                            sb.Replace("{F_TO/AT}", "at");
                            sb.Replace(" {F_CREDIT_CHANGEVALUE}", "");
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchDfigure = Regex.Match(strDFigure.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchDfigure.Success)
                    {
                        strDFigure = strDFigure.Trim().Replace(",", "");
                        strDFigure = Regex.Replace(strDFigure, " {1,}", "");
                        decimal dclDepFigure = Convert.ToDecimal(strDFigure);
                        if (dclDepFigure > 0)
                        {
                            if (dclDepFigure >= 1000)
                            {//trillion
                                dclDepFigure = dclDepFigure / 1000;
                                sb.Replace("{DEPOSIT_VALUE}", dclDepFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{D_TRILLION/BILLION/MILLION}", "trillion");
                            }
                            else if (dclDepFigure < 1)
                            {
                                dclDepFigure = dclDepFigure * 1000;
                                sb.Replace("{DEPOSIT_VALUE}", dclDepFigure.ToString("0.0", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{D_TRILLION/BILLION/MILLION}", "million");
                            }
                            else
                            {
                                sb.Replace("{DEPOSIT_VALUE}", dclDepFigure.ToString("0.00", CultureInfo.InvariantCulture).Trim());
                                sb.Replace("{D_TRILLION/BILLION/MILLION}", "billion");
                            }
                        }
                        else
                            return;
                    }
                    else
                        return;
                    Match matchDChange = Regex.Match(strDChangeValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchDChange.Success)
                    {
                        strDChangeValue = strDChangeValue.Trim().Replace(",", "");
                        strDChangeValue = Regex.Replace(strDChangeValue, " {1,}", "");
                        decimal dclDChange = Convert.ToDecimal(strDChangeValue);
                        if (dclDChange != 0)
                        {
                            if (dclDChange > 0)
                                sb.Replace("{D_ROSE/FELL/REMAIN UNCHANGED}", "rose");
                            else
                            {
                                dclDChange = Math.Abs(dclDChange);
                                sb.Replace("{D_ROSE/FELL/REMAIN UNCHANGED}", "fell");
                            }
                            sb.Replace("{D_TO/AT}", "to");
                            if (dclDChange >= 1000)
                            {//trillion
                                dclDChange = dclDChange / 1000;
                                sb.Replace("{DEPOSIT_CHANGEVALUE}", dclDChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                            }
                            else if (dclDChange < 1)
                            {
                                dclDChange = dclDChange * 1000;
                                sb.Replace("{DEPOSIT_CHANGEVALUE}", dclDChange.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");
                            }
                            else
                            {
                                sb.Replace("{DEPOSIT_CHANGEVALUE}", dclDChange.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                            }

                        }
                        else if (dclDChange == 0)
                        {
                            sb.Replace("{D_ROSE/FELL/REMAIN UNCHANGED}", "remained same");
                            sb.Replace("{D_TO/AT}", "at");
                            sb.Replace(" {DEPOSIT_CHANGEVALUE}", "");
                        }
                        else
                            return;
                    }
                    else
                        return;
                    string[] strArr_EnglishMonth = { "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" };
                    if (str_arrShortEngMonth[iMonth - 1].ToUpper().Trim() == strArr_EnglishMonth[iMonth - 1].ToUpper().Trim())
                        sb.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[iMonth - 1].Trim() + " " + dtFound.Day);
                    else
                        sb.Replace("{OUTSTANDING_WEEK}", str_arrShortEngMonth[iMonth - 1].Trim() + ". " + dtFound.Day);
                    string Code = "India Standard Time";
                    DateTime dtNow = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                    sb.Replace("{DATELINE}", str_arrShortEngMonth[dtNow.Month - 1].Trim() + " " + dtNow.Day);
                    sb.Replace("{WEEKDAY}", dtNow.DayOfWeek.ToString());
                    if (!string.IsNullOrWhiteSpace(strCurrency))
                    {
                        decimal dclCurrency = Convert.ToDecimal(strCurrency.Trim());
                        sb.Replace("{CONVERTED_VALUE}", dclCurrency.ToString("0.0000"));
                    }
                    //sb.Replace("{CONVERTED_VALUE}", strCurrency.Trim());
                    else
                        sb.Replace("($1 = {CONVERTED_VALUE} Indian rupees)", "");
                    // sb.Replace("{SOURCE_TEXT}", "Source text: (" + oUrlPollStatus.Source.Url + ")");
                    MySourceStore mystore = (MySourceStore)Store;
                    lock (mystore.locker)
                    {
                        if (objStoryBank.IsSent == false)
                            objStoryBank.Send(sbHeader.ToString(), sb.ToString(), oUrlPollStatus);
                    }

                }
                else
                    return;
            }
            catch (Exception ex)
            {
                oUrlPollStatus.PollAttempt.LogComment("Exception : story filling for commercial bank==>" + ex.Message);
            }
        }
        public void StoryFiliingLiaAsset(UrlPollStatus oUrlPollStatus, DateTime dtDate, StoryPublicationMessage objStoryLiaAsset, string[] strarrWeek, string[] strArrCentral, string strCentralValue, string[] strArrState, string strStateValue, string[] str_arrShortEngMonth)
        {
            try
            {
                List<string> lstFigure = new List<string>();
                MySourceStore mystore = (MySourceStore)Store;
                string strCurrency = mystore.strCurrencyValue;
                //
                DateTime dtPrWeekDate = dtDate.AddDays(-7);
                int iPosPWeekint = Array.FindLastIndex(strarrWeek, x => Regex.Match(x, @"(" + dtPrWeekDate.ToString("MMM", CultureInfo.InvariantCulture) + "|" + dtPrWeekDate.ToString("MMMM", CultureInfo.InvariantCulture) + @")\W*" + "(" + dtPrWeekDate.Day + "|" + dtPrWeekDate.ToString("dd", CultureInfo.InvariantCulture) + ")", RegexOptions.IgnoreCase).Success);
                if (iPosPWeekint != -1)
                {
                    string strPCentralValue = strArrCentral[iPosPWeekint].Trim();
                    string strPStateValue = strArrState[iPosPWeekint].Trim();
                    StringBuilder sb = new StringBuilder(objStoryLiaAsset.StoryTextTemplate);
                    StringBuilder sbHeader = new StringBuilder(objStoryLiaAsset.HeadlineTemplate);
                    if (!string.IsNullOrWhiteSpace(strCurrency))
                    {
                        decimal dclCurrency = Convert.ToDecimal(strCurrency.Trim());
                        sb.Replace("{CONVERTED_VALUE}", dclCurrency.ToString("0.0000"));
                    }
                    else
                        sb.Replace("($1 = {CONVERTED_VALUE} Indian rupees)", "");
                    // sb.Replace("{SOURCE_TEXT}", "Source text: (" + oUrlPollStatus.Source.Url + ")");
                    if (string.IsNullOrWhiteSpace(strCentralValue)) strCentralValue = "-";
                    if (string.IsNullOrWhiteSpace(strStateValue)) strStateValue = "-";
                    if (string.IsNullOrWhiteSpace(strPCentralValue)) strPCentralValue = "-";
                    if (string.IsNullOrWhiteSpace(strPStateValue)) strPStateValue = "-";
                    if ((!string.IsNullOrWhiteSpace(strCentralValue)) && (!string.IsNullOrWhiteSpace(strPCentralValue)) && (!string.IsNullOrWhiteSpace(strStateValue)) && (!string.IsNullOrWhiteSpace(strPStateValue)))
                    {
                        lstFigure.Add(strCentralValue);
                        lstFigure.Add(strPCentralValue);
                        lstFigure.Add(strStateValue);
                        lstFigure.Add(strPStateValue);
                        int iFigure = -1;
                        for (int i = 0; i < lstFigure.Count; i++)
                        {
                            if ((lstFigure[i].Trim() != "-") && (lstFigure[i].Trim() != "–"))
                            {
                                iFigure = i;
                                break;
                            }
                        }
                        if (((strPCentralValue.Trim() == "-") || (strPCentralValue.Trim() == "–") || (strPCentralValue.Trim() == "0")) && ((strCentralValue.Trim() == "-") || (strCentralValue.Trim() == "–") || (strCentralValue.Trim() == "0")))
                            sb.Replace("{as well}", "as well");
                        else
                            sb.Replace(" {as well}", "");
                        #region CentralGovt
                        #region Central_CUR_Govt
                        if ((strCentralValue.Trim() == "-") || (strCentralValue.Trim() == "–") || (strCentralValue.Trim() == "0"))// || (strCentralValue.Trim().ToUpper() == "NA") || (strCentralValue.Trim().ToUpper() == "N/A"))
                        {
                            sbHeader.Replace("{CURRENT_VALUE}", "no");
                            sb.Replace("{CURRENT_VALUE}", "no");
                        }
                        else
                        {

                            Match matchCentralValue = Regex.Match(strCentralValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchCentralValue.Success)
                            {
                                strCentralValue = strCentralValue.Trim().Replace(",", "");
                                decimal dclCentralValue = Convert.ToDecimal(strCentralValue.Trim());
                                if (dclCentralValue > 0)
                                {
                                    if (dclCentralValue >= 1000)
                                    {//trillion
                                        dclCentralValue = dclCentralValue / 1000;
                                        if (iFigure == 0)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion)");//trillion
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");//trillion
                                                }
                                            }
                                            else
                                                sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");//trillion
                                        sbHeader.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trln rupees");//trillion
                                    }
                                    else if (dclCentralValue < 1)
                                    {
                                        dclCentralValue = dclCentralValue * 1000;
                                        if (iFigure == 0)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                            }
                                            else
                                                sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                        sbHeader.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " mln rupees");//trillion
                                    }
                                    else
                                    {
                                        if (iFigure == 0)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                                }
                                            }
                                            else
                                                sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                        }
                                        else
                                            sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                        sbHeader.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " bln rupees");
                                    }
                                }
                                if (dclCentralValue == 0)
                                    return;
                                if (dclCentralValue < 0)
                                    return;
                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Current week Central bank figure is not the numeric(" + strCentralValue + ")");
                                return;
                            }
                        }
                        #endregion
                        #region Central_PREV_Govt
                        if ((strPCentralValue.Trim() == "-") || (strPCentralValue.Trim() == "–") || (strPCentralValue.Trim() == "0"))// || (strPCentralValue.Trim().ToUpper() == "NA") || (strPCentralValue.Trim().ToUpper() == "N/A")))
                            sb.Replace("{PREVIOUS_VALUE}", "no");
                        else
                        {
                            Match matchPCentralValue = Regex.Match(strPCentralValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchPCentralValue.Success)
                            {
                                strPCentralValue = strPCentralValue.Trim().Replace(",", "");
                                decimal dclPCentralValue = Convert.ToDecimal(strPCentralValue.Trim());
                                if (dclPCentralValue > 0)
                                {
                                    if (dclPCentralValue >= 1000)
                                    {
                                        dclPCentralValue = dclPCentralValue / 1000;
                                        if (iFigure == 1)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion)");//trillion
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");//trillion
                                                }
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                                    }
                                    else if (dclPCentralValue < 1)
                                    {
                                        dclPCentralValue = dclPCentralValue * 1000;
                                        if (iFigure == 1)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                                                                                                                                                      // sbHeader.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " mln rupees");//trillion

                                    }
                                    else
                                    {
                                        if (iFigure == 1)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPCentralValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                                }
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_VALUE}", dclPCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                    }
                                }
                                if (dclPCentralValue == 0)
                                    return;
                                if (dclPCentralValue < 0)
                                    return;
                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Previous week figure for central bank is not a numeric(" + strPCentralValue + ") in liabilites and asset table");
                                return;
                            }
                        }
                        #endregion
                        #endregion

                        #region StateGovt
                        #region State_CUR_Govt
                        if ((strStateValue.Trim() == "-") || (strStateValue.Trim() == "–") || (strStateValue.Trim() == "0"))// || (strStateValue.Trim().ToUpper() == "NA") || (strStateValue.Trim().ToUpper() == "N/A"))
                            sb.Replace("{CURRENT_SVALUE}", "no");
                        else
                        {
                            Match matchStateValue = Regex.Match(strStateValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchStateValue.Success)
                            {
                                strStateValue = strStateValue.Trim().Replace(",", "");
                                decimal dclStateValue = Convert.ToDecimal(strStateValue.Trim());
                                if (dclStateValue > 0)
                                {
                                    if (dclStateValue >= 1000)
                                    {
                                        dclStateValue = dclStateValue / 1000;
                                        if (iFigure == 2)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion)");//trillion
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");//trillion
                                                }
                                            }
                                            else
                                                sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");//trillion
                                    }
                                    else if (dclStateValue < 1)
                                    {
                                        dclStateValue = dclStateValue * 1000;
                                        if (iFigure == 2)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                            }
                                            else
                                                sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                                                                                                                                                   //sbHeader.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " mln rupees");//trillion
                                    }
                                    else
                                    {
                                        if (iFigure == 2)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                                }
                                            }
                                            else
                                                sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                        }
                                        else
                                            sb.Replace("{CURRENT_SVALUE}", dclStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                    }
                                }
                                if (dclStateValue == 0)
                                    sb.Replace("{CURRENT_SVALUE}", "no");
                                if (dclStateValue < 0)
                                    return;
                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Current week figure for state govt. is not a numeric(" + strPCentralValue + ") in liabilites and asset table");
                                return;
                            }
                        }
                        #endregion
                        #region State_Prev_Govt
                        if ((strPStateValue.Trim() == "-") || (strPStateValue.Trim() == "–") || (strPStateValue.Trim() == "0"))// || (strPStateValue.Trim().ToUpper() == "NA") || (strPStateValue.Trim().ToUpper() == "N/A"))
                            sb.Replace("{PREVIOUS_SVALUE}", "no loans");
                        else
                        {
                            Match matchPStateValue = Regex.Match(strPStateValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchPStateValue.Success)
                            {
                                strPStateValue = strPStateValue.Trim().Replace(",", "");
                                decimal dclPStateValue = Convert.ToDecimal(strPStateValue.Trim());
                                if (dclPStateValue > 0)
                                {
                                    if (dclPStateValue >= 1000)
                                    {
                                        dclPStateValue = dclPStateValue / 1000;
                                        //sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");//trillion
                                        if (iFigure == 3)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion)");//trillion
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");//trillion
                                                }
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " trillion rupees");

                                    }
                                    else if (dclPStateValue < 1)
                                    {
                                        dclPStateValue = dclPStateValue * 1000;
                                        if (iFigure == 3)
                                        {
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                                                                                                                                                         //sbHeader.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " mln rupees");//trillion
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million rupees");//trillion
                                    }
                                    else
                                    {
                                        if (iFigure == 3)
                                        {
                                            // sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                            if (!string.IsNullOrWhiteSpace(strCurrency))
                                            {
                                                decimal dclConvertedValue = dclPStateValue / Convert.ToDecimal(strCurrency.Trim());
                                                if (dclConvertedValue >= 1)
                                                    sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion)");
                                                else
                                                {
                                                    dclConvertedValue = dclConvertedValue * 1000;
                                                    sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees ($" + dclConvertedValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " million)");
                                                }
                                            }
                                            else
                                                sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                        }
                                        else
                                            sb.Replace("{PREVIOUS_SVALUE}", dclPStateValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " billion rupees");
                                    }
                                }
                                if (dclPStateValue == 0)
                                    return;
                                if (dclPStateValue < 0)
                                    return;
                            }
                            else
                            {
                                oUrlPollStatus.PollAttempt.LogComment("Previous week figure for state govt. is not numeric in liabilities and asset");
                            }
                        }
                        #endregion
                        #endregion

                        sbHeader.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].Trim() + " " + dtDate.Day);
                        string[] strArr_EnglishMonth = { "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" };
                        if (str_arrShortEngMonth[dtDate.Month - 1].ToUpper().Trim() == strArr_EnglishMonth[dtDate.Month - 1].ToUpper().Trim())
                            sb.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].Trim() + " " + dtDate.Day);
                        else
                            sb.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].Trim() + ". " + dtDate.Day);
                        string Code = "India Standard Time";
                        DateTime dtNow = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                        sb.Replace("{DATELINE}", str_arrShortEngMonth[dtNow.Month - 1].Trim() + " " + dtNow.Day);
                        sb.Replace("{WEEKDAY}", dtNow.DayOfWeek.ToString());
                        lock (mystore.locker)
                        {
                            if (objStoryLiaAsset.IsSent == false)
                                objStoryLiaAsset.Send(sbHeader.ToString(), sb.ToString(), oUrlPollStatus);
                        }
                    }
                    else
                    {
                        oUrlPollStatus.PollAttempt.LogComment("One of the value is null or empty in commercial bank table.");
                        return;
                    }
                    //Null or empty
                }//pweek index=-1
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in StoryFilling_LiabilitesAssets : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        public void AlertFilling_LiabilitiesAsset(UrlPollStatus oUrlPollStatus, DateTime dtDate, string strCentralValue, string[] str_arrShortEngMonth, AlertPublicationMessage objAlertLiaAsset)
        {
            try
            {
                StringBuilder sb = new StringBuilder(objAlertLiaAsset.AlertTemplate);
                if (!string.IsNullOrWhiteSpace(strCentralValue))
                {
                    if ((strCentralValue.Trim() == "-") || (strCentralValue.Trim() == "–") || (strCentralValue.Trim() == "0"))//|| (strCentralValue.Trim().ToUpper() == "NA") || (strCentralValue.Trim().ToUpper() == "N/A"))
                    {
                        sb.Replace("{CURRENT_VALUE}", "NO");
                        sb.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].ToUpper().Trim() + " " + dtDate.Day);
                        objAlertLiaAsset.Send(sb.ToString(), oUrlPollStatus);
                        HandbrakeMessage hbLoanAdv = (HandbrakeMessage)Store.PublicationMessages.GetPublicationMessage("HANDBRAKE_LOAN_ADV");
                        if (hbLoanAdv != null)
                            hbLoanAdv.Description = hbLoanAdv.Description.Replace("{ALERT_URL}", "<a href=\"" + oUrlPollStatus.Source.Url + "\" target=\"_blank\">");
                    }
                    else
                    {
                        Match matchdigit = Regex.Match(strCentralValue.Trim(), @"\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (matchdigit.Success)
                        {
                            strCentralValue = strCentralValue.Trim().Replace(",", "");
                            decimal dclCentralValue = Convert.ToDecimal(strCentralValue.Trim());

                            if (dclCentralValue > 0)
                            {
                                if (dclCentralValue >= 1000)
                                {
                                    dclCentralValue = dclCentralValue / 1000;
                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " TRLN RUPEES");//trillion
                                }
                                else if (dclCentralValue < 1)
                                {
                                    dclCentralValue = dclCentralValue * 1000;
                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.0", CultureInfo.InvariantCulture).Trim() + " MLN RUPEES");//trillion
                                }
                                else
                                    sb.Replace("{CURRENT_VALUE}", dclCentralValue.ToString("0.00", CultureInfo.InvariantCulture).Trim() + " BLN RUPEES");
                            }
                            if (dclCentralValue == 0)
                                return;
                            if (dclCentralValue < 0)
                                return;

                            sb.Replace("{CURRENT_WEEK}", str_arrShortEngMonth[dtDate.Month - 1].ToUpper().Trim() + " " + dtDate.Day);
                            objAlertLiaAsset.Send(sb.ToString(), oUrlPollStatus);
                        }
                        else
                            return;
                    }
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in Alert_LiabilitesAssets : " + e.Message + "   StackTrace : " + e.StackTrace);
                oUrlPollStatus.PollAttempt.LogComment(strCentralValue);
            }
        }


        private void PDF_LiquidityOMO(UrlPollStatus oUrlPollStatus, string strConverted_Text, DateTime dtDate, AlertPublicationMessage objAlertOMO, StoryPublicationMessage objStoryOMO)
        {
            bool cbIsUnitCrore = false;
            //NEWSource obj = new NEWSource();
            //obj.Store = this.Store;
            Match matchOMOHeader = null;
            oUrlPollStatus.PollAttempt.LogComment("OMO header starts");
            matchOMOHeader = Regex.Match(strConverted_Text, @"Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|reserve\W*bank\W*(?:of)?\W*india)\W*`?\s*(Billion|bn|bln|crore|crores|cr)\W*?\s*(OMO)?\s*Liquidity\s*Adjustment\s*Facilit(?:y|ies).*?\s*(?(1)|(OMO))[^\n]*\n(?<content>.*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

            if (!matchOMOHeader.Success)
            {
                matchOMOHeader = Regex.Match(strConverted_Text, @"Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|reserve\W*bank\W*(?:of)?\W*india)\W*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*Liquidity\s*Adjustment\s*Facilit(?:y|ies)\s*OMO\s*(?:\(\s*Outright\s*\))?\s*[^\n]*\n(?<content>.*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            }
            if (!matchOMOHeader.Success)
                matchOMOHeader = Regex.Match(strConverted_Text, @"Liquidity\s*Operations?\s*by\s*(?:R\W*B\W*I\W*|reserve\W*bank\W*(?:of)?\W*india)\W*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:date)?\s*Liquidity\s*Adjustment\s*Facilit(?:y|ies).*?OMO\s*(?:\(\s*Outright\s*\))?[^\n]*\n(?<content>.*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

            oUrlPollStatus.PollAttempt.LogComment("OMO header ends");
            if (matchOMOHeader.Success)
            {
                string csUnit = matchOMOHeader.Groups[1].Captures[0].Value.Trim();
                if (csUnit.ToLower().Contains("cr"))
                    cbIsUnitCrore = true;
                string strOMOContent = matchOMOHeader.Groups["content"].Value;
                StringReader reader = new StringReader(strOMOContent);
                string strline = null;
                decimal dclTotalSale = 0;
                decimal dclTotalPurchase = 0;
                bool flagSalPur = false;
                bool flagAbsorption = false;
                //  bool flagSalPurFound = false;
                bool flagSPFound = false;
                List<DateTime> lstDate = new List<DateTime>();
                Match matchSalePur = null;
                oUrlPollStatus.PollAttempt.LogComment("OMO first while starts");
                while ((strline = reader.ReadLine()) != null)
                {

                    matchSalePur = Regex.Match(strline, @"\s+sales?\s+purchases?", RegexOptions.IgnoreCase);
                    if (matchSalePur.Success)
                    {
                        string[] strarrSalPur = Regex.Split(strline, @" {2,}", RegexOptions.IgnoreCase);
                        Match matchSale = Regex.Match(strarrSalPur[strarrSalPur.Count() - 3], @"sales?", RegexOptions.IgnoreCase);
                        Match matchPur = Regex.Match(strarrSalPur[strarrSalPur.Count() - 2], @"Purchases?", RegexOptions.IgnoreCase);
                        if (matchSale.Success && matchSalePur.Success)
                        {
                            flagSalPur = true;
                            break;
                        }
                        // flagSalPurFound = true;
                    }
                    Match matchSalePur1 = Regex.Match(matchSalePur.Value, @"\s+sales?\s+purchases?\s*$", RegexOptions.IgnoreCase);
                    if (matchSalePur1.Success)
                    {
                        flagSPFound = true;

                    }

                    Match matAbsorption = Regex.Match(strline, @"(?:net|injection|absorption|(\d+\W+){1,})\W*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matAbsorption.Success)
                        flagAbsorption = true;
                    if ((flagAbsorption == true) && (flagSPFound == true))
                    {
                        flagSalPur = true;
                        break;
                    }

                }//while
                oUrlPollStatus.PollAttempt.LogComment("OMO first while ends");
                //  if ((flagSalPur == true) || (flagSalPurFound == true))
                if (flagSalPur == true)
                {
                    Match matchdate = Regex.Match(strOMOContent, @"((" + dtDate.ToString("MMM") + @"|" + dtDate.AddMonths(-1).ToString("MMM") + ").*?)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    reader = new StringReader(matchdate.Groups[1].Value);
                    if (matchdate.Success)
                    {
                        while ((strline = reader.ReadLine()) != null)
                        {
                            string strEndingString = @"^\s*(?:\d+\W*)?(Scheduled\s*Commercial\s*Bank|Money\s*Stock|Liquidity\s*Operation|((Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?)|Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?|press\W*releases?)";
                            Match MatchEnd = Regex.Match(strline, strEndingString, RegexOptions.IgnoreCase);
                            if (MatchEnd.Success)
                                break;
                            if (!string.IsNullOrWhiteSpace(strline))
                            {
                                string[] strarrFigure = Regex.Split(strline.Trim(), @" {2,}", RegexOptions.IgnoreCase);

                                List<string> ls = new List<string>();
                                ls.Add(strarrFigure[0]);
                                string sNewstrline = new Regex(new Regex("\\W+", RegexOptions.IgnoreCase | RegexOptions.Singleline).Replace(strarrFigure[0], "\\W*") + @" {2,}", RegexOptions.Singleline | RegexOptions.IgnoreCase).Replace(strline, "");
                                strarrFigure = Regex.Split(sNewstrline.Trim(), @" {1,}", RegexOptions.IgnoreCase);
                                foreach (string str in strarrFigure)
                                    ls.Add(str);
                                strarrFigure = ls.ToArray();
                                if (strarrFigure.Count() >= 3)
                                {
                                    int iColCount = strarrFigure.Count();
                                    string strValueSale = strarrFigure[iColCount - 3];
                                    string strValuePur = strarrFigure[iColCount - 2];
                                    if (iColCount >= 12)
                                    {
                                        strValueSale = strarrFigure[8];
                                        strValuePur = strarrFigure[9];
                                    }
                                    ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strarrFigure);
                                }
                            }
                            // if ((strarrFigure.Count() == 10) || (strarrFigure.Count() == 9))
                            //  {
                            // string strValueSale = null;
                            // string strValuePur = null;

                            //if (strarrFigure.Count() == 10)
                            //{
                            //    strValueSale = strarrFigure[7];
                            //    strValuePur = strarrFigure[8];
                            //}
                            //if (strarrFigure.Count() == 9)
                            //{
                            //    strValueSale = strarrFigure[6];
                            //    strValuePur = strarrFigure[7];
                            //}
                            //ExtractOMOFigures(oUrlPollStatus, strValueSale, strValuePur, ref dclTotalSale, ref dclTotalPurchase, lstDate, strarrFigure);
                            // }
                        }//while
                        if (csUnit.ToLower().Contains("cr"))
                        {
                            dclTotalSale = dclTotalSale / 100;
                            dclTotalPurchase = dclTotalPurchase / 100;

                        }
                        OMOFilling(oUrlPollStatus, objAlertOMO, objStoryOMO, ref dclTotalSale, ref dclTotalPurchase, lstDate);
                    }
                }
                else
                    ValidationFailureMail(oUrlPollStatus, strOMOContent, "Sales-Purchase are not at spectic index");

            }
            else
                ValidationFailureMail(oUrlPollStatus, strConverted_Text, "OMO header not found from PDF source");
        }
        private void PDF_ScheduledBank(UrlPollStatus oUrlPollStatus, string strContent, DateTime dtDate, EconPublicationMessage objEconDeposit, AlertPublicationMessage objAlertbankDeposit, EconPublicationMessage objEconLoan, AlertPublicationMessage objAlertbankloan, StoryPublicationMessage objStory)
        {
            try
            {
                bool cbIsUnitCrore = false;
                MySourceStore mystore = (MySourceStore)Store;
                string strYYYY = "";
                string strConverted_Text = strContent;
                strConverted_Text = Regex.Replace(strConverted_Text.Trim(), @"\b+(?:Items?|Variations?\s*Over)\b+", " ", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                string strCurrency = mystore.strCurrencyValue;
                Match matchCommercialHeader = null;
                string strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:items?)?\s*outstanding\s*(?:variations?\s*over)?\s*(?:items?)?\s*as\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+\s*financial\s*year\s*so\s*far\s*(?:(?:year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s*(?:items?)?\s*(\d{4})?\s*fortnight\s*(?<year>\d{4})?\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                try
                {
                    matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                }
                catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                if (matchCommercialHeader.Success)
                {
                    if (!string.IsNullOrWhiteSpace(matchCommercialHeader.Groups[4].Value))
                        strYYYY = matchCommercialHeader.Groups[4].Value.Trim();
                    else
                        strYYYY = matchCommercialHeader.Groups["year"].Value.Trim();
                }
                if (!matchCommercialHeader.Success)
                {
                    strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*outstanding\s*as\s*on\s*financial\s*year\s*so\s*far\s*(?:(?:year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4})\s*fortnight\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                    try
                    {
                        matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                    }
                    catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                }
                if (!matchCommercialHeader.Success)
                {
                    strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:items?)?\s*outstanding\s*as\s*(?:variations?\s*over)?\s*(?:items?)?\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+\s*financial\s*year\s*so\s*far\s*(?:(?:year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s*(?:items?)?\s*fortnight\s*(\d{4})\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                    try
                    {
                        matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                    }
                    catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                }
                if (!matchCommercialHeader.Success)
                {
                    strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:items?)?\s*(?:variations?\s*over)?\s*(?:items?)?\s*outstanding\s*as\s*(?:items?)?\s*financial\s*year\s*so\s*far\s*(?:(?:year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s*(?:items?)?\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4})\s*(?:items?)?\s*fortnight\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                    try
                    {
                        matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                    }
                    catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                }
                if (!matchCommercialHeader.Success)
                {
                    strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:items?)?\s*(?:variations?\s*over)?\s*(?:items?)?\s*outstanding\s*as\s*(?:variations?\s*over)?\s*(?:items?)?\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4})\s*(?:items?)?\s*fortnight\s*financial\s*year\s*so\s*far\s*(?:(?:year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                    try
                    {
                        matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                    }
                    catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                }
                if (!matchCommercialHeader.Success)
                {
                    strRegexCommercial = @"scheduled\s*commercial\s*banks?[^\n]*\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*(?:items?)?\s*outstanding\s*(?:variations?\s*over)?\s*(?:items?)?\s*as\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*\s*Financial\s*year\s*so\s*far\s*(?:(?:Year\W*(?:on|over)\W*year)|(?:yoy)|(?:y\W*y)|(?:year\W*year))\s*(?:items?)?\s*(\d{1,2})\W*\s*(\d{4})?\s*fortnight\s*(?<year>\d{4})?\s+\d{4}(?:\-\d{2})?\s+\d{4}(?:\-\d{2})?\s+\d{4}\s+(\d{4})\s*[\n](.*?)$";
                    try
                    {
                        matchCommercialHeader = Regex.Match(strConverted_Text, strRegexCommercial, RegexOptions.IgnoreCase | RegexOptions.Singleline, TimeSpan.FromSeconds(iRegxTimeout));
                    }
                    catch (Exception ex) { oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString()); }
                }
                if (matchCommercialHeader.Success)
                {
                    if (string.IsNullOrWhiteSpace(strYYYY))
                        strYYYY = matchCommercialHeader.Groups[4].Value.Trim();
                    string csUnit = matchCommercialHeader.Groups[1].Captures[0].Value.Trim();
                    if (csUnit.ToLower().Contains("cr"))
                        cbIsUnitCrore = true;
                }
                if (!string.IsNullOrWhiteSpace(strYYYY))
                {
                    string strDtfortnight = Convert.ToDateTime(matchCommercialHeader.Groups[2].Value.Trim() + " " + matchCommercialHeader.Groups[3].Value.Trim() + " " + strYYYY.Trim()).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture);

                    DateTime dtFound = new DateTime();
                    if (DateTime.TryParseExact(strDtfortnight.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtFound) == true)
                    {
                        if (dtDate.AddDays(-7) == dtFound)
                        {
                            string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };

                            int iMonth = dtFound.Month;
                            if ((dtDate.AddDays(-7)).ToString("yyyy", CultureInfo.InvariantCulture).ToUpper().Trim() == matchCommercialHeader.Groups[5].Value.Trim().ToUpper())
                            {
                                string strCommercialTable = matchCommercialHeader.Groups[6].Value;
                                StringReader reader = new StringReader(strCommercialTable);
                                string strline = "";
                                string strLiab = null;
                                string strBankCredit = null;
                                bool flagLiab = false;
                                bool flagBankCredit = false;

                                string DFigure = null;
                                string DFortnight = null;
                                string BCreditFigure = null;
                                string BCreditFortnight = null;
                                string foodFigure = null;
                                string nonFoodFigure = null;
                                string foodFortnight = null;
                                string nonfoodFortnight = null;
                                string strDepositValue = null;
                                string strLoanValue = null;

                                string strEndingString = @"^\s*(?:\d+\W*)?(Liquidity\s*Operation|((Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?)|Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?|Money\s*Stock)";
                                if (!oUrlPollStatus.IsRequestCompleted)
                                    return;
                                while ((strline = reader.ReadLine()) != null)
                                {
                                    Match matchEnd = Regex.Match(strline, strEndingString, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    if (matchEnd.Success)
                                        break;
                                    if (flagBankCredit == true)
                                        //                                        strBankCredit = strBankCredit + strline + Environment.NewLine; -ROBOTCHANGE-20180316
                                        strBankCredit = strBankCredit + strline + "\r\n";
                                    Match matchBankCredit = Regex.Match(strline, @"Bank\s*Credit", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    if (matchBankCredit.Success)
                                    {
                                        //                                        strBankCredit = strBankCredit + strline + Environment.NewLine; -ROBOTCHANGE-20180316
                                        strBankCredit = strBankCredit + strline + "\r\n";
                                        flagBankCredit = true;
                                    }
                                    if (matchBankCredit.Success)
                                        flagBankCredit = true;
                                    if ((flagLiab == true) && (flagBankCredit == false))
                                    {
                                        //                                        strLiab = strLiab + strline + Environment.NewLine; -ROBOTCHANGE-20180316
                                        strLiab = strLiab + strline + "\r\n";
                                    }
                                    Match matchLiab = Regex.Match(strline, @"liabilit(y|ies)\s*to\s*others?", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    if (matchLiab.Success)
                                        flagLiab = true;
                                    #region Alert_Deposit

                                    if (!string.IsNullOrWhiteSpace(strLiab))
                                    {
                                        if (string.IsNullOrWhiteSpace(strDepositValue))
                                        {
                                            Match matchLia_GrowthPCT = Regex.Match(strLiab, @"growth\s*\(?(?:per\s*cent|\%|pct|cent|percentage)\)?([^\n]*)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                            if (matchLia_GrowthPCT.Success)
                                            {
                                                Match matchFigure = Regex.Match(matchLia_GrowthPCT.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                if (matchFigure.Success)
                                                {
                                                    if (matchFigure.Groups[1].Captures.Count == 5)
                                                    {
                                                        string strPCTVALUE = matchFigure.Groups[1].Captures[4].Value.Trim();

                                                        strDepositValue = Alert_BankDeposit(oUrlPollStatus, objEconDeposit, objAlertbankDeposit, str_arrShortEngMonth, iMonth, dtFound, strPCTVALUE);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    #endregion
                                    #region Alert_Loan
                                    if (!string.IsNullOrWhiteSpace(strBankCredit))
                                    {
                                        if (string.IsNullOrWhiteSpace(strLoanValue))
                                        {
                                            Match matchBankCredit_GrowthPCT = Regex.Match(strBankCredit, @"growth\s*\(?(?:per\s*cent|\%|pct|cent|percentage)\)?([^\n]*)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                            if (matchBankCredit_GrowthPCT.Success)
                                            {
                                                Match matchFigure = Regex.Match(matchBankCredit_GrowthPCT.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                                if (matchFigure.Success)
                                                {
                                                    if (matchFigure.Groups[1].Captures.Count == 5)
                                                    {
                                                        string strPCTVALUE = matchFigure.Groups[1].Captures[4].Value.Trim();
                                                        strLoanValue = Alert_BankLoan(oUrlPollStatus, objEconLoan, objAlertbankloan, str_arrShortEngMonth, iMonth, dtFound, strPCTVALUE);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    #endregion

                                    #region Story

                                    if (!string.IsNullOrWhiteSpace(strLiab))
                                    {
                                        #region AggreDeposit
                                        if ((string.IsNullOrWhiteSpace(DFigure)) || (string.IsNullOrWhiteSpace(DFortnight)))
                                        {
                                            Match matchAggDeposit = Regex.Match(strLiab, @"Aggregate\s*Deposits?(.*?$)", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            if (matchAggDeposit.Success)
                                            {
                                                Match figure = Regex.Match(matchAggDeposit.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                                if (figure.Success)
                                                {
                                                    if (figure.Groups[1].Captures.Count == 6)
                                                    {
                                                        if (cbIsUnitCrore)
                                                        {

                                                            DFigure = GetValuesinBillions(figure.Groups[1].Captures[0].Value.Trim());
                                                            DFortnight = GetValuesinBillions(figure.Groups[1].Captures[1].Value.Trim());
                                                        }
                                                        else
                                                        {
                                                            DFigure = figure.Groups[1].Captures[0].Value.Trim();
                                                            DFortnight = figure.Groups[1].Captures[1].Value.Trim();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    if (!string.IsNullOrWhiteSpace(strBankCredit))
                                    {
                                        #region bankCredit
                                        if ((string.IsNullOrWhiteSpace(BCreditFigure)) || (string.IsNullOrWhiteSpace(BCreditFortnight)))
                                        {
                                            Match matchBankCreditFigure = Regex.Match(strBankCredit, @"Bank\s*Credit(.*?$)", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                            if (matchBankCreditFigure.Success)
                                            {
                                                Match figure = Regex.Match(matchBankCreditFigure.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                                if (figure.Success)
                                                {
                                                    if (figure.Groups[1].Captures.Count == 6)
                                                    {
                                                        if (cbIsUnitCrore)
                                                        {

                                                            BCreditFigure = GetValuesinBillions(figure.Groups[1].Captures[0].Value.Trim());
                                                            BCreditFortnight = GetValuesinBillions(figure.Groups[1].Captures[1].Value.Trim());
                                                        }
                                                        else
                                                        {
                                                            BCreditFigure = figure.Groups[1].Captures[0].Value.Trim();
                                                            BCreditFortnight = figure.Groups[1].Captures[1].Value.Trim();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                        #region Food

                                        Match MatchFood = null;
                                        MatchFood = Regex.Match(strBankCredit, @"food\s*credit([^\n]*).*?non\W*food\s*credit([^\n]*)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        if (MatchFood.Success)
                                        {
                                            Match figureFood = Regex.Match(MatchFood.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                            Match figureNonFood = Regex.Match(MatchFood.Groups[2].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                            if ((string.IsNullOrWhiteSpace(foodFigure)) || (string.IsNullOrWhiteSpace(foodFortnight)))
                                            {
                                                if (figureFood.Success)
                                                {
                                                    if (figureFood.Groups[1].Captures.Count == 6)
                                                    {
                                                        if (cbIsUnitCrore)
                                                        {

                                                            foodFigure = GetValuesinBillions(figureFood.Groups[1].Captures[0].Value.Trim());
                                                            foodFortnight = GetValuesinBillions(figureFood.Groups[1].Captures[1].Value.Trim());
                                                        }
                                                        else
                                                        {
                                                            foodFigure = figureFood.Groups[1].Captures[0].Value.Trim();
                                                            foodFortnight = figureFood.Groups[1].Captures[1].Value.Trim();
                                                        }
                                                    }
                                                }
                                            }
                                            if ((string.IsNullOrWhiteSpace(nonFoodFigure)) || (string.IsNullOrWhiteSpace(nonfoodFortnight)))
                                            {
                                                if (figureNonFood.Success)
                                                {
                                                    if (figureNonFood.Groups[1].Captures.Count == 6)
                                                    {
                                                        if (cbIsUnitCrore)
                                                        {

                                                            nonFoodFigure = GetValuesinBillions(figureNonFood.Groups[1].Captures[0].Value.Trim());
                                                            nonfoodFortnight = GetValuesinBillions(figureNonFood.Groups[1].Captures[1].Value.Trim());
                                                        }
                                                        else
                                                        {
                                                            nonFoodFigure = figureNonFood.Groups[1].Captures[0].Value.Trim();
                                                            nonfoodFortnight = figureNonFood.Groups[1].Captures[1].Value.Trim();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            MatchFood = Regex.Match(strBankCredit, @"non\W*food\s*credit([^\n]*).*?food\s*credit([^\n]*)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                            if (MatchFood.Success)
                                            {
                                                Match figureFood = Regex.Match(MatchFood.Groups[2].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                                Match figureNonFood = Regex.Match(MatchFood.Groups[1].Value, @"((\s+-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                                                if ((string.IsNullOrWhiteSpace(foodFigure)) || (string.IsNullOrWhiteSpace(foodFortnight)))
                                                {
                                                    if (figureFood.Success)
                                                    {
                                                        if (figureFood.Groups[1].Captures.Count == 6)
                                                        {
                                                            if (cbIsUnitCrore)
                                                            {
                                                                foodFigure = GetValuesinBillions(figureFood.Groups[1].Captures[0].Value.Trim());
                                                                foodFortnight = GetValuesinBillions(figureFood.Groups[1].Captures[1].Value.Trim());
                                                            }
                                                            else
                                                            {
                                                                foodFigure = figureFood.Groups[1].Captures[0].Value.Trim();
                                                                foodFortnight = figureFood.Groups[1].Captures[1].Value.Trim();
                                                            }
                                                        }
                                                    }
                                                }
                                                if ((string.IsNullOrWhiteSpace(nonFoodFigure)) || (string.IsNullOrWhiteSpace(nonfoodFortnight)))
                                                {
                                                    if (figureNonFood.Success)
                                                    {
                                                        if (figureNonFood.Groups[1].Captures.Count == 6)
                                                        {
                                                            if (cbIsUnitCrore)
                                                            {

                                                                nonFoodFigure = GetValuesinBillions(figureNonFood.Groups[1].Captures[0].Value.Trim());
                                                                nonfoodFortnight = GetValuesinBillions(figureNonFood.Groups[1].Captures[1].Value.Trim());
                                                            }
                                                            else
                                                            {
                                                                nonFoodFigure = figureNonFood.Groups[1].Captures[0].Value.Trim();
                                                                nonfoodFortnight = figureNonFood.Groups[1].Captures[1].Value.Trim();
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    if ((!string.IsNullOrWhiteSpace(strDepositValue)) && (!string.IsNullOrWhiteSpace(strLoanValue)) &&
                                        (!string.IsNullOrWhiteSpace(DFigure)) && (!string.IsNullOrWhiteSpace(DFortnight)) &&
                                        (!string.IsNullOrWhiteSpace(BCreditFigure)) && (!string.IsNullOrWhiteSpace(BCreditFortnight)) &&
                                        (!string.IsNullOrWhiteSpace(foodFigure)) && (!string.IsNullOrWhiteSpace(foodFortnight)) &&
                                        (!string.IsNullOrWhiteSpace(nonFoodFigure)) && (!string.IsNullOrWhiteSpace(nonfoodFortnight)))
                                    {

                                        Story_Commercialbank(oUrlPollStatus, objStory, str_arrShortEngMonth, iMonth, dtFound, strDepositValue, strLoanValue, strCurrency, ref DFigure, ref DFortnight, ref foodFigure, ref foodFortnight, ref nonFoodFigure, ref nonfoodFortnight, ref BCreditFigure, ref BCreditFortnight);

                                    }
                                    #endregion

                                }

                            }
                            else
                                oUrlPollStatus.PollAttempt.LogComment("Last column year from schedule bank does not match in PDF source");
                        }
                        else
                        {
                            ValidationFailureMail(oUrlPollStatus, matchCommercialHeader.Value, "Fortnight date does not match in PDF source");
                            if (oUrlPollStatus.IsRequestCompleted)
                            {
                                objAlertbankDeposit.IsSent = true;
                                objAlertbankloan.IsSent = true;
                                objStory.IsSent = true;
                                objEconLoan.IsSent = true;
                                objEconDeposit.IsSent = true;
                            }
                            // oUrlPollStatus.PollAttempt.LogComment("Fortnight date does not match in PDF source");
                        }

                    }
                    else
                        oUrlPollStatus.PollAttempt.LogComment("Date found tryparse error in PDF source");
                }
                else
                    ValidationFailureMail(oUrlPollStatus, strConverted_Text, "Scheduled commercial bank header does not found from PDF source");
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in PDFSource(schedule bank) : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        private void PDF_ForexTableExtraction(UrlPollStatus oUrlPollStatus, string strConverted_Text, AlertPublicationMessage objAlertForex, StoryPublicationMessage objStoryForex, EconPublicationMessage objEconForex)
        {
            try
            {
                //  string strForeignExchangeRes_Header = @"(?:(?:Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?)\s*(?:variation\s*over)?\s*(?:items?)?\s*As\s*on\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W+[^\n]*\s*(?:items?)?[^\n]*\s*(?:items?)?(?:[^\n]*){0,}\s*(?:items?)?(\s*`?\s*(?:billion|bln|bn)\W+us\s*\$\s*(?:million|mln|mn).*?)$";
                string strForeignExchangeRes_Header = @"(?:(?:Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?).{0,200}(?:variation\s*over)?.{0,200}(?:items?)?\s*As\s*on\s*(?:variation\s*over)?\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\W*(?:variation\s*over)?\s*(\d{1,2})\W+[^\n]*\s*(?:items?)?[^\n]*\s*(?:items?)?(?:[^\n]*){0,}\s*(?:items?)?(\s*`?\s*(?:billion|bln|bn|crore|crores|cr)\W+us\s*\$\s*(?:million|mln|mn).*?Reserve\s*Position\s*(?:in)?\s*(?:the)?\s*(?:imf)?((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*[\n]+)";
                Match matchForexHeader = Regex.Match(strConverted_Text, strForeignExchangeRes_Header, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchForexHeader.Success)
                {
                    string Code = "India Standard Time";
                    string strPickedmonth = Regex.Replace(matchForexHeader.Groups[1].Value.Trim(), @"^sept$", "sep", RegexOptions.IgnoreCase);
                    DateTime dtNowTemp = GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store);
                    if ((Regex.IsMatch(strPickedmonth.Trim(), @"^dec", RegexOptions.IgnoreCase)) && (dtNowTemp.Month == 1))
                        dtNowTemp = dtNowTemp.AddYears(-1);

                    oUrlPollStatus.ChunkAttempt.LogComment("Forex table content : " + matchForexHeader.Value);
                    string strForexContent = matchForexHeader.Value;
                    DateTime dtDateFilling = Convert.ToDateTime(matchForexHeader.Groups[2].Value.Trim() + " " + strPickedmonth + " " + dtNowTemp.Year);
                    // DateTime dtDateFilling = Convert.ToDateTime(matchForexHeader.Groups[2].Value.Trim() + " " + matchForexHeader.Groups[1].Value.Trim());
                    oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling : " + dtDateFilling.ToString());

                    bool flagBillion = false;
                    bool IsTotalReserve = false;
                    bool IsForeignCurrencyAsset = false;
                    bool IsGold = false;
                    bool IsSDR = false;
                    bool IsIMF = false;
                    Match matchTotalReserve = null;
                    Match matchForeignCurrencyAsset = null;
                    Match matchGold = null;
                    Match matchSDR = null;
                    Match matchIMF = null;
                    int iBillionCount = 0;

                    //string strEndingString = @"^\s*(?:\d+\W*)?(Liquidity\s*Operation|(Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?)|Scheduled\s*Commercial\s*Bank|Money\s*Stock)";
                    //Match matchEndString = Regex.Match(strline, strEndingString, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    //if (matchEndString.Success)
                    //    break;
                    string strRegexBillion = @"(\s*`?\s*(?:billion|bln|bn|crore|crores|cr)\W+us\s*\$\s*(?:million|mln|mn)\W*){1,}\s*$";
                    Match matchBillion = Regex.Match(strForexContent, strRegexBillion, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    if (matchBillion.Success)
                    {
                        iBillionCount = (matchBillion.Groups[1].Captures.Count) * 2;
                        flagBillion = true;
                    }
                    if (flagBillion == true)
                    {
                        if (IsTotalReserve == false)
                        {
                            matchTotalReserve = Regex.Match(strForexContent, @"Total\s*Reserves?((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            if (matchTotalReserve.Success)
                            {
                                IsTotalReserve = true;

                            }
                        }
                        if (IsForeignCurrencyAsset == false)
                        {
                            //matchForeignCurrencyAsset = Regex.Match(strForexContent, @"Foreign\s*Currency\s*Assets?((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            matchForeignCurrencyAsset = Regex.Match(strForexContent, @"Foreign\s*Currency\s*Assets?\W*((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            if (matchForeignCurrencyAsset.Success)
                                IsForeignCurrencyAsset = true;
                        }
                        if (IsGold == false)
                        {
                            matchGold = Regex.Match(strForexContent, @"gold((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            if (matchGold.Success)
                                IsGold = true;
                        }
                        if (IsSDR == false)
                        {
                            matchSDR = Regex.Match(strForexContent, @"SDRs?((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            if (matchSDR.Success)
                                IsSDR = true;
                        }
                        if (IsIMF == false)
                        {
                            matchIMF = Regex.Match(strForexContent, @"Reserves?\s*Positions?\s*(?:in)?\s*(?:the)?\s*(?:IMF)?((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            if (!matchIMF.Success)
                            {
                                matchIMF = Regex.Match(strForexContent, @"IMF((\s+\-?\d{1,}(?:[,](\d{1,3}))*(\.\d{1,})*)|\s+\-){1,}\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                            }
                            if (matchIMF.Success)
                                IsIMF = true;
                        }
                        if ((IsTotalReserve == true) && (IsForeignCurrencyAsset == true) && (IsGold == true) && (IsSDR == true) && (IsIMF == true))
                        {

                            List<string> strArrTotalReserve = new List<string>();
                            List<string> strArrForeignCurrencyAsset = new List<string>();
                            List<string> strArrGold = new List<string>();
                            List<string> strArrSDR = new List<string>();
                            List<string> strArrIMF = new List<string>();

                            for (int i = 0; i < matchTotalReserve.Groups[1].Captures.Count; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(matchTotalReserve.Groups[1].Captures[i].Value))
                                    strArrTotalReserve.Add(matchTotalReserve.Groups[1].Captures[i].Value.Trim());
                            }
                            for (int i = 0; i < matchForeignCurrencyAsset.Groups[1].Captures.Count; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(matchForeignCurrencyAsset.Groups[1].Captures[i].Value))
                                    strArrForeignCurrencyAsset.Add(matchForeignCurrencyAsset.Groups[1].Captures[i].Value.Trim());
                            }
                            for (int i = 0; i < matchGold.Groups[1].Captures.Count; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(matchGold.Groups[1].Captures[i].Value))
                                    strArrGold.Add(matchGold.Groups[1].Captures[i].Value.Trim());
                            }
                            for (int i = 0; i < matchSDR.Groups[1].Captures.Count; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(matchSDR.Groups[1].Captures[i].Value))
                                    strArrSDR.Add(matchSDR.Groups[1].Captures[i].Value.Trim());
                            }
                            for (int i = 0; i < matchIMF.Groups[1].Captures.Count; i++)
                            {
                                if (!string.IsNullOrWhiteSpace(matchIMF.Groups[1].Captures[i].Value))
                                    strArrIMF.Add(matchIMF.Groups[1].Captures[i].Value.Trim());
                            }

                            if ((iBillionCount == strArrTotalReserve.Count) &&
                               (strArrTotalReserve.Count == strArrForeignCurrencyAsset.Count)
                               && (strArrForeignCurrencyAsset.Count == strArrGold.Count) &&
                               (strArrGold.Count == strArrSDR.Count)
                               && (strArrSDR.Count == strArrIMF.Count))
                            {
                                string strTotalReserve = strArrTotalReserve[1];
                                string strForex = strArrForeignCurrencyAsset[1];
                                string strGold = strArrGold[1];
                                string strSDR = strArrSDR[1];
                                string strIMF = strArrIMF[1];
                                if (string.IsNullOrWhiteSpace(strTotalReserve)) strTotalReserve = "-";
                                if (string.IsNullOrWhiteSpace(strForex)) strForex = "-";
                                if (string.IsNullOrWhiteSpace(strGold)) strGold = "-";
                                if (string.IsNullOrWhiteSpace(strSDR)) strSDR = "-";
                                if (string.IsNullOrWhiteSpace(strIMF)) strIMF = "-";
                                if ((!string.IsNullOrWhiteSpace(strTotalReserve)) && (!string.IsNullOrWhiteSpace(strForex)) && (!string.IsNullOrWhiteSpace(strGold)) && (!string.IsNullOrWhiteSpace(strSDR)) && (!string.IsNullOrWhiteSpace(strIMF)))
                                {
                                    if ((strTotalReserve.Trim() != "-") && (strForex.Trim() != "-") && (strGold.Trim() != "-") && (strSDR.Trim() != "-") && (strIMF.Trim() != "-"))
                                    {
                                        oUrlPollStatus.ChunkAttempt.LogComment("dtDateFilling before story : " + dtDateFilling.ToString());
                                        Filling_ForexReserve(oUrlPollStatus, objEconForex, objAlertForex, objStoryForex, dtDateFilling, strTotalReserve, strForex, strGold, strSDR, strIMF);
                                    }
                                }
                                else
                                {
                                    oUrlPollStatus.PollAttempt.LogComment("Any of the required value is empty in PDF source for Forex table");
                                }
                            }

                        }
                    }
                }//forex header not match
                else
                {
                    ValidationFailureMail(oUrlPollStatus, strConverted_Text, "Forex table header not found from PDF source");
                }
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in PDFSource(forex reserve) : " + e.Message + "   StackTrace : " + e.StackTrace);

            }
        }
        private void PDF_LiabilitiesAsset_OutstandingTable(DateTime dtDate, UrlPollStatus oUrlPollStatus, string strConverted_Text, AlertPublicationMessage objAlertLiaAsset, StoryPublicationMessage objStoryLiaAsset)
        {
            try
            {
                bool cbIsUnitCrore = false;
                string strPreviousYear = (dtDate.AddYears(-1)).ToString("yyyy", CultureInfo.InvariantCulture);
                string strYear = dtDate.ToString("yyyy", CultureInfo.InvariantCulture);
                string strRegexLiaAsset = null;
                if (dtDate.Month == 12)
                {
                    DateTime dtStartDecWeek = new DateTime(dtDate.Year, dtDate.Month, 24);
                    DateTime dtEndDecWeek = new DateTime(dtDate.AddYears(1).Year, dtDate.AddMonths(1).Month, 10);
                    if ((dtDate >= dtStartDecWeek) && (dtDate <= dtEndDecWeek))
                        strRegexLiaAsset = @"Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?\W*[\r\n]+\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*[\r\n]+\s*(?:items?)?\s*(?:" + strPreviousYear.Trim() + "|" + strYear.Trim() + @")\s*" + strYear.Trim() + @"[^\n]*\s*(?:items?)?(\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*){1,}\s*week\s*year\s*[\r\n]+(.*?)$";
                    else
                        strRegexLiaAsset = @"Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?\W*[\r\n]+\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*[\r\n]+\s*(?:items?)?\s*" + strPreviousYear.Trim() + @"\s*" + strYear.Trim() + @"[^\n]*\s*(?:items?)?(\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*){1,}\s*week\s*year\s*[\r\n]+(.*?)$";

                }
                else
                    strRegexLiaAsset = @"Liabilit(?:ies|y)\s*(?:and|&)\s*Assets?\W*[\r\n]+\s*\(?\s*`?\s*(Billion|bn|bln|crore|crores|cr)\s*\)?\s*[\r\n]+\s*(?:items?)?\s*" + strPreviousYear.Trim() + @"\s*" + strYear.Trim() + @"[^\n]*\s*(?:items?)?(\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*){1,}\s*week\s*year\s*[\r\n]+(.*?)$";
                Match matchLiabilityAsset = Regex.Match(strConverted_Text, strRegexLiaAsset, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (matchLiabilityAsset.Success)
                {
                    string csUnit = matchLiabilityAsset.Groups[1].Captures[0].Value.Trim();
                    //if (csUnit.ToLower().Contains("cr"))
                    //    cbIsUnitCrore = true;
                    string strLia_assTable = matchLiabilityAsset.Groups[5].Value;
                    StringReader reader = new StringReader(strLia_assTable);
                    string strline = "";
                    bool flag = false;
                    string strCentralState = null;
                    while ((strline = reader.ReadLine()) != null)
                    {
                        string strEndingString = @"^\s*(?:\d+\W*)?(Liquidity\s*Operation|((Foreign\W*Exchange|for\W*ex|FX)\s*Reserves?)|Scheduled\s*Commercial\s*Bank|Money\s*Stock)";
                        Match matchEndString = Regex.Match(strline, strEndingString, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        if (matchEndString.Success)
                            break;
                        if (!string.IsNullOrWhiteSpace(strCentralState))
                        {
                            //                            strCentralState = strCentralState + strline + Environment.NewLine; ; -ROBOTCHANGE-20180316
                            strCentralState = strCentralState + strline + "\r\n"; ;
                            string strRegex = @"(\d+)?\s*Loans?\s*(?:and|&)\s*Advances?.*?[\r\n]+\s*(\d+)?\W*(\d+)?\s*(central|state)\s*(governments?|govt).*?[\r\n]+\s*(\d+)?\W*(\d+)?\s*(central|state)\s*(governments?|govt).*?[\r\n]+";
                            Match matchCen_State = Regex.Match(strCentralState, strRegex, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                            if (matchCen_State.Success)
                            {
                                Match matchState = Regex.Match(matchCen_State.Value, @"States?\s*(?:governments?|govt)(.*?)$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                Match matchCentral = Regex.Match(matchCen_State.Value, @"Central\s*(?:governments?|govt)(.*?)$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                                if ((matchState.Success) && (matchCentral.Success))
                                {
                                    List<string> lstarrWeek = new List<string>();
                                    for (int i = 0; i < matchLiabilityAsset.Groups[2].Captures.Count; i++)
                                    {
                                        if (!string.IsNullOrWhiteSpace(matchLiabilityAsset.Groups[2].Captures[i].Value))
                                            lstarrWeek.Add(matchLiabilityAsset.Groups[2].Captures[i].Value.Trim());
                                    }
                                    string[] strStates = null;
                                    string[] strCentral = null;
                                    if (csUnit.ToLower().Contains("cr"))
                                    {
                                        strStates = Regex.Split(matchState.Groups[1].Value.Trim(), @" {2,}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        strCentral = Regex.Split(matchCentral.Groups[1].Value.Trim(), @" {2,}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        strCentral = GetValuesinBillions(strCentral);
                                        strStates = GetValuesinBillions(strStates);
                                    }
                                    else
                                    {
                                        strStates = Regex.Split(matchState.Groups[1].Value.Trim(), @" {2,}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                        strCentral = Regex.Split(matchCentral.Groups[1].Value.Trim(), @" {2,}", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    }
                                    if ((strStates.Count() != 0) && (strStates.Count() == 5) && (strStates.Count() == strCentral.Count()) && (matchLiabilityAsset.Groups[2].Captures.Count == 3))
                                    {
                                        MySourceStore mystore = (MySourceStore)Store;
                                        int iPosWeekint = Array.FindLastIndex(lstarrWeek.ToArray(), x => Regex.Match(x, @"(" + dtDate.ToString("MMM", CultureInfo.InvariantCulture) + "|" + dtDate.ToString("MMMM", CultureInfo.InvariantCulture) + @")\W*" + "(" + dtDate.Day + "|" + dtDate.ToString("dd", CultureInfo.InvariantCulture) + ")", RegexOptions.IgnoreCase).Success);
                                        if (iPosWeekint != -1)
                                        {
                                            string strCentralValue = strCentral[iPosWeekint].Trim();
                                            string strStateValue = strStates[iPosWeekint].Trim();
                                            string[] str_arrShortEngMonth = { "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" };
                                            if (objAlertLiaAsset.IsSent == false)

                                                AlertFilling_LiabilitiesAsset(oUrlPollStatus, dtDate, strCentralValue, str_arrShortEngMonth, objAlertLiaAsset);

                                            StoryFiliingLiaAsset(oUrlPollStatus, dtDate, objStoryLiaAsset, lstarrWeek.ToArray(), strCentral, strCentralValue, strStates, strStateValue, str_arrShortEngMonth);


                                        }//cweek index=-1
                                    }
                                    else
                                        ValidationFailureMail(oUrlPollStatus, strCentralState, "value Count doesnot match for states or central government from PDF source");
                                }
                                else
                                {
                                    if (!matchState.Success)
                                        ValidationFailureMail(oUrlPollStatus, strCentralState, "States government regex does not found from PDF source");
                                    if (!matchCentral.Success)
                                        ValidationFailureMail(oUrlPollStatus, strCentralState, "Central government regex does not found from PDF source");
                                }
                                break;
                            }
                        }
                        if (flag == false)
                        {
                            Match matchLoanAdvance = Regex.Match(strline, @"Loans?\s*(?:and|&)\s*advances?.*?$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                            if (matchLoanAdvance.Success)
                            {
                                flag = true;
                                //                                strCentralState = strline + Environment.NewLine; -ROBOTCHANGE-20180316
                                strCentralState = strline + "\r\n";
                            }
                        }
                    }//while

                }
                else
                    ValidationFailureMail(oUrlPollStatus, strConverted_Text, "Liability and asset table not found from PDF source");
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in PDFSource(lia_asset) : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        public string[] GetValuesinBillions(string[] carrList)
        {
            string[] carrValues = new string[carrList.Length];
            double cdValue = 0.0;
            for (int i = 0; i < carrList.Length; i++)
            {


                if (double.TryParse(carrList[i], out cdValue))
                {
                    carrValues[i] = (cdValue / 100).ToString();
                }
                else
                {
                    carrValues[i] = carrList[i];
                }
            }
            return carrValues;
        }
        public string GetValuesinBillions(string csValue)
        {
            double cdValue = 0.0;
            if (double.TryParse(csValue, out cdValue))
            {
                csValue = (cdValue / 100).ToString();
            }

            return csValue;
        }
        public override bool OnHistoryLoaded()
        {
            //History poll is completed, you can perform any action if required.
            //Response and Content of history poll is available via History property.

            return true;
        }
    }

    public class Global : URLSource
    {
        public DateTime GetCurrentDateAccToTimeZone(string Code, MySourceStore myStore)
        {
            if (!string.IsNullOrEmpty(myStore.sDate_FORCE_FILE_FOR_QA)) return myStore.dtCurrent_FORCE_FILE_FOR_QA;
            DateTime timeUtc = DateTime.UtcNow;
            TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById(Code);
            DateTime cstTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, cstZone);

            return cstTime;
        }
        public void ValidationFailureMail_Attachment(UrlPollStatus oUrlPollStatus, string strContent, string strMessage)
        {
            if (oUrlPollStatus.IsRequestCompleted)
            {
                string strValidationFailure_content = null;
                //                strValidationFailure_content = strValidationFailure_content + "Automation name : India Central Bank - Weekly Stats" + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "Automation name : India Central Bank - Weekly Stats" + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + "Date time : " + DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "Date time : " + DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + @"Error detail : " + strMessage + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + @"Error detail : " + strMessage + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + "URL/Data : " + oUrlPollStatus.Source.Url + Environment.NewLine + strContent; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "URL/Data : " + oUrlPollStatus.Source.Url + "\r\n" + strContent;

                List<EmailAttachment> EmailAttachment_1 = new List<EmailAttachment>();
                EmailAttachment_1.Add(new EmailAttachment("HtmlData.html", oUrlPollStatus.Content));
                EmailMessage obj_Validation_fail = (EmailMessage)Store.EmailMessages.GetEmailMessage("ValidationFailureNotification");
                if (obj_Validation_fail != null)
                    obj_Validation_fail.Send(obj_Validation_fail.Subject, strValidationFailure_content, "", EmailAttachment_1);
            }
        }
        public void ValidationFailureMail(UrlPollStatus oUrlPollStatus, string strContent, string strMessage)
        {
            if (oUrlPollStatus.IsRequestCompleted)
            {
                string strValidationFailure_content = null;
                //                strValidationFailure_content = strValidationFailure_content + "Automation name : India Central Bank - Weekly Stats" + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "Automation name : India Central Bank - Weekly Stats" + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + "Date time : " + DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "Date time : " + DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + @"Error detail : " + strMessage + Environment.NewLine; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + @"Error detail : " + strMessage + "\r\n";
                //                strValidationFailure_content = strValidationFailure_content + "URL/Data : " + oUrlPollStatus.Source.Url + Environment.NewLine + strContent; -ROBOTCHANGE-20180316
                strValidationFailure_content = strValidationFailure_content + "URL/Data : " + oUrlPollStatus.Source.Url + "\r\n" + strContent;

                EmailMessage obj_Validation_fail = (EmailMessage)Store.EmailMessages.GetEmailMessage("ValidationFailureNotification");

                if (obj_Validation_fail != null)
                    obj_Validation_fail.Send(obj_Validation_fail.Subject, strValidationFailure_content, "");
                oUrlPollStatus.PollAttempt.LogComment(strMessage);
            }
        }
        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            try
            {
            }
            catch (Exception e)
            {
                oUrlPollStatus.PollAttempt.LogComment("EXCEPTION in global : " + e.Message + "   StackTrace : " + e.StackTrace);
            }
        }
        public override bool OnHistoryLoaded()
        {
            //History poll is completed, you can perform any action if required.
            //Response and Content of history poll is available via History property.

            return true;
        }
    }

    public class PressReleasePage : Global
    {

        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            try
            {
                string sContent = "";
                MySourceStore mystore = (MySourceStore)Store;


                if (!string.IsNullOrEmpty(oUrlPollStatus.ContentString) && oUrlPollStatus.IsRequestCompleted)
                {
                    sContent = oUrlPollStatus.ContentString;
                    Match matchHeader;
                    matchHeader = Regex.Match(sContent, @"(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\W*(\d{1,2})\W*(\d{4}).{0,500}?weekly\s*statistical\s*supplement", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchHeader.Success)
                    {
                        string Code = "India Standard Time";
                        DateTime dtDate = new DateTime();
                        if (DateTime.TryParseExact(Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY").Value.Trim().Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDate) == true)
                        {
                            DateTime dtReleaseDate = new DateTime();
                            string strReleaseDate = Convert.ToDateTime(matchHeader.Groups[1].Value.Trim() + " " + matchHeader.Groups[2].Value.Trim() + " " + matchHeader.Groups[3].Value.Trim()).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture);
                            if (DateTime.TryParseExact(strReleaseDate.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtReleaseDate) == true)
                            {
                                DateTime dtNow = Convert.ToDateTime(GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store).ToShortDateString());

                                DateTime dtWeeklastDate = dtReleaseDate.AddDays(7);
                                if ((dtNow >= dtReleaseDate) && (dtNow < dtWeeklastDate))
                                {
                                    string pattern = @"(?:" + dtReleaseDate.ToString("MMM") + "|" + dtReleaseDate.ToString("MMMM") + @")\W*(?:" + dtReleaseDate.ToString("dd") + "|" + dtReleaseDate.Day.ToString("d") + @")\W*" + dtReleaseDate.ToString("yyyy") + @".{0,200}?href\s*\=\s*[""'](?<InnerLink>[^'""]*)[""'][^>]*>.{0,500}weekly\s*statistical\s*supplement\s*[^>]*.*?<a\s+[^>]*href\s*\=\s*[""'](?<PdfLink>[^'""]*)[""'][^>]*";
                                    Regex patternRegex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    Match match = patternRegex.Match(sContent);
                                    if (match.Success)
                                    {                                   
                                        string htmlLink = match.Groups["InnerLink"].Value;
                                        var matchHtmllinks = mystore.newLinks.Any(x => x.Equals(htmlLink));
                                        if (!string.IsNullOrEmpty(htmlLink) && !matchHtmllinks)
                                        {
                                            Source Htmlurl = new NEWSource();
                                            Store.LoadURLSource("NEW_SOURCE", (NEWSource)Htmlurl);
                                            ((NEWSource)Htmlurl).Url = htmlLink;
                                            string Url_Id = "NEWLINK_HTMLSOURCE" + mystore.m_iTotalAlertLinks++.ToString();
                                            Htmlurl.ID = Url_Id;
                                            Store.Sources.AddSource(Url_Id, ref Htmlurl);
                                            mystore.newLinks.Add(htmlLink);
                                            Htmlurl.Activate();
                                        }
                                        string link = match.Groups["PdfLink"].Value;
                                        var matchPdflinks = mystore.newLinks.Any(x => x.Equals(link));
                                        if (!string.IsNullOrEmpty(link) && !matchHtmllinks)
                                        {                                          
                                            Source PDFurl = new NEWSource();
                                            Store.LoadURLSource("NEW_SOURCE", (NEWSource)PDFurl);
                                            ((NEWSource)PDFurl).Url = link;
                                            int i = mystore.m_iTotalAlertLinks++;
                                            string Url_Id = "NEWLINK_PDFSOURCE" + i.ToString();
                                            PDFurl.ID = Url_Id;
                                            Store.Sources.AddSource(Url_Id, ref PDFurl);
                                            mystore.newLinks.Add(link);
                                            PDFurl.Activate();
                                        }
                                    }
                                }
                                else
                                    ValidationFailureMail(oUrlPollStatus, sContent, "Date is not between range in source");
                            }
                            else
                                oUrlPollStatus.PollAttempt.LogComment("Header date parsing error");
                        }
                        else
                            oUrlPollStatus.PollAttempt.LogComment("Setting date parsing error");
                    }
                    else
                    {
                        oUrlPollStatus.PollAttempt.LogComment("Header not matched");
                    }
                }
            }
            catch (Exception ex)
            {
                oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString());
            }
        }


        public override bool OnHistoryLoaded()
        {

            return true;
        }

    }

    public class RBIHomePage : Global
    {

        public override void OnDataReceived(UrlPollStatus oUrlPollStatus)
        {
            try
            {
                string sContent = "";
                MySourceStore myStore = (MySourceStore)Store;

                if (!string.IsNullOrEmpty(oUrlPollStatus.ContentString) && oUrlPollStatus.IsRequestCompleted)
                {
                    sContent = oUrlPollStatus.ContentString;
                    Match matchHeader;
                    matchHeader = Regex.Match(sContent, @"(jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec|january|february|march|april|may|june|july|august|september|october|november|december)\W*(\d{1,2})\W*(\d{4}).{0,200}?PRESS\s*RELEASES.{0,500}?weekly\s*statistical\s*supplement", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    if (matchHeader.Success)
                    {
                        string Code = "India Standard Time";
                        DateTime dtDate = new DateTime();
                        if (DateTime.TryParseExact(Store.Settings.GetSetting("RELEASE_PERIOD_WEEKLY_DD-MMM-YYYY").Value.Trim().Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtDate) == true)
                        {
                            DateTime dtReleaseDate = new DateTime();
                            string strReleaseDate = Convert.ToDateTime(matchHeader.Groups[1].Value.Trim() + " " + matchHeader.Groups[2].Value.Trim() + " " + matchHeader.Groups[3].Value.Trim()).ToString("dd-MMMM-yyyy", CultureInfo.InvariantCulture);
                            if (DateTime.TryParseExact(strReleaseDate.Trim(), "dd'-'MMMM'-'yyyy", null, DateTimeStyles.None, out dtReleaseDate) == true)
                            {
                                DateTime dtNow = Convert.ToDateTime(GetCurrentDateAccToTimeZone(Code, (MySourceStore)Store).ToShortDateString());

                                DateTime dtWeeklastDate = dtReleaseDate.AddDays(7);
                               
                                if ((dtNow >= dtReleaseDate) && (dtNow < dtWeeklastDate))
                                {
                                    string pattern = @"(?:" + dtReleaseDate.ToString("MMM") + "|" + dtReleaseDate.ToString("MMMM") + @")\W*(?:" + dtReleaseDate.ToString("dd") + "|" + dtReleaseDate.Day.ToString("d") + @")\W*" + dtReleaseDate.ToString("yyyy") + @".{0,200}?PRESS\s*RELEASES.{0,500}?href\s*\=\s*[""'](?<InnerLink>[^'""]*)[""'][^>]*>.{0,500}?weekly\s*statistical\s*supplement";
                                    Regex patternRegex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                                    Match match = patternRegex.Match(sContent);
                                    if (match.Success)
                                    {
                                        string htmlLink = match.Groups["InnerLink"].Value;
                                        var matchHtmllinks = myStore.newLinks.Any(x => x.Equals(htmlLink));
                                        if (!string.IsNullOrEmpty(htmlLink) && !matchHtmllinks)
                                        {
                                            Source Htmlurl = new NEWSource();
                                            Store.LoadURLSource("NEW_SOURCE", (NEWSource)Htmlurl);
                                            ((NEWSource)Htmlurl).Url = htmlLink;
                                            string Url_Id = "NEWLINK_HTMLSOURCE" + myStore.m_iTotalAlertLinks++.ToString();
                                            Htmlurl.ID = Url_Id;
                                            Store.Sources.AddSource(Url_Id, ref Htmlurl);
                                            myStore.newLinks.Add(htmlLink);
                                            Htmlurl.Activate();
                                        }
                                    }
                                }
                                else
                                    ValidationFailureMail(oUrlPollStatus, sContent, "Date is not between range in source");
                            }
                            else
                                oUrlPollStatus.PollAttempt.LogComment("Header date parsing error");
                        }
                        else
                            oUrlPollStatus.PollAttempt.LogComment("Setting date parsing error");
                    }
                    else
                    {
                        oUrlPollStatus.PollAttempt.LogComment("Header not matched");
                    }
                }

            }
            catch (Exception ex)
            {
                oUrlPollStatus.ChunkAttempt.LogComment(ex.ToString());
            }
        }


        public override bool OnHistoryLoaded()
        {

            return true;
        }

    }
}




