﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
namespace IndiaCBankWklyStats
{
    public class HtmlToText
    {
        public  string ConvertToText(ref string t_sHtml)
        {
            Regex tagComment = new Regex("<!--(.|\\s)*?-->", RegexOptions.Singleline | RegexOptions.IgnoreCase );
            Regex tagScript = new Regex("<(script|style).*?>.*?</(script|style)[\\s]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            Regex tagS = new Regex("\\s+");
            Regex tagW = new Regex("<[\\w!/](.|\n)*?>", RegexOptions.IgnoreCase );
            Regex tagS2 = new Regex("^\\s+", RegexOptions.Multiline );
            string sFormat = "";
            string sText = t_sHtml;
            sText = System.Web.HttpUtility.HtmlDecode(sText);

            sFormat = "";
            sText = tagComment.Replace(sText, sFormat);

            sFormat = "";
            sText = tagScript.Replace(sText, sFormat);

            sFormat = " ";

            sText = tagS.Replace(sText, sFormat);
             sText = Regex.Replace(sText, @"<\s*table[^>]*>","@@@@",RegexOptions.IgnoreCase | RegexOptions.Singleline);
             sText = Regex.Replace(sText, @"</\s*table>", "&&&&", RegexOptions.IgnoreCase | RegexOptions.Singleline);

            sText = Regex.Replace(sText, @"(?:</\s*t(d|h)\s*>\s*)?</\s*tr\s*>", "%%%%", RegexOptions.Singleline|RegexOptions.IgnoreCase);
            sText = Regex.Replace(sText, @"</\s*t(d|h)\s*>", "||||", RegexOptions.Singleline | RegexOptions.IgnoreCase);
          // sText = Regex.Replace(sText, @"<\s*a(\s+[^>]*href[^>]*)(>.*?)</a>", "@@@@@$1$2&&&&", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            sText = Regex.Replace(sText, @"<[\/]?[!b-zB-Z][^>]*>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
           // sText = Regex.Replace(sText, @"<[!a-zA-Z\/][^>]*>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
          //  sText = Regex.Replace(sText, @"@@@@@","<a",RegexOptions.IgnoreCase | RegexOptions.Singleline);
           // sText = Regex.Replace(sText, @"&&&&", "</a>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
         

            sFormat = "";
            sText = tagS2.Replace(sText, sFormat);

            return sText.Trim();
        }

        //public static string ConvertToText(string m_sHtml, bool t_cbTableHeaderWant)
        //{
        //    string sFormat = "";
        //    string sText = m_sHtml;
        //    sText = HttpUtility.HtmlDecode(sText);
        //    Regex tag;

        //    tag = new Regex("<!--(.|\\s)*?-->", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sFormat = "";
        //    sText = tag.Replace(sText, sFormat);

        //    tag = new Regex("<(script|style).*?>.*?</(script|style)[\\s]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase); //| RegexOptions.Multiline | RegexOptions.IgnorePatternWhitespace
        //    sFormat = "";
        //    sText = tag.Replace(sText, sFormat);

        //    tag = new Regex("\\s+");
        //    sFormat = " ";
        //    sText = tag.Replace(sText, sFormat);

        //    tag = new Regex("<table[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
//        //    sText = tag.Replace(sText, Environment.NewLine); -ROBOTCHANGE-20180316
        //    sText = tag.Replace(sText, "\r\n");

        //    tag = new Regex("</table[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
//        //    sText = tag.Replace(sText, Environment.NewLine); -ROBOTCHANGE-20180316
        //    sText = tag.Replace(sText, "\r\n");


        //    tag = new Regex("<td[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sText = tag.Replace(sText, "");

        //    tag = new Regex("</td[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sText = tag.Replace(sText, "|||||");

        //    if (t_cbTableHeaderWant == true)
        //    {
        //        tag = new Regex("<th[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //        sText = tag.Replace(sText, "");

        //        tag = new Regex("</th[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //        sText = tag.Replace(sText, "|||||");
        //    }

        //    tag = new Regex("<tr[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sText = tag.Replace(sText, "\r\n");

        //    tag = new Regex("</tr[^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sText = tag.Replace(sText, "");

        //    tag = new Regex("<[\\w!/][^>]*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    //tag = new Regex("<.*?>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        //    sFormat = "";
        //    sText = tag.Replace(sText, sFormat);

        //    tag = new Regex("<[\\w!/](.|\n)*?>", RegexOptions.IgnoreCase);
        //    sFormat = "";
        //    sText = tag.Replace(sText, sFormat);


        //    tag = new Regex("^\\s+", RegexOptions.Multiline);
        //    sFormat = "";
        //    sText = tag.Replace(sText, sFormat);

        //    return sText.Trim();
        //}
    }
}

