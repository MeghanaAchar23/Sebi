using AutomationCore;
using System;


namespace IndiaSEBIDailyHeadlines
{
    public class GenericList : URLSource
    {

        public override void OnDataReceived(UrlPollStatus urlPollStatus)
        {
            MySourceStore mystore = (MySourceStore)Store;

            if (!urlPollStatus.IsRequestCompleted)
            {
                return;
            }


            if (!string.IsNullOrEmpty(urlPollStatus.ContentString) && urlPollStatus.IsRequestCompleted)
            {

                try
                {
                    string type = GetType(urlPollStatus.Source.ID);

                    GenericPageParser parser = new GenericPageParser(urlPollStatus.ContentString);

                    PublicationData publicationData = parser.GetRequiredData(mystore.RunDate, type);

                    if (publicationData.Stories.Count > 0)
                    {

                        mystore.ProcessAndPublishData(publicationData, urlPollStatus);
                    }
                    else
                    {
                        urlPollStatus.ChunkAttempt.LogComment("Unable to get data from " + urlPollStatus.Source.Url);
                    }

                }
                catch (Exception ex)
                {
                    Store.AutomationClient.OperatorLog(Utility.BuildExceptionLogs(ex));
                }

            }
        }


        private string GetType(string id)
        {
            string _type = string.Empty;

            switch (id)
            {
                case TemplateConstants.REPORTS_LIST:
                    _type = TemplateConstants.REPORTS;
                    break;

                case TemplateConstants.CIRCULARS_LIST:
                    _type = TemplateConstants.CIRCULARS;
                    break;

                case TemplateConstants.PRESS_RELEASE_LIST:
                    _type = TemplateConstants.PRESSRELEASE;
                    break;

                case TemplateConstants.ORDERS_LIST:
                    _type = TemplateConstants.ORDERS;
                    break;

                default:
                    break;
            }

            return _type;
        }

    }
}
