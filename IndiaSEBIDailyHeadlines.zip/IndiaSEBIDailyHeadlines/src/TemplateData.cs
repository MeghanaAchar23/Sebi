﻿using System.Collections.Generic;

namespace IndiaSEBIDailyHeadlines
{
    internal class TemplateData
    {
        public static Dictionary<string, bool> AllStoriesHeadlines = new Dictionary<string, bool>()
        { };

        public static Dictionary<string, bool> AllAlertText = new Dictionary<string, bool>()
        { };
    }
}
