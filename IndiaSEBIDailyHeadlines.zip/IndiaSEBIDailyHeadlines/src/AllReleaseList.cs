using AutomationCore;
using System;


namespace IndiaSEBIDailyHeadlines
{
    public class AllReleaseList : URLSource
    {
        public override void OnDataReceived(UrlPollStatus urlPollStatus)
        {
            if (!urlPollStatus.IsRequestCompleted)
            {
                return;
            }

            MySourceStore mystore = (MySourceStore)Store;

            if (!string.IsNullOrEmpty(urlPollStatus.ContentString) && urlPollStatus.IsRequestCompleted)
            {

                try
                {
                    AllReleaseParser parser = new AllReleaseParser(urlPollStatus.ContentString);
                    PublicationData publicationData = parser.GetRequiredData(mystore.RunDate);

                    if (publicationData.Stories.Count > 0)
                    {

                        mystore.ProcessAndPublishData(publicationData, urlPollStatus);
                    }
                    else
                    {
                        urlPollStatus.ChunkAttempt.LogComment("Unable to get data from " + urlPollStatus.Source.Url);
                    }
                }
                catch (Exception ex)
                {
                    Store.AutomationClient.OperatorLog(Utility.BuildExceptionLogs(ex));
                }

            }

        }
    }


}
