﻿using HtmlAgilityPack;
using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace IndiaSEBIDailyHeadlines
{
    internal class AllReleaseParser
    {
        #region Variables

        private string content;
        private string dateRegex = @"(?:{month})\W*(?:{day})\W*(?:{year})";
        private StringBuilder builder;
        private string[] dateFormats = new string[] { "MMMM dd, yyyy", "MMM dd, yyyy", "MM dd, yyyy", "MMMM dd, yy", "MMM dd, yyyy" };
        private string linkPrefix = @"https://www.sebi.gov.in/";
        private Story story = null;
        private PublicationData dataModel;
        private HtmlNode[] rows = null;
        private DateTime rowDate = DateTime.MinValue;
        private int indexOfDate = -1;
        private int indexOfTitle = -1;
        private int indexOfType = -1;

        #endregion Variables

        public AllReleaseParser(string contentString)
        {
            this.content = contentString;
            this.dataModel = new PublicationData();
        }

        internal PublicationData GetRequiredData(DateTime runDate)
        {
            HtmlDocument htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(content);

            var table = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class, 'table-scrollable')]")?
                            .FirstOrDefault()?
                            .Descendants("table")?
                            .FirstOrDefault();

            if (table != null)
            {
                builder = new StringBuilder(dateRegex);
                builder.Replace("{day}", runDate.ToString("d|dd"));
                builder.Replace("{month}", runDate.ToString("MMMM|MMM|MM|M"));
                builder.Replace("{year}", runDate.ToString("yyyy|yy"));

                dateRegex = builder.ToString();

                indexOfTitle = Array.IndexOf(table.Descendants("th").Select(th => th.InnerText.Trim()).ToArray(), "Title");
                indexOfDate = Array.IndexOf(table.Descendants("th").Select(th => th.InnerText.Trim()).ToArray(), "Date");
                indexOfType = Array.IndexOf(table.Descendants("th").Select(th => th.InnerText.Trim()).ToArray(), "Type");

                if (indexOfDate != -1 && indexOfTitle != -1 && indexOfType != -1)
                {
                    rows = table.Descendants("tr")
                              .Where(tr => tr.Descendants("td").Count() > 0 &&
                               tr.Descendants("td").ToArray()[indexOfDate].InnerText.Trim().Length > 0 &&
                               Regex.IsMatch(tr.Descendants("td").ToArray()[indexOfDate].InnerText.Trim(),
                               dateRegex, RegexOptions.IgnoreCase | RegexOptions.Multiline)
                               &&
                               (
                               (tr.Descendants("td").ToArray()[indexOfType].InnerText.Trim() ==
                               TemplateConstants.REPORTS)
                               ||
                               (tr.Descendants("td").ToArray()[indexOfType].InnerText.Trim() ==
                               TemplateConstants.CIRCULARS)
                               ||
                               (tr.Descendants("td").ToArray()[indexOfType].InnerText.Trim() ==
                               TemplateConstants.ORDERS)
                               ||
                               (tr.Descendants("td").ToArray()[indexOfType].InnerText.Trim() ==
                               TemplateConstants.PRESSRELEASE)
                               )
                               )
                              .ToArray();

                    if (rows != null && rows.Length > 0)
                    {
                        for (int index = 0; index < rows.Length; index++)
                        {
                            var tds = rows[index].Descendants("td").ToArray();

                            if (DateTime.TryParseExact(tds[0].InnerText, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out rowDate))
                            {
                                if (rowDate > runDate)
                                {
                                    continue;
                                }
                                else
                                {
                                    if (rowDate < runDate)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        if (rowDate == runDate)
                                        {
                                            if (tds[indexOfType].InnerText.Trim().ToLower() == TemplateConstants.REPORTS.ToLower())
                                            {
                                                dataModel.Stories.Add(GetStory(rows[index], TemplateConstants.REPORTS, indexOfTitle));
                                            }
                                            else
                                            {
                                                if (tds[indexOfType].InnerText.Trim().ToLower() == TemplateConstants.CIRCULARS.ToLower())
                                                {
                                                    dataModel.Stories.Add(GetStory(rows[index], TemplateConstants.CIRCULARS, indexOfTitle));
                                                }
                                                else
                                                {
                                                    if (tds[indexOfType].InnerText.Trim().ToLower() == TemplateConstants.ORDERS.ToLower())
                                                    {
                                                        dataModel.Stories.Add(GetStory(rows[index], TemplateConstants.ORDERS, indexOfTitle));
                                                    }
                                                    else
                                                    {
                                                        if (tds[indexOfType].InnerText.Trim().ToLower() == TemplateConstants.PRESSRELEASE.ToLower())
                                                        {
                                                            dataModel.Stories.Add(GetStory(rows[index], TemplateConstants.PRESSRELEASE, indexOfTitle));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return dataModel;
        }

        private Story GetStory(HtmlNode htmlNode, string type, int indexOfTitle)
        {
            var tds = htmlNode.Descendants("td").ToArray();

            story = new Story();

            story.Headline = tds[indexOfTitle].InnerText.Trim();
            story.Type = type;
            story.Text = GetStoryText(tds[indexOfTitle]);

            return story;
        }

        private string GetStoryText(HtmlNode htmlNode)
        {
            string storyText = string.Empty;

            string link = htmlNode
                          .Descendants("a")
                          .FirstOrDefault()
                          .GetAttributeValue("href", string.Empty);

            Uri url = new Uri(new Uri(linkPrefix), link);
            link = url.AbsoluteUri;

            builder = new StringBuilder();
            builder.AppendLine(htmlNode.InnerText.Trim());
            builder.AppendLine(link);
            builder.Replace("Click here to provide your comments", string.Empty);

            storyText = builder.ToString().Trim();

            return storyText;
        }
    }
}