﻿using AutomationCore;
using System;
using System.Text;
using TimeZoneConverter;

namespace IndiaSEBIDailyHeadlines
{
    internal class Utility
    {
        internal static string BuildExceptionLogs(Exception ex)
        {
            StringBuilder exceptionBuilder = new StringBuilder();
            exceptionBuilder.AppendLine("Exception is ");
            exceptionBuilder.AppendLine(ex.Message);
            exceptionBuilder.AppendLine(".Happened at ");
            exceptionBuilder.AppendLine(ex.StackTrace);

            return exceptionBuilder.ToString();
        }

        internal static string GetSettingValue(string settingName, MySourceStore store)
        {
            string settingValue = string.Empty;

            Setting setting = store.Settings.GetSetting(settingName);

            if (setting != null)
            {
                settingValue = setting.Value;

                if (!string.IsNullOrEmpty(settingValue))
                {
                    settingValue = settingValue.Trim();
                }
            }

            return settingValue;
        }

        public static DateTime GetRunDate(string Code)
        {
            DateTime timeUtc = DateTime.UtcNow;
            TimeZoneInfo cstZone = TZConvert.GetTimeZoneInfo(Code);
            DateTime cstTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, cstZone);
            return cstTime;
        }
    }
}
