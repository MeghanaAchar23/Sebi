using AutomationCore;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace IndiaSEBIDailyHeadlines
{
    public class MySourceStore : SourceStore
    {
        #region Variables

        public DateTime RunDate;
        public string CircularKeywords = string.Empty;
        public string PressReleaseKeywords = string.Empty;
        public object objLock = new object();

        #endregion Variables

        #region Methods

        public MySourceStore(string strAutomationDllFullPath, Config config)
            : base(strAutomationDllFullPath, config)
        {

        }
        public override void OnHistoryLoaded()
        {

        }
        public override void OnPollingStopped()
        {

        }


        internal void ProcessAndPublishData(PublicationData publicationData, UrlPollStatus urlPollStatus)
        {

            if (publicationData.Stories.Count > 0)
            {
                foreach (Story story in publicationData.Stories)
                {
                    if (!TemplateData.AllStoriesHeadlines.ContainsKey(story.Headline.ToUpper()))
                    {
                        TemplateData.AllStoriesHeadlines.Add(story.Headline.ToUpper(), false);
                    }

                    if (story.Type == TemplateConstants.CIRCULARS)
                    {
                        PublishStory(urlPollStatus, story.Text, story.Headline);

                        if (!string.IsNullOrEmpty(CircularKeywords)
                            &&
                            Regex.IsMatch(story.Headline, CircularKeywords, RegexOptions.IgnoreCase | RegexOptions.Multiline)
                            )
                        {
                            if (!TemplateData.AllAlertText.ContainsKey(story.Headline.ToUpper()))
                            {
                                TemplateData.AllAlertText.Add(story.Headline.ToUpper(), false);
                            }

                            PublishAlert(urlPollStatus, story.Headline);
                        }
                        else
                        {
                            AutomationClient.OperatorLog("Circular Alert not published for " + story.Headline + " as it does not match the keywords: " + CircularKeywords.Replace(@"\W*", string.Empty));
                        }
                    }
                    else if (story.Type == TemplateConstants.PRESSRELEASE)
                    {
                        if (!string.IsNullOrEmpty(PressReleaseKeywords)
                            &&
                            Regex.IsMatch(story.Headline, PressReleaseKeywords, RegexOptions.IgnoreCase | RegexOptions.Multiline)
                            )
                        {
                            PublishStory(urlPollStatus, story.Text, story.Headline);
                        }
                        else
                        {
                            AutomationClient.OperatorLog("Press Release Alert not published for " + story.Headline + " as it does not match the keywords: " + PressReleaseKeywords.Replace(@"\W*",string.Empty));
                        }
                    }
                    else if (story.Type == TemplateConstants.REPORTS)
                    {
                        PublishStory(urlPollStatus, story.Text, story.Headline);

                    }
                    else if (story.Type == TemplateConstants.ORDERS)
                    {
                        PublishStory(urlPollStatus, story.Text, story.Headline);
                    }
                }
            }
        }

        private void PublishAlert(UrlPollStatus urlPollStatus, string alertText)
        {
            AlertPublicationMessage objAlert = (AlertPublicationMessage)PublicationMessages.GetPublicationMessage(TemplateConstants.ALERT);

            if (objAlert != null)
            {
                objAlert.IsSent = false;

                StringBuilder alertBuilder = new StringBuilder(objAlert.AlertTemplate);

                alertBuilder.Replace("{alert}", alertText);

                lock (objLock)
                {
                    if (!TemplateData.AllAlertText[alertText.ToUpper()])
                    {
                        TemplateData.AllAlertText[alertText.ToUpper()] = objAlert.Send(alertBuilder.ToString(), urlPollStatus);
                    }
                }

            }
        }

        public void PublishStory(UrlPollStatus urlPollStatus, string body, string headline)
        {
            StoryPublicationMessage Story = (StoryPublicationMessage)PublicationMessages.GetPublicationMessage(TemplateConstants.STORY);

            if (Story != null)
            {
                Story.IsSent = false;

                StringBuilder sbStoryHeadlineText = new StringBuilder(Story.HeadlineTemplate);
                sbStoryHeadlineText.Replace("{headline}", headline);
                sbStoryHeadlineText.Replace("Click here to provide your comments", string.Empty);

                StringBuilder sbStoryBodyText = new StringBuilder(Story.StoryTextTemplate);
                sbStoryBodyText.Replace("{body}", body);

                lock (objLock)
                {
                    if (!TemplateData.AllStoriesHeadlines[headline.ToUpper()])
                    {
                        TemplateData.AllStoriesHeadlines[headline.ToUpper()] = Story.Send(sbStoryHeadlineText.ToString(), sbStoryBodyText.ToString(), urlPollStatus);
                    }
                }

            }
        }

        #endregion Methods
    }
}
