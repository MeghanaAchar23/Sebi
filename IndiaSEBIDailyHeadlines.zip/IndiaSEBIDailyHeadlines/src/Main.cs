using System;
using System.Globalization;
using System.Net;
using AutomationCore;

namespace IndiaSEBIDailyHeadlines
{
    public class Main : AutomationClient
    {

        public override SourceStore LoadSourceStore(Config config)
        {
            MySourceStore mainStore = new MySourceStore(this.GetType().Assembly.Location, config);
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

                string runDate = Utility.GetSettingValue(TemplateConstants.ForceFilingDate, mainStore);

                mainStore.CircularKeywords = Utility.GetSettingValue(TemplateConstants.CIRCULAR_KEYWORDS, mainStore).Replace(" ",@"\W*");
                mainStore.PressReleaseKeywords = Utility.GetSettingValue(TemplateConstants.PRESS_RELEASE_KEYWORDS, mainStore).Replace(" ", @"\W*"); 

                if (!string.IsNullOrEmpty(runDate))
                {
                    mainStore.RunDate = DateTime.ParseExact(runDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    mainStore.RunDate = Utility.GetRunDate(TemplateConstants.TimeZone);
                }

                string forceFilingSwitch = Utility.GetSettingValue(TemplateConstants.forceFilingSwitch, mainStore).ToLower();

                string url = string.Empty;

                #region Forcefiling
                if (!string.IsNullOrEmpty(forceFilingSwitch) && forceFilingSwitch == "on")
                {
                   
                    //url = Utility.GetSettingValue(TemplateConstants.ForceFillingReleaseList, mainStore);

                    //if (!string.IsNullOrEmpty(url))
                    //{
                    //    Source allReleaseList = new AllReleaseList();
                    //    mainStore.LoadURLSource(TemplateConstants.ALL_RELEASE_LIST, (AllReleaseList)allReleaseList);
                    //    ((AllReleaseList)allReleaseList).Url = url;
                    //    mainStore.Sources.AddSource(TemplateConstants.ALL_RELEASE_LIST, ref allReleaseList);
                    //}

                    //url = Utility.GetSettingValue(TemplateConstants.forceFillingUrlCircularsList, mainStore);

                    //if (!string.IsNullOrEmpty(url))
                    //{
                    //    Source circularsList = new GenericList();
                    //    mainStore.LoadURLSource(TemplateConstants.CIRCULARS_LIST, (GenericList)circularsList);
                    //    ((GenericList)circularsList).Url = url;
                    //    mainStore.Sources.AddSource(TemplateConstants.CIRCULARS_LIST, ref circularsList);
                    //}

                    //url = Utility.GetSettingValue(TemplateConstants.forceFillingUrlReportsList, mainStore);

                    //if (!string.IsNullOrEmpty(url))
                    //{
                    //    Source reportsList = new GenericList();
                    //    mainStore.LoadURLSource(TemplateConstants.REPORTS_LIST, (GenericList)reportsList);
                    //    ((GenericList)reportsList).Url = url;
                    //    mainStore.Sources.AddSource(TemplateConstants.REPORTS_LIST, ref reportsList);
                    //}

                    url = Utility.GetSettingValue(TemplateConstants.forceFillingUrlOrdersList, mainStore);

                    if (!string.IsNullOrEmpty(url))
                    {
                        Source ordersList = new GenericList();
                        mainStore.LoadURLSource(TemplateConstants.ORDERS_LIST, (GenericList)ordersList);
                        ((GenericList)ordersList).Url = url;
                        mainStore.Sources.AddSource(TemplateConstants.ORDERS_LIST, ref ordersList);
                    }

                    //url = Utility.GetSettingValue(TemplateConstants.forceFillingUrlPressReleaseList, mainStore);

                    //if (!string.IsNullOrEmpty(url))
                    //{
                    //    Source pressReleaseList = new GenericList();
                    //    mainStore.LoadURLSource(TemplateConstants.PRESS_RELEASE_LIST, (GenericList)pressReleaseList);
                    //    ((GenericList)pressReleaseList).Url = url;
                    //    mainStore.Sources.AddSource(TemplateConstants.PRESS_RELEASE_LIST, ref pressReleaseList);
                    //}

                }
                #endregion

                else
                {
                    #region add ALL_RELEASE_LIST
                    Source allReleaseList = new AllReleaseList();
                    mainStore.LoadURLSource(TemplateConstants.ALL_RELEASE_LIST, (AllReleaseList)allReleaseList);
                    mainStore.Sources.AddSource(TemplateConstants.ALL_RELEASE_LIST, ref allReleaseList);

                    #endregion

                    #region add CIRCULARS_LIST
                    Source circularsList = new GenericList();
                    mainStore.LoadURLSource(TemplateConstants.CIRCULARS_LIST, (GenericList)circularsList);
                    mainStore.Sources.AddSource(TemplateConstants.CIRCULARS_LIST, ref circularsList);

                    #endregion

                    #region add REPORTS_LIST
                    Source reportsList = new GenericList();
                    mainStore.LoadURLSource(TemplateConstants.REPORTS_LIST, (GenericList)reportsList);
                    mainStore.Sources.AddSource(TemplateConstants.REPORTS_LIST, ref reportsList);

                    #endregion

                    #region add ORDERS_list
                    Source ordersList = new GenericList();
                    mainStore.LoadURLSource(TemplateConstants.ORDERS_LIST, (GenericList)ordersList);
                    mainStore.Sources.AddSource(TemplateConstants.ORDERS_LIST, ref ordersList);

                    #endregion

                    #region add PRESS_RELEASE_LIST
                    Source pressReleaseList = new GenericList();
                    mainStore.LoadURLSource(TemplateConstants.PRESS_RELEASE_LIST, (GenericList)pressReleaseList);
                    mainStore.Sources.AddSource(TemplateConstants.PRESS_RELEASE_LIST, ref pressReleaseList);

                    #endregion


                }

                DefaultCommandExecutionSequence = TemplateConstants.DEFAULT_COMMAND_EXECUTION_SEQUENCE;

            }
            catch (Exception ex)
            {
                mainStore.PerformanceLog.LogError(Utility.BuildExceptionLogs(ex));
            }

            return mainStore;
        }
    }
}


